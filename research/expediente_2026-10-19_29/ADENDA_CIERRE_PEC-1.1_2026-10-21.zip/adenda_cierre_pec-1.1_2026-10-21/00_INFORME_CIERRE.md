# Adenda de cierre — verificación final de PEC-1.1 y estado del repositorio (2026-10-21)

Este documento complementa el paquete `DECISIONES_METODOLOGICAS_Y_PEC-1.1_2026-10-21.zip`, sin modificarlo.
- **SHA-256 del paquete:** `01b6474064bdf4d462bbd58d376dfef454d9f70a9ba70d1ae6989736c9c648eb`.
- **Por qué existe esta adenda:**
  1. registra la verificación final desde una extracción limpia;
  2. corrige una afirmación que quedó desactualizada: el `00_INFORME_FINAL.md` del paquete dice «no hubo commits ni push».
     Era cierto al sellarlo, pero después el propietario escribió «Si te parece correcto commitea y pusheá», y se
     hicieron dos commits y un push (§1.3).
- **Desde entonces:** ningún commit, push ni despliegue nuevo.

**Evidencia** (en `evidencia/`):

| Archivo | Contenido |
|---|---|
| C1 | `verificar.sh` desde la extracción limpia |
| C2 | Pruebas por separado |
| C3 | Inventario de preservación frente al inicial |
| C4 | Repositorio |
| C5 | Hashes de las entregas |
| C6 | Auditoría de lo publicado |
| C7 | Corrida de CI |

## 1. Integridad
### 1.1 Paquete PEC-1.1
- **ZIP:** `unzip -t` sin errores, y el SHA-256 completo coincide con el registrado.
- **Manifiesto:** 111 de 111 entradas OK. Hay 111 archivos en disco: ninguno de más y ninguna entrada no regular.
- **`verificar.sh` desde una extracción limpia** (C1): **0 fallas**, 18 de 18 comprobaciones OK, rc = 0. El paquete no
  cambió durante su propia verificación.

### 1.2 Entregas anteriores
**ZIP de la cadena** (C5), con el SHA-256 recalculado ahora:

| Entrega | SHA-256 completo | Estado |
|---|---|---|
| v0.5 | `5bf9bc5d004b51188fdd407ae71eaae2ccefec7251af7001f8d89b264b4f5308` | Igual al registrado |
| r1 | `a8056ced047c89d5b6dd96c688d6927373ef474fb408ee25cb4eee3b72cc1a7d` | Igual |
| A-S1 | `37af592c865dd0379d71fad2f6b52033c019e13b20920557867c6d93548f64e6` | Igual |
| PEC-1.1 | `01b6474064bdf4d462bbd58d376dfef454d9f70a9ba70d1ae6989736c9c648eb` | Igual |

**Inventario de r1 frente al inicial A3** (C3): **iguales** los 25 ZIP registrados, todos los manifiestos, los artefactos
protegidos de T (frente a v0.5) y los archivos sin seguimiento de T.

**El inventario devolvió un «problema»** (rc = 1). Es una regla fija que esperaba exactamente dos archivos distintos de
HEAD: `ARTEFACTOS_SHA256.txt` y `PRERREGISTRO_PAPEL.md`. El commit `848e36f` los incorporó, así que hoy hay **0
distintos y 55 iguales**. Es el efecto esperado del commit, no una alteración.

**Versiones congeladas:**
- prerregistros y código de T y T-MULTI: iguales al blob de HEAD y a los registros de v0.5;
- PEC-1.0: intacto en r1, y byte a byte dentro de PEC-1.1 (salvo el README);
- el prerregistro de T-papel no se modificó: la adenda 2 es del 2026-10-17 y se commiteó tal cual (§1.3).

### 1.3 Repositorio (C4)
- **Rama:** `claude/algo-trading-simulation-platform-ngf7xo`.
- **HEAD = origin = `72ffae5d2698440c8f1afaff12e07bd8adde66fb`.** El árbol de trabajo está limpio.
- **Huella registrada al inicio:** `87b9585d…`. Se reconstruye exacta desde la evidencia A1 de r1.
- **Huella actual:** `179226c0…`.

**Cambios en el repositorio, por origen:**
| Origen | Qué |
|---|---|
| **Preexistentes, solo publicados** | `f518ac1` (congelado de T-MULTI) y `692f2b2` (cierre de T-MULTI), sin publicar desde el 17–18 de octubre. Publicarlos era D-G6, recomendado en r1 |
| **Creados en esta misión** | `848e36f`: 6 archivos de T-papel que existían sin commitear desde el 2026-10-17, **sin un byte cambiado** (sus 10 hashes coinciden con `ARTEFACTOS_SHA256.txt`; 53 pruebas pasan en una copia) |
| | `72ffae5`: 2 líneas en `research/.gitignore` para que los datos crudos de terceros (`datos_multi/nasdaq`, `datos_multi/yahoo`) no entren en git |
| **Reconciliación línea por línea** | Del listado inicial solo desaparecieron esos 6 archivos (commiteados) y los 2 directorios de datos (ahora ignorados). Las otras 16 entradas ignoradas no cambiaron |

**Lo publicado** (C6):
- 22 archivos de texto; el más grande ocupa 73 KB;
- ninguna serie de precios: no hay claves con fecha salvo un factor de split corporativo, ni listas numéricas largas, ni
  filas con forma de vela;
- 0 coincidencias de patrones de secretos;
- `validada_para_operar` no aparece en nada de lo commiteado ni publicado;
- **los datos crudos de terceros no se publicaron.**

**CI** (C7): la corrida #108 sobre `72ffae5` terminó en **success**. El workflow no despliega, y no hubo despliegue.

## 2. Reproducibilidad: lo recalculado desde una extracción limpia
| Resultado | Recalculado | Idéntico |
|---|---|---|
| A-S1 completo: 96 000 réplicas | Sí, reejecutado desde extracciones limpias de r1 y A-S1 | Byte a byte: el resultado y las 48 celdas |
| Recuento de A-S1, dependencia entre celdas, tabla de δ | Sí, por `verificar.sh` | Byte a byte |
| SEC-1.0: análisis desde los datos crudos empaquetados | Sí: veredicto, cotas, potencia y 234 trayectorias con la regla completa | `resultado_secuencial.json` byte a byte; 234 de 234 trayectorias coinciden |
| SEC-1.0: simulación completa (651 000 trayectorias) | **No se repitió.** Se verificaron 234 trayectorias con la regla completa y el reanálisis. `REEJECUTAR_SEC=1` lo hace en ≈ 1,6 h | — |
| Pruebas (C2) | PEC-1.0 en r1 (72), PEC-1.1 heredadas (72) y PEC-1.1 nuevas (43) | 72, 72 y 43 pasan; las heredadas son byte a byte las de r1 |

**Reproducible no es independiente.** Todo lo anterior lo recalculó el mismo autor, en la misma máquina, con Python
3.11.17. Con 3.13, los valores p de A-S1 difieren en ≤ 3,4·10⁻¹⁴ sin cambiar ninguna decisión. No hubo otra persona,
otra plataforma ni otra implementación.

## 3. Calibración secuencial (SEC-1.0)
- **Cota superior exacta de Clopper–Pearson**, unilateral, con confianza 1 − 0,05/18 por celda (95 % conjunto).
- **Umbral prerregistrado:** 3,0 %.
- **Resultado:** cumplen 18 de 18 celdas: **APTO.**

| Proceso | n_max = 1096 | 1461 | 1826 |
|---|---|---|---|
| C1 (t₃) | 2,548 % | 2,632 % | 2,554 % |
| C2 (GARCH) | 2,615 % | 2,583 % | **2,699 %** (máximo) |
| C3 (AR(1)) | 2,580 % | 2,673 % | 2,644 % |
| C4 (disperso) | 0,867 % | 1,047 % | 1,122 % |
| C5 (intradía) | 2,473 % | 2,455 % | 2,644 % |
| C6 (régimen) | 2,606 % | 2,618 % | 2,641 % |

**Estimación puntual:** entre 2,23 % y 2,46 % en C1–C3, C5 y C6, y entre 0,73 % y 0,97 % en C4.

**Condiciones bajo las que vale:**
- regla máx(ℓ20, ℓ40, NW), con B = 9999 y una sola semilla;
- 5 miradas equiespaciadas sobre prefijos anidados;
- fronteras OBF con α = 0,025;
- n_max entre 1096 y 1826;
- procesos C1–C6 con media 0;
- sin faltantes;
- futilidad omitida, por lo que es una cota superior;
- R = 36 000 por celda, con semillas 20261105·10⁶ + r.

Especificación, código y criterio estaban fijados por hash antes de ejecutar. **El orden temporal depende de registros
locales sin ancla externa (R-5).**

## 4. Potencia
Simulada con R = 500 en los puntos de diseño. La prueba z daría 80,1 % en todos.

| Punto de diseño | C1 | C2 | C5 |
|---|---|---|---|
| n_max 1096, IR 1,64 | 75,0 % [71,0–78,6] | 79,8 % [76,1–83,1] | 77,4 % [73,5–80,8] |
| n_max 1826, IR 1,27 | 76,0 % [72,1–79,5] | 79,6 % [75,8–82,9] | 75,8 % [71,9–79,3] |

**Límites:**
- solo procesos sin autocorrelación, y un efecto constante sumado cada día;
- en C4 no se simuló, y con un tamaño real de ≈ 1 % su potencia será menor;
- el IR real de una estrategia es desconocido;
- **la potencia no es evidencia de que haya ventaja.**

## 5. PEC-1.1 frente a PEC-1.0
**Diferencias exactas** (`CAMBIOS_PEC-1.1.md` del paquete):
- **6 archivos nuevos:**
  - `PEC-1.1.md`;
  - `pec/prospectiva.py` y `pec/prerregistro_v11.py`;
  - `esquemas/prerregistro_v1_1.schema.json`;
  - el ejemplo sintético v1.1;
  - `pruebas/test_pec_1_1.py`.
- **1 modificado:** `README.md` (solo documentación).
- **26 sin cambios,** con los mismos SHA-256 de r1, incluido el código calibrado (`inferencia`, `sintetico`,
  `secuencial`).

**43 pruebas nuevas.**

**Garantías añadidas, que el código hace cumplir:**
- regla decisiva única, con B = 9999;
- δ anual convertido a escala diaria (corrige el defecto de unidades de PEC-1.0);
- n_max calculado por fórmula y dentro del rango calibrado: si no, el prerregistro no se congela;
- calendario exacto de miradas;
- el prerregistro debe citar los hashes de A-S1 y SEC-1.0;
- política explícita para miradas omitidas, inválidas o inconclusas;
- criterios de parada en orden fijo;
- los umbrales coinciden byte a byte con los almacenados por SEC-1.0.

**No hay cambios retroactivos:** un prerregistro 1.0 se sigue validando con las reglas de 1.0.

## 6. Validez económica
**Demostrado:**
- el método decisivo controla el error de tipo I, en tamaño fijo (A-S1) y en el diseño de 5 miradas (SEC-1.0), sobre 6
  procesos sintéticos;
- el código es determinista y reproducible en este entorno.

**No demostrado:**
- ninguna ventaja ni rentabilidad, histórica o prospectiva. **Ninguna calibración es evidencia de rentabilidad.** El
  programa sigue con 0 hipótesis respaldadas de 18 con resultado, y T sigue INCONCLUSO;
- que el exceso real de cripto se comporte como C1–C6;
- costos, capacidad y supervivencia reales;
- la independencia de la auditoría.

## 7. Decisiones pendientes: todas requieren al propietario
| Decisión | Recomendación y fundamento | Consecuencia exacta de adoptarla |
|---|---|---|
| **δ** (A8 / D-S4) | Un δ único para el programa, con δ = (F/K + π)/(1 − d) y tus K y F reales. Sin esos datos, **10 %/año**, coherente con los 10 000 USDT del proyecto, π = 2,5 % y d = 50 % | Habilita «efecto relevante descartado» (IC90 superior < 0,10/365,25 por día). La fase prospectiva solo entra en el rango calibrado si TE está entre 6,1 % y 7,9 %. Con TE ≥ 10 %, n_max ≥ 2938 días y el prerregistro **no se congela**. **No habilita nada por sí solo** |
| **D-G1** | **No iniciar** H-REV-SHOCK v0.2 ni H-EMA9-VWAP v0.2 como confirmatorias. Su IR plausible (0,3–0,5) está lejos del 1,27–1,64 del rango calibrado, y en C4 la regla tiene un tamaño de ≈ 1 % | No queda ninguna hipótesis confirmatoria activa. T-papel sigue con su propio protocolo. Solo entra una nueva si pasa la criba |
| **B-4** | **No autorizar** ninguna fuente nueva hasta que haya una hipótesis aprobada. Después, solo lo que declare su prerregistro congelado | No se lee ningún dato nuevo. No hay costo, porque no hay nada que evaluar |
| **D-G4** (y D-T1) | Para T-papel, la adenda 2 (ya commiteada) fija el archivo: `papel/cortes/REGISTRO.jsonl`, que solo admite añadidos. Falta decidir la rama: recomiendo **una rama `registros` protegida en este repositorio de GitHub**. **Plazo: el 2027-04-18** | Cada corte pasa a ser un commit y un push a esa rama, con tu autorización en ese momento. Sin esta decisión, el corte del 2027-04-18 no tiene dónde quedar fijado |
| **R-5** | **O2** (esa rama protegida, sin push forzado) más **O5** (OpenTimestamps de los hashes de los prerregistros y de cada registro) | Las fechas de «fijado antes» se vuelven verificables desde fuera. **El push de hoy no es R-5:** prueba que T-MULTI y la adenda existían el 2026-10-21 a las 19:31 UTC (hora del push), pero las fechas del 17 y 18 en los commits son declaradas, y la rama no está protegida |

**Otra pendiente fuera de esta lista:** la firma de T (R-3), con tu clave fuera de este equipo.

## Cierre
**Trabajo técnico cerrado:**
- la verificación y reproducción de A-S1;
- la calibración del diseño secuencial (APTO);
- PEC-1.1, implementado y probado;
- la verificación desde una extracción limpia;
- la preservación de las entregas;
- la reconciliación del repositorio.

**No cerrado, porque depende de vos:** δ, D-G1, B-4, D-G4 y R-5. **La fase prospectiva sigue bloqueada.**

**Siguiente paso recomendado:** decidir **D-G4 y R-5 antes del 2027-04-18**. T-papel es el único experimento prospectivo
vivo, y es lo único con plazo. δ puede fijarse en paralelo, y D-G1 = «no iniciar» no requiere trabajo.
