# Entrega P1, P2 y P4 (Trader-IA, 2026-10-20)

**Persistencia:** todo está en el **scratchpad efímero** de la sesión. No dispongo de un directorio persistente autorizado: **los archivos no quedan preservados** si el contenedor se libera (D-G0).

**Restricciones cumplidas:**
- **Repositorio:**
  - no se modificó;
  - no hubo commits, push ni despliegues;
  - SHA-256 de `git status --porcelain --ignored`: `87b9585d…` antes y después.
- **Ejecuciones y datos:**
  - no se ejecutaron backtests ni descargas;
  - no se evaluaron datos de mercado;
  - no se repitió la evaluación fuera de muestra de T;
  - no se invocó `fuera_de_muestra_T.py` ni se tocó su cerrojo.
- **Expedientes previos:** intactos según sus SHA256SUMS (`evidencia/98_…`).
- **Expediente v0.2:** bootstrap-t y los demás cambios estadísticos siguen siendo **propuestas no validadas**; la calibración no se ejecutó.

## 1. Archivos creados

| Archivo | Contenido |
|---|---|
| `INFORME_ENTREGA_P1_P2_P4.md` | Este informe |
| `SHA256SUMS` | Hash de todos los demás archivos |
| `p1/verificar_reproduccion_T.py` | **Corrección**: verificador aislado de resultados de T (322 líneas) |
| `p1/test_verificar_reproduccion_T.py` | Pruebas sintéticas de P1 (418 líneas) |
| `p1/P1_verificador.patch` | **Diff aplicable**: dos archivos nuevos en `research/tendencia_btc/verificacion/`. **No aplicado al repositorio** |
| `p1/README_P1.md` | Hallazgo, corrección, resultados y límites |
| `p2/politica_avance_T.py` | **Política de avance v0.1** (81 líneas) |
| `p2/test_politica_avance_T.py` | Pruebas: las 63 combinaciones y entradas inválidas |
| `p2/POLITICA_AVANCE_T_v0.1.md` | Política versionada, con las ambigüedades A1–A5 |
| `p4/uso_unico.py` | **Prototipo** de ejecución de uso único (332 líneas) |
| `p4/_conductor.py` | Conductor de caídas reales en un proceso hijo |
| `p4/test_uso_unico.py` | Pruebas de fallos, concurrencia, integridad y recuperación |
| `p4/ESTADO_Y_INVARIANTES.md` | Máquina de estados, invariantes I1–I10, pseudocódigo, tabla de fallos y límites |

**Evidencias** (en `evidencia/`):
- **Estado del repositorio y de los expedientes:**
  - `00_estado_inicial_git.txt` y `99_estado_final_git.txt`;
  - `98_integridad_expedientes_previos.txt`.
- **P1:**
  - `p1_pytest.txt`;
  - `p1_artefacto_real.txt`, con `p1_esperados_reales.json` y `p1_esperado_equivocado.json`;
  - `p1_aplicacion_parche.txt`.
- **P2 y P4:** `p2_pytest.txt`, `p4_pytest.txt` y `p4_repeticiones.txt`.
- **Mutantes:** `mutantes_p1/`, `mutantes_p2/` y `mutantes_p4/`. Cada carpeta tiene `mutar.py`, `resultado_mutantes.txt` y las copias mutadas en `out/` (16, 35 y 42 archivos).

## 2. El diff y el prototipo
- **P1:** `p1/P1_verificador.patch`, en formato `git diff`. Solo agrega archivos y no modifica ningún archivo existente ni congelado.
  - `git apply --check` y `git apply` funcionan sobre una **copia exportada** de HEAD 692f2b2, obtenida con `git archive`.
  - Los archivos aplicados son idénticos a los entregados.
- **P4:** `p4/uso_unico.py`. **No está integrado** en `papel/corte.py` ni en ningún ejecutor protegido.

## 3. Comandos ejecutados y resultados
Todos se ejecutaron con `PYTHONDONTWRITEBYTECODE=1`, `-B` y `-p no:cacheprovider`, usando el intérprete `research/hcarry_next/.venv/bin/python` (Python 3.11.17, pytest 9.1.1).

| Comando | Resultado |
|---|---|
| `cd p1 && PYTHONPATH=<T>/src:<hcarry_next>/src python -B -m pytest -v test_verificar_reproduccion_T.py` | **122 pasan, 0 fallan** |
| `python -B evidencia/mutantes_p1/mutar.py` | **8 de 8 mutantes detectados** |
| `python3 -I -B p1/verificar_reproduccion_T.py <T>/experimentos/fuera_de_muestra_T.json --esperados … --archivo …` | **VERIFICADO**, código de salida 0. La decisión registrada y la recalculada coinciden: EVIDENCIA INSUFICIENTE. El JSON tiene el mismo SHA-256 antes y después |
| El mismo comando, pidiendo el hash canónico de reglas | **RECHAZADO** con `HASH_SEMANTICA`, código de salida 1 |
| `git apply --check` y `git apply` en la copia exportada, y pytest allí | Se aplica sin conflictos. **121 pasan y 1 se omite**: `corte.py` no tiene commit |
| `cd p2 && python -B -m pytest -v test_politica_avance_T.py` | **106 pasan, 0 fallan** |
| `python -B evidencia/mutantes_p2/mutar.py` | **7 de 7 mutantes detectados**, entre ellos «la robustez veta», «la robustez crea avance» y «autorización automática» |
| `cd p4 && python -B -m pytest -v test_uso_unico.py`, más 3 repeticiones | **36 pasan, 0 fallan**, en las 4 corridas |
| `python -B evidencia/mutantes_p4/mutar.py` | **14 de 14 mutantes detectados**: sin cerrojo, sin cadena, archivo antes del presellado, aceptar un recálculo distinto, ignorar entradas cambiadas, terminal reversible, etc. |
| `git status --porcelain --ignored \| sha256sum`, antes y después | `87b9585d…` en ambos casos |

## 4. Hashes
Están en `SHA256SUMS`, que cubre todos los archivos de esta carpeta salvo él mismo. Para verificarlos: `sha256sum -c SHA256SUMS`.

## 5. Demostrado, propuesto y pendiente

| Ítem | Demostrado (ejecutado aquí) | Propuesto (no aplicado o no aprobado) | Pendiente |
|---|---|---|---|
| **P1: incompatibilidad** | Los esquemas divergen (`decision` frente a `decision_prerregistrada`, la ubicación de P y `prerregistro_sha256` con dos significados) y hay un 0,5 por defecto en el código congelado. Se reproduce con pruebas de regresión | — | Si el encargo se refería a **otro** verificador concreto, ese archivo no está en el entorno |
| **P1: corrección** | Verificador estricto con 122 pruebas y 8 de 8 mutantes. Verifica el JSON real y la salida del productor real de cortes con una fuente simulada | **Aplicar el parche al repositorio** | Tu autorización. Recalcular `huella_codigo` y los hashes de los manifiestos contra los archivos (hoy solo se comparan por valor) |
| **P2: política** | Implementación v0.1: etiqueta literal, robustez y avance separados. 63 combinaciones, 106 pruebas y 7 de 7 mutantes. Aplicada al resultado histórico: EVIDENCIA INSUFICIENTE / INDETERMINADA / NO AVANZA | La política v0.1 en sí (**no aprobada**) | **Definir R1 y R3 para T (A1 y A2)**. Mientras tanto se evalúan como `NO_DEFINIDO` |
| **P4: uso único** | Prototipo aislado. 36 pruebas con caídas reales en 10 puntos, SIGKILL, 8 procesos concurrentes, alteración del resultado, edición del diario, temporales plantados, entradas o semilla cambiadas y registro global. 14 de 14 mutantes | Integrarlo en un ejecutor protegido | Un ancla externa (L3) y aislar el cálculo (L2); tu autorización para integrarlo |
| **Expediente v0.2** | Documentos intactos según sus hashes | Bootstrap-t, Bonferroni, O'Brien–Fleming y demás cambios estadísticos | Calibración sintética (A-S1), **no ejecutada** en esta fase |
| **Persistencia** | — | — | **Preservar esta carpeta fuera del scratchpad (D-G0)** |

## 6. Decisiones que requieren tu autorización
1. **D-G0: preservar esta carpeta.** Descargarla o indicar un almacenamiento persistente. Sin eso, se pierde.
2. **D-P1: aplicar `P1_verificador.patch`** al repositorio y hacer commit. Hoy está prohibido.
3. **D-P1b: ¿había otro verificador concreto en el encargo original de P1?** Si es así, necesito su ruta o el archivo.
4. **A1: definición de R1 para T.** Opciones (a), (b) o (c) de `POLITICA_AVANCE_T_v0.1.md` §4. Advertencia: con (a), R1 es redundante con la etiqueta RESPALDADA.
5. **A2: definición de R3 para T.** IC̄ no tiene análogo en T y las subventanas registradas son 2, no 3.
6. **A3: ¿R1 o R3 pueden vetar la candidatura?** La v0.1 implementa «no», según tu indicación de que son informativos.
7. **A4 y A5:**
   - **A4:** R1 y R3 tienen que definirse **antes** del primer corte del papel que decide. Sobre 2022–2026 serían un análisis post hoc.
   - **A5:** qué es «la etapa siguiente» de T.
8. **Aprobar la política v0.1,** o pedir la v0.2 con cambios.
9. **D-P4: integrar el prototipo de uso único** en un ejecutor protegido. Requiere modificar un archivo protegido; no se hizo.
10. **D-G6 / L3: publicar un ancla externa** (hashes de las reservas y los resultados). Implica publicar commits o un sellado de tiempo; está prohibido sin tu orden.
11. **A-S1: calibración sintética** del marco estadístico v0.2. No se ejecutó.
