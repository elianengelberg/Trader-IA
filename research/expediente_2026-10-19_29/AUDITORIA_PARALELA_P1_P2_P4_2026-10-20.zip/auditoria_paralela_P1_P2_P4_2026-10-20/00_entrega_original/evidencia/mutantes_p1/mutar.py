"""Crea copias mutadas del verificador y corre la suite contra cada una (la suite debe fallar en todas)."""
import pathlib, shutil, subprocess, sys, os
AQUI = pathlib.Path(__file__).resolve().parent
P1 = AQUI.parents[1] / "p1"
src = (P1 / "verificar_reproduccion_T.py").read_text(encoding="utf-8")
MUT = {
 "M1_sin_rango_de_probabilidad": ('    if not 0.0 <= v <= 1.0:\n', '    if False:\n'),
 "M2_sin_recalcular_decision": ('    recalculada = recalcular_decision(r)\n', '    recalculada = r.decision\n'),
 "M3_sin_semantica_de_hashes": ('        if nombre not in SEMANTICA[r.esquema]:\n', '        if False:\n'),
 "M4_p_por_defecto_0_5": ('    return _prob(obj, f"{ruta}.p_mayor_que_cero"), _ic(obj, f"{ruta}.intervalo_anual")',
                          '    return obj[ruta].get("p_mayor_que_cero", 0.5), _ic(obj, f"{ruta}.intervalo_anual")'),
 "M5_hash_en_mayusculas": ('all(c in "0123456789abcdef" for c in v)', 'all(c in "0123456789abcdefABCDEF" for c in v)'),
 "M6_bool_como_numero": ('    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):',
                         '    if not isinstance(v, (int, float)) or not math.isfinite(v):'),
 "M7_sin_coherencia_corte_evaluacion": ('        if r.hashes["reglas_corte"] != r.hashes["reglas_canonicas"] or',
                                        '        if False and r.hashes["reglas_corte"] != r.hashes["reglas_canonicas"] or'),
 "M8_bootstrap_no_aplicable_sin_control": ('        if r.meses >= 12:  # aquí', '        if False:  # aquí'),
}
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
total_ok = True
for nombre, (a, b) in MUT.items():
    assert src.count(a) == 1, nombre
    d = AQUI / "out" / nombre
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    (d / "verificar_reproduccion_T.py").write_text(src.replace(a, b), encoding="utf-8")
    shutil.copy(P1 / "test_verificar_reproduccion_T.py", d)
    r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", "--no-header",
                        "-rN", str(d / "test_verificar_reproduccion_T.py")], capture_output=True, text=True, env=env,
                       cwd=d)
    ultima = r.stdout.strip().splitlines()[-1]
    detectado = r.returncode != 0
    total_ok &= detectado
    print(f"{nombre}: {'DETECTADO' if detectado else 'NO DETECTADO'} (pytest -x: {ultima})")
print("TODOS LOS MUTANTES DETECTADOS" if total_ok else "HAY MUTANTES NO DETECTADOS")
sys.exit(0 if total_ok else 1)
