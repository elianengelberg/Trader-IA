"""Copias mutadas de la política de avance; la suite debe fallar con cada una."""
import os, pathlib, shutil, subprocess, sys
AQUI = pathlib.Path(__file__).resolve().parent
RAIZ = AQUI.parents[1]
src = (RAIZ / "p2" / "politica_avance_T.py").read_text(encoding="utf-8")
MUT = {
 "M1_robustez_veta": ('    avance = CANDIDATA if clase == "RESPALDADA" else NO_AVANZA',
                      '    avance = CANDIDATA if clase == "RESPALDADA" and rob == "ROBUSTA" else NO_AVANZA'),
 "M2_robustez_crea_avance": ('    avance = CANDIDATA if clase == "RESPALDADA" else NO_AVANZA',
                             '    avance = CANDIDATA if clase == "RESPALDADA" or rob == "ROBUSTA" else NO_AVANZA'),
 "M3_normaliza_etiqueta": ('    if not isinstance(etiqueta, str) or etiqueta not in ETIQUETAS:',
                           '    etiqueta = etiqueta.strip() if isinstance(etiqueta, str) else etiqueta\n'
                           '    if not isinstance(etiqueta, str) or etiqueta not in ETIQUETAS:'),
 "M4_no_definido_como_cumple": ('    if "NO_DEFINIDO" in (r1, r3):\n        return "INDETERMINADA"', '    if False:\n        return "INDETERMINADA"'),
 "M5_autorizacion_automatica": ('"autorizacion_automatica": False', '"autorizacion_automatica": rob == "ROBUSTA" and clase == "RESPALDADA"'),
 "M6_exceso_bloquea": ('    clase, rob = ETIQUETAS[etiqueta], robustez(r1, r3)',
                       '    clase, rob = ETIQUETAS[etiqueta], robustez(r1, r3)\n    clase = "INSUFICIENTE" if exceso_no_positivo else clase'),
 "M7_sin_verificar_resultado": ('    inf = V.verificar(obj, esperados=esperados)',
                                '    r = V.normalizar(obj)\n    inf = {"decision": r.decision, "exceso_anual": r.exceso_anual, "esquema": r.esquema, "decision_recalculada": r.decision, "dias": r.dias, "hashes": r.hashes}'),
}
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
ok = True
for nombre, (a, b) in MUT.items():
    assert src.count(a) == 1, nombre
    d = AQUI / "out" / nombre / "p2"
    if d.parent.exists():
        shutil.rmtree(d.parent)
    d.mkdir(parents=True)
    (d / "politica_avance_T.py").write_text(src.replace(a, b), encoding="utf-8")
    for f in ("test_politica_avance_T.py", "POLITICA_AVANCE_T_v0.1.md"):
        shutil.copy(RAIZ / "p2" / f, d)
    shutil.copytree(RAIZ / "p1", d.parent / "p1", ignore=shutil.ignore_patterns("*.patch", "README*"))
    r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", "--no-header",
                        str(d / "test_politica_avance_T.py")], capture_output=True, text=True, env=env, cwd=d)
    ultima = r.stdout.strip().splitlines()[-1]
    ok &= r.returncode != 0
    print(f"{nombre}: {'DETECTADO' if r.returncode else 'NO DETECTADO'} ({ultima})")
print("TODOS LOS MUTANTES DETECTADOS" if ok else "HAY MUTANTES NO DETECTADOS")
sys.exit(0 if ok else 1)
