"""Copias mutadas del prototipo de uso único (cada una elimina una garantía); la suite debe fallar con cada una."""
import os, pathlib, shutil, subprocess, sys
AQUI = pathlib.Path(__file__).resolve().parent
P4 = AQUI.parents[1] / "p4"
src = (P4 / "uso_unico.py").read_text(encoding="utf-8")
MUT = {
 "M01_sin_cerrojo": ("            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)\n", "            pass\n"),
 "M02_cerrojo_bloqueante": ("fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)", "fcntl.flock(fd, fcntl.LOCK_EX)"),
 "M03_sin_cadena": ('ev.get("anterior") != anterior or _canon(ev) != crudo', 'False'),
 "M04_archivo_antes_del_presellado": ('        fallo("tras_calculo")\n',
                                      '        (d / RESULTADO).write_bytes(crudo)\n        fallo("tras_calculo")\n'),
 "M05_acepta_archivo_distinto": ("        if _sha(en_disco) != pre:\n", "        if False:\n"),
 "M06_acepta_recalculo_distinto": ("            if _sha(crudo) != pre:\n", "            if False:\n"),
 "M07_ignora_entradas_cambiadas": ('    if eventos[0]["datos"] != reserva:\n', '    if False:\n'),
 "M08_cola_rota_sin_recortar": ("        if cola:\n            _descartar_cola(ruta, lineas, eventos, cola)\n        _validar_secuencia",
                                "        _validar_secuencia"),
 "M09_lee_temporales": ('    for t in d.glob(".*.tmp"):  # restos de una escritura interrumpida: nunca se leen\n        t.unlink()\n',
                        '    for t in d.glob(".resultado.json.*.tmp"):\n        os.replace(t, d / RESULTADO)\n'),
 "M10_recalcula_siempre": ('    if pre is None:  # RESERVADO', '    if True:  # RESERVADO'),
 "M11_global_sin_estado_local": ('            if propios:\n                return "RECHAZADO"', '            if False:\n                return "RECHAZADO"'),
 "M12_global_sin_resultado": ("            if previos and previos[0] != resultado_sha:\n", "            if False:\n"),
 "M13_terminal_reversible": ("    if estado in ERRORES_TERMINALES:\n        _anotar", "    if False:\n        _anotar"),
 "M14_resultado_sin_diario_aceptado": ('        if (d / RESULTADO).exists():\n            return Salida("INCONSISTENTE"',
                                       '        if False:\n            return Salida("INCONSISTENTE"'),
}
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
ok = True
for nombre, (a, b) in MUT.items():
    assert src.count(a) == 1, (nombre, src.count(a))
    d = AQUI / "out" / nombre
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    (d / "uso_unico.py").write_text(src.replace(a, b), encoding="utf-8")
    for f in ("test_uso_unico.py", "_conductor.py"):
        shutil.copy(P4 / f, d)
    try:
        r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", "--no-header", "-x",
                            str(d / "test_uso_unico.py")], capture_output=True, text=True, env=env, cwd=d, timeout=300)
        ultima, codigo = r.stdout.strip().splitlines()[-1], r.returncode
    except subprocess.TimeoutExpired:
        ultima, codigo = "tiempo agotado (300 s): la suite no terminó", 1
    ok &= codigo != 0
    print(f"{nombre}: {'DETECTADO' if codigo else 'NO DETECTADO'} ({ultima})")
print("TODOS LOS MUTANTES DETECTADOS" if ok else "HAY MUTANTES NO DETECTADOS")
sys.exit(0 if ok else 1)
