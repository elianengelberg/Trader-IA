# P1: verificador de reproducción de T (2026-10-20)

**Estado:** corrección aislada **implementada y probada**. Está en el scratchpad y **no se aplicó al repositorio**: aplicarla requiere tu autorización.

## 1. Incompatibilidad encontrada en el código real

Hay **dos productores** de resultados de T con **esquemas distintos para el mismo concepto**:
- `src/tendencia/papel.py:129-157`, `evaluar`, también envuelto por `papel/corte.py`;
- `experimentos/fuera_de_muestra_T.py`, que produce `fuera_de_muestra_T.json`.

| Concepto | Papel (`evaluar` / `corte.py → evaluacion`) | Fuera de muestra (`fuera_de_muestra_T.json`) |
|---|---|---|
| Decisión | `decision` | `decision_prerregistrada` |
| P del conjunto | `bootstrap_conjunto.p_mayor_que_cero` | `principal.conjunto.p` |
| P de BTC | `bootstrap_btc.p_mayor_que_cero` | `principal.BTC.p` |
| IC90 | `bootstrap_conjunto.intervalo_anual` | `principal.conjunto.ic90_anual` |
| Exceso con costos ×2 | `exceso_anual_conjunto_costes_x2` | `secundarios.costes_x2.conjunto` |
| **`prerregistro_sha256`** | **hash canónico de las reglas** (`d2e4e1fb…`) | **SHA-256 del archivo .md** (`94a16556…`) |

**Consecuencias, reproducidas por pruebas de regresión:**
1. **La clave de la decisión no coincide.** Un verificador que lee `r["decision"]` lanza `KeyError` con el esquema fuera de muestra (`test_regresion_verificador_ingenuo_falla_con_el_esquema_fuera_de_muestra`).
2. **La misma clave tiene dos significados.** Si se compara `prerregistro_sha256` a ciegas, se rechazan resultados correctos o se acepta el hash equivocado (`test_regresion_mismo_nombre_de_clave_dos_hashes_distintos`).
3. **Valor por defecto silencioso en el código congelado.** `evaluar` decide con `b.get("p_mayor_que_cero", 0.5)`. La clave falta cuando `bootstrap_media` devuelve `{"aplicable": False}`, es decir, con menos de 40 días. Con los parámetros congelados (bloque de 20 días) eso solo ocurre con menos de 12 meses, cuando la decisión es INFORMATIVO de todos modos: **hoy no cambia ninguna decisión.** Sí la cambiaría si se modificara el bloque. La prueba `test_regresion_el_codigo_congelado_decide_con_p_por_defecto` lo muestra con la función `decidir` congelada.

**Qué no encontré:** ningún verificador existente en el entorno falla hoy. Antes, en esta misma sesión, verifiqué en solo lectura:
- `corte.py`;
- `evidencia_t_multi.py verificar`;
- la reproducción `identico_al_json: true` de `revision_fuera_de_muestra_T.json`.

Si el encargo original de P1 se refería a **otro verificador concreto**, ese archivo **no está en el entorno**: su texto no aparece en el historial de la sesión ni en el repositorio. Para revisarlo necesito la ruta o el archivo.

## 2. Corrección

Archivo nuevo `verificar_reproduccion_T.py`. Solo usa la biblioteca estándar; no importa ni ejecuta `fuera_de_muestra_T.py` ni `corte.py`.

- **Detección explícita del esquema:** `fuera_de_muestra`, `papel_evaluar` o `papel_corte`. Si es desconocido o ambiguo, rechaza (`ESQUEMA`).
- **Acceso estricto sin valores por defecto.** Códigos de error estables:
  - `AUSENTE`, `TIPO` (incluidos bool, NaN e inf), `RANGO`, `VALOR`;
  - `HASH_FORMATO`, `HASH`;
  - `HASH_SEMANTICA`: hash pedido con el nombre lógico equivocado;
  - `CONTRADICCION`, `SIN_EVALUACION`, `LECTURA` (solo en la línea de comandos).
- **Hashes con nombre lógico:** `prerregistro_archivo` frente a `reglas_canonicas`, más `script`, `codigo` y `manifiesto_*`. También puede verificar el SHA-256 de archivos en disco.
- **Recálculo de la decisión** con copias literales de las reglas congeladas. Una prueba las compara con el código congelado, extraído con `ast` sin ejecutar el módulo.
- **Coherencia interna:**
  - `meses = dias / 30,44`;
  - el corte coincide con su evaluación y los hashes con los de la evaluación;
  - un estado provisional no puede traer una evaluación;
  - un bootstrap no aplicable solo se acepta con menos de 12 meses.
- **`comparar(a, b, tolerancia)`:** discrepancias entre un resultado y su reproducción. Con tolerancia 0 exige igualdad exacta.
- **El código congelado no se modifica.** El valor por defecto 0,5 queda documentado y detectado, no corregido.

**Parche:** `P1_verificador.patch` agrega dos archivos nuevos en `research/tendencia_btc/verificacion/`. No modifica ningún archivo existente.

## 3. Resultados ejecutados (salidas completas en `../evidencia/`)

| Prueba | Resultado |
|---|---|
| Suite sintética (`p1_pytest.txt`) | **122 de 122 pasan** |
| Mutación (`mutantes_p1/resultado_mutantes.txt`): 8 verificadores defectuosos, entre ellos uno con el 0,5 por defecto y otro sin recálculo de la decisión | **8 de 8 detectados** |
| Artefacto real `fuera_de_muestra_T.json`, en solo lectura (`p1_artefacto_real.txt`) | **VERIFICADO**. Coinciden los 5 hashes esperados y los 2 archivos; decisión registrada = recalculada = EVIDENCIA INSUFICIENTE; el SHA-256 del JSON es el mismo antes y después |
| Mismo artefacto con el hash canónico pedido como si perteneciera a este resultado | **RECHAZADO** con `HASH_SEMANTICA` |
| Productor real `papel/corte.py` con la fuente **simulada** de sus propias pruebas, en un directorio temporal | La salida pasa el verificador. Al alterar la decisión, la rechaza con `CONTRADICCION` |
| `git apply --check` y `git apply` sobre una **copia exportada** de HEAD 692f2b2 (`p1_aplicacion_parche.txt`) | Se aplica sin conflictos; archivos idénticos. Suite en la copia: **121 pasan y 1 se omite** (`corte.py` no tiene commit, así que no está en HEAD) |
| SHA-256 de `git status --porcelain --ignored`, antes y después | `87b9585d…`, sin cambios |

## 4. Límites
- **El hash `codigo` (`73b22f3e…`)** se compara contra el valor esperado, pero **no se recalcula**: no repliqué `huella_codigo`.
- **Los manifiestos** se comparan por valor, no contra los archivos.
- **El esquema `papel_corte`** se probó con una sola salida real del productor (corte 2027-10-19, fuente simulada).
