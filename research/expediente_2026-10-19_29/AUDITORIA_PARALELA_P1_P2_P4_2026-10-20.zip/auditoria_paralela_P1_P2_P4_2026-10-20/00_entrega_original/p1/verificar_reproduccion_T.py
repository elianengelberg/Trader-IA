"""Verificador de reproducción de T (P1). Aislado: solo biblioteca estándar, solo lectura.

Problema que resuelve (verificado en el código real, 2026-10-20). Los dos productores de resultados de T usan esquemas
distintos para el mismo concepto, y un verificador escrito para uno falla o, peor, acepta en silencio el otro:

  concepto                     | papel (tendencia.papel.evaluar)           | fuera de muestra (fuera_de_muestra_T.json)
  -----------------------------+-------------------------------------------+----------------------------------------------
  decisión                     | "decision"                                | "decision_prerregistrada"
  exceso anual del conjunto    | "exceso_anual_conjunto"                   | principal.conjunto.exceso_anual
  P del conjunto / de BTC      | bootstrap_conjunto.p_mayor_que_cero / ... | principal.conjunto.p / principal.BTC.p
  IC90 del conjunto            | bootstrap_conjunto.intervalo_anual        | principal.conjunto.ic90_anual
  exceso con costes ×2         | "exceso_anual_conjunto_costes_x2"         | secundarios.costes_x2.conjunto
  "prerregistro_sha256"        | hash CANÓNICO de las reglas (d2e4e1fb…)   | SHA-256 del ARCHIVO .md (94a16556…)

Además, ``papel.evaluar`` (código congelado, no se toca) decide con ``b.get("p_mayor_que_cero", 0.5)``: si la clave
falta, usa 0,5 sin avisar. La clave falta de verdad cuando ``bootstrap_media`` devuelve ``{"aplicable": False, ...}``
(menos de 2 bloques de 20 días). Con los parámetros congelados eso solo ocurre con menos de 40 días, es decir con
menos de 12 meses, y la decisión es INFORMATIVO de todos modos: hoy el 0,5 no cambia ninguna decisión, pero lo haría si
cambiara el bloque. Este verificador nunca usa valores por defecto: una clave ausente es un error, y un bootstrap no
aplicable solo se acepta si la decisión no depende de P (menos de 12 meses).

Nota: ``evaluar`` pasa a ``decidir`` el exceso x2 DIARIO (``fmean``) y guarda el ANUAL (×365); el signo es el mismo, así
que la condición ``x2 > 0`` es equivalente.

No importa ni ejecuta ``experimentos/fuera_de_muestra_T.py`` ni ``papel/corte.py``; no consume ningún cerrojo.

Uso: python3 -I verificar_reproduccion_T.py <resultado.json> [--esperados esperados.json] [--archivo nombre=ruta ...]
"""
from __future__ import annotations

import hashlib
import json
import math
import sys
from dataclasses import dataclass, field

DECISIONES_FUERA = ("RESPALDADA FUERA DE MUESTRA", "NO RESPALDADA", "EVIDENCIA INSUFICIENTE")
DECISIONES_PAPEL = ("INFORMATIVO (menos de 12 meses: ninguna decisión)", "HIPÓTESIS NO RESPALDADA: detener",
                    "VENTAJA RESPALDADA", "EVIDENCIA INSUFICIENTE: continuar")


class ErrorVerificacion(Exception):
    """Error de verificación con un código estable (para pruebas y para el informe)."""

    def __init__(self, codigo: str, detalle: str):
        super().__init__(f"{codigo}: {detalle}")
        self.codigo, self.detalle = codigo, detalle


@dataclass
class Registro:
    esquema: str
    decision: str
    exceso_anual: float
    ic90: tuple[float, float] | None  # None: bootstrap no aplicable (solo papel, menos de 12 meses)
    p_conjunto: float | None
    p_btc: float | None
    exceso_x2: float
    dias: int
    meses: float | None
    hashes: dict[str, str] = field(default_factory=dict)


# ---------- acceso estricto (sin valores por defecto) ----------
def _clave(obj: object, ruta: str):
    actual = obj
    for parte in ruta.split("."):
        if not isinstance(actual, dict):
            raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un objeto antes de '{parte}', hay {type(actual).__name__}")
        if parte not in actual:
            raise ErrorVerificacion("AUSENTE", f"falta la clave '{ruta}'")
        actual = actual[parte]
    return actual


def _num(obj: object, ruta: str) -> float:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un número finito, hay {v!r}")
    return float(v)


def _prob(obj: object, ruta: str) -> float:
    v = _num(obj, ruta)
    if not 0.0 <= v <= 1.0:
        raise ErrorVerificacion("RANGO", f"{ruta}: probabilidad fuera de [0, 1]: {v}")
    return v


def _entero(obj: object, ruta: str) -> int:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, int) or v <= 0:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un entero positivo, hay {v!r}")
    return v


def _texto(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not isinstance(v, str) or not v:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un texto no vacío, hay {v!r}")
    return v


def _sha(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not (isinstance(v, str) and len(v) == 64 and all(c in "0123456789abcdef" for c in v)):
        raise ErrorVerificacion("HASH_FORMATO", f"{ruta}: no es un SHA-256 en hexadecimal: {v!r}")
    return v


def _ic(obj: object, ruta: str) -> tuple[float, float]:
    v = _clave(obj, ruta)
    if not (isinstance(v, list) and len(v) == 2):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba una lista de 2 números, hay {v!r}")
    lo, hi = (_num({"x": x}, "x") for x in v)
    if lo > hi:
        raise ErrorVerificacion("RANGO", f"{ruta}: extremo inferior > superior ({lo} > {hi})")
    return lo, hi


# ---------- esquemas ----------
def detectar_esquema(obj: object) -> str:
    if not isinstance(obj, dict):
        raise ErrorVerificacion("TIPO", f"el resultado debe ser un objeto JSON, es {type(obj).__name__}")
    marcas = {"fuera_de_muestra": "decision_prerregistrada" in obj and "principal" in obj,
              "papel_corte": "corte_exclusivo" in obj and "estado" in obj,
              "papel_evaluar": "rama" in obj and "corte" in obj and "inicio" in obj}
    hallados = [k for k, v in marcas.items() if v]
    if len(hallados) != 1:
        raise ErrorVerificacion("ESQUEMA", f"esquema desconocido o ambiguo (coincide con {hallados or 'ninguno'})")
    return hallados[0]


def normalizar(obj: dict, esquema: str | None = None) -> Registro:
    esquema = esquema or detectar_esquema(obj)
    if esquema == "fuera_de_muestra":
        r = Registro("fuera_de_muestra", _texto(obj, "decision_prerregistrada"),
                     _num(obj, "principal.conjunto.exceso_anual"), _ic(obj, "principal.conjunto.ic90_anual"),
                     _prob(obj, "principal.conjunto.p"), _prob(obj, "principal.BTC.p"),
                     _num(obj, "secundarios.costes_x2.conjunto"), _entero(obj, "dias"), None,
                     {"prerregistro_archivo": _sha(obj, "prerregistro_sha256"), "script": _sha(obj, "script_sha256"),
                      "codigo": _sha(obj, "codigo_sha256"),
                      **{f"manifiesto_{s}": _sha(obj, f"manifiestos_sha256.{s}") for s in ("BTCUSDT", "ETHUSDT")}})
        if r.decision not in DECISIONES_FUERA:
            raise ErrorVerificacion("VALOR", f"decision_prerregistrada desconocida: {r.decision!r}")
        return r
    if esquema == "papel_evaluar":
        return _normalizar_papel(obj, "papel_evaluar")
    if esquema == "papel_corte":
        estado = _texto(obj, "estado")
        if estado != "EVALUADO":
            if "evaluacion" in obj:
                raise ErrorVerificacion("CONTRADICCION", f"estado {estado!r} pero hay una sección 'evaluacion'")
            raise ErrorVerificacion("SIN_EVALUACION", f"corte provisional ({estado!r}): no hay decisión que verificar")
        ev = _clave(obj, "evaluacion")
        if _texto(ev, "corte") != _texto(obj, "corte_exclusivo"):
            raise ErrorVerificacion("CONTRADICCION", "evaluacion.corte distinto de corte_exclusivo")
        r = _normalizar_papel(ev, "papel_corte")
        r.hashes["reglas_corte"] = _sha(obj, "reglas_sha256")
        r.hashes["codigo_corte"] = _sha(obj, "codigo_sha256")
        if r.hashes["reglas_corte"] != r.hashes["reglas_canonicas"] or r.hashes["codigo_corte"] != r.hashes["codigo"]:
            raise ErrorVerificacion("CONTRADICCION", "los hashes del corte y de su evaluación no coinciden")
        return r
    raise ErrorVerificacion("ESQUEMA", f"esquema no soportado: {esquema!r}")


def _bootstrap(obj: dict, ruta: str) -> tuple[float | None, tuple[float, float] | None]:
    aplicable = _clave(obj, f"{ruta}.aplicable")
    if not isinstance(aplicable, bool):
        raise ErrorVerificacion("TIPO", f"{ruta}.aplicable: se esperaba true/false, hay {aplicable!r}")
    if not aplicable:
        return None, None
    return _prob(obj, f"{ruta}.p_mayor_que_cero"), _ic(obj, f"{ruta}.intervalo_anual")


def _normalizar_papel(obj: dict, esquema: str) -> Registro:
    if _texto(obj, "rama") not in ("A", "B"):
        raise ErrorVerificacion("VALOR", f"rama desconocida: {obj['rama']!r}")
    if "decision" not in obj and "estado" in obj:  # evaluar devolvió antes de decidir (sin datos o datos no aptos)
        if esquema == "papel_corte":
            raise ErrorVerificacion("CONTRADICCION", f"corte EVALUADO pero la evaluación dice {obj['estado']!r}")
        raise ErrorVerificacion("SIN_EVALUACION", f"evaluación sin decisión: {obj['estado']!r}")
    p_conj, ic = _bootstrap(obj, "bootstrap_conjunto")
    p_btc, _ = _bootstrap(obj, "bootstrap_btc")
    r = Registro(esquema, _texto(obj, "decision"), _num(obj, "exceso_anual_conjunto"), ic, p_conj, p_btc,
                 _num(obj, "exceso_anual_conjunto_costes_x2"), _entero(obj, "dias"), _num(obj, "meses"),
                 {"reglas_canonicas": _sha(obj, "prerregistro_sha256"), "codigo": _sha(obj, "codigo_sha256")})
    if r.decision not in DECISIONES_PAPEL:
        raise ErrorVerificacion("VALOR", f"decision desconocida: {r.decision!r}")
    if abs(r.meses - r.dias / 30.44) > 1e-9:
        raise ErrorVerificacion("CONTRADICCION", f"meses ({r.meses}) ≠ dias/30,44 ({r.dias / 30.44})")
    return r


# ---------- reglas de decisión congeladas, replicadas (la prueba las compara con las originales) ----------
def decision_fuera_de_muestra(p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)."""
    if p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "RESPALDADA FUERA DE MUESTRA"
    if p_conj < 0.10:
        return "NO RESPALDADA"
    return "EVIDENCIA INSUFICIENTE"


def decision_papel(meses: float, p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de tendencia.papel.decidir (código 73b22f3e…)."""
    if meses < 12:
        return "INFORMATIVO (menos de 12 meses: ninguna decisión)"
    if p_conj < 0.10:
        return "HIPÓTESIS NO RESPALDADA: detener"
    if meses >= 24 and p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "VENTAJA RESPALDADA"
    return "EVIDENCIA INSUFICIENTE: continuar"


def recalcular_decision(r: Registro) -> str:
    if r.esquema == "fuera_de_muestra":
        return decision_fuera_de_muestra(r.p_conjunto, r.p_btc, r.exceso_x2)
    if r.p_conjunto is None or r.p_btc is None:
        if r.meses >= 12:  # aquí el código congelado habría decidido con P = 0,5 por defecto
            raise ErrorVerificacion("CONTRADICCION", f"bootstrap no aplicable con {r.meses:.2f} meses: la decisión "
                                                     "dependería del 0,5 por defecto")
        return DECISIONES_PAPEL[0]
    return decision_papel(r.meses, r.p_conjunto, r.p_btc, r.exceso_x2)


# ---------- verificación ----------
SEMANTICA = {"fuera_de_muestra": {"prerregistro_archivo", "script", "codigo", "manifiesto_BTCUSDT", "manifiesto_ETHUSDT"},
             "papel_evaluar": {"reglas_canonicas", "codigo"},
             "papel_corte": {"reglas_canonicas", "codigo", "reglas_corte", "codigo_corte"}}


def verificar(obj: object, esperados: dict[str, str] | None = None, archivos: dict[str, str] | None = None) -> dict:
    """Devuelve un informe si todo es coherente; si no, lanza ErrorVerificacion.

    esperados: hashes de referencia por nombre lógico (p. ej. {"prerregistro_archivo": "94a1…", "codigo": "73b2…"}).
    archivos:  nombre lógico -> ruta; el SHA-256 del archivo debe coincidir con el del resultado (p. ej. el script)."""
    r = normalizar(obj)
    esperados, archivos = esperados or {}, archivos or {}
    for nombre, valor in esperados.items():
        if nombre not in SEMANTICA[r.esquema]:
            otros = [e for e, s in SEMANTICA.items() if nombre in s]
            raise ErrorVerificacion("HASH_SEMANTICA", f"'{nombre}' no se aplica al esquema {r.esquema} (se aplica a {otros})")
        if r.hashes[nombre] != valor:
            # error típico: comparar el hash del ARCHIVO del prerregistro con el hash CANÓNICO de las reglas, o al revés
            raise ErrorVerificacion("HASH", f"{nombre}: el resultado dice {r.hashes[nombre][:12]}…, se esperaba {valor[:12]}…")
    for nombre, ruta in archivos.items():
        if nombre not in r.hashes:
            raise ErrorVerificacion("HASH_SEMANTICA", f"'{nombre}' no es un hash de archivo de este esquema")
        try:
            with open(ruta, "rb") as fh:
                real = hashlib.sha256(fh.read()).hexdigest()
        except OSError as e:
            raise ErrorVerificacion("AUSENTE", f"no se puede leer {ruta}: {e}") from e
        if real != r.hashes[nombre]:
            raise ErrorVerificacion("HASH", f"{nombre}: el archivo {ruta} tiene {real[:12]}…, el resultado registra "
                                            f"{r.hashes[nombre][:12]}…")
    recalculada = recalcular_decision(r)
    if recalculada != r.decision:
        raise ErrorVerificacion("CONTRADICCION", f"decisión registrada {r.decision!r} ≠ la que dan sus propias cifras "
                                                 f"con la regla congelada ({recalculada!r})")
    return {"esquema": r.esquema, "decision": r.decision, "decision_recalculada": recalculada,
            "exceso_anual": r.exceso_anual, "ic90": list(r.ic90) if r.ic90 else None, "p_conjunto": r.p_conjunto, "p_btc": r.p_btc,
            "exceso_x2": r.exceso_x2, "dias": r.dias, "hashes": r.hashes, "esperados_verificados": sorted(esperados),
            "archivos_verificados": sorted(archivos)}


def comparar(a: object, b: object, tolerancia: float = 0.0) -> list[str]:
    """Evidencia contradictoria entre dos registros del MISMO experimento (p. ej. el resultado y una reproducción).
    Devuelve la lista de discrepancias; vacía = coherentes. Con tolerancia 0 exige igualdad exacta."""
    ra, rb = normalizar(a), normalizar(b)
    dif = []
    if ra.esquema != rb.esquema:
        dif.append(f"esquemas distintos ({ra.esquema} / {rb.esquema})")
    for campo in ("decision", "dias"):
        if getattr(ra, campo) != getattr(rb, campo):
            dif.append(f"{campo}: {getattr(ra, campo)!r} ≠ {getattr(rb, campo)!r}")
    for campo in ("exceso_anual", "p_conjunto", "p_btc", "exceso_x2"):
        x, y = getattr(ra, campo), getattr(rb, campo)
        if (x is None) != (y is None) or (x is not None and abs(x - y) > tolerancia):
            dif.append(f"{campo}: {x!r} ≠ {y!r}")
    if (ra.ic90 is None) != (rb.ic90 is None) or (
            ra.ic90 and any(abs(x - y) > tolerancia for x, y in zip(ra.ic90, rb.ic90))):
        dif.append(f"ic90: {ra.ic90} ≠ {rb.ic90}")
    for k in sorted(set(ra.hashes) | set(rb.hashes)):
        if ra.hashes.get(k) != rb.hashes.get(k):
            dif.append(f"hash {k}: {ra.hashes.get(k)} ≠ {rb.hashes.get(k)}")
    return dif


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    esperados, archivos, ruta = {}, {}, argv[0]
    opciones = argv[1:]
    if len(opciones) % 2 or any(o not in ("--esperados", "--archivo") for o in opciones[::2]):
        print(__doc__)
        return 2
    try:
        for opcion, valor in zip(opciones[::2], opciones[1::2]):
            if opcion == "--esperados":
                with open(valor, encoding="utf-8") as fh:
                    esperados = json.load(fh)
            else:
                k, v = valor.split("=", 1)
                archivos[k] = v
        with open(ruta, encoding="utf-8") as fh:
            obj = json.load(fh)
        informe = verificar(obj, esperados, archivos)
    except (OSError, ValueError) as e:
        print(json.dumps({"resultado": "RECHAZADO", "codigo": "LECTURA", "detalle": str(e)}, ensure_ascii=False))
        return 1
    except ErrorVerificacion as e:
        print(json.dumps({"resultado": "RECHAZADO", "codigo": e.codigo, "detalle": e.detalle}, ensure_ascii=False))
        return 1
    print(json.dumps({"resultado": "VERIFICADO", **informe}, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
