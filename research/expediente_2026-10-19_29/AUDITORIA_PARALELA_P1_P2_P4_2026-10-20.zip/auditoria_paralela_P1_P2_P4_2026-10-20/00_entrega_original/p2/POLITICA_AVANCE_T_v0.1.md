# Política de avance de T, POLITICA_AVANCE_T v0.1 (2026-10-20)

**Estado: PROPUESTA, NO APROBADA.**
- No modifica ningún artefacto congelado, no se aplicó al repositorio y no autoriza nada.
- **Implementación:** `politica_avance_T.py`.
- **Pruebas:** `test_politica_avance_T.py`.
- Cualquier cambio da lugar a la v0.2, con hash propio; esta versión no se edita.

## 1. Tres salidas separadas

| Salida | De dónde sale | Qué puede cambiarla |
|---|---|---|
| `etiqueta_estadistica` | Texto **literal** del productor congelado: `decision_prerregistrada` o `decision` | Nada. Se copia tal cual, y una etiqueta con otro texto se rechaza |
| `robustez` | R1 y R3, **recibidos ya evaluados** como `CUMPLE`, `NO_CUMPLE` o `NO_DEFINIDO` | Solo R1 y R3. Es **informativa** |
| `avance` | **Solo** la clase de la etiqueta | Nada más. R1, R3 y el exceso ≤ 0 no lo cambian |

`autorizacion_automatica` es siempre `false`. **«Candidata» no es una autorización:** requiere tu decisión expresa. Siguen vigentes estas restricciones: sin dinero real, sin operación en vivo y sin despliegues.

## 2. Etiquetas, clases y avance

| Etiqueta literal | Productor | Clase | Avance |
|---|---|---|---|
| `RESPALDADA FUERA DE MUESTRA` | `fuera_de_muestra_T.py:44-49` | RESPALDADA | CANDIDATA: requiere autorización humana expresa |
| `NO RESPALDADA` | ídem | NO_RESPALDADA | NO AVANZA |
| `EVIDENCIA INSUFICIENTE` | ídem | INSUFICIENTE | NO AVANZA |
| `VENTAJA RESPALDADA` | `tendencia.papel.decidir` | RESPALDADA | CANDIDATA: requiere autorización humana expresa |
| `HIPÓTESIS NO RESPALDADA: detener` | ídem | NO_RESPALDADA | NO AVANZA |
| `EVIDENCIA INSUFICIENTE: continuar` | ídem | INSUFICIENTE | NO AVANZA |
| `INFORMATIVO (menos de 12 meses: ninguna decisión)` | ídem | INFORMATIVO | NO AVANZA |

- **La acción propia de cada etiqueta** («detener», «continuar») está en el texto de la etiqueta, que se conserva. La política no la reinterpreta.
- **La etiqueta solo se clasifica si el resultado pasa el verificador de P1** (`desde_resultado`). Una etiqueta sin P, con hashes erróneos o que contradice sus cifras no se clasifica.

## 3. Regla de robustez

| R1 \ R3 | CUMPLE | NO_CUMPLE | NO_DEFINIDO |
|---|---|---|---|
| **CUMPLE** | ROBUSTA | NO_ROBUSTA | INDETERMINADA |
| **NO_CUMPLE** | NO_ROBUSTA | NO_ROBUSTA | NO_ROBUSTA |
| **NO_DEFINIDO** | INDETERMINADA | NO_ROBUSTA | INDETERMINADA |

- **Fuente de la regla:** «ROBUSTA si se cumplen las seis» (protocolo E3 v3 §6.3, `PROTOCOLO_E3_v3_PROPUESTO.md`, SHA-256 `279a865f6471afe5b19544840f39d5783442858a64a000acb5768983dc51c18e`), restringida a R1 y R3 como pediste.
- **No introduce umbrales:** solo combina estados.

## 4. Ambigüedades registradas: decisiones que te pido

**A1. Qué es R1 para T.**
- **No está definido en ningún documento de T.** Lo busqué en:
  - los prerregistros fuera de muestra y de papel;
  - `prerregistro_papel.json`;
  - el informe y la revisión crítica;
  - `ESTADO_FINAL_2026-10-18.md`.
- **La única definición del proyecto** es la de E3 v3 §6.3: «Exceso neto > 0 con costos ×2».
- **Posibles transposiciones (no elegí ninguna):**
  - (a) exceso anual del **conjunto** con costos ×2 > 0;
  - (b) BTC **y** ETH por separado > 0;
  - (c) otra.
- **Observación:** las dos etiquetas RESPALDADA ya exigen exceso con costos ×2 > 0. Con (a), R1 sería redundante justo donde podría importar.

**A2. Qué es R3 para T.**
- **En E3 v3:** «IC̄ > 0 en ≥ 2 de 3 tercios … y exceso neto > 0 en ≥ 2 de 3 tercios».
- **IC̄ no tiene análogo en T:** un solo activo por regla, sin ranking transversal.
- **Las subventanas registradas de T son 2, no 3:** 2022-2023 y 2024-01 → 2026-05.
- **Posibles transposiciones (no elegí ninguna):**
  - (a) solo la parte del exceso, con tercios de días del período evaluado;
  - (b) las dos subventanas existentes;
  - (c) otra.

**A3. ¿R1 o R3 pueden vetar la candidatura?**
- **La v0.1 implementa «no»,** siguiendo tu indicación: «R1, R3 y el exceso de retorno menor o igual a cero son resultados informativos, no criterios decisorios independientes».
- **Una robustez distinta de ROBUSTA** solo genera una advertencia para tu decisión.
- **La alternativa** es un veto: RESPALDADA más NO_ROBUSTA daría NO AVANZA. Pide tu aprobación y sería la v0.2.

**A4. Uso sobre el período fuera de muestra ya consumido.**
- Evaluar R1 o R3 sobre 2022–2026 sería un análisis **post hoc**: no estaban en el prerregistro de T.
- R3 exigiría además recalcular sobre datos ya usados, lo que excede «no repetir la evaluación fuera de muestra».
- **Por eso** la política se aplicó al resultado histórico con R1 y R3 en `NO_DEFINIDO`.
- **Para el papel,** R1 y R3 tendrían que definirse **antes** del primer corte que decide.

**A5. Qué es «la etapa siguiente» de T.**
- Ningún documento de T lo define.
- La política solo dice si T es **candidata**. El contenido de la etapa siguiente es tu decisión.

## 5. Estado de T con esta política (solo lectura del JSON registrado)

| Etiqueta | Robustez | Avance |
|---|---|---|
| `EVIDENCIA INSUFICIENTE` (sin cambios) | INDETERMINADA (R1 y R3 sin definir) | NO AVANZA |

## 6. Pruebas ejecutadas
Resultados en `../evidencia/p2_pytest.txt`. Cubren:
- **las 63 combinaciones** (7 etiquetas × 3 estados × 3 estados);
- la invariancia del avance frente a R1, R3 y el exceso;
- el rechazo de etiquetas no literales, de estados inválidos y de excesos que no son booleanos;
- la igualdad del conjunto de etiquetas con los `return` del código congelado (leídos con `ast`, sin ejecutarlo);
- la aplicación al JSON histórico real, en solo lectura, con su hash igual antes y después.
