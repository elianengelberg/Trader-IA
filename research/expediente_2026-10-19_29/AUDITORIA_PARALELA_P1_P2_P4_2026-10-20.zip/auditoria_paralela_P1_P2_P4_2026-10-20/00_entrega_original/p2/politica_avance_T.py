"""Política de avance de T, v0.1 — PROPUESTA, NO APROBADA. Solo biblioteca estándar; no lee datos ni escribe nada.

Separa tres cosas que no deben mezclarse:
  1. etiqueta_estadistica: la decisión prerregistrada, copiada LITERALMENTE de su productor (nunca se reescribe);
  2. robustez: resumen INFORMATIVO de R1 y R3 (CUMPLE / NO_CUMPLE / NO_DEFINIDO cada uno);
  3. avance: si T es candidata a pasar a la etapa siguiente. Depende SOLO de la etiqueta y nunca es automático.

R1 y R3 no están definidos para T (ver POLITICA_AVANCE_T_v0.1.md, ambigüedades A1 y A2): esta política no calcula R1
ni R3 ni fija umbrales; los recibe ya evaluados, y mientras no haya definición aprobada el único valor honesto es
NO_DEFINIDO. Por tu indicación, R1, R3 y un exceso ≤ 0 son informativos: no crean ni bloquean el avance (A3).
"""
from __future__ import annotations

import sys
from pathlib import Path

VERSION = "POLITICA_AVANCE_T v0.1"
ESTADO_VERSION = "PROPUESTA: no aprobada"

# Etiquetas literales de los dos productores congelados -> clase. La clase solo agrupa; la etiqueta se conserva tal cual.
ETIQUETAS = {
    # experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)
    "RESPALDADA FUERA DE MUESTRA": "RESPALDADA",
    "NO RESPALDADA": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE": "INSUFICIENTE",
    # tendencia.papel.decidir (código 73b22f3e…)
    "VENTAJA RESPALDADA": "RESPALDADA",
    "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
    "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO",
}
ESTADOS_R = ("CUMPLE", "NO_CUMPLE", "NO_DEFINIDO")
CANDIDATA = "CANDIDATA: requiere autorización humana expresa"
NO_AVANZA = "NO AVANZA"


class ErrorPolitica(ValueError):
    pass


def robustez(r1: str, r3: str) -> str:
    """ROBUSTA solo si se cumplen ambas (como E3 v3 §6.3: «ROBUSTA si se cumplen las seis»); NO_ROBUSTA si alguna
    falla; INDETERMINADA si ninguna falla pero alguna no está definida."""
    for nombre, v in (("R1", r1), ("R3", r3)):
        if not isinstance(v, str) or v not in ESTADOS_R:
            raise ErrorPolitica(f"{nombre} debe ser uno de {ESTADOS_R}, es {v!r}")
    if "NO_CUMPLE" in (r1, r3):
        return "NO_ROBUSTA"
    if "NO_DEFINIDO" in (r1, r3):
        return "INDETERMINADA"
    return "ROBUSTA"


def aplicar(etiqueta: str, r1: str, r3: str, exceso_no_positivo: bool | None = None) -> dict:
    if not isinstance(etiqueta, str) or etiqueta not in ETIQUETAS:
        raise ErrorPolitica(f"etiqueta estadística desconocida (se exige el texto literal del productor): {etiqueta!r}")
    if exceso_no_positivo is not None and not isinstance(exceso_no_positivo, bool):
        raise ErrorPolitica(f"exceso_no_positivo debe ser true, false o null, es {exceso_no_positivo!r}")
    clase, rob = ETIQUETAS[etiqueta], robustez(r1, r3)
    avance = CANDIDATA if clase == "RESPALDADA" else NO_AVANZA
    advertencias = []
    if "NO_DEFINIDO" in (r1, r3):
        advertencias.append("R1/R3 sin definición aprobada para T (ambigüedades A1 y A2): robustez no evaluable")
    if clase == "RESPALDADA" and rob != "ROBUSTA":
        advertencias.append(f"robustez {rob}: dato para la decisión humana; en v0.1 no veta la candidatura (A3)")
    notas = []
    if exceso_no_positivo is not None:
        notas.append(f"exceso anual {'≤' if exceso_no_positivo else '>'} 0: informativo, no cambia el avance")
    return {"version": VERSION, "estado_version": ESTADO_VERSION, "etiqueta_estadistica": etiqueta,
            "clase_estadistica": clase, "R1": r1, "R3": r3, "robustez": rob, "avance": avance,
            "autorizacion_automatica": False, "advertencias": advertencias, "notas_informativas": notas}


def desde_resultado(obj: object, r1: str, r3: str, esperados: dict[str, str] | None = None) -> dict:
    """Aplica la política a un resultado de T solo después de verificarlo con el verificador de P1: una etiqueta
    que no pasa la verificación (claves ausentes, hashes, contradicciones) no se clasifica."""
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "p1"))
    import verificar_reproduccion_T as V
    inf = V.verificar(obj, esperados=esperados)
    return {**aplicar(inf["decision"], r1, r3, exceso_no_positivo=inf["exceso_anual"] <= 0),
            "resultado_verificado": {k: inf[k] for k in ("esquema", "decision_recalculada", "dias", "hashes")}}
