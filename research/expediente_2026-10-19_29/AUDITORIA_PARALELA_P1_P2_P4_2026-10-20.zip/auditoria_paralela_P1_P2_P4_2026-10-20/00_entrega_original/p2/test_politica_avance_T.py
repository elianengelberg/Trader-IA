"""Pruebas sintéticas de la política de avance de T v0.1: las 63 combinaciones (7 etiquetas × 3 estados de R1 × 3 de R3),
entradas inválidas y las propiedades que separan etiqueta, robustez y avance."""
from __future__ import annotations

import ast
import copy
import hashlib
import itertools
import json
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent / "p1"))
import politica_avance_T as PA  # noqa: E402
import verificar_reproduccion_T as V  # noqa: E402
from test_verificar_reproduccion_T import T, con_t, evaluar, oos, quitar  # noqa: E402

# Tablas esperadas escritas a mano (no derivadas del módulo bajo prueba).
CLASE = {"RESPALDADA FUERA DE MUESTRA": "RESPALDADA", "VENTAJA RESPALDADA": "RESPALDADA",
         "NO RESPALDADA": "NO_RESPALDADA", "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
         "EVIDENCIA INSUFICIENTE": "INSUFICIENTE", "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
         "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO"}
ROBUSTEZ = {("CUMPLE", "CUMPLE"): "ROBUSTA", ("CUMPLE", "NO_CUMPLE"): "NO_ROBUSTA",
            ("CUMPLE", "NO_DEFINIDO"): "INDETERMINADA", ("NO_CUMPLE", "CUMPLE"): "NO_ROBUSTA",
            ("NO_CUMPLE", "NO_CUMPLE"): "NO_ROBUSTA", ("NO_CUMPLE", "NO_DEFINIDO"): "NO_ROBUSTA",
            ("NO_DEFINIDO", "CUMPLE"): "INDETERMINADA", ("NO_DEFINIDO", "NO_CUMPLE"): "NO_ROBUSTA",
            ("NO_DEFINIDO", "NO_DEFINIDO"): "INDETERMINADA"}
AVANCE = {"RESPALDADA": "CANDIDATA: requiere autorización humana expresa", "NO_RESPALDADA": "NO AVANZA",
          "INSUFICIENTE": "NO AVANZA", "INFORMATIVO": "NO AVANZA"}
COMBINACIONES = list(itertools.product(CLASE, PA.ESTADOS_R, PA.ESTADOS_R))


def test_hay_63_combinaciones() -> None:
    assert len(COMBINACIONES) == 63 and len(set(COMBINACIONES)) == 63


@pytest.mark.parametrize("etiqueta,r1,r3", COMBINACIONES)
def test_combinacion(etiqueta: str, r1: str, r3: str) -> None:
    s = PA.aplicar(etiqueta, r1, r3)
    assert s["etiqueta_estadistica"] == etiqueta  # literal, sin reescribir
    assert s["clase_estadistica"] == CLASE[etiqueta]
    assert s["robustez"] == ROBUSTEZ[(r1, r3)]
    assert s["avance"] == AVANCE[CLASE[etiqueta]]
    assert s["autorizacion_automatica"] is False
    assert (s["R1"], s["R3"], s["version"]) == (r1, r3, "POLITICA_AVANCE_T v0.1")
    assert any("A1 y A2" in a for a in s["advertencias"]) == ("NO_DEFINIDO" in (r1, r3))
    assert any("no veta" in a for a in s["advertencias"]) == (
        CLASE[etiqueta] == "RESPALDADA" and ROBUSTEZ[(r1, r3)] != "ROBUSTA")


@pytest.mark.parametrize("etiqueta", list(CLASE))
def test_r1_r3_y_exceso_son_informativos(etiqueta: str) -> None:
    """Para una etiqueta fija, ninguna combinación de R1, R3 o exceso cambia el avance ni la etiqueta."""
    salidas = [PA.aplicar(etiqueta, r1, r3, x) for r1, r3 in itertools.product(PA.ESTADOS_R, repeat=2)
               for x in (None, True, False)]
    assert {s["avance"] for s in salidas} == {AVANCE[CLASE[etiqueta]]}
    assert {s["etiqueta_estadistica"] for s in salidas} == {etiqueta}


def test_robustez_no_crea_avance_ni_lo_bloquea() -> None:
    for etiqueta, clase in CLASE.items():
        if clase != "RESPALDADA":  # robusta no basta para avanzar
            assert PA.aplicar(etiqueta, "CUMPLE", "CUMPLE")["avance"] == "NO AVANZA"
        else:  # no robusta no veta (v0.1, A3), pero queda advertida y nunca es automática
            s = PA.aplicar(etiqueta, "NO_CUMPLE", "NO_CUMPLE")
            assert s["avance"].startswith("CANDIDATA") and s["autorizacion_automatica"] is False and s["advertencias"]


@pytest.mark.parametrize("etiqueta", ["respaldada fuera de muestra", "VENTAJA RESPALDADA ", "RESPALDADA", "",
                                      "EVIDENCIA INSUFICIENTE: Continuar", None, 1, ["VENTAJA RESPALDADA"]])
def test_rechaza_etiqueta_no_literal(etiqueta) -> None:  # type: ignore[no-untyped-def]
    with pytest.raises(PA.ErrorPolitica):
        PA.aplicar(etiqueta, "CUMPLE", "CUMPLE")


@pytest.mark.parametrize("valor", [True, False, None, 1, "cumple", "SI", "", "INDETERMINADA"])
@pytest.mark.parametrize("cual", ["R1", "R3"])
def test_rechaza_estado_r_invalido(cual: str, valor) -> None:  # type: ignore[no-untyped-def]
    r1, r3 = (valor, "CUMPLE") if cual == "R1" else ("CUMPLE", valor)
    with pytest.raises(PA.ErrorPolitica, match=cual):
        PA.aplicar("VENTAJA RESPALDADA", r1, r3)


@pytest.mark.parametrize("x", ["no", 0, 1, 0.0])
def test_rechaza_exceso_no_booleano(x) -> None:  # type: ignore[no-untyped-def]
    with pytest.raises(PA.ErrorPolitica):
        PA.aplicar("EVIDENCIA INSUFICIENTE", "NO_DEFINIDO", "NO_DEFINIDO", x)


def test_etiquetas_iguales_a_las_del_codigo_congelado_y_del_verificador() -> None:
    assert set(PA.ETIQUETAS) == set(CLASE) == set(V.DECISIONES_FUERA) | set(V.DECISIONES_PAPEL)


@con_t
def test_etiquetas_iguales_a_los_textos_que_devuelve_el_codigo_congelado() -> None:
    """Lee (sin ejecutar) los return de ``decision`` y ``decidir``: ninguna etiqueta falta ni sobra."""
    textos = set()
    for ruta, nombre in ((T / "experimentos" / "fuera_de_muestra_T.py", "decision"),
                         (T / "src" / "tendencia" / "papel.py", "decidir")):
        f = next(n for n in ast.parse(ruta.read_bytes()).body if isinstance(n, ast.FunctionDef) and n.name == nombre)
        textos |= {n.value.value for n in ast.walk(f) if isinstance(n, ast.Return)}
    assert textos == set(PA.ETIQUETAS)


def test_desde_resultado_exige_verificacion_y_no_modifica_la_entrada() -> None:
    o = oos()
    copia = copy.deepcopy(o)
    s = PA.desde_resultado(o, "NO_DEFINIDO", "NO_DEFINIDO")
    assert o == copia
    assert s["etiqueta_estadistica"] == "EVIDENCIA INSUFICIENTE" and s["avance"] == "NO AVANZA"
    assert s["resultado_verificado"]["decision_recalculada"] == s["etiqueta_estadistica"]
    ev = evaluar()
    assert PA.desde_resultado(ev, "CUMPLE", "CUMPLE")["avance"].startswith("CANDIDATA")
    with pytest.raises(V.ErrorVerificacion):  # sin P: no se clasifica
        PA.desde_resultado(quitar(ev, "bootstrap_conjunto.p_mayor_que_cero"), "CUMPLE", "CUMPLE")
    with pytest.raises(V.ErrorVerificacion):  # etiqueta que contradice sus cifras: no se clasifica
        PA.desde_resultado(oos(p_conj=0.5, decision="RESPALDADA FUERA DE MUESTRA"), "CUMPLE", "CUMPLE")


def test_exceso_no_positivo_se_lee_del_resultado_verificado() -> None:
    o = oos()
    o["principal"]["conjunto"]["exceso_anual"] = -0.01
    s = PA.desde_resultado(o, "NO_DEFINIDO", "NO_DEFINIDO")
    assert any("≤ 0" in n for n in s["notas_informativas"]) and s["avance"] == "NO AVANZA"


@con_t
def test_resultado_historico_real_conserva_su_etiqueta() -> None:
    """Solo lectura del JSON registrado; R1/R3 = NO_DEFINIDO porque no hay definición aprobada para T."""
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    antes = hashlib.sha256(ruta.read_bytes()).hexdigest()
    s = PA.desde_resultado(json.loads(ruta.read_text(encoding="utf-8")), "NO_DEFINIDO", "NO_DEFINIDO")
    assert (s["etiqueta_estadistica"], s["robustez"], s["avance"]) == (
        "EVIDENCIA INSUFICIENTE", "INDETERMINADA", "NO AVANZA")
    assert hashlib.sha256(ruta.read_bytes()).hexdigest() == antes


def test_documento_de_la_politica_corresponde_a_esta_version() -> None:
    doc = (AQUI / "POLITICA_AVANCE_T_v0.1.md").read_text(encoding="utf-8")
    assert PA.VERSION in doc and "NO APROBADA" in doc.upper()
    for etiqueta in PA.ETIQUETAS:
        assert f"`{etiqueta}`" in doc
