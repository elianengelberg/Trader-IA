# P4: ejecución de uso único, estados, invariantes y pseudocódigo (2026-10-20)

**Naturaleza:** prototipo **aislado**.
- **Archivos:** `uso_unico.py`, probado con `test_uso_unico.py` y `_conductor.py`.
- **No está integrado** en `papel/corte.py`, en `experimentos/fuera_de_muestra_T.py` ni en ningún ejecutor protegido. No se invocó ninguno de ellos.
- **Datos:** todos sintéticos.

**Objetivo:** que un experimento se calcule con entradas fijadas de antemano y que **ningún resultado observado pueda sustituirse por otro** (por ejemplo, uno más favorable) mediante:
- volver a ejecutar;
- borrar, alterar o plantar archivos;
- cambiar la semilla o los datos;
- renombrar el experimento.

## 1. Estados persistidos (se deducen del diario `DIARIO.jsonl`)

```
NUEVO ──reserva atómica──▶ RESERVADO ──(CALCULANDO: solo en memoria)──▶ PRESELLADO ──archivo atómico──▶ SELLADO ──▶ REGISTRADO
                              │                                            │                             │
                              └────── caída: se recalcula (nada visto) ────┘                             │
                                                    caída: se recalcula y DEBE coincidir con el presellado
Terminales de error (nunca se abandonan):
- CONFLICTO: el recálculo no reproduce el presellado.
- CORRUPTO: el archivo no coincide.
- INCONSISTENTE: el diario está roto o hay un resultado sin diario.
```

| Estado | Cómo se reconoce en disco | Qué hace la siguiente llamada |
|---|---|---|
| NUEVO | No hay diario. Si hay `resultado.json` sin diario, el estado es INCONSISTENTE | Comprueba el registro global, reserva y calcula |
| RESERVADO | Diario con `RESERVADO` (más `INTENTO`), sin `PRESELLADO` | Recalcula: el resultado anterior, si existió, no llegó al disco ni a nadie |
| PRESELLADO | Hay `PRESELLADO {resultado_sha256}`, sin `SELLADO` | Si el archivo existe, debe coincidir (si no, CORRUPTO). Si no existe, recalcula y **debe** coincidir (si no, CONFLICTO) |
| SELLADO | Hay `SELLADO`, sin `REGISTRADO` | Verifica el archivo y anota `REGISTRADO` |
| REGISTRADO | Hay `REGISTRADO` | Devuelve el archivo verificado **sin recalcular**. Si el archivo fue borrado, solo acepta el **mismo** resultado (`RESTAURADO`) o pasa a CONFLICTO |
| CONFLICTO / CORRUPTO | Evento terminal en el diario | Anota `INTENTO` y devuelve el error, **sin resultado** |
| INCONSISTENTE | La cadena no verifica, la secuencia es imposible, hay un resultado sin diario o el registro global no coincide | Devuelve el error **sin escribir nada** |

**Resultados de una llamada que no son estados persistidos:**
- **OCUPADO:** otro proceso tiene el cerrojo. No se calcula.
- **RECHAZADO:**
  - las entradas o la semilla no son las reservadas (queda anotado);
  - o el registro global ya tiene ese experimento o esas entradas;
  - o la reserva figura en el registro global pero falta el estado local.

## 2. Invariantes

| # | Invariante | Cómo se garantiza | Pruebas |
|---|---|---|---|
| I1 | **Reserva previa y única.** Se calcula solo después de una reserva durable que liga el experimento, la semilla y el SHA-256 de cada entrada | La primera línea va a un temporal con fsync y luego `os.link`, que es atómico y exclusivo | `test_flujo_normal…`, caídas `antes_de_reservar` y `durante_reserva` |
| I2 | **Nada sale antes del presellado.** Ningún byte del resultado llega al disco ni al llamador antes de que su SHA-256 esté en el diario con fsync | El cálculo queda en memoria, luego se anota `PRESELLADO` y después se escribe el archivo | `test_caida_y_reinicio` (rastreo de bytes en disco), mutante M04 |
| I3 | **Unicidad.** Tras el presellado solo vale el resultado con ese hash | Un recálculo distinto da CONFLICTO; un archivo distinto da CORRUPTO. Nunca se reemplaza | `…no_determinista…`, `test_borrar_el_resultado…`, `test_resultado_alterado…`, `test_reescritura_coherente…` |
| I4 | **Entradas fijas.** Cada llamada vuelve a calcular los hashes y calcula con **esos mismos bytes** verificados (sin carrera entre verificar y leer) | Si `reserva ≠ ofrecida`, `RECHAZADO_ENTRADAS_DISTINTAS` queda anotado y no se calcula | `test_entradas_o_semilla_cambiadas…` |
| I5 | **Diario encadenado, solo de añadidos.** Cada línea lleva `n` y el SHA-256 de la anterior, en JSON canónico | Editar, borrar, reordenar, agregar espacios o insertar líneas da INCONSISTENTE, sin escribir. Una línea a medias (solo puede ser la última) se recorta y su contenido queda anotado | `test_diario_editado…` (5 ediciones), caídas `durante_presellado` y `durante_registro` |
| I6 | **Los terminales son definitivos.** CONFLICTO, CORRUPTO e INCONSISTENTE no se abandonan. REGISTRADO no se recalcula, salvo para reponer exactamente los mismos bytes | Comprobación al inicio; la secuencia no admite eventos tras un terminal (salvo `INTENTO`) | `test_resultado_alterado…` (reponer el archivo no revierte), mutante M13 |
| I7 | **Exclusión.** Toda lectura y escritura del estado ocurre con `flock` exclusivo; las demás llamadas devuelven OCUPADO sin calcular | Si el proceso muere, el núcleo libera el cerrojo | `test_concurrencia_un_solo_calculo` (8 procesos), `test_muerte_con_sigkill…` |
| I8 | **Todo intento queda anotado.** Cada llamada que obtiene el cerrojo deja `INTENTO` o `RECHAZADO_…` | Se anota antes de calcular | `test_flujo_normal…` (6 intentos) |
| I9 | **Escrituras atómicas.** Los temporales nunca se leen | El resultado se escribe con temporal, fsync, `os.replace` y fsync del directorio. Los temporales se borran al reiniciar | Caída `durante_escritura`, `test_temporal_huerfano_nunca_se_lee` |
| I10 | **Ancla fuera del directorio (opcional).** `registro_global` anota RESERVA y RESULTADO | Se rechaza: borrar el estado local y repetir; las mismas entradas con otro nombre o semilla; y un resultado local distinto del anotado | `test_registro_global_…` (3), `test_concurrencia_con_registro_global…` |

## 3. Pseudocódigo

```
ejecutar(dir, experimento, archivos, semilla, calcular, registro_global?):
  tomar flock(dir/.cerrojo, exclusivo, no bloqueante)        si está tomado → OCUPADO
  diario ← leer y verificar la cadena y la secuencia          si falla → INCONSISTENTE (sin escribir)
  si hay una cola sin '\n' → recortarla y anotar COLA_ROTA_DESCARTADA{sha, contenido}
  borrar dir/.*.tmp
  bytes ← leer archivos;  reserva ← {experimento, semilla, sha256(bytes)}
  si el diario está vacío:
      si existe resultado.json → INCONSISTENTE
      [con el cerrojo global: rechazar si el experimento o las entradas ya constan, o si la reserva consta sin estado local]
      crear el diario con RESERVADO(reserva)  (temporal + fsync + link)  [y anotar RESERVA en el global]
  si el estado es terminal → anotar INTENTO; devolver el error sin resultado
  si reserva ≠ diario[0] → anotar RECHAZADO_ENTRADAS_DISTINTAS; devolver RECHAZADO
  anotar INTENTO
  si no hay PRESELLADO:
      r ← canon(calcular(bytes, semilla))                     # en memoria; no se muestra
      anotar PRESELLADO{sha(r)} con fsync
  si existe resultado.json:
      si sha(archivo) ≠ presellado → anotar CORRUPTO; devolver el error
  si no:
      si r no está en memoria: r ← canon(calcular(bytes, semilla))
          si sha(r) ≠ presellado → anotar CONFLICTO; devolver el error
      escribir r de forma atómica; anotar RESTAURADO si ya estaba sellado
  si falta SELLADO → anotarlo;  si falta REGISTRADO → anotarlo
  [global: anotar RESULTADO o comprobar que coincide → si no, INCONSISTENTE]
  devolver REGISTRADO(r)
```

## 4. Fallos probados: caídas reales con `os._exit(137)`, sin `finally` ni vaciado de búferes

| Momento | Punto | Estado en disco tras la caída | Al reiniciar (cálculo determinista) | Con cálculo no determinista |
|---|---|---|---|---|
| Antes | `antes_del_cerrojo`, `antes_de_reservar` | Sin diario | Se reserva y calcula: 1 cálculo | — |
| Antes | `durante_reserva` | Temporal del diario; sin diario | El temporal se borra; 1 cálculo | — |
| Durante el cálculo | `durante_calculo` (y SIGKILL con el cerrojo tomado) | RESERVADO + INTENTO | Se recalcula: 2 cálculos, mismo resultado | REGISTRADO: el primero nunca se vio |
| Después de calcular | `tras_calculo` | Ídem; ningún byte del resultado en disco | Ídem | REGISTRADO |
| Durante la persistencia | `durante_presellado` | Media línea PRESELLADO | Se recorta, se anota y se recalcula | REGISTRADO |
| Durante la persistencia | `tras_presellado` | PRESELLADO sin archivo | Se recalcula y **coincide** con el presellado | **CONFLICTO**: no se entrega otro resultado |
| Durante la persistencia | `durante_escritura` | PRESELLADO y un temporal a medias | El temporal se ignora y se borra; recálculo coincidente | **CONFLICTO** |
| Después de persistir | `tras_archivo` | Archivo sin SELLADO | **No se recalcula**: se verifica y se sella | REGISTRADO con el archivo sellado |
| Después de persistir | `durante_registro` | SELLADO y media línea REGISTRADO | Se recorta; se registra sin recalcular | Ídem |
| Tras reiniciar | Repetición tras REGISTRADO | — | Devuelve lo mismo sin recalcular; se anota cada INTENTO | — |

**Integridad y repetición deliberada:**

| Acción | Resultado |
|---|---|
| Borrar `resultado.json` | Solo se acepta el **mismo** resultado (RESTAURADO); un cálculo distinto da CONFLICTO |
| Alterar `resultado.json` | CORRUPTO, terminal aunque después se reponga el original |
| Plantar un temporal «favorable» | Se ignora y se borra |
| Editar el diario (5 variantes) | INCONSISTENTE, sin escribir |
| Reescribir el diario **entero** de forma coherente con otro hash | CORRUPTO, porque el archivo no coincide |
| Reescribir el diario y el resultado de forma coherente | Solo lo detecta el registro global: INCONSISTENTE |
| Cambiar los datos o la semilla tras la reserva | RECHAZADO y anotado; no se calcula |
| Borrar el directorio de estado | Con registro global: RECHAZADO. **Sin registro global: se repite (límite L3)** |
| Otro nombre y otra semilla con las mismas entradas | Con registro global: RECHAZADO |

## 5. Límites (no resueltos por el prototipo)
- **L1. El cálculo debe ser determinista.** Si no lo es, la recuperación tras el presellado termina en CONFLICTO: es seguro, pero bloquea.
- **L2. Canales laterales.** Si la función de cálculo imprime, escribe en otro lugar o usa la red, viola I2 por fuera del prototipo. En una integración real tendría que correr en un proceso aislado, sin salida visible.
- **L3. Hace falta un ancla externa.** Borrar el directorio de estado **y** el registro global, o reescribir ambos de forma coherente, no se puede detectar localmente. Hace falta publicar los hashes de la reserva y del resultado fuera de la máquina, por ejemplo con un commit publicado o un sellado de tiempo. **Esa publicación requiere tu autorización (D-G6).** `test_limitacion_sin_ancla_externa…` documenta este límite: **no es un éxito**.
- **L4. Un solo equipo y un sistema de archivos local.** `flock` y `link` tienen otra semántica en NFS.
- **L5. Las horas UTC del diario son informativas.** No prueban el orden frente a terceros.

## 6. Integración (solo propuesta; no realizada)
El ejecutor protegido existente (`papel/corte.py`) ya usa:
- `flock`;
- escritura atómica;
- un registro encadenado.

Lo que este prototipo agrega y podría trasladarse:
- el **presellado**: el hash es durable antes de que el resultado exista en disco;
- la **comparación obligatoria** en cada recálculo de recuperación;
- los **estados terminales**;
- el **registro global**.

**Trasladarlo** implica modificar un ejecutor protegido y requiere tu autorización. No se hizo.
