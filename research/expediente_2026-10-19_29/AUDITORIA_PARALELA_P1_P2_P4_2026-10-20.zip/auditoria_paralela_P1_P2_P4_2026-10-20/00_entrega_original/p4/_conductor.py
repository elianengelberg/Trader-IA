"""Conductor de las pruebas de P4: ejecuta ``uso_unico.ejecutar`` en un proceso aparte y, si se pide, lo mata con
``os._exit(137)`` en un punto (sin finally ni vaciado de búferes, como una caída real). Datos sintéticos."""
from __future__ import annotations

import json
import os
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import uso_unico as U  # noqa: E402


def calculadora(modo: str = "det", punto: str | None = None, contador: str | None = None):  # type: ignore[no-untyped-def]
    """Media bootstrap sembrada de los datos (sintéticos). Cada llamada deja una línea en ``contador``."""
    def calcular(contenidos: dict[str, bytes], semilla: int) -> dict:
        if contador:
            with open(contador, "a", encoding="utf-8") as fh:
                fh.write(f"{os.getpid()}\n")
        datos = [float(x) for x in contenidos["datos"].decode().split()]
        rng = random.Random(semilla)
        medias = [sum(rng.choice(datos) for _ in datos) / len(datos) for _ in range(200)]
        if punto == "durante_calculo":
            os._exit(137)
        if modo == "lento":
            time.sleep(1.5)
        res = {"media": sum(datos) / len(datos), "p_mayor_que_cero": sum(m > 0 for m in medias) / len(medias),
               "n": len(datos)}
        if modo == "no_determinista":
            res["ruido"] = os.urandom(8).hex()
        return res
    return calcular


if __name__ == "__main__":
    a = json.loads(sys.argv[1])
    punto = a.get("punto")
    if a.get("esperar_hasta"):
        while time.time() < a["esperar_hasta"]:
            time.sleep(0.0005)
    s = U.ejecutar(a["dir"], a["experimento"], a["archivos"], a["semilla"],
                   calculadora(a.get("modo", "det"), punto, a.get("contador")),
                   registro_global=a.get("registro_global"), fallo=lambda p: os._exit(137) if p == punto else None)
    print(json.dumps(s.__dict__, ensure_ascii=False))
