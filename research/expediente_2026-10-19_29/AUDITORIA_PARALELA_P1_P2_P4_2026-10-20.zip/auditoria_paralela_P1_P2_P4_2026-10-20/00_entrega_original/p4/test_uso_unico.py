"""Pruebas sintéticas del prototipo de uso único (P4). Las caídas son reales: el proceso hijo muere con os._exit(137)
en cada punto (sin finally ni vaciado), y luego se reinicia. Ningún dato es de mercado."""
from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import uso_unico as U  # noqa: E402
from _conductor import calculadora  # noqa: E402

CONDUCTOR = AQUI / "_conductor.py"
DATOS = [0.01, -0.02, 0.03, 0.005, -0.01, 0.02, 0.015, -0.005] * 5


@pytest.fixture
def e(tmp_path: Path) -> dict:
    ent = tmp_path / "entradas"
    ent.mkdir()
    (ent / "protocolo.md").write_text("protocolo sintético v1\n", encoding="utf-8")
    (ent / "codigo.py").write_text("def f():\n    return 1\n", encoding="utf-8")
    (ent / "datos.txt").write_text(" ".join(map(str, DATOS)), encoding="utf-8")
    return {"dir": str(tmp_path / "estado"), "experimento": "SINTETICO-1", "semilla": 7,
            "archivos": {k: str(ent / f) for k, f in (("protocolo", "protocolo.md"), ("codigo", "codigo.py"),
                                                      ("datos", "datos.txt"))},
            "contador": str(tmp_path / "llamadas.txt"), "tmp": tmp_path}


def correr(e: dict, modo: str = "det", **kw) -> U.Salida:  # type: ignore[no-untyped-def]
    return U.ejecutar(kw.get("dir", e["dir"]), kw.get("experimento", e["experimento"]), e["archivos"],
                      kw.get("semilla", e["semilla"]), calculadora(modo, None, e["contador"]),
                      registro_global=kw.get("registro_global"))


def hijo(e: dict, **extra) -> subprocess.Popen:  # type: ignore[no-untyped-def]
    args = {k: e[k] for k in ("dir", "experimento", "semilla", "archivos", "contador")} | extra
    return subprocess.Popen([sys.executable, "-B", str(CONDUCTOR), json.dumps(args)], stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})


def llamadas(e: dict) -> int:
    p = Path(e["contador"])
    return len(p.read_text(encoding="utf-8").splitlines()) if p.exists() else 0


def referencia(e: dict) -> tuple[dict, str]:
    """El resultado correcto, calculado una vez en un directorio limpio aparte (sin contar llamadas)."""
    s = U.ejecutar(e["tmp"] / "referencia", e["experimento"], e["archivos"], e["semilla"], calculadora())
    assert s.estado == "REGISTRADO"
    return s.resultado, s.resultado_sha256


def eventos(e: dict) -> list[str]:
    return U.leer(e["dir"])["eventos"]


def sin_temporales(d: str) -> bool:
    return not list(Path(d).glob(".*.tmp"))


# ---------- flujo normal y repetición ----------
def test_flujo_normal_y_repeticiones_no_recalculan(e: dict) -> None:
    ref, ref_sha = referencia(e)
    s = correr(e)
    assert (s.estado, s.resultado, s.resultado_sha256, s.calculado) == ("REGISTRADO", ref, ref_sha, True)
    assert eventos(e) == ["RESERVADO", "INTENTO", "PRESELLADO", "SELLADO", "REGISTRADO"]
    for _ in range(5):
        r = correr(e)
        assert (r.estado, r.resultado_sha256, r.calculado) == ("REGISTRADO", ref_sha, False)
    assert llamadas(e) == 1  # el cálculo ocurrió una sola vez
    assert eventos(e).count("INTENTO") == 6  # cada intento queda anotado
    assert U.leer(e["dir"])["archivo_coincide"]


# ---------- caídas en cada punto, y reinicio ----------
# punto -> (eventos en disco tras la caída, ¿existe resultado.json?, ¿cola rota?, llamadas al reiniciar con éxito)
TRAS_CAIDA = {
    "antes_del_cerrojo": (None, False, False, 1),
    "antes_de_reservar": (None, False, False, 1),
    "durante_reserva": (None, False, False, 1),
    "durante_calculo": (["RESERVADO", "INTENTO"], False, False, 2),
    "tras_calculo": (["RESERVADO", "INTENTO"], False, False, 2),
    "durante_presellado": (["RESERVADO", "INTENTO"], False, True, 2),
    "tras_presellado": (["RESERVADO", "INTENTO", "PRESELLADO"], False, False, 2),
    "durante_escritura": (["RESERVADO", "INTENTO", "PRESELLADO"], False, False, 2),
    "tras_archivo": (["RESERVADO", "INTENTO", "PRESELLADO"], True, False, 1),
    "durante_registro": (["RESERVADO", "INTENTO", "PRESELLADO", "SELLADO"], True, True, 1),
}


def test_todos_los_puntos_de_fallo_estan_probados() -> None:
    assert set(TRAS_CAIDA) == set(U.PUNTOS_DE_FALLO)


@pytest.mark.parametrize("punto", list(TRAS_CAIDA))
def test_caida_y_reinicio(e: dict, punto: str) -> None:
    ref, ref_sha = referencia(e)
    p = hijo(e, punto=punto)
    p.wait(timeout=60)
    assert p.returncode == 137, p.stderr.read()
    ev, hay_archivo, cola, n_llamadas = TRAS_CAIDA[punto]
    d = Path(e["dir"])
    estado_disco = U.leer(d)
    assert (estado_disco.get("eventos") or None) == ev
    assert (d / U.RESULTADO).exists() == hay_archivo and estado_disco["cola_rota"] == cola
    if not hay_archivo:  # I2: ningún byte del resultado está en disco antes del presellado (o del sellado)
        visibles = b"".join(f.read_bytes() for f in d.iterdir() if f.is_file() and f.name != U.DIARIO)
        assert b"p_mayor_que_cero" not in visibles or punto == "durante_escritura"
    if punto == "durante_escritura":  # temporal a medias, posterior al presellado
        assert list(d.glob(".resultado.json.*.tmp"))
    s = correr(e)
    assert (s.estado, s.resultado, s.resultado_sha256) == ("REGISTRADO", ref, ref_sha)
    assert llamadas(e) == n_llamadas
    fin = U.leer(d)
    assert fin["estado"] == "REGISTRADO" and fin["archivo_coincide"] and sin_temporales(e["dir"])
    assert fin["eventos"].count("PRESELLADO") == 1 and fin["eventos"][-1] == "REGISTRADO"
    assert ("COLA_ROTA_DESCARTADA" in fin["eventos"]) == cola


# Con un cálculo NO determinista, ¿qué ocurre al reiniciar tras cada caída?
NO_DET = {"durante_calculo": "REGISTRADO", "tras_calculo": "REGISTRADO",  # nada se observó: se calcula una vez
          "durante_presellado": "REGISTRADO",
          "tras_presellado": "CONFLICTO", "durante_escritura": "CONFLICTO",  # presellado: el recálculo no coincide
          "tras_archivo": "REGISTRADO", "durante_registro": "REGISTRADO"}  # el archivo sellado manda; no se recalcula


@pytest.mark.parametrize("punto", list(NO_DET))
def test_caida_con_calculo_no_determinista_nunca_sustituye_un_resultado_presellado(e: dict, punto: str) -> None:
    p = hijo(e, punto=punto, modo="no_determinista")
    p.wait(timeout=60)
    assert p.returncode == 137
    pre = U.leer(e["dir"]).get("presellado")
    s = correr(e, modo="no_determinista")
    assert s.estado == NO_DET[punto]
    if pre is not None:  # si había presellado, o se entrega ESE resultado o ninguno
        assert s.resultado_sha256 in (pre, None)
    if s.estado == "CONFLICTO":
        assert s.resultado is None and not (Path(e["dir"]) / U.RESULTADO).exists()
        n = llamadas(e)
        for _ in range(3):  # terminal: no se vuelve a calcular
            assert correr(e, modo="no_determinista").estado == "CONFLICTO"
        assert llamadas(e) == n


def test_muerte_con_sigkill_durante_el_calculo_libera_el_cerrojo(e: dict) -> None:
    ref, ref_sha = referencia(e)
    p = hijo(e, modo="lento")
    limite = time.time() + 30
    while llamadas(e) == 0 and time.time() < limite:
        time.sleep(0.01)
    assert correr(e).estado == "OCUPADO"  # mientras calcula, nadie más entra
    p.send_signal(signal.SIGKILL)
    p.wait(timeout=30)
    s = correr(e)
    assert (s.estado, s.resultado_sha256, llamadas(e)) == ("REGISTRADO", ref_sha, 2)


# ---------- integridad ----------
def test_borrar_el_resultado_no_da_otra_extraccion(e: dict) -> None:
    s = correr(e)
    (Path(e["dir"]) / U.RESULTADO).unlink()
    r = correr(e)  # determinista: se restaura EXACTAMENTE el mismo
    assert (r.estado, r.resultado_sha256) == ("REGISTRADO", s.resultado_sha256)
    assert eventos(e)[-2:] == ["INTENTO", "RESTAURADO"]
    (Path(e["dir"]) / U.RESULTADO).unlink()
    c = correr(e, modo="no_determinista")  # un cálculo que daría otro número: conflicto, nunca otro resultado
    assert (c.estado, c.resultado) == ("CONFLICTO", None)
    assert correr(e).estado == "CONFLICTO"  # terminal, aunque luego se use el cálculo determinista


def test_resultado_alterado_es_corrupto_y_terminal(e: dict) -> None:
    s = correr(e)
    ruta = Path(e["dir"]) / U.RESULTADO
    original = ruta.read_bytes()
    ruta.write_bytes(original.replace(b'"n":40', b'"n":41'))
    assert correr(e).estado == "CORRUPTO"
    ruta.write_bytes(original)  # aunque se reponga, queda constancia y el estado es terminal
    r = correr(e)
    assert (r.estado, r.resultado) == ("CORRUPTO", None) and llamadas(e) == 1 and s.estado == "REGISTRADO"


@pytest.mark.parametrize("edicion", ["cambiar_hash", "borrar_linea", "reordenar", "espacios", "basura"])
def test_diario_editado_es_inconsistente_y_no_se_escribe(e: dict, edicion: str) -> None:
    correr(e)
    ruta = Path(e["dir"]) / U.DIARIO
    lineas = ruta.read_bytes().split(b"\n")[:-1]
    if edicion == "cambiar_hash":
        ev = json.loads(lineas[2])
        ev["datos"]["resultado_sha256"] = "0" * 64
        lineas[2] = json.dumps(ev, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    elif edicion == "borrar_linea":
        del lineas[1]
    elif edicion == "reordenar":
        lineas[1], lineas[2] = lineas[2], lineas[1]
    elif edicion == "espacios":
        lineas[1] = lineas[1].replace(b",", b", ", 1)
    else:
        lineas.insert(2, b"{}")
    ruta.write_bytes(b"\n".join(lineas) + b"\n")
    antes = ruta.read_bytes()
    s = correr(e)
    assert (s.estado, s.resultado) == ("INCONSISTENTE", None)
    assert ruta.read_bytes() == antes and llamadas(e) == 1


def test_reescritura_coherente_del_diario_se_detecta_por_el_resultado(e: dict) -> None:
    """Un diario reescrito ENTERO con hashes válidos pero otro presellado: el archivo sellado no coincide."""
    correr(e)
    ruta = Path(e["dir"]) / U.DIARIO
    evs = [json.loads(x) for x in ruta.read_bytes().split(b"\n")[:-1]]
    falso, anterior, salida = "f" * 64, None, b""
    for ev in evs:
        if "resultado_sha256" in ev["datos"]:
            ev["datos"]["resultado_sha256"] = falso
        ev["anterior"] = anterior
        crudo = json.dumps(ev, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        anterior = U._sha(crudo)
        salida += crudo + b"\n"
    ruta.write_bytes(salida)
    assert correr(e).estado == "CORRUPTO"


def test_resultado_sin_diario_es_inconsistente(e: dict) -> None:
    correr(e)
    (Path(e["dir"]) / U.DIARIO).unlink()
    s = correr(e)
    assert (s.estado, s.resultado) == ("INCONSISTENTE", None) and llamadas(e) == 1


def test_temporal_huerfano_nunca_se_lee(e: dict) -> None:
    ref, ref_sha = referencia(e)
    p = hijo(e, punto="tras_presellado")
    p.wait(timeout=60)
    falso = Path(e["dir"]) / ".resultado.json.99999.tmp"
    falso.write_bytes(b'{"media":1.0,"n":40,"p_mayor_que_cero":1.0}')  # un resultado «favorable» plantado
    s = correr(e)
    assert (s.estado, s.resultado_sha256) == ("REGISTRADO", ref_sha) and not falso.exists()


# ---------- entradas ligadas a la reserva ----------
def test_entradas_o_semilla_cambiadas_tras_la_reserva_se_rechazan(e: dict) -> None:
    ref, ref_sha = referencia(e)
    p = hijo(e, punto="durante_calculo")
    p.wait(timeout=60)
    datos = Path(e["archivos"]["datos"])
    original = datos.read_bytes()
    datos.write_bytes(original + b" 0.5")  # otros datos
    assert correr(e).estado == "RECHAZADO"
    datos.write_bytes(original)
    assert correr(e, semilla=8).estado == "RECHAZADO"  # otra semilla
    assert llamadas(e) == 1  # solo la del hijo que murió: con entradas distintas no se calcula
    assert eventos(e).count("RECHAZADO_ENTRADAS_DISTINTAS") == 2
    s = correr(e)  # con las entradas reservadas, se reanuda
    assert (s.estado, s.resultado_sha256) == ("REGISTRADO", ref_sha)
    assert correr(e, semilla=8).estado == "RECHAZADO" and correr(e).resultado_sha256 == ref_sha


# ---------- concurrencia con procesos reales ----------
def test_concurrencia_un_solo_calculo(e: dict) -> None:
    ref, ref_sha = referencia(e)
    inicio = time.time() + 1.0
    ps = [hijo(e, modo="lento", esperar_hasta=inicio) for _ in range(8)]
    salidas = [json.loads(p.communicate(timeout=120)[0]) for p in ps]
    estados = sorted(s["estado"] for s in salidas)
    assert set(estados) <= {"REGISTRADO", "OCUPADO"} and llamadas(e) == 1
    registrados = [s for s in salidas if s["estado"] == "REGISTRADO"]
    assert sum(s["calculado"] for s in registrados) == 1
    assert {s["resultado_sha256"] for s in registrados} == {ref_sha}
    assert correr(e).resultado_sha256 == ref_sha and llamadas(e) == 1


def test_concurrencia_con_registro_global_dos_directorios(e: dict) -> None:
    """Dos directorios y dos nombres con las MISMAS entradas, a la vez: solo uno reserva y calcula."""
    reg = str(e["tmp"] / "global" / "REGISTRO_GLOBAL.jsonl")
    inicio = time.time() + 1.0
    a = hijo(e, modo="lento", esperar_hasta=inicio, registro_global=reg)
    b = hijo({**e, "dir": str(e["tmp"] / "estado_b"), "experimento": "SINTETICO-1-bis", "semilla": 99},
             modo="lento", esperar_hasta=inicio, registro_global=reg)
    sa, sb = (json.loads(p.communicate(timeout=120)[0]) for p in (a, b))
    assert sorted([sa["estado"], sb["estado"]]) == ["RECHAZADO", "REGISTRADO"] and llamadas(e) == 1


# ---------- registro global: borrar el estado local no da otra extracción ----------
def test_registro_global_impide_reejecutar_tras_borrar_el_estado(e: dict) -> None:
    reg = e["tmp"] / "global" / "REGISTRO_GLOBAL.jsonl"
    s = correr(e, registro_global=reg)
    assert s.estado == "REGISTRADO"
    import shutil
    shutil.rmtree(e["dir"])
    r = correr(e, registro_global=reg)
    assert r.estado == "RECHAZADO" and "falta su estado local" in r.detalle
    r = correr(e, registro_global=reg, dir=e["tmp"] / "otro", experimento="SINTETICO-1-v2", semilla=8)
    assert r.estado == "RECHAZADO" and "mismas entradas" in r.detalle  # renombrar y cambiar semilla no sirve
    assert llamadas(e) == 1
    evs = [json.loads(x)["evento"] for x in reg.read_bytes().split(b"\n")[:-1]]
    assert evs == ["RESERVA", "RESULTADO"]


def test_registro_global_detecta_un_resultado_local_sustituido(e: dict) -> None:
    """Diario local y resultado reescritos de forma coherente: solo el ancla de fuera lo detecta."""
    reg = e["tmp"] / "global" / "REGISTRO_GLOBAL.jsonl"
    correr(e, registro_global=reg)
    d = Path(e["dir"])
    otro = b'{"media":1.0,"n":40,"p_mayor_que_cero":1.0}'
    (d / U.RESULTADO).write_bytes(otro)
    evs = [json.loads(x) for x in (d / U.DIARIO).read_bytes().split(b"\n")[:-1]]
    anterior, salida = None, b""
    for ev in evs:
        if "resultado_sha256" in ev["datos"]:
            ev["datos"]["resultado_sha256"] = U._sha(otro)
        ev["anterior"] = anterior
        crudo = json.dumps(ev, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        anterior = U._sha(crudo)
        salida += crudo + b"\n"
    (d / U.DIARIO).write_bytes(salida)
    s = correr(e, registro_global=reg)
    assert (s.estado, s.resultado) == ("INCONSISTENTE", None) and "otro" in s.detalle


def test_limitacion_sin_ancla_externa_borrar_todo_permite_repetir(e: dict) -> None:
    """LÍMITE CONOCIDO, no un éxito: sin registro global (o borrándolo también), nada local puede detectar que el
    experimento ya se ejecutó. Hace falta un ancla externa (p. ej., publicar el hash de la reserva)."""
    import shutil
    correr(e)
    shutil.rmtree(e["dir"])
    assert correr(e).estado == "REGISTRADO" and llamadas(e) == 2
