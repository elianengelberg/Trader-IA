"""Prototipo AISLADO de ejecución de uso único (P4). Solo biblioteca estándar.

No está integrado en ``papel/corte.py`` ni en ``experimentos/fuera_de_muestra_T.py`` y no debe integrarse sin
autorización. Garantía buscada: un experimento se calcula con entradas fijadas de antemano, y ningún resultado
observado puede sustituirse por otro (más favorable) repitiendo la ejecución, borrando o alterando archivos.
Estados, invariantes I1–I10, pseudocódigo y límites: ESTADO_Y_INVARIANTES.md.

Archivos en ``dir_estado``: DIARIO.jsonl (solo añadidos, encadenado por hash), resultado.json, .cerrojo.
``registro_global`` (opcional) es un segundo diario, fuera de ``dir_estado``, con las reservas y resultados de todos
los experimentos: detecta un estado local borrado y la misma entrada reservada con otro nombre o semilla.
"""
from __future__ import annotations

import datetime as dt
import fcntl
import hashlib
import json
import os
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

DIARIO, RESULTADO, CERROJO = "DIARIO.jsonl", "resultado.json", ".cerrojo"
ERRORES_TERMINALES = ("CONFLICTO", "CORRUPTO", "INCONSISTENTE")
# Puntos donde las pruebas matan el proceso (os._exit, sin finally ni vaciado de búferes). «durante_calculo» lo
# provoca la propia función de cálculo de las pruebas.
PUNTOS_DE_FALLO = ("antes_del_cerrojo", "antes_de_reservar", "durante_reserva", "durante_calculo", "tras_calculo",
                   "durante_presellado", "tras_presellado", "durante_escritura", "tras_archivo", "durante_registro")


@dataclass
class Salida:
    estado: str  # REGISTRADO | OCUPADO | RECHAZADO | CONFLICTO | CORRUPTO | INCONSISTENTE
    resultado: dict | None = None
    resultado_sha256: str | None = None
    calculado: bool = False  # True si esta llamada ejecutó la función de cálculo
    detalle: str = ""


class _CadenaRota(Exception):
    pass


def _nada(_punto: str) -> None:
    return None


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _canon(x: object) -> bytes:
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def _ahora() -> str:
    return dt.datetime.now(dt.UTC).isoformat(timespec="microseconds")


def _fsync_dir(d: Path) -> None:
    fd = os.open(d, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


# ---------- diario encadenado ----------
def _leer_cadena(ruta: Path) -> tuple[list[dict], list[bytes], bytes]:
    """(eventos, líneas crudas, cola sin salto de línea). Lanza _CadenaRota si algo no encadena."""
    if not ruta.exists():
        return [], [], b""
    *completas, cola = ruta.read_bytes().split(b"\n")
    eventos: list[dict] = []
    anterior = None
    for i, crudo in enumerate(completas):
        try:
            ev = json.loads(crudo)
        except ValueError as e:
            raise _CadenaRota(f"{ruta.name}: línea {i + 1} ilegible") from e
        if not isinstance(ev, dict) or ev.get("n") != i or ev.get("anterior") != anterior or _canon(ev) != crudo:
            raise _CadenaRota(f"{ruta.name}: cadena rota en la línea {i + 1}")
        eventos.append(ev)
        anterior = _sha(crudo)
    return eventos, completas, cola


def _anotar(ruta: Path, lineas: list[bytes], eventos: list[dict], evento: str, datos: dict,
            fallo: Callable[[str], None] = _nada, punto: str | None = None, crear: bool = False) -> None:
    ev = {"n": len(lineas), "evento": evento, "utc": _ahora(), "datos": datos,
          "anterior": _sha(lineas[-1]) if lineas else None}
    linea = _canon(ev)
    fd = os.open(ruta, os.O_WRONLY | os.O_APPEND | (os.O_CREAT if crear else 0), 0o644)
    try:
        if punto:  # media línea en disco antes del punto de fallo: así se prueba una línea rota de verdad
            os.write(fd, linea[: len(linea) // 2])
            os.fsync(fd)
            fallo(punto)
            os.write(fd, linea[len(linea) // 2:] + b"\n")
        else:
            os.write(fd, linea + b"\n")
        os.fsync(fd)
    finally:
        os.close(fd)
    lineas.append(linea)
    eventos.append(ev)


def _descartar_cola(ruta: Path, lineas: list[bytes], eventos: list[dict], cola: bytes) -> None:
    """Una línea a medias solo puede ser la última (escritura interrumpida). Se recorta y su contenido queda anotado."""
    with open(ruta, "r+b") as fh:
        fh.truncate(sum(len(x) + 1 for x in lineas))
        fh.flush()
        os.fsync(fh.fileno())
    _anotar(ruta, lineas, eventos, "COLA_ROTA_DESCARTADA",
            {"bytes": len(cola), "sha256": _sha(cola), "contenido": cola.decode("utf-8", "replace")})


def _validar_secuencia(eventos: list[dict]) -> None:
    if not eventos:
        return
    tipos = [e["evento"] for e in eventos]
    if tipos[0] != "RESERVADO" or tipos.count("RESERVADO") != 1:
        raise _CadenaRota("el diario no empieza por una única reserva")
    pres = [e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"]
    if len(pres) > 1:
        raise _CadenaRota("más de un presellado")
    for i, e in enumerate(eventos):
        if e["evento"] in ("SELLADO", "RESTAURADO", "REGISTRADO") and (
                not pres or e["datos"]["resultado_sha256"] != pres[0] or "PRESELLADO" not in tipos[:i]):
            raise _CadenaRota(f"{e['evento']} sin presellado coherente (línea {i + 1})")
        if e["evento"] == "REGISTRADO" and "SELLADO" not in tipos[:i]:
            raise _CadenaRota(f"REGISTRADO sin SELLADO previo (línea {i + 1})")
    terminal = next((i for i, t in enumerate(tipos) if t in ERRORES_TERMINALES), None)
    if terminal is not None and any(t != "INTENTO" for t in tipos[terminal + 1:]):
        raise _CadenaRota("hay eventos después de un estado terminal")


def estado_actual(eventos: list[dict]) -> str:
    if not eventos:
        return "NUEVO"
    tipos = {e["evento"] for e in eventos}
    for t in (*ERRORES_TERMINALES, "REGISTRADO", "SELLADO", "PRESELLADO"):
        if t in tipos:
            return t
    return "RESERVADO"


# ---------- escrituras atómicas ----------
def _reservar(d: Path, reserva: dict, fallo: Callable[[str], None]) -> None:
    """La primera línea del diario se escribe completa en un temporal y se enlaza: o existe entera o no existe."""
    tmp = d / f".{DIARIO}.{os.getpid()}.tmp"
    with open(tmp, "wb") as fh:
        fh.write(_canon({"n": 0, "evento": "RESERVADO", "utc": _ahora(), "datos": reserva, "anterior": None}) + b"\n")
        fh.flush()
        os.fsync(fh.fileno())
    fallo("durante_reserva")
    try:
        os.link(tmp, d / DIARIO)  # exclusivo: falla si el diario ya existe
    finally:
        tmp.unlink()
    _fsync_dir(d)


def _escribir_atomico(ruta: Path, datos: bytes, fallo: Callable[[str], None]) -> None:
    tmp = ruta.with_name(f".{ruta.name}.{os.getpid()}.tmp")
    with open(tmp, "wb") as fh:
        fh.write(datos[: len(datos) // 2])
        fh.flush()
        os.fsync(fh.fileno())
        fallo("durante_escritura")
        fh.write(datos[len(datos) // 2:])
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, ruta)
    _fsync_dir(ruta.parent)


# ---------- registro global (ancla fuera del directorio de estado) ----------
def _global(ruta: Path, reserva: dict, reserva_sha: str, crear_local: Callable[[], None] | None = None,
            resultado_sha: str | None = None) -> tuple[str, str] | None:
    """Con el cerrojo del registro global: rechaza otra reserva del mismo experimento o de las mismas entradas, una
    reserva cuyo estado local desapareció y un resultado distinto del ya anotado. Anota lo que falte."""
    ruta.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(f"{ruta}.cerrojo", os.O_CREAT | os.O_RDWR, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        eventos, lineas, cola = _leer_cadena(ruta)
        if cola:
            _descartar_cola(ruta, lineas, eventos, cola)
        propios = [e for e in eventos if e["datos"].get("reserva_sha256") == reserva_sha]
        for e in eventos:
            x = e["datos"]
            if e["evento"] == "RESERVA" and x["reserva_sha256"] != reserva_sha:
                if x["experimento"] == reserva["experimento"]:
                    return "RECHAZADO", f"registro global: {x['experimento']} ya tiene otra reserva (semilla {x['semilla']})"
                if x["archivos_sha256"] == reserva["archivos_sha256"]:
                    return "RECHAZADO", (f"registro global: las mismas entradas ya están reservadas por "
                                         f"{x['experimento']} (semilla {x['semilla']})")
        if crear_local is not None:
            if propios:
                return "RECHAZADO", "registro global: la reserva ya consta pero falta su estado local; no se recalcula"
            crear_local()
        if not any(e["evento"] == "RESERVA" for e in propios):
            _anotar(ruta, lineas, eventos, "RESERVA", {**reserva, "reserva_sha256": reserva_sha}, crear=True)
        if resultado_sha is not None:
            previos = [e["datos"]["resultado_sha256"] for e in propios if e["evento"] == "RESULTADO"]
            if previos and previos[0] != resultado_sha:
                return "INCONSISTENTE", "registro global: el resultado anotado allí es otro"
            if not previos:
                _anotar(ruta, lineas, eventos, "RESULTADO", {"experimento": reserva["experimento"],
                                                             "reserva_sha256": reserva_sha,
                                                             "resultado_sha256": resultado_sha})
        return None
    except _CadenaRota as e:
        return "INCONSISTENTE", f"registro global: {e}"
    finally:
        os.close(fd)


# ---------- ejecución ----------
def ejecutar(dir_estado: str | Path, experimento: str, archivos: dict[str, str | Path], semilla: int,
             calcular: Callable[[dict[str, bytes], int], dict], registro_global: str | Path | None = None,
             fallo: Callable[[str], None] = _nada) -> Salida:
    """``calcular(contenidos, semilla)`` recibe los bytes ya verificados de ``archivos`` y debe ser determinista."""
    d = Path(dir_estado)
    d.mkdir(parents=True, exist_ok=True)
    fallo("antes_del_cerrojo")
    fd = os.open(d / CERROJO, os.O_CREAT | os.O_RDWR, 0o644)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return Salida("OCUPADO", detalle="otra ejecución tiene el cerrojo; no se calcula")
        return _bajo_cerrojo(d, experimento, archivos, semilla, calcular,
                             Path(registro_global) if registro_global else None, fallo)
    finally:
        os.close(fd)  # libera el cerrojo; si el proceso muere, lo libera el núcleo


def _bajo_cerrojo(d: Path, experimento: str, archivos: dict[str, str | Path], semilla: int,
                  calcular: Callable[[dict[str, bytes], int], dict], glob: Path | None,
                  fallo: Callable[[str], None]) -> Salida:
    ruta = d / DIARIO
    try:
        eventos, lineas, cola = _leer_cadena(ruta)
        if cola:
            _descartar_cola(ruta, lineas, eventos, cola)
        _validar_secuencia(eventos)
    except _CadenaRota as e:
        return Salida("INCONSISTENTE", detalle=str(e))  # no se escribe nada sobre una cadena en la que no se confía
    for t in d.glob(".*.tmp"):  # restos de una escritura interrumpida: nunca se leen
        t.unlink()
    contenidos = {k: Path(p).read_bytes() for k, p in sorted(archivos.items())}
    reserva = {"experimento": experimento, "semilla": semilla,
               "archivos_sha256": {k: _sha(v) for k, v in contenidos.items()}}
    reserva_sha = _sha(_canon(reserva))

    if not eventos:
        if (d / RESULTADO).exists():
            return Salida("INCONSISTENTE", detalle="hay un resultado sin diario")
        fallo("antes_de_reservar")
        if glob is not None:
            problema = _global(glob, reserva, reserva_sha, crear_local=lambda: _reservar(d, reserva, fallo))
            if problema:
                return Salida(problema[0], detalle=problema[1])
        else:
            _reservar(d, reserva, fallo)
        eventos, lineas, _ = _leer_cadena(ruta)

    estado = estado_actual(eventos)
    if estado in ERRORES_TERMINALES:
        _anotar(ruta, lineas, eventos, "INTENTO", {"pid": os.getpid(), "estado_previo": estado})
        motivo = next(e["datos"].get("motivo", "") for e in eventos if e["evento"] == estado)
        return Salida(estado, detalle=motivo)
    if eventos[0]["datos"] != reserva:
        _anotar(ruta, lineas, eventos, "RECHAZADO_ENTRADAS_DISTINTAS", {"ofrecidas": reserva})
        return Salida("RECHAZADO", detalle="las entradas o la semilla no son las reservadas; no se calcula")
    if glob is not None and (problema := _global(glob, reserva, reserva_sha)):
        return Salida(problema[0], detalle=problema[1])
    _anotar(ruta, lineas, eventos, "INTENTO", {"pid": os.getpid(), "estado_previo": estado})

    pre = next((e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"), None)
    calculado, crudo = False, None
    if pre is None:  # RESERVADO: nada se ha observado todavía
        crudo = _canon(calcular(contenidos, semilla))
        calculado = True
        fallo("tras_calculo")
        pre = _sha(crudo)
        _anotar(ruta, lineas, eventos, "PRESELLADO", {"resultado_sha256": pre}, fallo, "durante_presellado")
        fallo("tras_presellado")
    archivo = d / RESULTADO
    if archivo.exists():
        en_disco = archivo.read_bytes()
        if _sha(en_disco) != pre:
            motivo = f"resultado.json ({_sha(en_disco)[:12]}…) no coincide con el presellado ({pre[:12]}…)"
            _anotar(ruta, lineas, eventos, "CORRUPTO", {"motivo": motivo, "encontrado_sha256": _sha(en_disco)})
            return Salida("CORRUPTO", detalle=motivo)
        crudo = en_disco
    else:
        if crudo is None:  # resultado perdido (caída o borrado): solo se acepta el MISMO resultado
            crudo = _canon(calcular(contenidos, semilla))
            calculado = True
            if _sha(crudo) != pre:
                motivo = f"el recálculo ({_sha(crudo)[:12]}…) no reproduce el presellado ({pre[:12]}…)"
                _anotar(ruta, lineas, eventos, "CONFLICTO", {"motivo": motivo, "recalculado_sha256": _sha(crudo)})
                return Salida("CONFLICTO", detalle=motivo)
        _escribir_atomico(archivo, crudo, fallo)
        fallo("tras_archivo")
        if any(e["evento"] == "SELLADO" for e in eventos):  # ya estaba sellado: se repuso el MISMO archivo
            _anotar(ruta, lineas, eventos, "RESTAURADO", {"resultado_sha256": pre})
    if not any(e["evento"] == "SELLADO" for e in eventos):  # también si la caída fue tras escribir el archivo
        _anotar(ruta, lineas, eventos, "SELLADO", {"resultado_sha256": pre})
    if estado != "REGISTRADO":
        _anotar(ruta, lineas, eventos, "REGISTRADO", {"resultado_sha256": pre}, fallo, "durante_registro")
    if glob is not None and (problema := _global(glob, reserva, reserva_sha, resultado_sha=pre)):
        return Salida(problema[0], detalle=problema[1])
    return Salida("REGISTRADO", json.loads(crudo), pre, calculado)


def leer(dir_estado: str | Path) -> dict:
    """Solo lectura: estado del diario, sus eventos y si resultado.json coincide con el presellado."""
    d = Path(dir_estado)
    try:
        eventos, _, cola = _leer_cadena(d / DIARIO)
        _validar_secuencia(eventos)
    except _CadenaRota as e:
        return {"estado": "INCONSISTENTE", "detalle": str(e)}
    pre = next((e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"), None)
    archivo = d / RESULTADO
    return {"estado": estado_actual(eventos), "eventos": [e["evento"] for e in eventos], "cola_rota": bool(cola),
            "presellado": pre, "archivo_coincide": archivo.exists() and _sha(archivo.read_bytes()) == pre}
