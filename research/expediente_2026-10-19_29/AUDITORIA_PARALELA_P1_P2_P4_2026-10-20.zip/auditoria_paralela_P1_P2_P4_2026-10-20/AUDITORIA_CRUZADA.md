# Auditoría cruzada P1 × P2 × P4 (2026-10-20)

**Prueba:** `cruzada/test_interacciones.py`, **11 de 11** pasan (`evidencia/cruzada_pytest.txt`).

**Cadena sintética probada:**
1. **P4 v0.2** reserva y ejecuta `cruzada/codigo_oos_sintetico.py`. Ese código produce un resultado con el **esquema fuera de muestra**, con cifras inventadas, y con los hashes de un árbol de T **sintético** que también se reserva.
2. **P1 v0.2** verifica ese `resultado.json` contra el árbol.
3. **P2 v0.2** lo clasifica.

**Integración mínima propuesta (`cadena`):** solo un REGISTRADO de P4 cuyo archivo coincide con su presellado pasa a P1. P1 recibe ese presellado como hash esperado del archivo. **No está integrada en ningún ejecutor.**

## 1. Interacciones exigidas

| # | Exigencia | Prueba | Resultado |
|---|---|---|---|
| X1 | P1 no declara reproducido un resultado si faltan datos de integridad | `test_X1_sin_integridad_no_hay_verificado` | Sin `--raiz` el nivel es COHERENTE_SIN_INTEGRIDAD. Si falta un manifiesto → AUSENTE. P1 nunca emite «REPRODUCIDO» |
| X2 | P2 no convierte un resultado no verificable en etiqueta | `test_X2_…` (3: sin integridad, contradictorio, código cambiado) | No hay etiqueta: `ErrorVerificacion` o `ErrorPolitica` |
| X3 | P4 no presenta un resultado fallido o incompleto como válido | `test_X3_…` | FALLO_CALCULO y REVISION_HUMANA: sin resultado ni archivo; la cadena se detiene. Un archivo alterado después del registro: la cadena se detiene y P4 pasa a CORRUPTO |
| X4 | Ningún componente modifica el resultado congelado de T | `test_X4_…` | SHA-256 **y `mtime_ns`** de los 13 archivos reales leídos, iguales antes y después de correr P1 y P2 sobre el JSON real. El JSON sigue en `4f8fafde…` |
| X5 | Ningún error técnico habilita una segunda evaluación histórica | `test_X5_…` (3) | P1 y P2 no importan `subprocess`, `runpy`, `importlib` ni `shutil`, no llaman a `exec`, `eval` ni `compile` y no escriben archivos (inspección con `ast`). P4 solo lanza su propio hijo de cálculo y no nombra a ningún ejecutor de T fuera de su docstring. Después de un rechazo de P1, repetir P4 no recalcula, y «arreglar» las entradas da RECHAZADO |
| X6 | Ningún diagnóstico de robustez autoriza automáticamente la etapa siguiente | `test_X6_…` | Etiqueta RESPALDADA con R1 y R3 en CUMPLE (definiciones **sintéticas**) da ROBUSTA y CANDIDATA_A_REVISION_HUMANA, con la autorización en **NO_OTORGADA**. P4 no tiene ningún campo de autorización |
| — | La cadena válida | `test_cadena_valida` | VERIFICADO → EVIDENCIA INSUFICIENTE / NO_CANDIDATA / NO_OTORGADA. El hash verificado por P1 es igual al presellado de P4 |

## 2. Hallazgo nuevo de la auditoría cruzada
**X-1 (registrado como D10 en el dictamen de P1, gravedad alta).**
- **Qué falla:** si `resultado.json` se altera **de forma coherente** (P = 0,755 → 0,999; con P de BTC = 0,8355 la decisión sigue siendo EVIDENCIA INSUFICIENTE), **P1 sola lo da por VERIFICADO**. P1 comprueba el resultado contra el árbol de T, pero no conoce el hash que P4 preselló. P4 sí lo detecta (CORRUPTO).
- **Corrección propuesta:**
  - P1 v0.2 acepta `resultado_sha256_esperado` (`--resultado-sha256`);
  - P2 lo transmite;
  - la cadena lo toma del presellado de P4, o de su ancla.
- **Pruebas:** `test_X3_…` (cruzada) y `p1/test_v0_2.py::test_X1_resultado_sha256_esperado`.
- **Límite:** el resultado fuera de muestra de T **ya existente** no tiene presellado ni ancla. Para ese archivo, la referencia es el hash registrado en `ARTEFACTOS_SHA256.txt` (`4f8fafde…`), que a su vez depende de publicar los commits (D-G6).

## 3. Lo que no se pudo probar sin datos reales ni autorización
- **La cadena con el resultado real de T pasando por P4:** no aplica, porque P4 no se integró y el fuera de muestra no puede volver a ejecutarse.
- **Un ancla externa real.**
- **La salida humana de REVISION_HUMANA.**

## 4. Cierre por componente

| Componente | Estado | Evidencia | Riesgo residual | Cambio propuesto | Autorización requerida |
|---|---|---|---|---|---|
| **P1** verificador | v0.1 auditada: **10 defectos confirmados** (D1–D10) y 5 candidatos descartados. **v0.2 propuesta**, probada, **no aplicada** | 15 sondas; 152 pruebas de v0.2; el JSON real VERIFICADO desde archivos; parche aplicable en `692f2b2` (145 pasan / 7 omitidas) y en `c6339e3` (140 / 12) | VERIFICADO ≠ auténtico ≠ reproducido. Los bytes de los datos reales no se leyeron. `corte.py` sin commit. Los artefactos de T solo están en commits locales | `P1_verificador_v0.2.patch`: 4 archivos nuevos en `research/tendencia_btc/verificacion/` | Aplicar el parche y hacer commit. ¿Se permite el SHA-256 de los bytes de datos reales? Publicar los commits (D-G6) |
| **P2** política | v0.1 auditada: **5 defectos** (D1–D5) y 3 candidatos descartados. **v0.2 propuesta**, **no aprobada** | 8 sondas; 129 pruebas; tabla de 63 filas verificada; el resultado real da EVIDENCIA INSUFICIENTE / INDETERMINADA / NO_CANDIDATA / NO_DEFINIDA / NO_OTORGADA | Los registros de definiciones y de etapas son diccionarios en código. `aprobada_utc` es un dato declarado. «Candidata» podría malinterpretarse | `POLITICA_AVANCE_T_v0.2.md` y su implementación | Aprobar la v0.2. Decidir A1–A8 (definiciones de R1 y R3, veto, etapa siguiente, regla de combinación, fecha de corte post hoc, δ y robustez económica) |
| **P4** uso único | v0.1 auditada: **6 defectos** (D1–D6, entre ellos la sustitución de un resultado observado tras restaurar el estado) y 3 protecciones confirmadas. **v0.2 propuesta**, **no integrada** | 12 sondas; 98 pruebas (2 omitidas) estables en 4 corridas; 7 de 7 mutantes dirigidos; 3 límites demostrados | **Sin ancla externa no hay protección** contra quien borra o restaura todo el estado. Corte de energía no probado. Canales laterales del código reservado | `uso_unico.py` v0.2 e interfaz de ancla (`ESTADO_Y_INVARIANTES_v0.2.md` §4) | Elegir e implementar un ancla externa y publicar hashes. Integrarlo en un ejecutor. Valor de `reintentos_tras_inicio`. Protocolo de REVISION_HUMANA |
| **Cruzada** | 6 interacciones probadas y 1 hallazgo (X-1) corregido en las propuestas | 11 pruebas | La cadena sigue siendo una propuesta de integración | Función `cadena` (prueba) como contrato P4 → P1 → P2 | Su integración |
