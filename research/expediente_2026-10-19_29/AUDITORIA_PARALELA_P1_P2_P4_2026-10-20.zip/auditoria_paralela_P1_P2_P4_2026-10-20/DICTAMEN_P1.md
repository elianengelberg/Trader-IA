# Dictamen P1: verificador de reproducción de T (2026-10-20)

**Objeto:** `00_entrega_original/p1/` (v0.1: verificador, pruebas, parche y evidencias). Se revisaron todos esos archivos; no hubo ninguno faltante.

**Revisor:** el mismo agente que escribió v0.1. Es una **auto-auditoría adversarial** con sondas ejecutables. **No es una revisión independiente por un tercero**, que sigue pendiente.

**Veredicto:** v0.1 **no debe usarse como verificador de integridad**.
- **Defectos confirmados:** 9 (D1–D9), más **D10**, que salió de la auditoría cruzada. Dos son graves: D1 y D2.
  - **D1:** la línea de comandos dice «VERIFICADO» sin comprobar ningún archivo.
  - **D2:** el código y los manifiestos se comparan contra constantes, nunca contra los archivos.
- **v0.2 (propuesta):** corrige los diez. Sigue siendo un verificador de **coherencia e integridad**, no de reproducción.
- **Validez del resultado congelado de T:** lo que se verificó es que el JSON registrado coincide con los archivos de T del árbol local. **No** prueba que ese árbol sea auténtico frente a terceros; para eso hace falta publicar los commits (D-G6).

## 1. Hallazgos

### A. Esquemas: confirmado por inspección del código real

| Campo | Papel (`tendencia.papel.evaluar`; `corte.py` lo envuelve en `evaluacion`) | Fuera de muestra (`fuera_de_muestra_T.py` → JSON) |
|---|---|---|
| Decisión | `decision`: texto de `decidir` (4 valores) | `decision_prerregistrada`: texto de `decision` (3 valores) |
| P del conjunto | `bootstrap_conjunto.p_mayor_que_cero`, o ausente si `aplicable: false` | `principal.conjunto.p` |
| P de BTC | `bootstrap_btc.p_mayor_que_cero` | `principal.BTC.p` |
| `prerregistro_sha256` | **Hash canónico de las reglas**: `hash_prerregistro()`, JSON ordenado de `PRERREGISTRO_PAPEL` → `d2e4e1fb…` | **SHA-256 del archivo** `PRERREGISTRO_FUERA_DE_MUESTRA_T.md` → `94a16556…` |
| `codigo_sha256` | `huella_codigo()`: SHA-256 de cada `src/tendencia/*.py` ordenado, como nombre + `\0` + bytes | Constante `CODIGO` escrita en el script. El script se niega a correr si `huella_codigo() ≠ CODIGO` |
| Manifiestos | `datos_sha256` del corte (no verificados en P1) | `manifiestos_sha256.{BTCUSDT, ETHUSDT}` = SHA-256 de `datos/<S>/MANIFIESTO.json` |

- **Los dos `prerregistro_sha256` son objetos distintos:** reglas canónicas frente a archivo .md. v0.1 y v0.2 los tratan por separado (`HASH_SEMANTICA`).
- **Valor por defecto 0,5** en `papel.py:153` (`b.get("p_mayor_que_cero", 0.5)`), en código congelado que no se modifica.
  - Solo se activa si el bootstrap no es aplicable (menos de 40 días). En ese caso hay menos de 12 meses y la decisión es INFORMATIVO de todos modos, así que hoy no cambia ninguna decisión.
  - El verificador nunca usa valores por defecto. Un bootstrap no aplicable con 12 meses o más da CONTRADICCION.

### B. Defectos confirmados en v0.1
Cada defecto lo demuestra una sonda ejecutada sobre la copia preservada (`p1/test_sondas_defectos_v0_1.py`, 15 de 15 pasan).

| # | Gravedad | Defecto | Sonda | Corrección v0.2 |
|---|---|---|---|---|
| D1 | **Alta** | La línea de comandos dice **VERIFICADO** sin comprobar ningún hash contra ningún archivo | `test_D1_…` | Dos niveles: `COHERENTE_SIN_INTEGRIDAD` (salida 3) y `VERIFICADO` (salida 0, exige `--raiz`) |
| D2 | **Alta** | El código y los manifiestos solo se comparan contra **constantes** («esperados»). Con el código o el manifiesto cambiados en disco, v0.1 verifica igual. La huella del código no se puede verificar por archivo | `test_D2_…` | La huella se recalcula con el algoritmo de `huella_codigo`; el hash de las reglas, desde `prerregistro_papel.json`; los manifiestos y el script, desde sus archivos. Los «esperados» pasan a ser referencias declaradas y no cuentan para VERIFICADO |
| D3 | Media | Un corte EVALUADO con `problemas` no vacíos se acepta. `corte.py` solo evalúa sin problemas | `test_D3_…` | CONTRADICCION |
| D4 | Media | Un estado desconocido, «NO EVALUABLE» sin problemas o «SIN OBSERVACIONES» con el corte posterior al inicio pasan como «no evaluable». **Un resultado evaluado al que se le quita la evaluación queda disfrazado de no evaluable** | `test_D4_…` (3 casos) | VALOR o CONTRADICCION; solo un estado provisional coherente da NO_EVALUABLE |
| D5 | Baja | Un resultado no evaluable sale como RECHAZADO, con la misma salida que un archivo alterado | `test_D5_…` | Resultado `NO_EVALUABLE`, salida 4 |
| D6 | Media | `REGISTRO.jsonl` de los cortes no se comprueba: un `resultado.json` alterado en un campo no verificado pasa. Probado con el **productor real** y una fuente simulada | `test_D6_…` | `--registro`: cadena `linea_anterior_sha256` y una línea con el SHA-256 de este archivo y su estado. EVALUADO único y último. Un corte sin registro no llega a VERIFICADO |
| D7 | Media | La ventana y los días no se comparan con los del prerregistro: un resultado de otra ventana verifica | `test_D7_…` | `ventana = principal.ventana`. Con `--raiz`, DESDE, HASTA y DIAS se leen con `ast` del script **cuyo hash se acaba de verificar** (no son constantes del verificador) |
| D8 | Media | Claves JSON duplicadas: `json.load` se queda con la última y un lector humano ve la primera | `test_D8_…` | `CLAVE_DUPLICADA` |
| D9 | Baja | El informe no identifica qué archivo se verificó | `test_D9_…` | `resultado_sha256` en el informe |
| D10 | **Alta** (auditoría cruzada, X-1) | Un `resultado.json` alterado **de forma coherente** (por ejemplo, P = 0,755 → 0,999 con la misma decisión) verifica, porque P1 no conoce el hash presellado por P4 | `cruzada/test_interacciones.py::test_X3_…` y `p1/test_v0_2.py::test_X1_…` | `resultado_sha256_esperado` / `--resultado-sha256`. P2 y la cadena lo pasan desde el presellado de P4 |

### C. Candidatos descartados (no son defectos)

| # | Candidato | Sonda |
|---|---|---|
| N1 | Tratar como equivalentes hashes de distinto significado | `test_N1_…`: v0.1 ya da HASH_SEMANTICA |
| N2 | El verificador usa P = 0,5 por defecto | `test_N2_…`: v0.1 da AUSENTE |
| N3 | Un JSON truncado se acepta | `test_N3_…`: LECTURA |
| N4 | Un resultado negativo evaluado se confunde con uno no evaluable | `test_N4_…`: NO RESPALDADA se verifica como decisión |
| N5 | Las reglas replicadas difieren de las congeladas | La prueba de rejilla (`test_reglas_identicas_a_las_congeladas`) las compara, extraídas con `ast` sin ejecutar los módulos: idénticas |

### D. Compatibilidad del parche
Detalle en `evidencia/p1_compatibilidad_parche_v0.2.txt`.

| Base | Artefactos fuera de muestra de T | `corte.py` | `git apply --check` | Suite del parche en la copia |
|---|---|---|---|---|
| HEAD `692f2b2` (local, sin publicar) | Presentes | **Ausente** (sin commit) | OK | **145 pasan y 7 se omiten** (las que necesitan `corte.py`) |
| origin `c6339e3` | **Ausentes** | Ausente | OK | **140 pasan y 12 se omiten** |

- **Agrega 4 archivos nuevos** en `research/tendencia_btc/verificacion/` y no modifica ningún archivo existente.
- **Fuera de la recolección por defecto:** `pyproject.toml` tiene `testpaths = ["tests"]`, así que la carpeta no se recoge con un `pytest` sin argumentos; hay que correrla explícitamente.
- **`corte.py` y su prueba** existen solo en el árbol de trabajo, sin commit. Su SHA-256 actual es `b5bc9a59…`, el registrado.

## 2. Separación de la evidencia

| Categoría | Contenido |
|---|---|
| **Confirmado por inspección** | Los esquemas y el significado de cada campo (§A). `codigo_sha256` es una constante del script, comprobada en tiempo de ejecución. El 0,5 por defecto (`papel.py:153`). `corte.py` solo evalúa sin problemas. El formato y la cadena de `REGISTRO.jsonl`. En origin no hay artefactos fuera de muestra |
| **Confirmado mediante pruebas ejecutadas** | D1–D9 presentes en v0.1 (15 sondas). v0.2 los corrige: **167 de 167** pasan en `p1/` (15 sondas más 152 de la suite portada y las pruebas nuevas, incluida D10). La huella de v0.2 es igual a la de `huella_codigo` congelado sobre el `src/` real (`73b22f3e…`). El hash de las reglas desde el JSON es `d2e4e1fb…`. **El JSON real** (`4f8fafde…`) da **VERIFICADO** con `--raiz`: 5 hashes recalculados desde archivos, más la ventana y los días; la decisión registrada coincide con la recalculada (EVIDENCIA INSUFICIENTE). La salida del productor real de cortes (fuente simulada) da VERIFICADO con `--registro`, y 5 alteraciones del archivo o del registro se rechazan. El parche se aplica en las dos bases |
| **Inferido** | Con los parámetros congelados, el 0,5 por defecto no puede cambiar ninguna decisión (derivado de bloque = 20 → mínimo 40 días → menos de 12 meses) |
| **No comprobado** | Los **bytes de los archivos de datos** listados en los manifiestos reales: no se leyeron, por la restricción 1 interpretada de forma conservadora. `--datos` solo se probó con datos sintéticos. `datos_sha256` y `decisiones_sha256` de los cortes. El `inicio` del papel frente al prerregistro. **La autenticidad del árbol local frente a terceros.** Una revisión por un tercero |
| **Pendiente de autorización** | Aplicar `P1_verificador_v0.2.patch` al repositorio. Decidir si el SHA-256 de los bytes de los archivos de datos reales (sin interpretarlos) está permitido. Publicar los commits locales (D-G6) |

## 3. Riesgos residuales
1. **VERIFICADO no significa AUTÉNTICO.** Un árbol de T fabricado de forma coherente (resultado, script, código y manifiestos) verifica. Sin un ancla externa (commits publicados), nadie fuera de esta máquina puede distinguirlo.
2. **VERIFICADO no significa REPRODUCIDO.** «Reproducido» exige `comparar(resultado, reproducción_independiente) == []`, y en T eso implicaría recalcular sobre datos fuera de muestra. **No se hizo y no debe hacerse sin autorización.** La reproducción del 2026-10-17 (`revision_fuera_de_muestra_T.json`, `identico_al_json: true`) es anterior y no se repitió.
3. **La huella del código cubre solo `src/tendencia/*.py`.** No cubre `hcarry/lab/estadistica.py` (el bootstrap) ni el intérprete. Así lo define el propio protocolo.
4. **Lo que el verificador lee del script con `ast`:** solo DESDE, HASTA y DIAS. Los parámetros del bootstrap (bloque, n, semilla) no figuran en el resultado y no se verifican.

## 4. Archivos (hashes en `SHA256SUMS.txt`)
| Archivo | Rol |
|---|---|
| `p1/verificar_reproduccion_T.py` | v0.2 (propuesta) |
| `p1/fabricas.py`, `p1/test_v0_2.py` | Fábricas sintéticas y pruebas de las correcciones |
| `p1/test_verificar_reproduccion_T.py` | Suite v0.1 portada a v0.2. Diff en `evidencia/p1_diff_pruebas_v0.1_v0.2.txt` |
| `p1/test_sondas_defectos_v0_1.py` | Sondas sobre v0.1 |
| `p1/P1_verificador_v0.2.patch` | Diff aplicable, **no aplicado** |
| `evidencia/p1_diff_verificador_v0.1_v0.2.txt` | Diff del verificador |
| `evidencia/p1_pytest_v0.2.txt`, `evidencia/p1_compatibilidad_parche_v0.2.txt`, `evidencia/02_reejecucion_v0.1.txt` | Salidas de las ejecuciones |
