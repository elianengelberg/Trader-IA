# Dictamen P2: política de robustez y avance de T (2026-10-20)

**Objeto:** `00_entrega_original/p2/`: `politica_avance_T.py`, `POLITICA_AVANCE_T_v0.1.md` y sus pruebas. Se revisaron todos.

**Revisor:** auto-auditoría adversarial con sondas ejecutables. No es una revisión por un tercero.

**Veredicto:** la v0.1 conserva la etiqueta histórica y no inventa umbrales, pero tiene **5 defectos demostrados**:
- **D1:** «NO AVANZA» no dice a qué etapa se refiere.
- **D2:** acepta R1 y R3 «CUMPLE» sin que exista una definición para T.
- **D3:** no separa la autorización.
- **D4:** clasifica resultados sin integridad verificada.
- **D5:** efecto colateral en `sys.path`.

La **v0.2 (propuesta)** los corrige. **No elige** ninguna definición de R1 o R3, ninguna etapa, ningún efecto mínimo ni ninguna definición económica de robustez.

## 1. Defectos (sondas en `p2/test_sondas_defectos_v0_1.py`, 8 de 8)

| # | Gravedad | Defecto en v0.1 | Corrección en v0.2 |
|---|---|---|---|
| D1 | **Alta** (lo pediste explícitamente) | La salida es `"NO AVANZA"`, sin etapa: se lee como una decisión universal | `decision_avance = {resultado, etapa, texto}`. Con la etapa sin definir: `etapa: NO_DEFINIDA` y el texto «no es una decisión universal: la acción vigente es la de la propia etiqueta». Las etapas solo pueden venir de `ETAPAS_DEFINIDAS`, hoy vacío |
| D2 | **Alta** | `aplicar("VENTAJA RESPALDADA", "CUMPLE", "CUMPLE")` da ROBUSTA aunque **no existe ninguna definición de R1 o R3 para T**. Cualquiera podría pasar una métrica de E3 | `CUMPLE` y `NO_CUMPLE` solo como `(estado, id)` con `id` en `DEFINICIONES_APROBADAS`, que exige `aplica_a = "T"`, el criterio correcto y campos de aprobación. **Registro vacío ⇒ R1 y R3 solo pueden ser NO_DEFINIDO.** Las definiciones de E3 se rechazan. Una definición aprobada en o después del inicio de la ventana se marca **post hoc** |
| D3 | Media | La autorización vive dentro del texto del avance («requiere autorización humana expresa»): avance y autorización no están separados | Cuarta salida `autorizacion_fase_posterior`, siempre `NO_OTORGADA` |
| D4 | Media (transversal con P1) | `desde_resultado` etiqueta un resultado verificado solo en su coherencia (P1 v0.1, D1) | Exige `nivel == VERIFICADO` de P1 v0.2. Un resultado coherente sin integridad, no evaluable, alterado o contradictorio no recibe etiqueta |
| D5 | Baja | `desde_resultado` agrega una entrada a `sys.path` en cada llamada | Se importa una sola vez |

**Candidatos descartados:**
- **N1:** la etiqueta nunca cambia por R1 o R3 (comprobado en las 63 combinaciones de v0.1).
- **N2:** no hay umbrales inventados. Las únicas constantes numéricas son 0 y 1: índices de ruta y el «≤ 0» que fijaste vos.
- **N3:** la política no importa `tendencia` ni toca `decidir`, que solo se cita en un comentario.

## 2. Tabla de decisión
- **Archivo:** `p2/TABLA_DECISION_P2_v0.2.md`, generado por `generar_tabla.py`. Una prueba exige que coincida con la política.
- **Cobertura:** las 63 combinaciones de 7 etiquetas literales × {NO_DEFINIDO, CUMPLE, NO_CUMPLE} para R1 × lo mismo para R3.
- **Filas alcanzables hoy:** solo las 7 con R1 = R3 = NO_DEFINIDO. Las demás usan definiciones **sintéticas** marcadas «PRUEBA SINTÉTICA (no es una propuesta)», solo para recorrer las ramas.

**Resumen de la tabla:**
- La etiqueta es igual a la de entrada en las 63 filas.
- RESPALDADA → CANDIDATA_A_REVISION_HUMANA; cualquier otra clase → NO_CANDIDATA.
- La etapa es NO_DEFINIDA y la autorización NO_OTORGADA en las 63 filas.
- La robustez solo depende de R1 y R3, y nunca cambia la etiqueta ni la decisión de avance.

## 3. Ambigüedades que requieren decisión humana
Están en `p2/POLITICA_AVANCE_T_v0.2.md` §4.

| # | Ambigüedad |
|---|---|
| A1 | Definición de R1 para T |
| A2 | Definición de R3 para T |
| A3 | ¿R1 o R3 pueden vetar la candidatura? |
| A4 | Uso de R1 y R3 sobre 2022–2026 (post hoc) |
| A5 | **Qué es la etapa siguiente de T** |
| A6 | ¿La regla de combinación «todas» de E3 vale para T? |
| A7 | ¿Qué fecha separa lo prerregistrado de lo post hoc? |
| A8 | **Efecto mínimo relevante y definición económica de robustez** (D-S4) |

No se eligió ninguna.

## 4. Separación de la evidencia

| Categoría | Contenido |
|---|---|
| **Confirmado por inspección** | `decidir` no se importa ni se modifica. No hay umbrales numéricos. Las etiquetas se copian literalmente. R1 y R3 solo están definidos en el protocolo E3 v3 (§6.3, sha `279a865f…`), para otro experimento |
| **Confirmado mediante pruebas ejecutadas** | D1–D5 en v0.1 (8 sondas). La v0.2 pasa 129 de 129, que incluyen: 63 combinaciones contra expectativas escritas a mano; invariancia de etiqueta, avance y autorización frente a R1, R3 y el exceso; rechazo de R1 y R3 sin definición aprobada; rechazo de definiciones de E3 o de otro criterio; marca post hoc; etapa explícita y etapas no inventadas; entradas inválidas; paso obligado por P1 VERIFICADO; el **resultado histórico real** en solo lectura (EVIDENCIA INSUFICIENTE / INDETERMINADA / NO_CANDIDATA / NO_DEFINIDA / NO_OTORGADA, con el hash del JSON igual antes y después); las etiquetas iguales a los `return` congelados leídos con `ast` |
| **Inferido** | Mientras los registros estén vacíos, la v0.2 no puede producir ROBUSTA ni NO_ROBUSTA para T, ni nombrar una etapa |
| **No comprobado** | Que la regla «todas» de E3 sea adecuada para T (A6). Una revisión por un tercero |
| **Pendiente de autorización** | Aprobar la v0.2 (o pedir cambios). Llenar `DEFINICIONES_APROBADAS` (A1, A2) y `ETAPAS_DEFINIDAS` (A5). Decidir A3, A6, A7 y A8 |

## 5. Riesgos residuales
1. **Los registros son diccionarios en código.** Quien edite el archivo puede llenarlos. La aprobación debería quedar fuera, por ejemplo en un documento con hash publicado, y el registro debería comprobar ese hash. Hoy `texto_sha256` se exige pero no se contrasta con ningún documento, porque no existe ninguno.
2. **La marca post hoc depende de `aprobada_utc`,** un dato declarado y no probado frente a terceros. Necesita un ancla externa (D-G6).
3. **«CANDIDATA_A_REVISION_HUMANA» puede leerse como una recomendación de avanzar.** No lo es: la autorización está separada y siempre es NO_OTORGADA.

## 6. Archivos
| Archivo | Rol |
|---|---|
| `p2/politica_avance_T.py` | v0.2 (propuesta) |
| `p2/POLITICA_AVANCE_T_v0.2.md` | Política versionada |
| `p2/TABLA_DECISION_P2_v0.2.md`, `p2/generar_tabla.py` | Tabla completa y su generador |
| `p2/test_politica_avance_T.py` | Pruebas de la v0.2 |
| `p2/test_sondas_defectos_v0_1.py` | Sondas sobre la v0.1 |
| `evidencia/p2_diff_politica_v0.1_v0.2.txt`, `evidencia/p2_pytest_v0.2.txt` | Diff y salidas de las ejecuciones |
