# Dictamen P4: ejecución de uso único (2026-10-20)

**Objeto:** todos los archivos de `00_entrega_original/p4/`, revisados: `uso_unico.py`, `_conductor.py`, `test_uso_unico.py` y `ESTADO_Y_INVARIANTES.md`.

**Revisor:** auto-auditoría adversarial con sondas ejecutables. No es una revisión por un tercero.

**Veredicto de seguridad:**
- **v0.1** protege bien contra caídas accidentales y concurrencia en un mismo equipo. Tiene **6 defectos confirmados**. El más grave es **D2c**: incluso con su registro global, un resultado ya escrito en disco, y por lo tanto observable, **puede sustituirse por otra extracción restaurando una copia anterior del estado local**.
- **v0.2 (propuesta)** cierra D1–D6 frente a **fallos accidentales y frente a la manipulación del estado local, siempre que exista un ancla que el atacante no controle**.
- **Sin ancla externa no hay protección** contra quien puede borrar o restaurar todo el estado local. El ancla local `AnclaArchivo` **no es un ancla externa**.

## 1. Defectos de v0.1 (sondas en `p4/test_sondas_defectos_v0_1.py`, 12 de 12)

| # | Gravedad | Defecto | Corrección v0.2 |
|---|---|---|---|
| D1 | **Alta** | **El código ejecutado no está ligado a la reserva:** se ejecuta cualquier función que pase el llamador, aunque la reserva tenga el hash de `codigo.py` (sonda D1). El entorno no forma parte de la reserva (D1b) | Se ejecutan los bytes reservados en un hijo aislado. Entorno, punto de entrada y reintentos van en la reserva. La API no acepta funciones |
| D2 | **Alta** | **Restaurar una copia antigua del estado:** <ul><li>(a) sin ancla, da otra extracción;</li><li>(b) con el registro global v0.1, se detecta tarde: el segundo resultado se calcula y **queda escrito en disco**;</li><li>(c) si se cae después de escribir el archivo y antes de anotarlo en el registro global, el resultado observado X se sustituye por Y y **Y queda registrado**</li></ul> | El ancla registra la reserva, cada inicio de cálculo y el presellado **antes** de escribir el resultado. En cada llamada se concilia antes de calcular |
| D3 | Media | Truncar la cola del diario (un prefijo válido) no se detecta localmente | El ancla lo detecta (INCONSISTENTE). Sin ancla, el truncamiento hasta un cálculo iniciado lleva a REVISION_HUMANA; hasta antes de iniciarlo queda como límite |
| D4 | Media | **No distingue una caída antes del cálculo de una durante el cálculo:** los dos diarios quedan idénticos | `CALCULO_INICIADO`, en el diario y en el ancla, antes de lanzar el hijo. Antes de eso se reintenta; después, solo hasta `reintentos_tras_inicio` (0 por defecto) y luego REVISION_HUMANA |
| D5 | Baja | Falta fsync del directorio padre al crear el directorio de estado y el registro global | `_crear_dir` y la creación del ancla hacen fsync del padre |
| D6 | **Alta** (causa de D2c) | El resultado se escribe en disco antes de que el registro global conozca su hash | Orden I3: presellado local, luego ancla, luego archivo |

**Protecciones que v0.1 ya tenía (N1–N3):**
- la reserva es durable antes de calcular;
- una edición en el medio del diario se detecta;
- entradas cambiadas después de la reserva se rechazan.

## 2. Modelo de amenazas, cada una por separado (v0.2)

| Amenaza | ¿Protegido? | Evidencia | Condición o límite |
|---|---|---|---|
| **Fallo accidental del proceso** (en 13 puntos) | **Sí** | `test_caida_reinicio_e_idempotencia`: 50 casos (13 puntos × con y sin ancla × reintentos 0 y 1, menos los 2 de `tras_ancla` sin ancla), más SIGKILL | Una caída **después** de iniciar el cálculo va a REVISION_HUMANA, salvo que la reserva permita reintentos |
| **Reinicio de la máquina o corte de energía** | **Parcial, no probado** | Inspección ejecutable del orden de los fsync (`test_fsync_…`). El cerrojo lo libera el núcleo | Sin inyección de fallos a nivel de disco |
| **Dos procesos concurrentes** | **Sí (un solo equipo)** | 8 procesos con un solo cálculo; dos directorios y dos nombres con las mismas entradas y el ancla compartida: un solo cálculo, el otro RECHAZADO | NFS u otros equipos: no probado |
| **Corrupción o modificación de archivos** | **Sí**, para el resultado y para ediciones del diario; **con ancla**, también para reescrituras coherentes | CORRUPTO terminal; INCONSISTENTE sin escribir; reescritura coherente con ancla → INCONSISTENTE | Sin ancla, una reescritura coherente del diario **y** del resultado no se detecta |
| **Eliminación del directorio de estado** | **Con ancla: sí** (RECHAZADO si se había iniciado un cálculo; se reanuda si no se había iniciado ninguno). **Sin ancla: no** | `test_borrar_el_estado_con_ancla…`, `…antes_de_calcular…`, `test_LIMITE_sin_ancla_borrar…` | — |
| **Restauración de una copia antigua** | **Con ancla: sí** (INCONSISTENTE o REVISION_HUMANA, sin calcular). **Sin ancla: no** | 4 pruebas con ancla; `test_LIMITE_sin_ancla_restaurar…` | — |
| **Pérdida de la conexión con el ancla durante la persistencia** | **Sí**: nunca queda un resultado escrito sin la confirmación del ancla; al volver la conexión se completa con el mismo hash | `test_ancla_no_disponible…`, con las 4 operaciones | Simulada (`AnclaIntermitente`), no con red real |
| **Usuario con permiso para modificar el registro local** | **Solo si el ancla está fuera de su control.** Con `AnclaArchivo` en la misma máquina, **no**: puede restaurar el estado y el ancla a la vez | `test_LIMITE_el_ancla_local_no_protege…` | **Requiere un ancla externa** (D-G6, sin implementar) |

## 3. Requisitos del encargo

| Requisito | Resultado |
|---|---|
| Estados y transiciones | `p4/ESTADO_Y_INVARIANTES_v0.2.md` §1 y §3. La secuencia se valida en cada llamada; los terminales no se abandonan |
| Entradas, código o configuración distintos de los reservados | RECHAZADO en los 6 casos: datos, código, semilla, reintentos, entorno y punto de entrada. **En v0.1 el código no estaba ligado (D1)** |
| Fallo previo al cálculo frente a cálculo que pudo observar resultados | `CALCULO_INICIADO` (D4). Las pruebas cubren las dos ramas |
| Resultado escrito antes de que la reserva sea durable | **No ocurre**: el `link` y el fsync de la reserva preceden a todo cálculo (N1 en v0.1 y v0.2) |
| Resultado escrito antes de que su hash sea durable | **No ocurre en v0.2**: primero el presellado local y luego el ancla (I3, mutante M2). En v0.1 sí ocurría respecto del registro global (D6) |
| Idempotencia de la recuperación | Reinicio más dos repeticiones en los 50 casos de caída: mismo estado y mismo hash |
| El diario encadenado detecta alteraciones, eliminaciones, truncamiento y restauraciones | Alteración, inserción, eliminación y reordenamiento en el medio: **sí** (localmente). **Truncamiento de la cola y restauración: no localmente** (un prefijo de una cadena válida es válido); **sí con ancla** |
| No confundir el hash encadenado local con un ancla externa | Explícito en el código (`descripcion` del ancla), en la `Salida` (campo `ancla`) y en las pruebas de límite |
| Pruebas pedidas | Las nueve (antes de reservar; después de reservar y antes de calcular; durante el cálculo; tras observar y antes de persistir; después de persistir; reinicio; concurrencia; entradas modificadas; borrado o restauración): todas en `test_uso_unico.py` |

## 4. Separación de la evidencia

| Categoría | Contenido |
|---|---|
| **Confirmado por inspección** | El orden de escritura y de fsync (I3, I12). El ancla local no es externa. La API v0.2 no acepta funciones. Ningún módulo de P4 importa ni invoca los ejecutores de T |
| **Confirmado mediante pruebas ejecutadas** | D1–D6 en v0.1 (12 sondas). La v0.2 da **98 pasan y 2 se omiten**, igual en las 4 corridas. Los **7 mutantes dirigidos** a las salvaguardas nuevas se detectan, cada uno con la prueba prevista. Los 3 límites `test_LIMITE_*` existen |
| **Inferido** | Que un ancla externa con la semántica del §4 de `ESTADO_Y_INVARIANTES_v0.2.md` cierra el último límite. Se deduce de que `AnclaArchivo` lo cierra cuando el atacante no la toca, pero no se probó con un servicio real |
| **No comprobado** | Un corte de energía real. NFS o varios equipos. Canales laterales del código reservado (archivos o red). Una revisión por un tercero |
| **Pendiente de autorización** | Elegir e implementar un ancla externa y publicar hashes (D-G6). Integrar en un ejecutor protegido (**no se hizo**). El valor de `reintentos_tras_inicio` para un experimento real (0 recomendado). La salida de REVISION_HUMANA (protocolo humano) |

## 5. Archivos
| Archivo | Rol |
|---|---|
| `p4/uso_unico.py` | v0.2 (propuesta) |
| `p4/_conductor.py` | Conductor de caídas reales |
| `p4/codigos_sinteticos/*.py` | 5 códigos sintéticos: determinista, no determinista, lento, que falla, que imprime |
| `p4/test_uso_unico.py` | Pruebas de la v0.2 |
| `p4/test_sondas_defectos_v0_1.py` | Sondas sobre la v0.1 |
| `p4/ESTADO_Y_INVARIANTES_v0.2.md` | Máquina de estados, invariantes, pseudocódigo e interfaz de ancla |
| `evidencia/p4_pytest_v0.2.txt`, `evidencia/p4_repeticiones_v0.2.txt` | Salidas de las ejecuciones |
| `evidencia/mutantes_p4_v0.2/` | Mutantes dirigidos |
| `evidencia/p4_diff_uso_unico_v0.1_v0.2.txt` | Diff |
