# Auditoría paralela P1, P2 y P4 (Trader-IA, 2026-10-20). Paquete versionado

**Persistencia:** este paquete está en el **scratchpad efímero** de la sesión. No existe un directorio persistente autorizado. La única preservación disponible es el **ZIP descargable** que acompaña esta entrega (AP-0).

**Repositorio:**
- no se modificó; no hubo commits ni push;
- SHA-256 de `git status --porcelain --ignored` = `87b9585d…`, igual antes y después;
- registro en `evidencia/99_estado_final_git.txt`.

## Contenido
| Ruta | Qué es |
|---|---|
| `00_entrega_original/` | La entrega anterior, **copiada sin modificar**. SHA256SUMS 122 de 122 OK (`evidencia/01_…`) |
| `DICTAMEN_P1.md`, `DICTAMEN_P2.md`, `DICTAMEN_P4.md` | Dictámenes, separando: confirmado por inspección, confirmado por pruebas, inferido, no comprobado y pendiente de autorización |
| `AUDITORIA_CRUZADA.md` | Las interacciones X1–X6, el hallazgo X-1 y la **tabla de cierre** |
| `MATRIZ_DECISIONES_PENDIENTES.md` | Decisiones que son tuyas; ninguna se tomó |
| `p1/` | Verificador v0.2, pruebas, sondas sobre v0.1 y **`P1_verificador_v0.2.patch`** (no aplicado) |
| `p2/` | Política v0.2, su documento, la tabla de 63 filas y su generador, pruebas y sondas |
| `p4/` | Prototipo v0.2, conductor, códigos sintéticos, pruebas, sondas y `ESTADO_Y_INVARIANTES_v0.2.md` |
| `cruzada/` | Pruebas de interacción y el código sintético que reserva P4 |
| `evidencia/` | Salidas originales de cada ejecución, diffs v0.1 → v0.2, mutantes dirigidos, compatibilidad del parche, ZIP de la entrega original y estado de Git |
| `REGISTRO_ACCIONES_Y_AUTORIZACIONES.jsonl` | Registro encadenado de acciones (cada línea lleva el SHA-256 de la anterior) |
| `ejecutar_todo.sh` | Reproduce todas las ejecuciones |
| `registrar.py` | Agrega líneas al registro |
| `SHA256SUMS.txt` | Hash de **todos los archivos salvo él mismo**. No hay ancla externa para él: su hash figura en la respuesta de la sesión |

## Reproducir
```
A=<esta carpeta> T=<repo>/research/tendencia_btc REPO=<repo> \
PY=<repo>/research/hcarry_next/.venv/bin/python HC=<repo>/research/hcarry_next/src bash ejecutar_todo.sh
sha256sum -c SHA256SUMS.txt
```
Requisitos: Python 3.11 y pytest. Las pruebas que leen el árbol real de T o ejecutan `corte.py` (con una fuente simulada) se omiten si esos archivos no están.

**Revisión independiente por un tercero: no realizada.** Esta es una auto-auditoría adversarial con sondas ejecutables.
