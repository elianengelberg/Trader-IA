# Matriz de decisiones pendientes: auditoría paralela P1, P2 y P4 (2026-10-20)

**Cómo leerla:**
- Cada decisión es independiente; no se pide aprobar en bloque.
- **No se tomó ninguna en tu nombre.**
- «Recomendación» es un juicio técnico, no una decisión.
- Los IDs D-G y D-S remiten a `expediente_metodologico_2026-10-20/MATRIZ_DE_DECISIONES_PENDIENTES.md`, que sigue vigente y no se modificó.

## Preservación
| ID | Decisión | Opciones | Recomendación | Bloquea |
|---|---|---|---|---|
| **AP-0** | **Guardar el ZIP de esta entrega fuera del scratchpad** | (a) Descargarlo; (b) indicar un almacenamiento persistente | **(a) ya**: el scratchpad es efímero y no existe un directorio persistente autorizado | Todo |

## P1: verificador
| ID | Decisión | Opciones | Recomendación | Tipo |
|---|---|---|---|---|
| AP-P1-1 | Aplicar `P1_verificador_v0.2.patch` al repositorio y hacer commit | Sí o no | Sí, después de una revisión por un tercero. Solo agrega 4 archivos | Autorización |
| AP-P1-2 | ¿El SHA-256 de los **bytes** de los archivos de datos reales (sin interpretarlos) cuenta como «cálculo sobre datos de mercado»? | Permitido o prohibido | Tu interpretación. Hoy no se hizo; `--datos` solo se probó con datos sintéticos | Interpretación de una restricción |
| AP-P1-3 | Publicar los commits locales `f518ac1` y `692f2b2` (D-G6) | Sí o no | Necesario para que «VERIFICADO» tenga valor frente a terceros | Autorización |
| AP-P1-4 | Versionar `papel/corte.py` y su prueba (hoy sin commit) | Sí o no | Sí. Sin eso, 7 pruebas del parche se omiten en HEAD | Autorización |

## P2: política de avance (ninguna de estas decisiones se tomó)
| ID | Decisión | Estado en v0.2 | Tipo |
|---|---|---|---|
| AP-P2-0 | Aprobar la política v0.2, o pedir cambios | No aprobada | Autorización |
| A1 | Definición de R1 para T | NO_DEFINIDO. La de E3 no se traslada | Metodológica |
| A2 | Definición de R3 para T | NO_DEFINIDO | Metodológica |
| A3 | ¿R1 o R3 pueden vetar la candidatura? | No, según tu indicación | Metodológica |
| A4 | Uso de R1 y R3 sobre 2022–2026 | Post hoc; R3 exigiría recalcular sobre la ventana consumida (prohibido) | Metodológica |
| **A5** | **Qué es la «etapa siguiente» de T** | NO_DEFINIDA | Programa |
| A6 | Regla de combinación «todas» (proveniente de E3) | Sin efecto mientras R1 y R3 sean NO_DEFINIDO | Metodológica |
| A7 | Fecha que separa lo prerregistrado de lo post hoc | Inicio de la ventana (conservador) | Metodológica |
| **A8** | **Efecto mínimo relevante y definición económica de robustez** (= D-S4) | Sin decidir | Económica |

## P4: uso único
| ID | Decisión | Opciones | Recomendación | Tipo |
|---|---|---|---|---|
| AP-P4-1 | **Ancla externa** | Registro de transparencia; sellado de tiempo RFC 3161 encadenado; repositorio remoto con historial protegido; ninguna | Elegir una. Sin ella, quien controla el estado local puede repetir. Publicar hashes requiere tu orden | Autorización |
| AP-P4-2 | Integrar P4 v0.2 en un ejecutor protegido (`corte.py` u otro) | Sí o no | Solo después de AP-P4-1 y de una revisión por un tercero | Autorización |
| AP-P4-3 | `reintentos_tras_inicio` para experimentos reales | 0 o más | **0**: un cálculo iniciado que no llegó al presellado va a revisión humana | Metodológica |
| AP-P4-4 | Protocolo humano para salir de REVISION_HUMANA, CONFLICTO, CORRUPTO o INCONSISTENTE | Por definir | Exigir un registro firmado del motivo y una reserva nueva, visible en el ancla | Procedimiento |
| AP-P4-5 | Pruebas de corte de energía (por ejemplo, dm-flakey) y sandbox de sistema para el cálculo | Sí o no | Sí, antes de usar P4 con un experimento real | Autorización |

## Transversales y vigentes
| ID | Decisión | Estado |
|---|---|---|
| AP-X-1 | Revisión de P1, P2 y P4 v0.2 **por un tercero** (otra persona u otro modelo) | No realizada: esta fue una auto-auditoría |
| A-S1 | Calibración sintética del marco estadístico v0.2 | **No ejecutada** (requiere autorización separada) |
| D-G5 | Reapertura de hipótesis descartadas | **No se decidió** |
