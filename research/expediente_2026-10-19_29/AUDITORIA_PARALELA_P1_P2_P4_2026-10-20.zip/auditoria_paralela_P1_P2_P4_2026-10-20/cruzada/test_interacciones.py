"""Auditoría cruzada P1 (v0.2) × P2 (v0.2) × P4 (v0.2): una o más pruebas sintéticas por interacción (X1–X6).
Cadena: P4 reserva y ejecuta un código sintético que produce un resultado con el esquema fuera de muestra → P1 lo verifica
contra un árbol de T sintético → P2 lo clasifica. Solo lectura sobre el árbol real de T (X4)."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent
import sys  # noqa: E402

for sub in ("p1", "p2", "p4"):
    sys.path.insert(0, str(RAIZ / sub))
import fabricas as F  # noqa: E402
import politica_avance_T as PA  # noqa: E402
import uso_unico as U  # noqa: E402
import verificar_reproduccion_T as V  # noqa: E402

T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.py").is_file(), reason="T no disponible")
EVIDENCIA_INSUF = {"p_conj": 0.755, "p_btc": 0.8355, "x2": 0.0438, "exceso": 0.07, "decision": "EVIDENCIA INSUFICIENTE"}
RESPALDADA = {"p_conj": 0.97, "p_btc": 0.95, "x2": 0.02, "exceso": 0.12, "decision": "RESPALDADA FUERA DE MUESTRA"}


def montar(tmp: Path, parametros: dict, codigo: Path = AQUI / "codigo_oos_sintetico.py") -> dict:
    raiz = F.arbol_t(tmp / "T")
    (tmp / "parametros.json").write_text(json.dumps(parametros), encoding="utf-8")
    (tmp / "contador.txt").write_text(str(tmp / "llamadas.txt"), encoding="utf-8")
    archivos = {"codigo": codigo, "parametros": tmp / "parametros.json", "contador": tmp / "contador.txt",
                "prerregistro": raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                "script": raiz / "experimentos" / "fuera_de_muestra_T.py",
                **{f"src/{p.name}": p for p in sorted((raiz / "src" / "tendencia").glob("*.py"))},
                **{f"manifiesto_{s}": raiz / "datos" / s / "MANIFIESTO.json" for s in ("BTCUSDT", "ETHUSDT")}}
    return {"raiz": raiz, "dir": tmp / "estado", "archivos": {k: str(v) for k, v in archivos.items()},
            "ancla": U.AnclaArchivo(tmp / "ancla" / "ANCLA.jsonl"), "llamadas": tmp / "llamadas.txt"}


def p4(m: dict) -> U.Salida:
    return U.ejecutar(m["dir"], "CRUZADA-1", m["archivos"], 7, ancla=m["ancla"])


def n_calculos(m: dict) -> int:
    return len(m["llamadas"].read_text().splitlines()) if m["llamadas"].exists() else 0


def cadena(m: dict, **kw) -> dict:  # type: ignore[no-untyped-def]
    """Integración mínima propuesta: solo un REGISTRADO de P4 cuyo archivo coincide con su presellado pasa a P1 y P2."""
    st = U.leer(m["dir"])
    if st.get("estado") != "REGISTRADO" or not st.get("archivo_coincide"):
        raise RuntimeError(f"P4 no entregó un resultado válido ({st.get('estado')})")
    return PA.desde_resultado(Path(m["dir"]) / U.RESULTADO, m["raiz"], resultado_sha256_esperado=st["presellado"], **kw)


def test_cadena_valida(tmp_path: Path) -> None:
    m = montar(tmp_path, EVIDENCIA_INSUF)
    assert p4(m).estado == "REGISTRADO"
    s = cadena(m)
    assert (s["etiqueta_estadistica"], s["resultado_verificado"]["nivel"], s["decision_avance"]["resultado"],
            s["autorizacion_fase_posterior"]["estado"]) == ("EVIDENCIA INSUFICIENTE", "VERIFICADO", "NO_CANDIDATA",
                                                            "NO_OTORGADA")
    assert s["resultado_verificado"]["resultado_sha256"] == U.leer(m["dir"])["presellado"]


# X1: P1 no declara verificado (ni reproducido) si faltan datos de integridad
def test_X1_sin_integridad_no_hay_verificado(tmp_path: Path) -> None:
    m = montar(tmp_path, EVIDENCIA_INSUF)
    p4(m)
    ruta = Path(m["dir"]) / U.RESULTADO
    assert V.verificar_archivo(ruta)["nivel"] == "COHERENTE_SIN_INTEGRIDAD"
    (m["raiz"] / "datos" / "ETHUSDT" / "MANIFIESTO.json").unlink()
    with pytest.raises(V.ErrorVerificacion) as e:
        V.verificar_archivo(ruta, raiz=m["raiz"])
    assert e.value.codigo == "AUSENTE"
    texto = (RAIZ / "p1" / "verificar_reproduccion_T.py").read_text(encoding="utf-8")
    assert '"REPRODUCIDO"' not in texto  # P1 nunca emite «reproducido»: exige comparar() con una reproducción


# X2: P2 no convierte un resultado no verificable en etiqueta
@pytest.mark.parametrize("caso", ["sin_integridad", "contradictorio", "codigo_cambiado"])
def test_X2_p2_no_etiqueta_lo_no_verificable(tmp_path: Path, caso: str) -> None:
    m = montar(tmp_path, {**EVIDENCIA_INSUF, "decision": "RESPALDADA FUERA DE MUESTRA"} if caso == "contradictorio"
               else EVIDENCIA_INSUF)
    assert p4(m).estado == "REGISTRADO"
    if caso == "codigo_cambiado":
        (m["raiz"] / "src" / "tendencia" / "a.py").write_text("X = 7\n", encoding="utf-8")
    if caso == "sin_integridad":  # falta un archivo que el resultado declara: la integridad no se puede recalcular
        (m["raiz"] / "experimentos" / "fuera_de_muestra_T.py").unlink()
    with pytest.raises((PA.ErrorPolitica, V.ErrorVerificacion)):
        cadena(m)


# X3: P4 no presenta un resultado fallido o incompleto como válido
def test_X3_p4_fallido_o_alterado_no_llega_a_p1_ni_p2(tmp_path: Path) -> None:
    falla = RAIZ / "p4" / "codigos_sinteticos" / "falla.py"
    m = montar(tmp_path / "a", EVIDENCIA_INSUF, codigo=falla)
    s = p4(m)
    assert (s.estado, s.resultado) == ("FALLO_CALCULO", None) and not (Path(m["dir"]) / U.RESULTADO).exists()
    with pytest.raises(RuntimeError):
        cadena(m)
    assert p4(m).estado == "REVISION_HUMANA"
    with pytest.raises(RuntimeError):
        cadena(m)
    m = montar(tmp_path / "b", EVIDENCIA_INSUF)
    p4(m)
    ruta = Path(m["dir"]) / U.RESULTADO
    pre = U.leer(m["dir"])["presellado"]
    ruta.write_bytes(ruta.read_bytes().replace(b"0.755", b"0.999"))  # alterado tras el registro, y aún coherente
    # Hallazgo X-1: P1 SOLO no lo detecta (la decisión sigue siendo coherente con las cifras alteradas)…
    assert V.verificar_archivo(ruta, raiz=m["raiz"])["nivel"] == "VERIFICADO"
    # …sí con el hash presellado por P4 (corrección propuesta en P1 v0.2), y la cadena lo bloquea antes de P1.
    with pytest.raises(V.ErrorVerificacion):
        V.verificar_archivo(ruta, raiz=m["raiz"], resultado_sha256_esperado=pre)
    with pytest.raises(RuntimeError):
        cadena(m)
    assert p4(m).estado == "CORRUPTO"


# X4: ningún componente modifica el resultado congelado de T
@con_t
def test_X4_los_artefactos_congelados_no_cambian(tmp_path: Path) -> None:
    leidos = [T / "experimentos" / "fuera_de_muestra_T.json", T / "experimentos" / "fuera_de_muestra_T.py",
              T / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md", *sorted((T / "src" / "tendencia").glob("*.py")),
              T / "datos" / "BTCUSDT" / "MANIFIESTO.json", T / "datos" / "ETHUSDT" / "MANIFIESTO.json",
              T / "papel" / "prerregistro_papel.json"]
    huella = lambda: [(str(p), hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns) for p in leidos]  # noqa: E731
    antes = huella()
    V.verificar_archivo(leidos[0], raiz=T)
    PA.desde_resultado(leidos[0], T)
    assert huella() == antes
    assert hashlib.sha256(leidos[0].read_bytes()).hexdigest() == (
        "4f8fafde372931aab29b94612eb658f5fac9259e51cdf7dace7a1b30fc633c45")


def _llamadas_peligrosas(ruta: Path) -> set[str]:
    arbol = ast.parse(ruta.read_bytes())
    nombres = {a.name.split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        (n.module or "").split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    llamadas = {getattr(n.func, "id", getattr(n.func, "attr", "")) for n in ast.walk(arbol) if isinstance(n, ast.Call)}
    escrituras = {"write_text", "write_bytes", "replace", "unlink", "rename", "system", "popen"} & llamadas
    return (nombres & {"subprocess", "runpy", "importlib", "shutil"}) | ({"exec", "eval", "compile", "__import__"}
                                                                        & llamadas) | escrituras


# X5: ningún error técnico habilita una segunda evaluación histórica
def test_X5_p1_y_p2_no_pueden_ejecutar_ni_escribir() -> None:
    assert _llamadas_peligrosas(RAIZ / "p1" / "verificar_reproduccion_T.py") == set()
    assert _llamadas_peligrosas(RAIZ / "p2" / "politica_avance_T.py") == set()


def test_X5_p4_solo_lanza_su_propio_hijo_de_calculo() -> None:
    arbol = ast.parse((RAIZ / "p4" / "uso_unico.py").read_bytes())
    lanzamientos = [ast.unparse(n.args[0]) for n in ast.walk(arbol) if isinstance(n, ast.Call)
                    and ast.unparse(n.func) in ("subprocess.Popen", "subprocess.run")]
    assert lanzamientos == ['[sys.executable, \'-I\', \'-S\', \'-B\', \'-c\', _HIJO, str(w)]']
    textos = [n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and isinstance(n.value, str)
              and n is not arbol.body[0].value]  # fuera del docstring del módulo
    assert not any("fuera_de_muestra_T" in t or "corte.py" in t for t in textos)


def test_X5_un_rechazo_de_p1_no_provoca_otra_evaluacion(tmp_path: Path) -> None:
    m = montar(tmp_path, EVIDENCIA_INSUF)
    p4(m)
    (m["raiz"] / "src" / "tendencia" / "a.py").write_text("X = 7\n", encoding="utf-8")
    with pytest.raises(V.ErrorVerificacion):
        cadena(m)
    assert p4(m).calculado is False and n_calculos(m) == 1  # repetir no recalcula
    Path(m["archivos"]["parametros"]).write_text(json.dumps(RESPALDADA), encoding="utf-8")  # «arreglar» y repetir
    assert p4(m).estado == "RECHAZADO" and n_calculos(m) == 1


# X6: ningún diagnóstico de robustez autoriza la etapa siguiente
def test_X6_robustez_completa_no_autoriza(tmp_path: Path) -> None:
    m = montar(tmp_path, RESPALDADA)
    p4(m)
    defs = {f"{c}-SINT": {"id": f"{c}-SINT", "criterio": c, "aplica_a": "T", "texto_sha256": "0" * 64,
                          "aprobada_utc": "2000-01-01T00:00:00Z", "aprobada_por": "PRUEBA SINTÉTICA"} for c in ("R1", "R3")}
    s = cadena(m, r1=("CUMPLE", "R1-SINT"), r3=("CUMPLE", "R3-SINT"), definiciones=defs)
    assert (s["robustez"]["resumen"], s["decision_avance"]["resultado"], s["autorizacion_fase_posterior"]["estado"]) == (
        "ROBUSTA", "CANDIDATA_A_REVISION_HUMANA", "NO_OTORGADA")
    assert "autoriz" not in json.dumps(U.Salida("REGISTRADO").__dict__)
