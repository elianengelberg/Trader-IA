#!/usr/bin/env bash
# Reproduce todas las ejecuciones de la auditoría paralela (solo pruebas sintéticas y lecturas de solo lectura del árbol
# de T). Uso: A=<esta carpeta> T=<research/tendencia_btc> PY=<python con pytest> HC=<hcarry_next/src> bash ejecutar_todo.sh
set -u
cd "$A"
export PYTHONDONTWRITEBYTECODE=1
corre() { echo "\$ (cd $1 && python -B -m pytest -v -p no:cacheprovider -rs ${*:2})"; (cd "$A/$1" && PYTHONPATH="$T/src:$HC" "$PY" -B -m pytest -v -p no:cacheprovider -rs "${@:2}" 2>&1); echo "exit=$?"; }
{ echo "# P1 v0.2 ($(date -u +%FT%TZ))"; corre p1 test_sondas_defectos_v0_1.py; corre p1 test_verificar_reproduccion_T.py test_v0_2.py; } > evidencia/p1_pytest_v0.2.txt
{ echo "# P2 v0.2 ($(date -u +%FT%TZ)); sondas y suite en procesos separados (módulos homónimos)"; corre p2 test_sondas_defectos_v0_1.py; corre p2 test_politica_avance_T.py; } > evidencia/p2_pytest_v0.2.txt
{ echo "# P4 v0.2 ($(date -u +%FT%TZ))"; corre p4 test_sondas_defectos_v0_1.py; corre p4 test_uso_unico.py; } > evidencia/p4_pytest_v0.2.txt
{ echo "# Auditoría cruzada ($(date -u +%FT%TZ))"; corre cruzada test_interacciones.py; } > evidencia/cruzada_pytest.txt
diff -u 00_entrega_original/p1/verificar_reproduccion_T.py p1/verificar_reproduccion_T.py > evidencia/p1_diff_verificador_v0.1_v0.2.txt
diff -u 00_entrega_original/p1/test_verificar_reproduccion_T.py p1/test_verificar_reproduccion_T.py > evidencia/p1_diff_pruebas_v0.1_v0.2.txt
diff -u 00_entrega_original/p2/politica_avance_T.py p2/politica_avance_T.py > evidencia/p2_diff_politica_v0.1_v0.2.txt
diff -u 00_entrega_original/p4/uso_unico.py p4/uso_unico.py > evidencia/p4_diff_uso_unico_v0.1_v0.2.txt
# parche de P1 (archivos nuevos) y su aplicación en copias exportadas de dos commits (nunca en el repositorio)
rm -rf p1/_arbol && mkdir -p p1/_arbol/research/tendencia_btc/verificacion
cp p1/verificar_reproduccion_T.py p1/fabricas.py p1/test_verificar_reproduccion_T.py p1/test_v0_2.py p1/_arbol/research/tendencia_btc/verificacion/
(cd p1/_arbol && for f in verificar_reproduccion_T.py fabricas.py test_verificar_reproduccion_T.py test_v0_2.py; do git diff --no-index /dev/null research/tendencia_btc/verificacion/$f; done) > p1/P1_verificador_v0.2.patch
rm -rf p1/_arbol
{ echo "# Compatibilidad del parche P1 v0.2 ($(date -u +%FT%TZ)); copias con git archive; el parche NO se aplica al repositorio"
  for c in 692f2b2 c6339e3; do
    W="$A/evidencia/_copia_$c"; rm -rf "$W"; mkdir -p "$W"
    git -C "$REPO" archive "$c" research/tendencia_btc research/hcarry_next/src | tar -x -C "$W"
    echo "== $c: $(git -C "$REPO" log -1 --format='%s' "$c")"
    for f in experimentos/fuera_de_muestra_T.py experimentos/fuera_de_muestra_T.json papel/corte.py tests/test_papel_corte.py; do
      printf "   %-40s %s\n" "$f" "$([ -f "$W/research/tendencia_btc/$f" ] && echo presente || echo AUSENTE)"; done
    (cd "$W" && git apply --check "$A/p1/P1_verificador_v0.2.patch" && echo "   git apply --check: OK" && git apply "$A/p1/P1_verificador_v0.2.patch")
    (cd "$W/research/tendencia_btc" && echo "   pytest verificacion/ (TRADER_IA_T=copia): $(TRADER_IA_T=$PWD PYTHONPATH=src:../hcarry_next/src "$PY" -B -m pytest -q -p no:cacheprovider verificacion/ 2>&1 | tail -1)")
    rm -rf "$W"
  done
  echo "En c6339e3 (origin) no existen el script, el resultado ni el prerregistro fuera de muestra de T (solo en f518ac1/692f2b2, sin publicar)."
} > evidencia/p1_compatibilidad_parche_v0.2.txt 2>&1
grep -hE "^(=+ .*(passed|failed).*)$|exit=|pytest verificacion" evidencia/p1_pytest_v0.2.txt evidencia/p2_pytest_v0.2.txt evidencia/p4_pytest_v0.2.txt evidencia/cruzada_pytest.txt evidencia/p1_compatibilidad_parche_v0.2.txt
