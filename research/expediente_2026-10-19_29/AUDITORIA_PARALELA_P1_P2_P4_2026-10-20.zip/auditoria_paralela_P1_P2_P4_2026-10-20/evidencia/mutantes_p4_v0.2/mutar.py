"""Mutantes DIRIGIDOS solo a las salvaguardas nuevas de v0.2 (7): cada uno elimina una; la suite debe fallar."""
import os, pathlib, shutil, subprocess, sys
AQUI = pathlib.Path(__file__).resolve().parent
P4 = AQUI.parents[1] / "p4"
src = (P4 / "uso_unico.py").read_text(encoding="utf-8")
MUT = {
 "M1_sin_conciliar_presellado_del_ancla": ("        if pre_ancla is not None and pre is None:\n", "        if False:\n"),
 "M2_archivo_antes_que_el_ancla": (
     "    if ancla is not None:  # el ancla conoce el hash ANTES de que el resultado exista en disco\n",
     "    if False:  # MUTANTE\n"),
 "M3_ignora_calculos_iniciados_en_el_ancla": (
     "        iniciados = max(sum(e[\"evento\"] == \"CALCULO_INICIADO\" for e in eventos), iniciados_ancla)\n",
     "        iniciados = sum(e[\"evento\"] == \"CALCULO_INICIADO\" for e in eventos)\n"),
 "M4_borrado_tras_calculo_no_se_rechaza": ("                if st[\"reserva\"] and (st[\"iniciados\"] or st[\"presellado\"]):\n",
                                           "                if False:\n"),
 "M5_sin_limite_de_reintentos": ("        if iniciados > reintentos:\n", "        if False:\n"),
 "M6_calculo_con_salida_visible": ("stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL", "stdout=None, stderr=None"),
 "M7_entorno_fuera_de_la_reserva": ('"reintentos_tras_inicio": reintentos, "entorno": _entorno(),',
                                    '"reintentos_tras_inicio": reintentos,'),
}
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
ok = True
for nombre, (a, b) in MUT.items():
    assert src.count(a) == 1, (nombre, src.count(a))
    d = AQUI / "out" / nombre
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    (d / "uso_unico.py").write_text(src.replace(a, b), encoding="utf-8")
    for f in ("test_uso_unico.py", "_conductor.py"):
        shutil.copy(P4 / f, d)
    shutil.copytree(P4 / "codigos_sinteticos", d / "codigos_sinteticos")
    r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", "--no-header", "-x",
                        str(d / "test_uso_unico.py")], capture_output=True, text=True, env=env, cwd=d, timeout=900)
    ultima = r.stdout.strip().splitlines()[-1]
    fallida = next((x for x in r.stdout.splitlines() if x.startswith("FAILED")), "")
    ok &= r.returncode != 0
    print(f"{nombre}: {'DETECTADO' if r.returncode else 'NO DETECTADO'} ({ultima}) {fallida[:110]}")
print("TODOS LOS MUTANTES DETECTADOS" if ok else "HAY MUTANTES NO DETECTADOS")
sys.exit(0 if ok else 1)
