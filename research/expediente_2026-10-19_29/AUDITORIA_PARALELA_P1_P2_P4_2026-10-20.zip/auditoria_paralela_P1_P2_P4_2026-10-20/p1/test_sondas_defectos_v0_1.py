"""SONDAS sobre el verificador v0.1 tal como se entregó. Cada prueba PASA si el defecto EXISTE en v0.1 (lo confirma);
si alguna fallara, ese defecto quedaría descartado. Las sondas N* comprueban candidatos que resultan NO ser defectos."""
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fabricas as F  # noqa: E402



def cargar_v0_1():  # type: ignore[no-untyped-def]
    """El verificador v0.1 tal como se entregó (copia preservada), con otro nombre para no chocar con v0.2."""
    ruta = Path(__file__).resolve().parents[1] / "00_entrega_original" / "p1" / "verificar_reproduccion_T.py"
    spec = importlib.util.spec_from_file_location("verificador_v0_1", ruta)
    m = importlib.util.module_from_spec(spec)
    sys.modules["verificador_v0_1"] = m  # dataclasses necesita el módulo registrado
    spec.loader.exec_module(m)  # type: ignore[union-attr]
    return m


V1 = cargar_v0_1()


def test_D1_verificado_sin_ninguna_comprobacion_de_integridad(tmp_path: Path) -> None:
    """La línea de comandos dice VERIFICADO aunque no se compruebe ningún hash contra ningún archivo."""
    p = tmp_path / "r.json"
    p.write_text(json.dumps(F.oos()), encoding="utf-8")
    r = subprocess.run([sys.executable, "-I", "-B", V1.__file__, str(p)], capture_output=True, text=True, check=False)
    salida = json.loads(r.stdout)
    assert r.returncode == 0 and salida["resultado"] == "VERIFICADO"
    assert salida["esperados_verificados"] == [] and salida["archivos_verificados"] == []


def test_D2_codigo_y_manifiestos_contra_constantes_no_contra_archivos(tmp_path: Path) -> None:
    """Con «esperados» copiados del propio resultado, v0.1 verifica aunque el código y el manifiesto en disco cambien."""
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    esperados = {"codigo": o["codigo_sha256"], "manifiesto_BTCUSDT": o["manifiestos_sha256"]["BTCUSDT"]}
    (raiz / "src" / "tendencia" / "a.py").write_text("X = 999  # código distinto\n", encoding="utf-8")
    (raiz / "datos" / "BTCUSDT" / "MANIFIESTO.json").write_text("{}", encoding="utf-8")
    inf = V1.verificar(o, esperados=esperados)
    assert inf["decision"] == "EVIDENCIA INSUFICIENTE" and "codigo" in inf["esperados_verificados"]
    with pytest.raises(V1.ErrorVerificacion):  # por archivo tampoco: la huella abarca varios archivos, uno solo no coincide
        V1.verificar(o, archivos={"codigo": str(raiz / "src" / "tendencia" / "a.py")})


def test_D3_corte_evaluado_con_problemas_se_acepta() -> None:
    """corte.py solo evalúa si no hay problemas; v0.1 acepta un EVALUADO con problemas registrados."""
    c = F.corte()
    c["problemas"] = ["datos no publicados: 2029-03-11"]
    assert V1.verificar(c)["decision"] == "VENTAJA RESPALDADA"


@pytest.mark.parametrize("estado,extra", [("EVALUAD0", {}), ("NO EVALUABLE (ver problemas)", {"problemas": []}),
                                          ("SIN OBSERVACIONES PROSPECTIVAS", {})])
def test_D4_estado_desconocido_o_incoherente_pasa_por_no_evaluable(estado: str, extra: dict) -> None:
    """Un resultado evaluado al que se le quita la evaluación y se le cambia el estado aparece como «no evaluable»:
    estado desconocido, NO EVALUABLE sin problemas, o SIN OBSERVACIONES con el corte posterior al inicio."""
    c = {k: v for k, v in F.corte().items() if k != "evaluacion"} | {"estado": estado} | extra
    with pytest.raises(V1.ErrorVerificacion) as e:
        V1.verificar(c)
    assert e.value.codigo == "SIN_EVALUACION"


def test_D5_no_evaluable_se_informa_como_rechazado(tmp_path: Path) -> None:
    c = {k: v for k, v in F.corte().items() if k != "evaluacion"} | {"estado": "NO EVALUABLE (ver problemas)",
                                                                     "problemas": ["x"]}
    p = tmp_path / "c.json"
    p.write_text(json.dumps(c), encoding="utf-8")
    r = subprocess.run([sys.executable, "-I", "-B", V1.__file__, str(p)], capture_output=True, text=True, check=False)
    assert r.returncode == 1 and json.loads(r.stdout)["resultado"] == "RECHAZADO"  # igual que un archivo alterado


@pytest.mark.skipif(not (F.T_REAL / "papel" / "corte.py").is_file(), reason="corte.py no disponible")
def test_D6_registro_de_cortes_no_se_comprueba(tmp_path: Path) -> None:
    """Productor REAL con fuente simulada: se altera un campo no verificado del resultado; el SHA-256 ya no es el del
    REGISTRO.jsonl, pero v0.1 no mira el registro y lo da por bueno."""
    raiz = F.corte_real_simulado(tmp_path)
    ruta = raiz / "2027-10-19" / "resultado.json"
    obj = json.loads(ruta.read_text(encoding="utf-8"))
    obj["monitor_carry"]["accion"] = "ALTERADO"
    ruta.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")
    registradas = [json.loads(x)["resultado_sha256"] for x in (raiz / "REGISTRO.jsonl").read_text().splitlines()]
    assert F.sha(ruta.read_bytes()) not in registradas
    assert V1.verificar(obj)["esquema"] == "papel_corte"


def test_D7_ventana_y_dias_no_se_comparan_con_el_prerregistro() -> None:
    o = F.oos()
    o["ventana"] = o["principal"]["ventana"] = ["2021-01-01", "2026-06-01"]
    o["dias"] = 1977
    assert V1.verificar(o)["dias"] == 1977


def test_D8_claves_json_duplicadas_se_aceptan(tmp_path: Path) -> None:
    """Dos «decision_prerregistrada»: un lector humano ve la primera; json.load se queda con la última."""
    texto = json.dumps(F.oos())[:-1] + ', "decision_prerregistrada": "EVIDENCIA INSUFICIENTE"}'
    texto = texto.replace('"decision_prerregistrada": "EVIDENCIA INSUFICIENTE"',
                          '"decision_prerregistrada": "RESPALDADA FUERA DE MUESTRA"', 1)
    p = tmp_path / "dup.json"
    p.write_text(texto, encoding="utf-8")
    r = subprocess.run([sys.executable, "-I", "-B", V1.__file__, str(p)], capture_output=True, text=True, check=False)
    assert r.returncode == 0 and json.loads(r.stdout)["resultado"] == "VERIFICADO"


def test_D9_el_informe_no_identifica_el_archivo_verificado(tmp_path: Path) -> None:
    p = tmp_path / "r.json"
    p.write_text(json.dumps(F.oos()), encoding="utf-8")
    r = subprocess.run([sys.executable, "-I", "-B", V1.__file__, str(p)], capture_output=True, text=True, check=False)
    assert F.sha(p.read_bytes()) not in r.stdout  # no se puede atar la verificación a un archivo concreto


# ---------- candidatos descartados ----------
def test_N1_hashes_de_distinto_significado_no_se_tratan_como_equivalentes() -> None:
    with pytest.raises(V1.ErrorVerificacion) as e:
        V1.verificar(F.oos(), esperados={"reglas_canonicas": "a" * 64})
    assert e.value.codigo == "HASH_SEMANTICA"


def test_N2_el_verificador_no_usa_el_0_5_por_defecto() -> None:
    with pytest.raises(V1.ErrorVerificacion) as e:
        V1.verificar(F.quitar(F.evaluar(), "bootstrap_conjunto.p_mayor_que_cero"))
    assert e.value.codigo == "AUSENTE"


def test_N3_json_truncado_se_rechaza(tmp_path: Path) -> None:
    p = tmp_path / "t.json"
    p.write_text(json.dumps(F.oos())[:-40], encoding="utf-8")
    r = subprocess.run([sys.executable, "-I", "-B", V1.__file__, str(p)], capture_output=True, text=True, check=False)
    assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "LECTURA"


def test_N4_resultado_negativo_evaluado_no_se_confunde_con_no_evaluable() -> None:
    assert V1.verificar(F.oos(p_conj=0.05, decision="NO RESPALDADA"))["decision"] == "NO RESPALDADA"
