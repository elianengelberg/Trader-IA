"""Pruebas de las correcciones de v0.2 (una por defecto confirmado D1–D9) y de la integridad contra archivos.
Datos sintéticos, salvo lecturas de SOLO LECTURA del árbol real de T (código, prerregistros, manifiestos: no se leen
bytes de datos de mercado) y el productor real de cortes con fuente SIMULADA."""
from __future__ import annotations

import ast
import json
import subprocess
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import fabricas as F  # noqa: E402
import verificar_reproduccion_T as V  # noqa: E402

T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.py").is_file(), reason="T no disponible")
con_corte = pytest.mark.skipif(not (T / "papel" / "corte.py").is_file(), reason="corte.py no disponible")


def cod(f, *a, **k) -> str:  # type: ignore[no-untyped-def]
    with pytest.raises(V.ErrorVerificacion) as e:
        f(*a, **k)
    return e.value.codigo


def cli(*args: str) -> tuple[int, dict]:
    r = subprocess.run([sys.executable, "-I", "-B", str(AQUI / "verificar_reproduccion_T.py"), *args],
                       capture_output=True, text=True, check=False)
    return r.returncode, (json.loads(r.stdout) if r.stdout.startswith("{") else {})


# D1: sin integridad no hay VERIFICADO
def test_D1_sin_raiz_solo_coherente(tmp_path: Path) -> None:
    p = tmp_path / "r.json"
    p.write_text(json.dumps(F.oos()), encoding="utf-8")
    c, s = cli(str(p))
    assert (c, s["resultado"]) == (3, "COHERENTE_SIN_INTEGRIDAD") and s["integridad_desde_archivos"] == {}


# D2: código y manifiestos se recalculan desde archivos
@pytest.mark.parametrize("cambio", ["codigo", "manifiesto", "prerregistro", "script", "py_nuevo"])
def test_D2_cualquier_archivo_cambiado_se_detecta(tmp_path: Path, cambio: str) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    assert V.verificar(o, raiz=raiz)["nivel"] == "VERIFICADO"
    {"codigo": lambda: (raiz / "src/tendencia/a.py").write_text("X = 999\n"),
     "manifiesto": lambda: (raiz / "datos/BTCUSDT/MANIFIESTO.json").write_text("{}"),
     "prerregistro": lambda: (raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md").write_text("otro\n"),
     "script": lambda: (raiz / "experimentos/fuera_de_muestra_T.py").write_text(
         'DESDE, HASTA, DIAS = "2022-01-01", "2026-06-01", 1612\n# cambio\n'),
     "py_nuevo": lambda: (raiz / "src/tendencia/c.py").write_text("Z = 3\n")}[cambio]()
    assert cod(V.verificar, o, raiz=raiz) == "HASH"


def test_D2_referencias_constantes_no_bastan_para_verificar(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    inf = V.verificar(o, esperados={"codigo": o["codigo_sha256"]})  # constante copiada del propio resultado
    assert inf["nivel"] == "COHERENTE_SIN_INTEGRIDAD" and inf["integridad_desde_archivos"] == {}


@con_t
def test_D2_huella_y_reglas_iguales_a_las_funciones_congeladas() -> None:
    """huella_codigo congelado (extraído con ast, sin importar el módulo) sobre el src real = la de v0.2 = 73b22f3e…;
    hash de reglas desde el JSON congelado = d2e4e1fb…."""
    nodo = next(n for n in ast.parse((T / "src/tendencia/papel.py").read_bytes()).body
                if isinstance(n, ast.FunctionDef) and n.name == "huella_codigo")
    ns: dict = {"hashlib": __import__("hashlib"), "SRC": T / "src" / "tendencia"}
    exec(compile(ast.Module(body=[nodo], type_ignores=[]), "papel.py", "exec"), ns)
    assert ns["huella_codigo"]() == V.huella_codigo(T / "src" / "tendencia") == (
        "73b22f3e3a8f21513d5533fb11a7553becae30b87c8736fb6880bccc36c11d2b")
    assert V.hash_reglas(T / "papel" / "prerregistro_papel.json") == (
        "d2e4e1fb43b8219b80e19736ba7a9abed22d6e858f0b8955171496fa06e74939")


# D3 y D4: estados de corte coherentes
def test_D3_evaluado_con_problemas_es_contradiccion() -> None:
    c = F.corte()
    c["problemas"] = ["datos no publicados: 2029-03-11"]
    assert cod(V.verificar, c) == "CONTRADICCION"


@pytest.mark.parametrize("estado,extra,codigo", [
    ("EVALUAD0", {}, "VALOR"), ("NO EVALUABLE (ver problemas)", {"problemas": []}, "CONTRADICCION"),
    ("SIN OBSERVACIONES PROSPECTIVAS", {}, "CONTRADICCION"),
    ("NO EVALUABLE (ver problemas)", {"problemas": ["historia incompleta"]}, "SIN_EVALUACION"),
    ("SIN OBSERVACIONES PROSPECTIVAS", {"corte_exclusivo": "2026-12-01"}, "SIN_EVALUACION")])
def test_D4_estados_provisionales(estado: str, extra: dict, codigo: str) -> None:
    c = {k: v for k, v in F.corte().items() if k != "evaluacion"} | {"estado": estado} | extra
    assert cod(V.verificar, c) == codigo


# D5: NO_EVALUABLE distinto de RECHAZADO
def test_D5_no_evaluable_tiene_salida_propia(tmp_path: Path) -> None:
    c = {k: v for k, v in F.corte().items() if k != "evaluacion"} | {"estado": "NO EVALUABLE (ver problemas)",
                                                                     "problemas": ["x"]}
    p = tmp_path / "c.json"
    p.write_text(json.dumps(c), encoding="utf-8")
    assert cli(str(p))[0] == 4 and cli(str(p))[1]["resultado"] == "NO_EVALUABLE"


# D6: registro de cortes
@con_corte
@pytest.mark.parametrize("alteracion", ["resultado", "registro_editado", "registro_sin_linea", "registro_truncado",
                                        "evaluado_duplicado"])
def test_D6_registro_de_cortes(tmp_path: Path, alteracion: str) -> None:
    raiz = F.corte_real_simulado(tmp_path)
    res, reg = raiz / "2027-10-19" / "resultado.json", raiz / "REGISTRO.jsonl"
    assert V.verificar_archivo(res, raiz=T, registro=reg)["nivel"] == "VERIFICADO"
    lineas = reg.read_text(encoding="utf-8").split("\n")[:-1]
    if alteracion == "resultado":
        obj = json.loads(res.read_text(encoding="utf-8"))
        obj["monitor_carry"]["accion"] = "ALTERADO"
        res.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")
    elif alteracion == "registro_editado":
        reg.write_text("\n".join([lineas[0].replace("EVALUADO", "EVALUADO ")] + lineas[1:]) + "\n", encoding="utf-8")
    elif alteracion == "registro_sin_linea":
        reg.write_text("".join(x + "\n" for x in lineas[:-1]), encoding="utf-8")
    elif alteracion == "registro_truncado":
        reg.write_text("\n".join(lineas)[:-5], encoding="utf-8")
    else:
        import hashlib
        x = json.loads(lineas[-1]) | {"linea_anterior_sha256": hashlib.sha256(lineas[-1].encode()).hexdigest()}
        reg.write_text("\n".join(lineas + [json.dumps(x, ensure_ascii=False)]) + "\n", encoding="utf-8")
    assert cod(V.verificar_archivo, res, raiz=T, registro=reg) in ("REGISTRO", "CONTRADICCION")


@con_corte
def test_D6_corte_sin_registro_no_es_verificado(tmp_path: Path) -> None:
    raiz = F.corte_real_simulado(tmp_path)
    inf = V.verificar_archivo(raiz / "2027-10-19" / "resultado.json", raiz=T)
    assert inf["nivel"] == "COHERENTE_SIN_INTEGRIDAD" and any("REGISTRO" in x for x in inf["no_comprobado"])


# D7: ventana y días contra el script verificado
@pytest.mark.parametrize("ventana,dias", [(["2021-01-01", "2026-06-01"], 1612), (["2022-01-01", "2026-06-01"], 1611)])
def test_D7_ventana_o_dias_distintos_del_script(tmp_path: Path, ventana: list, dias: int) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    o["ventana"] = o["principal"]["ventana"] = ventana
    o["dias"] = dias
    assert cod(V.verificar, o, raiz=raiz) == "CONTRADICCION"


def test_D7_ventana_interna_incoherente() -> None:
    o = F.oos()
    o["principal"]["ventana"] = ["2021-01-01", "2026-06-01"]
    assert cod(V.verificar, o) == "CONTRADICCION"


# D8: claves duplicadas
def test_D8_claves_duplicadas(tmp_path: Path) -> None:
    texto = json.dumps(F.oos())[:-1] + ', "decision_prerregistrada": "EVIDENCIA INSUFICIENTE"}'
    p = tmp_path / "dup.json"
    p.write_text(texto, encoding="utf-8")
    c, s = cli(str(p))
    assert (c, s["codigo"]) == (1, "CLAVE_DUPLICADA")


# D9: el informe identifica el archivo
def test_D9_informe_con_sha_del_archivo(tmp_path: Path) -> None:
    p = tmp_path / "r.json"
    p.write_text(json.dumps(F.oos()), encoding="utf-8")
    assert V.verificar_archivo(p)["resultado_sha256"] == F.sha(p.read_bytes())


# --datos: solo sintético en esta fase
def test_datos_sinteticos_contra_manifiesto(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    inf = V.verificar(o, raiz=raiz, datos=True)
    assert inf["integridad_desde_archivos"]["datos_BTCUSDT"] == "3 archivos" and not inf["no_comprobado"]
    (raiz / "datos/ETHUSDT/spot/ETHUSDT-1.zip").write_bytes(b"truncado")
    assert cod(V.verificar, o, raiz=raiz, datos=True) == "HASH"
    (raiz / "datos/ETHUSDT/spot/ETHUSDT-1.zip").unlink()
    assert cod(V.verificar, o, raiz=raiz, datos=True) == "AUSENTE"


def test_naturaleza_distingue_informativo_de_decision() -> None:
    inf = V.verificar(F.evaluar(dias=300, decision="INFORMATIVO (menos de 12 meses: ninguna decisión)"))
    assert inf["naturaleza"] == "EVALUADO_SIN_DECISION"
    assert V.verificar(F.oos(p_conj=0.05, decision="NO RESPALDADA"))["naturaleza"] == "EVALUADO_CON_DECISION"


@con_t
def test_artefacto_real_verificado_desde_archivos() -> None:
    """Solo lectura: script, prerregistro, src/tendencia/*.py y los dos MANIFIESTO.json (metadatos). No se leen datos."""
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    inf = V.verificar_archivo(ruta, raiz=T)
    assert inf["nivel"] == "VERIFICADO" and inf["resultado_sha256"] == (
        "4f8fafde372931aab29b94612eb658f5fac9259e51cdf7dace7a1b30fc633c45")
    assert set(inf["integridad_desde_archivos"]) == {"prerregistro_archivo", "script", "codigo", "manifiesto_BTCUSDT",
                                                     "manifiesto_ETHUSDT", "ventana_y_dias"}
    assert inf["no_comprobado"] == ["archivos de datos listados en los manifiestos (no se leen sin --datos)"]


# X-1 (auditoría cruzada): el hash del propio archivo contra el presellado de P4
def test_X1_resultado_sha256_esperado(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    p = tmp_path / "r.json"
    p.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    bueno = F.sha(p.read_bytes())
    assert V.verificar_archivo(p, raiz=raiz, resultado_sha256_esperado=bueno)["resultado_sha256_esperado_coincide"]
    p.write_text(json.dumps(F.oos(p_conj=0.999, raiz=raiz)), encoding="utf-8")  # alterado y aún coherente
    assert V.verificar_archivo(p, raiz=raiz)["nivel"] == "VERIFICADO"  # sin el hash esperado, pasa
    assert cod(V.verificar_archivo, p, raiz=raiz, resultado_sha256_esperado=bueno) == "HASH"
    c, s = cli(str(p), "--raiz", str(raiz), "--resultado-sha256", bueno)
    assert (c, s["codigo"]) == (1, "HASH")
