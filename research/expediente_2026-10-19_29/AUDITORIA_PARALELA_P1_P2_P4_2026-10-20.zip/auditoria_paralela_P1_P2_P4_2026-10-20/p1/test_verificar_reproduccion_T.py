"""Pruebas del verificador de reproducción de T (P1), PORTADAS de v0.1 a v0.2. Cambios respecto de la suite v0.1 (todos
por la API de integridad de v0.2; diff en ../evidencia/p1_diff_pruebas_v0.1_v0.2.txt): archivos se reemplaza por
raiz; dias_calendario del corte sintético pasa a ser coherente; el corte SIN OBSERVACIONES pasa a tener el corte ≤
inicio; la línea de comandos tiene los niveles nuevos.

(Texto original de v0.1:) Pruebas del verificador de reproducción de T (P1). Todos los resultados son SINTÉTICOS salvo dos pruebas de solo
lectura sobre artefactos existentes (se saltan si el directorio de T no está):

- ``test_reglas_identicas_a_las_congeladas``: extrae con ``ast`` las funciones ``decision`` (fuera_de_muestra_T.py:44-49)
  y ``decidir`` (tendencia/papel.py) de los archivos congelados, SIN importar ni ejecutar esos módulos, y las compara con
  las copias del verificador en una rejilla. No se ejecuta el script de uso único ni se toca su cerrojo.
- ``test_artefacto_real_fuera_de_muestra``: verifica el JSON ya registrado (no recalcula nada a partir de datos).
- ``test_productor_real_de_cortes_con_fuente_simulada``: ejecuta ``papel/corte.py`` en un directorio temporal con la
  fuente SIMULADA de sus propias pruebas (no son datos de mercado) y verifica su salida con este verificador.
"""
from __future__ import annotations

import ast
import copy
import hashlib
import importlib.util
import itertools
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import verificar_reproduccion_T as V  # noqa: E402


def _dir_t() -> Path | None:
    # v0.2: si TRADER_IA_T está definida es la ÚNICA candidata (una copia aislada no cae en el árbol real)
    candidatos = [os.environ["TRADER_IA_T"]] if os.environ.get("TRADER_IA_T") else [
        AQUI.parent, "/home/user/Trader-IA/research/tendencia_btc"]
    for c in candidatos:
        if (Path(c) / "experimentos" / "fuera_de_muestra_T.py").is_file():
            return Path(c)
    return None


T = _dir_t()
con_t = pytest.mark.skipif(T is None, reason="directorio de T no disponible")
SCRIPT_SHA = "941b6e11f6566319b93614ee671b184d60c7b5fbc64a3931a6ff2c8da17fe0fa"
PAPEL_PY_SHA = "b3b3728d38356f75f559987949a376a96a13ebeb6176089f85bcec7ba84d1055"  # observado el 2026-10-20
RESULTADO_SHA = "4f8fafde372931aab29b94612eb658f5fac9259e51cdf7dace7a1b30fc633c45"


# ---------- resultados sintéticos con la forma exacta de cada productor ----------
def oos(p_conj: float = 0.755, p_btc: float = 0.8355, x2: float = 0.0438,
        decision: str = "EVIDENCIA INSUFICIENTE") -> dict:
    """Forma de experimentos/fuera_de_muestra_T.json; cifras sintéticas."""
    return {"categoria": "SINTÉTICO", "prerregistro_sha256": "a" * 64, "script_sha256": "b" * 64,
            "codigo_sha256": "c" * 64, "manifiestos_sha256": {"BTCUSDT": "d" * 64, "ETHUSDT": "e" * 64},
            "ventana": ["2022-01-01", "2026-06-01"], "dias": 1612, "decision_prerregistrada": decision,
            "principal": {"ventana": ["2022-01-01", "2026-06-01"],
                          "BTC": {"exceso_anual": 0.09, "ic90_anual": [-0.07, 0.25], "p": p_btc},
                          "ETH": {"exceso_anual": 0.05, "ic90_anual": [-0.13, 0.24], "p": 0.65},
                          "conjunto": {"exceso_anual": 0.07, "ic90_anual": [-0.09, 0.23], "p": p_conj}},
            "secundarios": {"costes_x2": {"BTC": 0.06, "ETH": 0.03, "conjunto": x2}}}


def _boot(p: float, ic: list[float]) -> dict:
    return {"aplicable": True, "dias": 800, "media_diaria": 0.0003, "media_anual": 0.11, "intervalo_anual": ic,
            "p_mayor_que_cero": p, "bloque": 20, "remuestreos": 2000, "semilla": 20261017, "nivel": 0.9}


def evaluar(dias: int = 800, p_conj: float = 0.97, p_btc: float = 0.93, x2: float = 0.05,
            decision: str = "VENTAJA RESPALDADA") -> dict:
    """Forma de tendencia.papel.evaluar (sin T_BTC/T_ETH); cifras sintéticas."""
    return {"prerregistro_sha256": "1" * 64, "codigo_sha256": "2" * 64, "rama": "B", "inicio": "2027-01-01",
            "corte": "2029-03-12", "dias": dias, "meses": dias / 30.44, "exceso_anual_conjunto": 0.11,
            "bootstrap_conjunto": _boot(p_conj, [0.01, 0.22]), "bootstrap_btc": _boot(p_btc, [0.0, 0.3]),
            "exceso_anual_conjunto_costes_x2": x2, "decision": decision}


def corte(ev: dict | None = None) -> dict:
    """Forma de papel/corte.py (resultado.json de un corte EVALUADO); cifras sintéticas."""
    import datetime as _dt
    ev = ev or evaluar()
    return {"corte_exclusivo": ev["corte"], "rama": ev["rama"], "inicio": ev["inicio"],
            "reglas_sha256": ev["prerregistro_sha256"], "codigo_sha256": ev["codigo_sha256"], "problemas": [],
            "datos_sha256": {"BTCUSDT": "3" * 64, "ETHUSDT": "4" * 64}, "estado": "EVALUADO",
            "evaluacion": {**ev, "metricas": {"T_BTC": {}, "T_ETH": {}}},
            "dias_calendario": (_dt.date.fromisoformat(ev["corte"]) - _dt.date.fromisoformat(ev["inicio"])).days,
            "decisiones_sha256": {"BTCUSDT": "5" * 64, "ETHUSDT": "6" * 64}, "monitor_carry": {"estado": "x"}}


FABRICAS = {"fuera_de_muestra": oos, "papel_evaluar": evaluar, "papel_corte": corte}


def quitar(obj: dict, ruta: str) -> dict:
    o = copy.deepcopy(obj)
    *pre, ult = ruta.split(".")
    d = o
    for p in pre:
        d = d[p]
    del d[ult]
    return o


def poner(obj: dict, ruta: str, valor) -> dict:  # type: ignore[no-untyped-def]
    o = copy.deepcopy(obj)
    *pre, ult = ruta.split(".")
    d = o
    for p in pre:
        d = d[p]
    d[ult] = valor
    return o


def codigo(f, *a, **k) -> str:  # type: ignore[no-untyped-def]
    with pytest.raises(V.ErrorVerificacion) as e:
        f(*a, **k)
    return e.value.codigo


# ---------- casos válidos ----------
@pytest.mark.parametrize("esquema", list(FABRICAS))
def test_valido(esquema: str) -> None:
    inf = V.verificar(FABRICAS[esquema]())
    assert inf["esquema"] == esquema and inf["decision"] == inf["decision_recalculada"]


def test_valido_bootstrap_no_aplicable_con_menos_de_12_meses() -> None:
    ev = evaluar(dias=30, decision="INFORMATIVO (menos de 12 meses: ninguna decisión)")
    ev["bootstrap_conjunto"] = ev["bootstrap_btc"] = {"aplicable": False, "motivo": "30 días < 2 bloques de 20"}
    inf = V.verificar(ev)
    assert inf["p_conjunto"] is None and inf["ic90"] is None and inf["decision"].startswith("INFORMATIVO")


def test_valido_con_hashes_esperados_y_raiz(tmp_path: Path) -> None:
    import fabricas as F
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    inf = V.verificar(o, raiz=raiz, esperados={"codigo": o["codigo_sha256"]})
    assert inf["nivel"] == "VERIFICADO" and set(inf["integridad_desde_archivos"]) >= {
        "prerregistro_archivo", "script", "codigo", "manifiesto_BTCUSDT", "manifiesto_ETHUSDT", "ventana_y_dias"}
    assert inf["referencias_declaradas_coinciden"] == ["codigo"]


# ---------- datos ausentes ----------
AUSENTES = [("fuera_de_muestra", r) for r in (
    "principal.conjunto.p", "principal.BTC.p", "principal.conjunto.exceso_anual", "principal.conjunto.ic90_anual",
    "secundarios.costes_x2.conjunto", "secundarios.costes_x2", "dias", "prerregistro_sha256", "script_sha256",
    "codigo_sha256", "manifiestos_sha256.ETHUSDT")] + [("papel_evaluar", r) for r in (
        "bootstrap_conjunto.p_mayor_que_cero",  # el caso que el código congelado sustituye por 0,5 sin avisar
        "bootstrap_btc.p_mayor_que_cero", "bootstrap_conjunto.aplicable", "bootstrap_conjunto.intervalo_anual",
        "bootstrap_btc", "exceso_anual_conjunto_costes_x2", "exceso_anual_conjunto", "meses", "dias", "decision",
        "prerregistro_sha256", "codigo_sha256")] + [("papel_corte", r) for r in (
            "reglas_sha256", "codigo_sha256", "evaluacion", "evaluacion.bootstrap_btc.p_mayor_que_cero",
            "evaluacion.corte")]


@pytest.mark.parametrize("esquema,ruta", AUSENTES)
def test_rechaza_dato_ausente(esquema: str, ruta: str) -> None:
    assert codigo(V.verificar, quitar(FABRICAS[esquema](), ruta)) == "AUSENTE"


def test_rechaza_archivo_ausente(tmp_path: Path) -> None:
    import fabricas as F
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    (raiz / "experimentos" / "fuera_de_muestra_T.py").unlink()
    assert codigo(V.verificar, o, raiz=raiz) == "AUSENTE"


# ---------- tipos incorrectos y rangos ----------
TIPOS = [("fuera_de_muestra", "principal.conjunto.p", "0.755"), ("fuera_de_muestra", "principal.conjunto.p", True),
         ("fuera_de_muestra", "principal.BTC.p", None), ("fuera_de_muestra", "dias", 1612.0),
         ("fuera_de_muestra", "dias", 0), ("fuera_de_muestra", "dias", "1612"),
         ("fuera_de_muestra", "principal.conjunto.exceso_anual", float("nan")),
         ("fuera_de_muestra", "principal.conjunto.exceso_anual", float("inf")),
         ("fuera_de_muestra", "principal.conjunto.ic90_anual", [0.1]),
         ("fuera_de_muestra", "principal.conjunto.ic90_anual", "[-0.09, 0.23]"),
         ("fuera_de_muestra", "principal.conjunto.ic90_anual", [-0.09, "0.23"]),
         ("fuera_de_muestra", "principal", [1, 2]), ("fuera_de_muestra", "decision_prerregistrada", 3),
         ("fuera_de_muestra", "decision_prerregistrada", ""),
         ("papel_evaluar", "bootstrap_conjunto.aplicable", "true"), ("papel_evaluar", "bootstrap_conjunto", 0.97),
         ("papel_evaluar", "meses", "26.3"), ("papel_evaluar", "exceso_anual_conjunto_costes_x2", None),
         ("papel_evaluar", "rama", 1), ("papel_corte", "estado", None)]


@pytest.mark.parametrize("esquema,ruta,valor", TIPOS)
def test_rechaza_tipo_incorrecto(esquema: str, ruta: str, valor) -> None:  # type: ignore[no-untyped-def]
    assert codigo(V.verificar, poner(FABRICAS[esquema](), ruta, valor)) == "TIPO"


@pytest.mark.parametrize("raiz", [[], "x", 3, None])
def test_rechaza_raiz_que_no_es_objeto(raiz) -> None:  # type: ignore[no-untyped-def]
    assert codigo(V.verificar, raiz) == "TIPO"


@pytest.mark.parametrize("ruta,valor", [("principal.conjunto.p", 1.2), ("principal.BTC.p", -0.1),
                                        ("principal.conjunto.ic90_anual", [0.23, -0.09])])
def test_rechaza_fuera_de_rango(ruta: str, valor) -> None:  # type: ignore[no-untyped-def]
    assert codigo(V.verificar, poner(oos(), ruta, valor)) == "RANGO"


@pytest.mark.parametrize("esquema,ruta,valor", [("fuera_de_muestra", "decision_prerregistrada", "RESPALDADA"),
                                                ("papel_evaluar", "decision", "VENTAJA RESPALDADA: avanzar"),
                                                ("papel_evaluar", "rama", "C")])
def test_rechaza_valor_desconocido(esquema: str, ruta: str, valor: str) -> None:
    assert codigo(V.verificar, poner(FABRICAS[esquema](), ruta, valor)) == "VALOR"


# ---------- hashes ----------
@pytest.mark.parametrize("valor", ["A" * 64, "a" * 63, "a" * 65, "g" * 64, 12345, None])
@pytest.mark.parametrize("ruta", ["script_sha256", "manifiestos_sha256.BTCUSDT", "prerregistro_sha256"])
def test_rechaza_hash_mal_formado(ruta: str, valor) -> None:  # type: ignore[no-untyped-def]
    assert codigo(V.verificar, poner(oos(), ruta, valor)) == "HASH_FORMATO"


@pytest.mark.parametrize("esquema,nombre", [("fuera_de_muestra", "codigo"), ("fuera_de_muestra", "script"),
                                            ("fuera_de_muestra", "prerregistro_archivo"),
                                            ("fuera_de_muestra", "manifiesto_ETHUSDT"),
                                            ("papel_evaluar", "reglas_canonicas"), ("papel_corte", "codigo")])
def test_rechaza_hash_esperado_distinto(esquema: str, nombre: str) -> None:
    assert codigo(V.verificar, FABRICAS[esquema](), esperados={nombre: "f" * 64}) == "HASH"


def test_rechaza_archivo_con_hash_distinto(tmp_path: Path) -> None:
    import fabricas as F
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    (raiz / "experimentos" / "fuera_de_muestra_T.py").write_bytes(b"otro contenido")
    assert codigo(V.verificar, o, raiz=raiz) == "HASH"


@pytest.mark.parametrize("esquema,esperados", [
    ("fuera_de_muestra", {"reglas_canonicas": "a" * 64}),  # hash CANÓNICO de reglas pedido a un resultado que no lo tiene
    ("papel_evaluar", {"prerregistro_archivo": "1" * 64}),  # hash de ARCHIVO pedido a un resultado de papel
    ("papel_evaluar", {"script": "1" * 64}), ("fuera_de_muestra", {"inventado": "a" * 64})])
def test_rechaza_confusion_semantica_de_hashes(esquema: str, esperados: dict) -> None:
    """Mismo nombre de clave (``prerregistro_sha256``), dos significados: el verificador exige nombrar cuál se espera."""
    assert codigo(V.verificar, FABRICAS[esquema](), esperados=esperados) == "HASH_SEMANTICA"


def test_rechaza_registro_de_cortes_para_otro_esquema(tmp_path: Path) -> None:
    (tmp_path / "x").write_bytes(b"x")
    assert codigo(V.verificar, evaluar(), registro=tmp_path / "x") == "HASH_SEMANTICA"


# ---------- evidencia contradictoria ----------
@pytest.mark.parametrize("obj", [
    oos(p_conj=0.97, p_btc=0.95, x2=0.01, decision="EVIDENCIA INSUFICIENTE"),  # sus cifras dan RESPALDADA
    oos(p_conj=0.97, p_btc=0.95, x2=0.0, decision="RESPALDADA FUERA DE MUESTRA"),  # x2 = 0 no basta
    oos(p_conj=0.05, decision="EVIDENCIA INSUFICIENTE"),  # sus cifras dan NO RESPALDADA
    oos(p_conj=0.10, decision="NO RESPALDADA"),  # 0,10 no es < 0,10
    evaluar(p_conj=0.97, p_btc=0.89, decision="VENTAJA RESPALDADA"),  # p_btc < 0,90
    evaluar(dias=700, decision="VENTAJA RESPALDADA"),  # 23 meses < 24
    evaluar(dias=300, p_conj=0.01, decision="HIPÓTESIS NO RESPALDADA: detener"),  # < 12 meses: informativo
    evaluar(p_conj=0.5, decision="VENTAJA RESPALDADA")])
def test_rechaza_decision_incoherente_con_sus_cifras(obj: dict) -> None:
    assert codigo(V.verificar, obj) == "CONTRADICCION"


@pytest.mark.parametrize("cambio,motivo", [
    (lambda o: o.update(meses=27.0), "dias/30,44"),
    (lambda o: o.update(dias=400, meses=400 / 30.44, decision="EVIDENCIA INSUFICIENTE: continuar",
                        bootstrap_conjunto={"aplicable": False, "motivo": "x"}), "0,5 por defecto"),  # sin P, ≥ 12 meses
])
def test_rechaza_contradicciones_internas_del_papel(cambio, motivo: str) -> None:  # type: ignore[no-untyped-def]
    o = evaluar()
    cambio(o)
    with pytest.raises(V.ErrorVerificacion, match=motivo) as e:
        V.verificar(o)
    assert e.value.codigo == "CONTRADICCION"


@pytest.mark.parametrize("cambio", [
    lambda c: c.update(corte_exclusivo="2029-03-13"),  # el corte no es el de su evaluación
    lambda c: c.update(reglas_sha256="9" * 64),  # reglas del corte ≠ reglas de la evaluación
    lambda c: c.update(codigo_sha256="9" * 64),
    lambda c: c.update(estado="NO EVALUABLE (ver problemas): no se calcula ningún resultado"),  # provisional con datos
    lambda c: c.update(evaluacion={k: v for k, v in c["evaluacion"].items() if k in (
        "prerregistro_sha256", "codigo_sha256", "rama", "inicio", "corte")} | {"estado": "datos no aptos para T_BTC"}),
])
def test_rechaza_corte_contradictorio(cambio) -> None:  # type: ignore[no-untyped-def]
    c = corte()
    cambio(c)
    assert codigo(V.verificar, c) == "CONTRADICCION"


def test_comparar_detecta_reproduccion_discrepante() -> None:
    a = oos()
    assert V.comparar(a, copy.deepcopy(a)) == []
    b = poner(a, "principal.conjunto.exceso_anual", 0.07 + 1e-12)
    assert V.comparar(a, b) and V.comparar(a, b, tolerancia=1e-9) == []  # tolerancia explícita, nunca implícita
    assert any("hash script" in d for d in V.comparar(a, poner(a, "script_sha256", "f" * 64)))
    assert any("p_btc" in d for d in V.comparar(a, poner(a, "principal.BTC.p", 0.84)))
    assert any("ic90" in d for d in V.comparar(a, poner(a, "principal.conjunto.ic90_anual", [-0.09, 0.24])))
    assert any("esquemas distintos" in d for d in V.comparar(a, evaluar()))
    sin_p = evaluar(dias=30, decision="INFORMATIVO (menos de 12 meses: ninguna decisión)")
    sin_p["bootstrap_conjunto"] = sin_p["bootstrap_btc"] = {"aplicable": False, "motivo": "x"}
    assert any("p_conjunto" in d for d in V.comparar(evaluar(dias=30, decision=sin_p["decision"]), sin_p))


# ---------- esquema ----------
@pytest.mark.parametrize("obj,cod", [
    ({}, "ESQUEMA"), ({"decision": "VENTAJA RESPALDADA"}, "ESQUEMA"),
    ({**oos(), "rama": "B", "corte": "2029-01-01", "inicio": "2027-01-01"}, "ESQUEMA"),  # ambiguo
    ({k: v for k, v in corte().items() if k != "evaluacion"} | {"corte_exclusivo": "2026-12-01",
        "estado": "SIN OBSERVACIONES PROSPECTIVAS: la primera ejecución es el 2026-10-18"}, "SIN_EVALUACION"),
    ({"prerregistro_sha256": "1" * 64, "codigo_sha256": "2" * 64, "rama": "B", "inicio": "2027-01-01",
      "corte": "2026-12-01", "estado": "sin datos de evaluación todavía"}, "SIN_EVALUACION")])
def test_esquema_desconocido_ambiguo_o_sin_evaluacion(obj: dict, cod: str) -> None:
    assert codigo(V.verificar, obj) == cod


# ---------- la incompatibilidad, reproducida ----------
def test_regresion_verificador_ingenuo_falla_con_el_esquema_fuera_de_muestra() -> None:
    """Un verificador escrito para la salida del papel (clave "decision") no puede leer el resultado fuera de muestra."""
    def ingenuo(r: dict) -> str:
        return r["decision"]
    with pytest.raises(KeyError):
        ingenuo(oos())
    assert V.verificar(oos())["decision"] == "EVIDENCIA INSUFICIENTE"


def test_regresion_mismo_nombre_de_clave_dos_hashes_distintos() -> None:
    """``prerregistro_sha256`` es el hash del ARCHIVO .md en fuera de muestra y el hash CANÓNICO de las reglas en el papel:
    comparar la clave a ciegas rechaza resultados correctos o acepta el hash equivocado."""
    reglas_canonicas, archivo_md = "d2e4e1fb" + "0" * 56, "94a16556" + "0" * 56
    o, e = poner(oos(), "prerregistro_sha256", archivo_md), poner(evaluar(), "prerregistro_sha256", reglas_canonicas)
    assert o["prerregistro_sha256"] != e["prerregistro_sha256"]  # lo que vería un verificador a ciegas
    V.verificar(o, esperados={"prerregistro_archivo": archivo_md})
    V.verificar(e, esperados={"reglas_canonicas": reglas_canonicas})
    assert codigo(V.verificar, o, esperados={"reglas_canonicas": reglas_canonicas}) == "HASH_SEMANTICA"


# ---------- comparación con el código congelado (solo lectura, sin importar ni ejecutar los módulos) ----------
def _funcion_congelada(ruta: Path, sha: str, nombre: str):  # type: ignore[no-untyped-def]
    datos = ruta.read_bytes()
    assert hashlib.sha256(datos).hexdigest() == sha, f"{ruta} cambió"
    nodo = next(n for n in ast.parse(datos).body if isinstance(n, ast.FunctionDef) and n.name == nombre)
    ns: dict = {}
    exec(compile(ast.Module(body=[nodo], type_ignores=[]), str(ruta), "exec"), ns)  # solo esa función
    return ns[nombre], nodo.lineno, nodo.end_lineno


@con_t
def test_reglas_identicas_a_las_congeladas() -> None:
    oos_f, ini, fin = _funcion_congelada(T / "experimentos" / "fuera_de_muestra_T.py", SCRIPT_SHA, "decision")
    assert (ini, fin) == (44, 49)
    papel_f, _, _ = _funcion_congelada(T / "src" / "tendencia" / "papel.py", PAPEL_PY_SHA, "decidir")
    ps = [0.0, 0.0999, 0.1, 0.5, 0.8999, 0.9, 0.9499, 0.95, 1.0]
    xs = [-0.01, 0.0, 1e-12, 0.05]
    for pc, pb, x in itertools.product(ps, ps, xs):
        assert V.decision_fuera_de_muestra(pc, pb, x) == oos_f(pc, pb, x)
        for m in (0.0, 11.99, 12.0, 23.99, 24.0, 60.0):
            assert V.decision_papel(m, pc, pb, x) == papel_f(m, pc, pb, x)


@con_t
def test_regresion_el_codigo_congelado_decide_con_p_por_defecto() -> None:
    """``evaluar`` hace ``b.get("p_mayor_que_cero", 0.5)``: con la clave ausente decide igual, en silencio."""
    papel_f, _, _ = _funcion_congelada(T / "src" / "tendencia" / "papel.py", PAPEL_PY_SHA, "decidir")
    texto = (T / "src" / "tendencia" / "papel.py").read_text(encoding="utf-8")
    assert 'b.get("p_mayor_que_cero", 0.5)' in texto
    sin_p = quitar(evaluar(dias=800, x2=0.05), "bootstrap_conjunto.p_mayor_que_cero")
    p = (lambda b: b.get("p_mayor_que_cero", 0.5))
    silenciosa = papel_f(sin_p["meses"], p(sin_p["bootstrap_conjunto"]), p(sin_p["bootstrap_btc"]), 0.05)
    assert silenciosa == "EVIDENCIA INSUFICIENTE: continuar"  # una decisión, sin dato que la sostenga
    assert codigo(V.verificar, poner(sin_p, "decision", silenciosa)) == "AUSENTE"


@con_t
def test_artefacto_real_fuera_de_muestra() -> None:
    """Verificación de solo lectura del resultado ya registrado. No recalcula nada a partir de datos de mercado."""
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    antes = hashlib.sha256(ruta.read_bytes()).hexdigest()
    assert antes == RESULTADO_SHA
    obj = json.loads(ruta.read_text(encoding="utf-8"))
    inf = V.verificar_archivo(ruta, raiz=T, esperados={
        "prerregistro_archivo": "94a165560ba2a1807bf604b079dbf2c8eea7e7e4401fcc5ccb5db275464db58f",
        "script": SCRIPT_SHA, "codigo": "73b22f3e3a8f21513d5533fb11a7553becae30b87c8736fb6880bccc36c11d2b"})
    assert inf["nivel"] == "VERIFICADO" and inf["resultado_sha256"] == RESULTADO_SHA
    assert inf["decision"] == inf["decision_recalculada"] == "EVIDENCIA INSUFICIENTE"
    assert (inf["p_conjunto"], inf["p_btc"], inf["dias"]) == (0.755, 0.8355, 1612)
    assert hashlib.sha256(ruta.read_bytes()).hexdigest() == antes


@con_t
def test_productor_real_de_cortes_con_fuente_simulada(tmp_path: Path) -> None:
    """``papel/corte.py`` real, en un directorio temporal y con la fuente simulada de sus pruebas (no datos de mercado):
    su salida pasa el verificador y una alteración de la decisión se rechaza."""
    pytest.importorskip("hcarry")
    if not (T / "papel" / "corte.py").is_file() or not (T / "tests" / "test_papel_corte.py").is_file():
        pytest.skip("papel/corte.py o su prueba no están (hoy no tienen commit)")
    spec = importlib.util.spec_from_file_location("_pruebas_corte", T / "tests" / "test_papel_corte.py")
    pc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pc)  # type: ignore[union-attr]
    r = pc.C.ejecutar("2027-10-19", raiz=tmp_path, abrir=pc.abridor(pc.fuente("2027-10-19")), base=None)
    assert r["estado"] == "EVALUADO"
    escrito = json.loads((tmp_path / "2027-10-19" / "resultado.json").read_text(encoding="utf-8"))
    inf = V.verificar_archivo(tmp_path / "2027-10-19" / "resultado.json", raiz=T, registro=tmp_path / "REGISTRO.jsonl")
    assert inf["nivel"] == "VERIFICADO" and inf["integridad_desde_archivos"]["reglas_canonicas"]
    assert inf["esquema"] == "papel_corte" and inf["decision"] == r["evaluacion"]["decision"]
    otra = next(d for d in V.DECISIONES_PAPEL if d != inf["decision"])
    assert codigo(V.verificar, poner(escrito, "evaluacion.decision", otra)) == "CONTRADICCION"


# ---------- línea de comandos ----------
def _cli(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, "-I", "-B", str(AQUI / "verificar_reproduccion_T.py"), *args],
                          capture_output=True, text=True, check=False)


def test_cli(tmp_path: Path) -> None:
    bueno, malo, roto, esp = (tmp_path / n for n in ("bueno.json", "malo.json", "roto.json", "esp.json"))
    bueno.write_text(json.dumps(oos()), encoding="utf-8")
    malo.write_text(json.dumps(quitar(oos(), "principal.BTC.p")), encoding="utf-8")
    roto.write_text("{no es json", encoding="utf-8")
    esp.write_text(json.dumps({"codigo": "f" * 64}), encoding="utf-8")
    r = _cli(str(bueno))  # sin --raiz: coherente, NO verificado
    assert r.returncode == 3 and json.loads(r.stdout)["resultado"] == "COHERENTE_SIN_INTEGRIDAD"
    r = _cli(str(malo))
    assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "AUSENTE"
    r = _cli(str(roto))
    assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "LECTURA"
    r = _cli(str(bueno), "--esperados", str(esp))
    assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "HASH"
    r = _cli(str(bueno), "--raiz", str(tmp_path / "no_existe"))
    assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "AUSENTE"
    assert _cli().returncode == 2 and _cli(str(bueno), "--otra", "x").returncode == 2
    assert _cli(str(bueno), "--raiz").returncode == 2
