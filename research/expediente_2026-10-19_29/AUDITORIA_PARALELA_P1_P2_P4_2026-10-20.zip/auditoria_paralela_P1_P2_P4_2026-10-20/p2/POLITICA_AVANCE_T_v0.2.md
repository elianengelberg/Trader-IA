# Política de avance de T: POLITICA_AVANCE_T v0.2 (2026-10-20)

**Estado:** PROPUESTA, **NO APROBADA**.
- Reemplaza a la v0.1 solo porque corrige defectos demostrados (ver `DICTAMEN_P2.md`). La v0.1 queda intacta en `00_entrega_original/p2/`.
- Implementación en `politica_avance_T.py`; pruebas en `test_politica_avance_T.py`; tabla completa en `TABLA_DECISION_P2_v0.2.md`.
- La función histórica `decidir` y el script fuera de muestra **no se importan, no se ejecutan y no se modifican**. Solo se citan sus textos.

## 1. Cuatro salidas que no se mezclan
| # | Salida | Qué puede cambiarla | Qué NO puede cambiarla |
|---|---|---|---|
| 1 | `etiqueta_estadistica`: texto **literal** del productor | Nada. Una etiqueta que no sea literal se rechaza | R1, R3, el exceso ≤ 0 y la etapa |
| 2 | `robustez`: diagnóstico **informativo** de R1 y R3 | Solo R1 y R3 evaluados con una **definición aprobada para T**. Hoy no existe ninguna (A1, A2), así que siempre es INDETERMINADA | La etiqueta y la decisión de avance |
| 3 | `decision_avance`: `CANDIDATA_A_REVISION_HUMANA` o `NO_CANDIDATA`, **con la etapa a la que se refiere** | Solo la clase de la etiqueta | R1, R3 y el exceso |
| 4 | `autorizacion_fase_posterior` | Nada: siempre `NO_OTORGADA`. Solo una decisión humana expresa, registrada fuera de la función, puede autorizar | Todo |

## 2. Etiquetas literales y su clase

| Etiqueta | Productor | Clase | Decisión de avance (etapa: NO_DEFINIDA) |
|---|---|---|---|
| `RESPALDADA FUERA DE MUESTRA` | `fuera_de_muestra_T.py:44-49` | RESPALDADA | CANDIDATA_A_REVISION_HUMANA |
| `NO RESPALDADA` | ídem | NO_RESPALDADA | NO_CANDIDATA |
| `EVIDENCIA INSUFICIENTE` | ídem | INSUFICIENTE | NO_CANDIDATA |
| `VENTAJA RESPALDADA` | `tendencia.papel.decidir` | RESPALDADA | CANDIDATA_A_REVISION_HUMANA |
| `HIPÓTESIS NO RESPALDADA: detener` | ídem | NO_RESPALDADA | NO_CANDIDATA |
| `EVIDENCIA INSUFICIENTE: continuar` | ídem | INSUFICIENTE | NO_CANDIDATA |
| `INFORMATIVO (menos de 12 meses: ninguna decisión)` | ídem | INFORMATIVO | NO_CANDIDATA |

**`NO_CANDIDATA` se refiere a una etapa con nombre.** Como hoy no hay ninguna etapa siguiente definida (A5), la salida dice `etapa: NO_DEFINIDA` y lo aclara en el texto: «esto no es una decisión universal: la acción vigente es la de la propia etiqueta».
- Para `HIPÓTESIS NO RESPALDADA: detener`, la acción vigente es «detener».
- Para `EVIDENCIA INSUFICIENTE: continuar`, la acción vigente es «continuar».

## 3. R1 y R3: cuándo pueden dejar de ser NO_DEFINIDO
Un estado `CUMPLE` o `NO_CUMPLE` solo se acepta como `(estado, id)`, donde `id` está en `DEFINICIONES_APROBADAS`. Ese registro **hoy está vacío**. La definición debe cumplir tres requisitos:
- tener los campos `id`, `criterio`, `aplica_a`, `texto_sha256`, `aprobada_utc` y `aprobada_por`;
- tener `criterio` igual a R1 o R3, según corresponda;
- tener `aplica_a = "T"`. **No se aceptan definiciones de E3 ni de otro experimento.**

**Post hoc.** Si una definición se aprobó en o después del **inicio de la ventana evaluada**, el diagnóstico se marca `post_hoc` con una advertencia y nunca se presenta como prerregistrado.
- Para el fuera de muestra de T (ventana desde 2022-01-01), **cualquier definición de hoy es post hoc**.
- Usar la fecha de inicio es la lectura conservadora; elegir otra fecha es la ambigüedad A7.

**Regla de combinación:** ROBUSTA solo si se cumplen ambas; NO_ROBUSTA si falla alguna; si no, INDETERMINADA. Viene de E3 v3 §6.3 («si se cumplen las seis»). Si se adopta para T es la ambigüedad **A6**; hoy no tiene efecto.

## 4. Ambigüedades que requieren tu decisión (no resueltas aquí)
| # | Ambigüedad | Estado en v0.2 |
|---|---|---|
| A1 | Definición de R1 para T. La única existente es la de E3 v3, «exceso neto > 0 con costos ×2». Con la transposición literal sería redundante con RESPALDADA, que ya exige costos ×2 > 0 | NO_DEFINIDO |
| A2 | Definición de R3 para T. IC̄ no tiene análogo en T, y T tiene 2 subventanas registradas, no 3 | NO_DEFINIDO |
| A3 | ¿R1 o R3 pueden vetar la candidatura? | No: solo generan una advertencia, siguiendo tu indicación de que son informativos |
| A4 | Uso de R1 y R3 sobre 2022–2026 | Sería post hoc (§3); además, R3 exigiría recalcular sobre la ventana consumida, lo que está prohibido |
| A5 | **Qué es la etapa siguiente de T** | `ETAPAS_DEFINIDAS` está vacío; etapa = NO_DEFINIDA |
| A6 | ¿La regla de combinación «todas» de E3 vale para T? | Sin efecto mientras R1 y R3 sean NO_DEFINIDO |
| A7 | ¿Qué fecha separa lo prerregistrado de lo post hoc: el inicio de la ventana o la fecha de ejecución? | Inicio de la ventana (conservador) |
| A8 | **Efecto mínimo relevante y definición económica de robustez** | No se decide aquí (D-S4) |

## 5. Entrada de resultados
`desde_resultado(ruta, raiz)` solo asigna una etiqueta si el verificador de P1 v0.2 da **VERIFICADO**, es decir, si la integridad se recalculó desde los archivos. En los demás casos no hay etiqueta:
- un resultado solo coherente da error;
- uno no evaluable da `SIN_EVALUACION`;
- uno alterado da `HASH` o `CONTRADICCION`.

## 6. Estado de T con esta política (solo lectura del JSON registrado)
| Etiqueta | Robustez | Decisión de avance | Etapa | Autorización |
|---|---|---|---|---|
| `EVIDENCIA INSUFICIENTE` (sin cambios) | INDETERMINADA | NO_CANDIDATA | NO_DEFINIDA | NO_OTORGADA |
