"""Pruebas sintéticas de la política de avance de T v0.2: tabla completa, todas las ramas, entradas inválidas,
separación etiqueta / robustez / avance / autorización y paso obligado por el verificador de P1 v0.2.
(Correr en un proceso aparte de las sondas de v0.1: ambos módulos se llaman igual.)"""
from __future__ import annotations

import ast
import hashlib
import itertools
import json
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent / "p1"))
import fabricas as F  # noqa: E402
import generar_tabla as G  # noqa: E402
import politica_avance_T as PA  # noqa: E402
import verificar_reproduccion_T as V  # noqa: E402

T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.py").is_file(), reason="T no disponible")
DEF = G.DEF_SINTETICAS

# Expectativas escritas a mano (no derivadas del módulo).
CLASE = {"RESPALDADA FUERA DE MUESTRA": "RESPALDADA", "VENTAJA RESPALDADA": "RESPALDADA",
         "NO RESPALDADA": "NO_RESPALDADA", "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
         "EVIDENCIA INSUFICIENTE": "INSUFICIENTE", "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
         "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO"}
ROB = {("CUMPLE", "CUMPLE"): "ROBUSTA", ("CUMPLE", "NO_CUMPLE"): "NO_ROBUSTA", ("CUMPLE", "NO_DEFINIDO"): "INDETERMINADA",
       ("NO_CUMPLE", "CUMPLE"): "NO_ROBUSTA", ("NO_CUMPLE", "NO_CUMPLE"): "NO_ROBUSTA",
       ("NO_CUMPLE", "NO_DEFINIDO"): "NO_ROBUSTA", ("NO_DEFINIDO", "CUMPLE"): "INDETERMINADA",
       ("NO_DEFINIDO", "NO_CUMPLE"): "NO_ROBUSTA", ("NO_DEFINIDO", "NO_DEFINIDO"): "INDETERMINADA"}
AVANCE = {"RESPALDADA": "CANDIDATA_A_REVISION_HUMANA", "NO_RESPALDADA": "NO_CANDIDATA", "INSUFICIENTE": "NO_CANDIDATA",
          "INFORMATIVO": "NO_CANDIDATA"}
COMB = list(itertools.product(CLASE, PA.ESTADOS_R, PA.ESTADOS_R))


def cod(f, *a, **k) -> str:  # type: ignore[no-untyped-def]
    with pytest.raises((PA.ErrorPolitica, V.ErrorVerificacion)) as e:
        f(*a, **k)
    return getattr(e.value, "codigo", "POLITICA")


@pytest.mark.parametrize("etiqueta,e1,e3", COMB)
def test_tabla_completa(etiqueta: str, e1: str, e3: str) -> None:
    s = PA.aplicar(etiqueta, G.valor("R1", e1), G.valor("R3", e3), fecha_inicio_ventana="2022-01-01", definiciones=DEF)
    assert s["etiqueta_estadistica"] == etiqueta and s["clase_estadistica"] == CLASE[etiqueta]
    assert (s["robustez"]["R1"]["estado"], s["robustez"]["R3"]["estado"], s["robustez"]["resumen"]) == (e1, e3, ROB[(e1, e3)])
    assert s["decision_avance"]["resultado"] == AVANCE[CLASE[etiqueta]] and s["decision_avance"]["etapa"] == "NO_DEFINIDA"
    assert s["autorizacion_fase_posterior"]["estado"] == "NO_OTORGADA"
    assert len(COMB) == 63


def test_archivo_de_tabla_coincide_con_la_politica() -> None:
    assert (AQUI / "TABLA_DECISION_P2_v0.2.md").read_text(encoding="utf-8") == G.markdown()


@pytest.mark.parametrize("etiqueta", list(CLASE))
def test_r1_r3_no_cambian_etiqueta_avance_ni_autorizacion(etiqueta: str) -> None:
    salidas = [PA.aplicar(etiqueta, G.valor("R1", a), G.valor("R3", b), fecha_inicio_ventana="2022-01-01",
                          definiciones=DEF, exceso_no_positivo=x)
               for a, b in itertools.product(PA.ESTADOS_R, repeat=2) for x in (None, True, False)]
    assert {s["etiqueta_estadistica"] for s in salidas} == {etiqueta}
    assert {s["decision_avance"]["resultado"] for s in salidas} == {AVANCE[CLASE[etiqueta]]}
    assert {s["autorizacion_fase_posterior"]["estado"] for s in salidas} == {"NO_OTORGADA"}


# ---------- R1/R3 sin definición aprobada para T ----------
def test_registros_vacios() -> None:
    assert PA.DEFINICIONES_APROBADAS == {} and PA.ETAPAS_DEFINIDAS == {}


@pytest.mark.parametrize("etiqueta", list(CLASE))
@pytest.mark.parametrize("r", ["CUMPLE", "NO_CUMPLE", ("CUMPLE", "R1-SINTETICA"), ("NO_CUMPLE", "R1-E3-v3")])
def test_sin_definicion_aprobada_solo_vale_no_definido(etiqueta: str, r: object) -> None:
    assert cod(PA.aplicar, etiqueta, r, "NO_DEFINIDO") == "POLITICA"  # registro real: vacío


def test_definicion_de_otro_experimento_o_criterio_se_rechaza() -> None:
    e3 = {"R1-E3": {**DEF["R1-SINTETICA"], "id": "R1-E3", "aplica_a": "E3"}}
    with pytest.raises(PA.ErrorPolitica, match="no se trasladan"):
        PA.aplicar("VENTAJA RESPALDADA", ("CUMPLE", "R1-E3"), definiciones=e3)
    with pytest.raises(PA.ErrorPolitica, match="no se trasladan"):  # definición de R1 usada como R3
        PA.aplicar("VENTAJA RESPALDADA", "NO_DEFINIDO", ("CUMPLE", "R1-SINTETICA"), definiciones=DEF)
    incompleta = {"R1-X": {"id": "R1-X", "criterio": "R1", "aplica_a": "T"}}
    with pytest.raises(PA.ErrorPolitica, match="campos"):
        PA.aplicar("VENTAJA RESPALDADA", ("CUMPLE", "R1-X"), definiciones=incompleta)


@pytest.mark.parametrize("aprobada,ventana,post_hoc", [("2026-10-20T12:00:00Z", "2022-01-01", True),
                                                       ("2022-01-01T00:00:00Z", "2022-01-01", True),
                                                       ("2021-12-31T23:00:00Z", "2022-01-01", False),
                                                       ("2000-01-01T00:00:00Z", None, True)])
def test_definicion_posterior_al_inicio_de_la_ventana_es_post_hoc(aprobada: str, ventana: str | None,
                                                                   post_hoc: bool) -> None:
    d = {"R1-SINTETICA": {**DEF["R1-SINTETICA"], "aprobada_utc": aprobada}}
    s = PA.aplicar("EVIDENCIA INSUFICIENTE", ("CUMPLE", "R1-SINTETICA"), fecha_inicio_ventana=ventana, definiciones=d)
    assert s["robustez"]["R1"]["post_hoc"] is post_hoc
    assert any("POST HOC" in a for a in s["advertencias"]) is post_hoc


# ---------- etapa y autorización ----------
def test_no_candidata_explicita_la_etapa_y_no_es_universal() -> None:
    s = PA.aplicar("EVIDENCIA INSUFICIENTE")
    assert s["decision_avance"]["etapa"] == "NO_DEFINIDA" and "no es una decisión universal" in s["decision_avance"]["texto"]
    etapas = {"ETAPA_SINTETICA_X": "solo para la prueba"}
    s = PA.aplicar("EVIDENCIA INSUFICIENTE", etapa="ETAPA_SINTETICA_X", etapas=etapas)
    assert s["decision_avance"]["texto"] == "T no es candidata a la etapa ETAPA_SINTETICA_X"
    s = PA.aplicar("VENTAJA RESPALDADA", etapa="ETAPA_SINTETICA_X", etapas=etapas)
    assert s["decision_avance"]["resultado"] == "CANDIDATA_A_REVISION_HUMANA"
    assert s["autorizacion_fase_posterior"]["estado"] == "NO_OTORGADA"
    with pytest.raises(PA.ErrorPolitica, match="no definida"):
        PA.aplicar("VENTAJA RESPALDADA", etapa="DINERO_REAL")


# ---------- entradas inválidas ----------
@pytest.mark.parametrize("etiqueta", ["respaldada fuera de muestra", "VENTAJA RESPALDADA ", "RESPALDADA", "", None, 1])
def test_etiqueta_no_literal(etiqueta) -> None:  # type: ignore[no-untyped-def]
    assert cod(PA.aplicar, etiqueta) == "POLITICA"


@pytest.mark.parametrize("r", [True, None, 1, "cumple", ("CUMPLE",), ("SI", "R1-SINTETICA"), ["CUMPLE", "R1-SINTETICA"]])
def test_r_invalido(r) -> None:  # type: ignore[no-untyped-def]
    assert cod(PA.aplicar, "VENTAJA RESPALDADA", r, definiciones=DEF) == "POLITICA"


@pytest.mark.parametrize("x", ["no", 0, 1, 0.0])
def test_exceso_no_booleano(x) -> None:  # type: ignore[no-untyped-def]
    assert cod(PA.aplicar, "EVIDENCIA INSUFICIENTE", exceso_no_positivo=x) == "POLITICA"


# ---------- solo resultados VERIFICADOS por P1 reciben etiqueta ----------
def test_desde_resultado_sintetico_verificado(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = tmp_path / "r.json"
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    s = PA.desde_resultado(ruta, raiz)
    assert s["etiqueta_estadistica"] == "EVIDENCIA INSUFICIENTE" and s["resultado_verificado"]["nivel"] == "VERIFICADO"


def test_desde_resultado_rechaza_lo_no_verificable(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = tmp_path / "r.json"
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    (raiz / "src" / "tendencia" / "a.py").write_text("X = 2\n", encoding="utf-8")  # código distinto
    assert cod(PA.desde_resultado, ruta, raiz) == "HASH"
    c = {k: v for k, v in F.corte().items() if k != "evaluacion"} | {"estado": "NO EVALUABLE (ver problemas)",
                                                                     "problemas": ["x"]}
    ruta.write_text(json.dumps(c), encoding="utf-8")
    assert cod(PA.desde_resultado, ruta, raiz) == "SIN_EVALUACION"  # no evaluable: sin etiqueta
    ruta.write_text(json.dumps(F.corte(F.evaluar(raiz=F.arbol_t(tmp_path / "T2")))), encoding="utf-8")
    with pytest.raises(PA.ErrorPolitica, match="no verificado"):  # corte sin --registro: solo coherente
        PA.desde_resultado(ruta, tmp_path / "T2")


@con_t
def test_resultado_historico_real() -> None:
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    antes = hashlib.sha256(ruta.read_bytes()).hexdigest()
    s = PA.desde_resultado(ruta, T)
    assert (s["etiqueta_estadistica"], s["robustez"]["resumen"], s["decision_avance"]["resultado"],
            s["decision_avance"]["etapa"], s["autorizacion_fase_posterior"]["estado"]) == (
        "EVIDENCIA INSUFICIENTE", "INDETERMINADA", "NO_CANDIDATA", "NO_DEFINIDA", "NO_OTORGADA")
    d = {"R1-SINTETICA": {**DEF["R1-SINTETICA"], "aprobada_utc": "2026-10-20T00:00:00Z"}}
    s = PA.desde_resultado(ruta, T, ("CUMPLE", "R1-SINTETICA"), definiciones=d)
    assert s["robustez"]["R1"]["post_hoc"] is True  # cualquier definición de hoy es post hoc para 2022–2026
    assert hashlib.sha256(ruta.read_bytes()).hexdigest() == antes


# ---------- estáticas ----------
def test_sin_umbrales_ni_importaciones_de_t() -> None:
    arbol = ast.parse((AQUI / "politica_avance_T.py").read_bytes())
    numeros = sorted({n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and type(n.value) in (int, float)})
    assert numeros == [0, 1, 2, 10]  # índices de ruta, tamaño de la tupla (estado, id), [:10] de una fecha, ≤ 0
    modulos = {a.name for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        n.module for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    assert modulos == {"__future__", "sys", "pathlib", "verificar_reproduccion_T"}


@con_t
def test_etiquetas_iguales_a_los_return_del_codigo_congelado() -> None:
    textos = set()
    for ruta, nombre in ((T / "experimentos" / "fuera_de_muestra_T.py", "decision"),
                         (T / "src" / "tendencia" / "papel.py", "decidir")):
        f = next(n for n in ast.parse(ruta.read_bytes()).body if isinstance(n, ast.FunctionDef) and n.name == nombre)
        textos |= {n.value.value for n in ast.walk(f) if isinstance(n, ast.Return)}
    assert textos == set(PA.ETIQUETAS)


def test_documento_corresponde_a_esta_version() -> None:
    doc = (AQUI / "POLITICA_AVANCE_T_v0.2.md").read_text(encoding="utf-8")
    assert PA.VERSION in doc and "NO APROBADA" in doc.upper()
    for etiqueta in PA.ETIQUETAS:
        assert f"`{etiqueta}`" in doc
