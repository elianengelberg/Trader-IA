"""SONDAS sobre la política de avance v0.1 tal como se entregó. Cada prueba D* PASA si el defecto EXISTE en v0.1;
las N* comprueban candidatos que resultan no ser defectos."""
from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

ORIGINAL = Path(__file__).resolve().parents[1] / "00_entrega_original"


def _cargar(nombre: str, ruta: Path):  # type: ignore[no-untyped-def]
    spec = importlib.util.spec_from_file_location(nombre, ruta)
    m = importlib.util.module_from_spec(spec)
    sys.modules[nombre] = m
    spec.loader.exec_module(m)  # type: ignore[union-attr]
    return m


PA1 = _cargar("politica_v0_1", ORIGINAL / "p2" / "politica_avance_T.py")
sys.path.insert(0, str(ORIGINAL / "p1"))
from test_verificar_reproduccion_T import oos  # noqa: E402  (fábrica de la suite v0.1)


def test_D1_no_avanza_sin_etapa() -> None:
    s = PA1.aplicar("EVIDENCIA INSUFICIENTE", "NO_DEFINIDO", "NO_DEFINIDO")
    assert s["avance"] == "NO AVANZA" and not any("etapa" in k for k in s)


def test_D2_acepta_r1_r3_evaluados_sin_definicion_aprobada_para_T() -> None:
    """No existe definición de R1/R3 para T, pero v0.1 acepta CUMPLE de quien sea (p. ej., una métrica de E3)."""
    s = PA1.aplicar("VENTAJA RESPALDADA", "CUMPLE", "CUMPLE")
    assert s["robustez"] == "ROBUSTA"


def test_D3_autorizacion_no_separada_del_avance() -> None:
    s = PA1.aplicar("VENTAJA RESPALDADA", "NO_DEFINIDO", "NO_DEFINIDO")
    assert "autorización" in s["avance"] and not any(k.startswith("autorizacion_fase") for k in s)


def test_D4_clasifica_un_resultado_solo_coherente_sin_integridad() -> None:
    """Con el verificador v0.1, ``desde_resultado`` etiqueta un resultado sin comprobar ningún archivo."""
    s = PA1.desde_resultado(oos(), "NO_DEFINIDO", "NO_DEFINIDO")
    assert s["etiqueta_estadistica"] == "EVIDENCIA INSUFICIENTE"


def test_D5_desde_resultado_modifica_sys_path_en_cada_llamada() -> None:
    antes = len(sys.path)
    PA1.desde_resultado(oos(), "NO_DEFINIDO", "NO_DEFINIDO")
    PA1.desde_resultado(oos(), "NO_DEFINIDO", "NO_DEFINIDO")
    assert len(sys.path) == antes + 2


def test_N1_la_etiqueta_nunca_cambia_por_r1_r3() -> None:
    for e in PA1.ETIQUETAS:
        for r1 in PA1.ESTADOS_R:
            for r3 in PA1.ESTADOS_R:
                assert PA1.aplicar(e, r1, r3)["etiqueta_estadistica"] == e


def test_N2_sin_umbrales_numericos_en_la_politica() -> None:
    """Las únicas constantes numéricas son 0 y 1: índices de ruta (sys.path.insert(0, …), parents[1]) y el
    «exceso ≤ 0» que vos fijaste como informativo. Ningún umbral inventado."""
    arbol = ast.parse((ORIGINAL / "p2" / "politica_avance_T.py").read_bytes())
    numeros = sorted({n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and type(n.value) in (int, float)})
    assert numeros == [0, 1]


def test_N3_no_importa_ni_altera_decidir() -> None:
    """Solo importa sys, pathlib y (dentro de desde_resultado) el verificador de P1; «decidir» aparece en un comentario."""
    arbol = ast.parse((ORIGINAL / "p2" / "politica_avance_T.py").read_bytes())
    modulos = {a.name for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        n.module for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    assert modulos == {"__future__", "sys", "pathlib", "verificar_reproduccion_T"}
