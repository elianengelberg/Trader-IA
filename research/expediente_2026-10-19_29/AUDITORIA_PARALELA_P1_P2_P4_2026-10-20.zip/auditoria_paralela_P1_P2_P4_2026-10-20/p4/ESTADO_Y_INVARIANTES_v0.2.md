# P4 v0.2: máquina de estados revisada, invariantes, pseudocódigo e interfaz de ancla (2026-10-20)

**Naturaleza:** prototipo **aislado** (`uso_unico.py` v0.2). Es una **propuesta**.
- **No está integrado** en `papel/corte.py`, en `fuera_de_muestra_T.py` ni en ningún ejecutor.
- **No se publicó ningún hash.**
- **Datos:** todos sintéticos.

La v0.1 queda intacta en `00_entrega_original/p4/`. El diff está en `evidencia/p4_diff_uso_unico_v0.1_v0.2.txt`.

## 1. Estados persistidos (se deducen del diario local, conciliado con el ancla)

```
NUEVO ─[ancla: RESERVA]→ RESERVADO ─[ancla: INICIO n]→ CALCULANDO (hijo aislado; solo en memoria)
   RESERVADO + CALCULO_INICIADO sin PRESELLADO = CALCULO_INTERRUMPIDO
   CALCULANDO → PRESELLADO (diario local, fsync) ─[ancla: PRESELLADO]→ (archivo atómico) → SELLADO → REGISTRADO
Terminales (nunca se abandonan): CONFLICTO · CORRUPTO · INCONSISTENTE · REVISION_HUMANA
```

| Estado | Reconocimiento | Qué hace la siguiente llamada |
|---|---|---|
| NUEVO | No hay diario | Hay tres casos:<ul><li>si el ancla registra un cálculo iniciado o un presellado para esta reserva → **RECHAZADO** (estado borrado o restaurado);</li><li>si el ancla tiene otra reserva del mismo experimento o con las mismas entradas → **RECHAZADO**;</li><li>si no → reserva en el ancla y luego en el diario local</li></ul> |
| RESERVADO | `RESERVADO`, sin `CALCULO_INICIADO` | Calcula: **no se inició ningún cálculo**, así que nada pudo observarse |
| CALCULO_INTERRUMPIDO | `CALCULO_INICIADO`, sin `PRESELLADO` | Si los cálculos iniciados (el **máximo** entre el diario local y el ancla) superan `reintentos_tras_inicio`, que está fijado en la reserva y vale 0 por defecto → **REVISION_HUMANA**. Si no, se reintenta |
| PRESELLADO | `PRESELLADO {sha}` | Anota el presellado en el ancla. Si el archivo existe y no coincide → CORRUPTO. Si no existe, recálculo de verificación: si no da el mismo sha → CONFLICTO |
| SELLADO / REGISTRADO | `SELLADO` / `REGISTRADO` | Verifica el archivo contra el presellado local y el del ancla. **No recalcula**, salvo para reponer exactamente los mismos bytes |
| INCONSISTENTE | La cadena no verifica, la secuencia es imposible, el ancla tiene un presellado que el diario no tiene (o uno distinto), o hay un resultado sin diario | No calcula. Si la cadena local es legible, lo anota como terminal |
| REVISION_HUMANA | Se agotaron los cálculos permitidos | No calcula. La salida de este estado es una decisión humana, fuera del prototipo |

**Resultados de una llamada que no son estados:**
- **OCUPADO:** otro proceso tiene el cerrojo.
- **RECHAZADO:** entradas, código, semilla, entorno, punto de entrada o reintentos distintos de los reservados (queda anotado), o un conflicto en el ancla.
- **FALLO_CALCULO:** el hijo falló; cuenta como cálculo iniciado.
- **ANCLA_NO_DISPONIBLE:** no se escribe ni se inicia nada que dependa del ancla.

## 2. Invariantes

| # | Invariante | Mecanismo | Pruebas (`test_uso_unico.py`) |
|---|---|---|---|
| I1 | La reserva es previa, única y liga **entradas, código, punto de entrada, semilla, entorno y reintentos** | Primero el ancla y luego `link` atómico del diario. Se calcula solo después de ambas | `test_entradas_codigo_entorno_o_configuracion_distintos…` (6), caídas `antes_de_reservar`, `durante_reserva` y `tras_reservar` |
| I2 | **El código ejecutado es el reservado** y se ejecuta sin salida visible | Proceso hijo `-I -S` sobre los bytes reservados. stdout y stderr van a /dev/null y el resultado vuelve por un descriptor propio. La API no acepta funciones | `test_no_se_puede_pasar_otra_funcion…`, `test_el_codigo_ejecutado_es_el_reservado…`, mutante M6 |
| I3 | **Ningún byte del resultado llega al disco antes de que su hash sea durable en el diario local y en el ancla** | Orden: `PRESELLADO` local con fsync → `ancla.registrar_presellado` → archivo atómico | `test_caida_reinicio_e_idempotencia` (rastreo de bytes), `tras_ancla`, mutante M2 |
| I4 | Tras el presellado, **solo vale ese resultado** | Un recálculo distinto da CONFLICTO; un archivo distinto da CORRUPTO; un presellado distinto en el ancla da INCONSISTENTE | `test_calculo_no_determinista…` (8 puntos), `test_resultado_alterado…`, `test_reescritura_coherente…` |
| I5 | **Un cálculo iniciado que no llegó al presellado no se repite sin permiso**: pudo observar un resultado | `CALCULO_INICIADO` se anota en el ancla y en el diario antes de lanzar el hijo. Recuento = máximo de los dos; tope = `reintentos_tras_inicio` reservado | Caídas `tras_iniciar_calculo`, `durante_calculo`, `tras_calculo` y `durante_presellado`; `test_calculo_que_falla…`; `test_restaurar_a_antes_de_un_calculo_iniciado…`; mutantes M3 y M5 |
| I6 | **Un fallo previo al inicio del cálculo se reintenta sin restricción** | Antes de `CALCULO_INICIADO` no se ejecutó ningún código reservado | Caídas `antes_del_cerrojo` … `tras_reservar`; `test_borrar_el_estado_antes_de_calcular…` |
| I7 | Con ancla, **el retroceso del estado local se detecta antes de calcular** (restauración de una copia, truncamiento de la cola, borrado) | Conciliación con el ancla en cada llamada | `test_restaurar_una_copia_antigua…` (2), `test_restaurar_tras_un_resultado_ya_escrito…`, `test_truncar_la_cola…` (2), `test_borrar_el_estado_con_ancla…`, mutantes M1 y M4 |
| I8 | El diario local está encadenado: una edición, inserción, reordenamiento o cambio de espacios en el medio da INCONSISTENTE **sin escribir**. Una línea a medias solo puede ser la última: se recorta y queda anotada | Cadena `n` + `anterior` + JSON canónico | `test_diario_editado…` (4), caídas `durante_presellado` y `durante_registro` |
| I9 | Los estados terminales son definitivos y **solo REGISTRADO trae resultado** | Comprobación al inicio; secuencia validada | Todas las de estados terminales |
| I10 | Exclusión: un solo proceso con el estado | `flock` no bloqueante; el núcleo lo libera si el proceso muere | `test_concurrencia_un_solo_calculo` (8 procesos), `…dos_directorios…`, `test_muerte_con_sigkill…` |
| I11 | La recuperación es idempotente | Reiniciar más dos repeticiones da el mismo estado y el mismo hash, sin cálculos extra | `test_caida_reinicio_e_idempotencia` (13 puntos × con y sin ancla × reintentos 0 y 1) |
| I12 | Durabilidad del orden | fsync del archivo, del directorio tras `link` y `replace`, y del padre al crear el directorio de estado o el ancla | `test_fsync_del_directorio_padre…`. Es una inspección ejecutable: **no se probó un corte de energía real** |

## 3. Pseudocódigo

```
ejecutar(dir, experimento, archivos{…, codigo}, semilla, punto_entrada, ancla?, reintentos):
  crear dir (fsync del padre); flock exclusivo no bloqueante          si está tomado → OCUPADO
  diario ← leer + verificar la cadena y la secuencia                  si falla → INCONSISTENTE (sin escribir)
  recortar la cola rota (anotada); borrar los temporales
  reserva ← {versión, experimento, semilla, punto_entrada, reintentos, entorno, sha256(archivos)}
  si el diario está vacío:
      si existe resultado.json → INCONSISTENTE
      si hay ancla: si ancla[reserva] tiene inicio o presellado → RECHAZADO (estado borrado o restaurado)
                    ancla.registrar_reserva (un conflicto → RECHAZADO; si no está disponible → ANCLA_NO_DISPONIBLE)
      crear el diario con RESERVADO (temporal + fsync + link)
  si el estado es terminal → anotar INTENTO; devolver el error
  si reserva ≠ diario[0] → anotar RECHAZADO_ENTRADAS_DISTINTAS; devolver RECHAZADO
  si hay ancla: reparar la reserva; si el ancla tiene un presellado y el diario no, o uno distinto → INCONSISTENTE
  anotar INTENTO
  si no hay presellado:
      n ← máx(CALCULO_INICIADO locales, inicios en el ancla)
      si n > reintentos → REVISION_HUMANA
      [ancla.registrar_inicio_calculo(n+1)]; anotar CALCULO_INICIADO(n+1)
      r ← hijo aislado(bytes reservados)          si falla → anotar CALCULO_FALLIDO; devolver FALLO_CALCULO
      anotar PRESELLADO(sha(r)) con fsync
  [ancla.registrar_presellado(sha)]               si no está disponible → ANCLA_NO_DISPONIBLE (no se escribe nada)
  si existe el archivo: si su sha ≠ el presellado → CORRUPTO
  si no: si r no está en memoria → anotar RECALCULO_DE_VERIFICACION; r ← hijo; si sha(r) ≠ presellado → CONFLICTO
         escribir r de forma atómica; anotar RESTAURADO si ya estaba sellado
  anotar SELLADO y REGISTRADO si faltan; devolver REGISTRADO(r)
```

## 4. Interfaz de ancla y qué fallo evita cada operación

| Operación | Semántica exigida | Fallo que evita |
|---|---|---|
| `consultar(reserva_sha) → {reserva, iniciados, presellado}` | Lectura consistente | Calcular sobre un estado local borrado, truncado o restaurado |
| `registrar_reserva(reserva_sha, reserva)` | Escritura única, idempotente y atómica con la comprobación de conflicto (mismo experimento o mismas entradas con otra reserva) | Renombrar el experimento o cambiar la semilla para obtener otra extracción; dos reservas concurrentes |
| `registrar_inicio_calculo(reserva_sha, n)` | Monótona: n solo crece; se rechaza después de un presellado | Borrar o restaurar el estado local después de que un cálculo pudo observar el resultado |
| `registrar_presellado(reserva_sha, sha)` | Escritura única: un segundo valor distinto se rechaza | Sustituir un resultado observable por otro (restauración, truncamiento, reescritura coherente del estado local) |
| Fallo de comunicación (`AnclaNoDisponible`) | El llamador no avanza | Escribir un resultado cuyo hash nadie fuera del estado local conoce |

**`AnclaArchivo` implementa la interfaz con un archivo local, y NO es un ancla externa.** Protege contra el borrado, la restauración o el truncamiento accidentales o parciales del directorio de estado. **No protege contra quien puede reescribir también el archivo del ancla** (`test_LIMITE_el_ancla_local_no_protege…`).

**Un ancla externa** tendría que ser un servicio de solo añadidos que el operador no pueda reescribir. Ejemplos:
- un registro de transparencia;
- un sellado de tiempo RFC 3161 encadenado;
- un repositorio remoto con historial protegido.

**Implementarla, contratarla o publicar hashes en ella requiere tu autorización (D-G6).** No se hizo.

## 5. Límites demostrados (pruebas `test_LIMITE_*`, que pasan cuando el límite **existe**)
| Límite | Prueba |
|---|---|
| **Sin ancla**, restaurar una copia antigua del estado da otra extracción con un cálculo no determinista | `test_LIMITE_sin_ancla_restaurar…` |
| **Sin ancla**, borrar todo permite repetir | `test_LIMITE_sin_ancla_borrar_todo…` |
| **Con ancla local**, quien restaura a la vez el estado y el ancla no es detectado | `test_LIMITE_el_ancla_local_no_protege…` |

## 6. Límites no resueltos ni probados
- **Corte de energía o reinicio de la máquina:** el orden de los fsync se verificó por inspección ejecutable. **No hubo inyección de fallos a nivel de disco** (por ejemplo, dm-flakey).
- **Canales laterales del código reservado:** el hijo no tiene stdout ni stderr, pero podría escribir archivos o usar la red. **No hay sandbox de sistema** (seccomp, espacios de nombres).
- **Determinismo:** si el cálculo no es determinista, la recuperación tras el presellado termina en CONFLICTO. Es seguro, pero bloquea.
- **Falso positivo conservador:** una caída entre `registrar_inicio_calculo` del ancla y la anotación local cuenta como un cálculo iniciado y lleva a REVISION_HUMANA con reintentos = 0.
- **Entorno:** solo se ligan la versión y la implementación del intérprete, no el hash del binario ni el de las bibliotecas.
- **Un solo equipo y un sistema de archivos local:** `flock` y `link` no tienen la misma semántica en NFS.
