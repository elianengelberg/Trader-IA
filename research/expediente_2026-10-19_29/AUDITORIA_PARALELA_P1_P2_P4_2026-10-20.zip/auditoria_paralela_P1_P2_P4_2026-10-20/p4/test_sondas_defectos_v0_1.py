"""SONDAS sobre el prototipo de uso único v0.1 tal como se entregó. Cada prueba D* PASA si el defecto o la falta de
protección EXISTE en v0.1; las N* comprueban protecciones que v0.1 sí tiene. Datos sintéticos; caídas reales en procesos
hijo con el conductor v0.1."""
from __future__ import annotations

import ast
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ORIGINAL = Path(__file__).resolve().parents[1] / "00_entrega_original" / "p4"
spec = importlib.util.spec_from_file_location("uso_unico_v0_1", ORIGINAL / "uso_unico.py")
U1 = importlib.util.module_from_spec(spec)
sys.modules["uso_unico_v0_1"] = U1
spec.loader.exec_module(U1)  # type: ignore[union-attr]
spec_c = importlib.util.spec_from_file_location("conductor_v0_1", ORIGINAL / "_conductor.py")
C1 = importlib.util.module_from_spec(spec_c)
sys.modules["uso_unico"] = U1  # el conductor v0.1 importa «uso_unico»
spec_c.loader.exec_module(C1)  # type: ignore[union-attr]


@pytest.fixture
def e(tmp_path: Path) -> dict:
    ent = tmp_path / "entradas"
    ent.mkdir()
    (ent / "protocolo.md").write_text("protocolo sintético\n", encoding="utf-8")
    (ent / "codigo.py").write_text("def calcular():\n    return 1\n", encoding="utf-8")
    (ent / "datos.txt").write_text(" ".join(map(str, [0.01, -0.02, 0.03, 0.005] * 10)), encoding="utf-8")
    return {"dir": str(tmp_path / "estado"), "experimento": "SINT", "semilla": 7, "contador": str(tmp_path / "n.txt"),
            "archivos": {k: str(ent / f) for k, f in (("protocolo", "protocolo.md"), ("codigo", "codigo.py"),
                                                      ("datos", "datos.txt"))}, "tmp": tmp_path}


def hijo(e: dict, **extra) -> int:  # type: ignore[no-untyped-def]
    args = {k: e[k] for k in ("dir", "experimento", "semilla", "archivos", "contador")} | extra
    r = subprocess.run([sys.executable, "-B", str(ORIGINAL / "_conductor.py"), json.dumps(args)], capture_output=True,
                       text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}, check=False, timeout=60)
    return r.returncode


def correr(e: dict, modo: str = "det", **kw):  # type: ignore[no-untyped-def]
    return U1.ejecutar(kw.get("dir", e["dir"]), e["experimento"], e["archivos"], e["semilla"],
                       C1.calculadora(modo, None, e["contador"]), registro_global=kw.get("registro_global"))


def llamadas(e: dict) -> int:
    p = Path(e["contador"])
    return len(p.read_text().splitlines()) if p.exists() else 0


def test_D1_el_codigo_ejecutado_no_esta_ligado_a_la_reserva(e: dict) -> None:
    """La reserva liga el hash de «codigo.py», pero se ejecuta la función que pase el llamador."""
    s = U1.ejecutar(e["dir"], "SINT", e["archivos"], 7, lambda c, sem: {"cualquier": "cosa"})
    assert s.estado == "REGISTRADO" and s.resultado == {"cualquier": "cosa"}


def test_D1b_la_reserva_no_liga_el_entorno() -> None:
    texto = (ORIGINAL / "uso_unico.py").read_text(encoding="utf-8")
    assert 'reserva = {"experimento": experimento, "semilla": semilla,' in texto and "sys.version" not in texto


def test_D2a_restaurar_una_copia_antigua_sin_ancla_da_otra_extraccion(e: dict) -> None:
    assert hijo(e, punto="durante_calculo", modo="no_determinista") == 137  # estado RESERVADO
    copia = e["tmp"] / "copia"
    shutil.copytree(e["dir"], copia)
    x = correr(e, "no_determinista")
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])  # se restaura el estado anterior al resultado
    y = correr(e, "no_determinista")
    assert x.estado == y.estado == "REGISTRADO" and x.resultado_sha256 != y.resultado_sha256


def test_D2b_con_el_registro_global_v0_1_la_segunda_extraccion_llega_al_disco(e: dict) -> None:
    reg = e["tmp"] / "global.jsonl"
    assert hijo(e, punto="durante_calculo", modo="no_determinista", registro_global=str(reg)) == 137
    copia = e["tmp"] / "copia"
    shutil.copytree(e["dir"], copia)
    x = correr(e, "no_determinista", registro_global=reg)
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    n = llamadas(e)
    y = correr(e, "no_determinista", registro_global=reg)
    en_disco = U1._sha((Path(e["dir"]) / "resultado.json").read_bytes())
    assert y.estado == "INCONSISTENTE" and llamadas(e) == n + 1  # se calculó otra vez
    assert en_disco != x.resultado_sha256  # y el segundo resultado quedó escrito (observable)


def test_D2c_observado_en_disco_y_luego_restaurado_con_registro_global(e: dict) -> None:
    """Caída tras escribir el archivo y antes de anotar el resultado en el registro global: el resultado X ya es
    observable. Se restaura el estado anterior y el recálculo Y queda REGISTRADO, también en el registro global."""
    reg = e["tmp"] / "global.jsonl"
    assert hijo(e, punto="durante_calculo", modo="no_determinista", registro_global=str(reg)) == 137
    copia = e["tmp"] / "copia"
    shutil.copytree(e["dir"], copia)
    assert hijo(e, punto="durante_registro", modo="no_determinista", registro_global=str(reg)) == 137
    x = U1._sha((Path(e["dir"]) / "resultado.json").read_bytes())  # observado
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    y = correr(e, "no_determinista", registro_global=reg)
    assert y.estado == "REGISTRADO" and y.resultado_sha256 != x


def test_D3_truncar_la_cola_del_diario_no_se_detecta_localmente(e: dict) -> None:
    correr(e, "no_determinista")
    ruta = Path(e["dir"]) / "DIARIO.jsonl"
    lineas = ruta.read_bytes().split(b"\n")[:-1]
    ruta.write_bytes(b"\n".join(lineas[:2]) + b"\n")  # quedan RESERVADO e INTENTO
    (Path(e["dir"]) / "resultado.json").unlink()
    assert correr(e, "no_determinista").estado == "REGISTRADO"  # prefijo de una cadena válida = cadena válida


def test_D4_no_distingue_caida_antes_del_calculo_de_caida_durante_el_calculo(e: dict, tmp_path: Path) -> None:
    """Un cálculo que muere al empezar y uno que muere tras calcular dejan el mismo diario."""
    assert hijo(e, punto="durante_calculo") == 137  # muere tras calcular (antes de devolver)
    a = U1.leer(e["dir"])["eventos"]
    e2 = {**e, "dir": str(tmp_path / "estado2")}
    guion = tmp_path / "muere_al_empezar.py"
    guion.write_text(f"import os, sys\nsys.path.insert(0, {str(ORIGINAL)!r})\nimport uso_unico as U\n"
                     f"U.ejecutar({e2['dir']!r}, 'SINT', {e['archivos']!r}, 7, lambda c, s: os._exit(137))\n")
    assert subprocess.run([sys.executable, "-B", str(guion)], check=False).returncode == 137
    assert U1.leer(e2["dir"])["eventos"] == a == ["RESERVADO", "INTENTO"]


def test_D5_sin_fsync_del_directorio_padre_al_crearlo() -> None:
    arbol = ast.parse((ORIGINAL / "uso_unico.py").read_bytes())
    llamadas_fsync = [ast.unparse(n.args[0]) for n in ast.walk(arbol) if isinstance(n, ast.Call)
                      and getattr(n.func, "id", "") == "_fsync_dir"]
    assert not any("parent" in x and "dir_estado" in x or x == "d.parent" for x in llamadas_fsync)
    assert "ruta.parent.mkdir(parents=True, exist_ok=True)" in (ORIGINAL / "uso_unico.py").read_text()


def test_D6_el_resultado_se_escribe_antes_de_que_el_registro_global_conozca_su_hash() -> None:
    texto = (ORIGINAL / "uso_unico.py").read_text(encoding="utf-8")
    assert texto.index("_escribir_atomico(archivo, crudo, fallo)") < texto.index("resultado_sha=pre))")


# ---------- protecciones que v0.1 sí tiene ----------
def test_N1_reserva_durable_antes_de_calcular() -> None:
    texto = (ORIGINAL / "uso_unico.py").read_text(encoding="utf-8")
    assert texto.index("os.link(tmp, d / DIARIO)") < texto.index("crudo = _canon(calcular(contenidos, semilla))")


def test_N2_edicion_intermedia_del_diario_se_detecta(e: dict) -> None:
    correr(e)
    ruta = Path(e["dir"]) / "DIARIO.jsonl"
    lineas = ruta.read_bytes().split(b"\n")[:-1]
    del lineas[1]
    ruta.write_bytes(b"\n".join(lineas) + b"\n")
    assert correr(e).estado == "INCONSISTENTE"


def test_N3_entradas_cambiadas_tras_la_reserva_se_rechazan(e: dict) -> None:
    assert hijo(e, punto="durante_calculo") == 137
    Path(e["archivos"]["datos"]).write_text("1 2 3", encoding="utf-8")
    assert correr(e).estado == "RECHAZADO"
