"""Pruebas sintéticas del prototipo de uso único v0.2 (P4). Caídas reales (os._exit(137) en un proceso hijo, SIGKILL),
procesos concurrentes reales, código de cálculo sintético ejecutado desde los bytes reservados. Ningún dato es de mercado.
Las pruebas «test_LIMITE_*» documentan límites: pasan cuando el límite EXISTE (no son garantías)."""
from __future__ import annotations

import inspect
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import uso_unico as U  # noqa: E402

CONDUCTOR = AQUI / "_conductor.py"
CODIGOS = AQUI / "codigos_sinteticos"
DATOS = [0.01, -0.02, 0.03, 0.005, -0.01, 0.02, 0.015, -0.005] * 5


def preparar(tmp: Path, codigo: str = "det", nombre: str = "e") -> dict:
    ent = tmp / f"entradas_{nombre}"
    ent.mkdir(parents=True)
    (ent / "protocolo.md").write_text("protocolo sintético v1\n", encoding="utf-8")
    (ent / "codigo.py").write_bytes((CODIGOS / f"{codigo}.py").read_bytes())
    (ent / "datos.txt").write_text(" ".join(map(str, DATOS)), encoding="utf-8")
    contador = tmp / f"llamadas_{nombre}.txt"
    (ent / "contador.txt").write_text(str(contador), encoding="utf-8")
    return {"dir": str(tmp / f"estado_{nombre}"), "experimento": "SINTETICO-1", "semilla": 7, "contador": str(contador),
            "archivos": {k: str(ent / f) for k, f in (("protocolo", "protocolo.md"), ("codigo", "codigo.py"),
                                                      ("datos", "datos.txt"), ("contador", "contador.txt"))},
            "tmp": tmp, "ancla": str(tmp / "ancla" / "ANCLA.jsonl")}


@pytest.fixture
def e(tmp_path: Path) -> dict:
    return preparar(tmp_path)


def ancla(e: dict) -> U.AnclaArchivo:
    return U.AnclaArchivo(e["ancla"])


def correr(e: dict, con_ancla: bool = False, reintentos: int = 0, **kw) -> U.Salida:  # type: ignore[no-untyped-def]
    return U.ejecutar(kw.get("dir", e["dir"]), kw.get("experimento", e["experimento"]), kw.get("archivos", e["archivos"]),
                      kw.get("semilla", e["semilla"]), ancla=kw.get("ancla_obj", ancla(e) if con_ancla else None),
                      reintentos_tras_inicio=reintentos)


def hijo(e: dict, con_ancla: bool = False, **extra) -> subprocess.Popen:  # type: ignore[no-untyped-def]
    args = {k: e[k] for k in ("dir", "experimento", "semilla", "archivos")} | (
        {"ancla": e["ancla"]} if con_ancla else {}) | extra
    return subprocess.Popen([sys.executable, "-B", str(CONDUCTOR), json.dumps(args)], stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})


def caer(e: dict, punto: str, **kw) -> None:  # type: ignore[no-untyped-def]
    p = hijo(e, punto=punto, **kw)
    p.wait(timeout=60)
    assert p.returncode == 137, p.stderr.read()


def llamadas(e: dict, esperar: int | None = None) -> int:
    p = Path(e["contador"])
    limite = time.time() + 20
    while True:  # un hijo de cálculo huérfano puede seguir unos milisegundos tras la caída del padre
        n = len(p.read_text(encoding="utf-8").splitlines()) if p.exists() else 0
        if esperar is None or n >= esperar or time.time() > limite:
            return n
        time.sleep(0.01)


def referencia(tmp: Path, codigo: str = "det") -> str:
    """Hash del resultado correcto, calculado aparte (otro contador; el resultado no depende de él)."""
    r = preparar(tmp / "ref", codigo, "ref")
    s = correr(r)
    assert s.estado == "REGISTRADO"
    return s.resultado_sha256


def eventos(e: dict) -> list[str]:
    return U.leer(e["dir"])["eventos"]


# ---------- flujo, código ligado, aislamiento ----------
@pytest.mark.parametrize("con_ancla", [False, True])
def test_flujo_normal_y_repeticiones(e: dict, con_ancla: bool) -> None:
    ref = referencia(e["tmp"])
    s = correr(e, con_ancla)
    assert (s.estado, s.resultado_sha256, s.calculado) == ("REGISTRADO", ref, True)
    assert ("LOCAL" in s.ancla) if con_ancla else s.ancla.startswith("NINGUNA")
    assert eventos(e) == ["RESERVADO", "INTENTO", "CALCULO_INICIADO", "PRESELLADO", "SELLADO", "REGISTRADO"]
    for _ in range(4):
        r = correr(e, con_ancla)
        assert (r.estado, r.resultado_sha256, r.calculado) == ("REGISTRADO", ref, False)
    assert llamadas(e) == 1 and eventos(e).count("INTENTO") == 5


def test_no_se_puede_pasar_otra_funcion_de_calculo() -> None:
    parametros = inspect.signature(U.ejecutar).parameters
    assert not any("calcul" in p and p != "reintentos_tras_inicio" for p in parametros)
    with pytest.raises(ValueError, match="codigo"):
        U.ejecutar("/nonexistent", "X", {"datos": "/dev/null"}, 1)


def test_el_codigo_ejecutado_es_el_reservado_y_no_tiene_salida_visible(tmp_path: Path, capfd) -> None:  # type: ignore[no-untyped-def]
    e = preparar(tmp_path, "imprime")
    s = correr(e)
    salida, errores = capfd.readouterr()
    assert (s.estado, s.resultado) == ("REGISTRADO", {"valor": 0.123})
    assert "FUGA-RESULTADO" not in salida + errores


@pytest.mark.parametrize("cambio", ["datos", "codigo", "semilla", "reintentos", "entorno", "punto_entrada"])
def test_entradas_codigo_entorno_o_configuracion_distintos_se_rechazan(e: dict, cambio: str, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    caer(e, "tras_reservar")
    kw: dict = {}
    if cambio == "datos":
        Path(e["archivos"]["datos"]).write_text("1 2 3", encoding="utf-8")
    elif cambio == "codigo":
        Path(e["archivos"]["codigo"]).write_bytes((CODIGOS / "nodet.py").read_bytes())
    elif cambio == "semilla":
        kw["semilla"] = 8
    elif cambio == "reintentos":
        kw["reintentos"] = 1
    elif cambio == "entorno":
        monkeypatch.setattr(U, "_entorno", lambda: {"python": "3.12.0 (otro)", "implementacion": "CPython"})
    if cambio == "punto_entrada":
        s = U.ejecutar(e["dir"], e["experimento"], e["archivos"], e["semilla"], punto_entrada="otra")
    else:
        s = correr(e, **kw)
    assert s.estado == "RECHAZADO" and llamadas(e) == 0
    assert eventos(e)[-1] == "RECHAZADO_ENTRADAS_DISTINTAS"


# ---------- caídas reales en cada punto ----------
# punto -> (estado al reiniciar con reintentos=0, cálculos totales; con reintentos=1, cálculos totales)
CAIDAS = {
    "antes_del_cerrojo": ("REGISTRADO", 1, "REGISTRADO", 1),
    "antes_de_reservar": ("REGISTRADO", 1, "REGISTRADO", 1),
    "durante_reserva": ("REGISTRADO", 1, "REGISTRADO", 1),
    "tras_reservar": ("REGISTRADO", 1, "REGISTRADO", 1),  # antes de iniciar el cálculo: se reintenta sin más
    "tras_iniciar_calculo": ("REVISION_HUMANA", 0, "REGISTRADO", 1),  # ya iniciado: no se repite sin permiso
    "durante_calculo": ("REVISION_HUMANA", 1, "REGISTRADO", 2),
    "tras_calculo": ("REVISION_HUMANA", 1, "REGISTRADO", 2),
    "durante_presellado": ("REVISION_HUMANA", 1, "REGISTRADO", 2),
    "tras_presellado": ("REGISTRADO", 2, "REGISTRADO", 2),  # recálculo de verificación: debe coincidir
    "tras_ancla": ("REGISTRADO", 2, "REGISTRADO", 2),
    "durante_escritura": ("REGISTRADO", 2, "REGISTRADO", 2),
    "tras_archivo": ("REGISTRADO", 1, "REGISTRADO", 1),
    "durante_registro": ("REGISTRADO", 1, "REGISTRADO", 1),
}


def test_todos_los_puntos_de_fallo_estan_probados() -> None:
    assert set(CAIDAS) == set(U.PUNTOS_DE_FALLO)


@pytest.mark.parametrize("reintentos", [0, 1])
@pytest.mark.parametrize("con_ancla", [True, False])
@pytest.mark.parametrize("punto", list(CAIDAS))
def test_caida_reinicio_e_idempotencia(tmp_path: Path, punto: str, con_ancla: bool, reintentos: int) -> None:
    if punto == "tras_ancla" and not con_ancla:
        pytest.skip("sin ancla ese punto no existe")
    e = preparar(tmp_path)
    ref = referencia(tmp_path)
    caer(e, punto, con_ancla=con_ancla, reintentos=reintentos)
    est, n = CAIDAS[punto][2 * reintentos], CAIDAS[punto][2 * reintentos + 1]
    if not (Path(e["dir"]) / U.RESULTADO).exists():  # nada observable antes del sellado salvo el temporal posterior
        visibles = b"".join(f.read_bytes() for f in Path(e["dir"]).iterdir() if f.is_file() and f.name != U.DIARIO)
        assert b"p_mayor_que_cero" not in visibles or punto == "durante_escritura"
    finales = [correr(e, con_ancla, reintentos) for _ in range(3)]  # reinicio y dos repeticiones: idempotente
    assert {s.estado for s in finales} == {est}
    if est == "REGISTRADO":
        assert {s.resultado_sha256 for s in finales} == {ref} and U.leer(e["dir"])["archivo_coincide"]
    else:
        assert all(s.resultado is None for s in finales) and not (Path(e["dir"]) / U.RESULTADO).exists()
    assert llamadas(e, esperar=n) == n
    assert not list(Path(e["dir"]).glob(".*.tmp")) and U.leer(e["dir"])["estado"] == est


# ---------- un resultado que pudo observarse nunca se sustituye ----------
@pytest.mark.parametrize("punto,esperado", [("durante_calculo", "REVISION_HUMANA"), ("tras_calculo", "REVISION_HUMANA"),
                                            ("durante_presellado", "REVISION_HUMANA"), ("tras_presellado", "CONFLICTO"),
                                            ("tras_ancla", "CONFLICTO"), ("durante_escritura", "CONFLICTO"),
                                            ("tras_archivo", "REGISTRADO"), ("durante_registro", "REGISTRADO")])
def test_calculo_no_determinista_nunca_da_una_segunda_extraccion(tmp_path: Path, punto: str, esperado: str) -> None:
    e = preparar(tmp_path, "nodet")
    caer(e, punto, con_ancla=True)
    pre = U.leer(e["dir"]).get("presellado")
    s = correr(e, True)
    assert s.estado == esperado and s.resultado_sha256 in (pre, None)
    if esperado != "REGISTRADO":
        assert correr(e, True).estado == esperado  # terminal


def test_reintento_explicito_permite_otra_extraccion_no_observada(tmp_path: Path) -> None:
    """Con reintentos_tras_inicio=1 (fijado en la reserva), un cálculo no determinista interrumpido se repite: es un
    riesgo aceptado explícitamente; por eso el valor por defecto es 0."""
    e = preparar(tmp_path, "nodet")
    caer(e, "tras_calculo", con_ancla=True, reintentos=1)
    assert correr(e, True, 1).estado == "REGISTRADO" and llamadas(e, esperar=2) == 2
    e2 = preparar(tmp_path, "nodet", "b")
    caer(e2, "tras_calculo", con_ancla=False, reintentos=1)
    caer(e2, "tras_calculo", con_ancla=False, reintentos=1)
    assert correr(e2, reintentos=1).estado == "REVISION_HUMANA"  # el cupo es finito


def test_calculo_que_falla_no_se_reintenta_sin_permiso(tmp_path: Path) -> None:
    e = preparar(tmp_path, "falla")
    assert correr(e, True).estado == "FALLO_CALCULO"
    assert correr(e, True).estado == "REVISION_HUMANA" and llamadas(e) == 1
    assert eventos(e)[-3:] == ["CALCULO_FALLIDO", "INTENTO", "REVISION_HUMANA"]


def test_muerte_con_sigkill_libera_el_cerrojo(tmp_path: Path) -> None:
    e = preparar(tmp_path, "lento")
    p = hijo(e, con_ancla=True, reintentos=1)
    llamadas(e, esperar=1)
    assert correr(e, True, 1).estado == "OCUPADO"
    p.send_signal(signal.SIGKILL)
    p.wait(timeout=30)
    assert correr(e, True, 1).estado == "REGISTRADO"


# ---------- restauración, truncamiento, borrado y reescritura del estado local ----------
@pytest.mark.parametrize("cuando", ["tras_reservar", "tras_iniciar_calculo"])
def test_restaurar_una_copia_antigua_con_ancla_se_detecta(tmp_path: Path, cuando: str) -> None:
    e = preparar(tmp_path, "nodet")
    caer(e, cuando, con_ancla=True, reintentos=1)
    copia = tmp_path / "copia"
    shutil.copytree(e["dir"], copia)
    x = correr(e, True, 1)
    assert x.estado == "REGISTRADO"
    n = llamadas(e)
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    s = correr(e, True, 1)
    assert (s.estado, s.resultado) == ("INCONSISTENTE", None) and "retroceso" in s.detalle
    assert llamadas(e) == n and not (Path(e["dir"]) / U.RESULTADO).exists()


def test_restaurar_a_antes_de_un_calculo_iniciado_y_no_terminado(tmp_path: Path) -> None:
    """El ancla recuerda el cálculo iniciado aunque el diario local restaurado no lo tenga: no hay segundo intento."""
    e = preparar(tmp_path, "nodet")
    caer(e, "tras_reservar", con_ancla=True)
    copia = tmp_path / "copia"
    shutil.copytree(e["dir"], copia)
    caer(e, "durante_calculo", con_ancla=True)
    llamadas(e, esperar=1)
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    assert correr(e, True).estado == "REVISION_HUMANA" and llamadas(e) == 1


def test_restaurar_tras_un_resultado_ya_escrito_con_ancla_se_detecta(tmp_path: Path) -> None:
    """El caso D2c de v0.1: el resultado X ya estaba en disco (observable) cuando se restaura el estado anterior."""
    e = preparar(tmp_path, "nodet")
    caer(e, "tras_reservar", con_ancla=True)
    copia = tmp_path / "copia"
    shutil.copytree(e["dir"], copia)
    caer(e, "durante_registro", con_ancla=True)
    assert (Path(e["dir"]) / U.RESULTADO).exists()
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    s = correr(e, True)
    assert (s.estado, s.resultado) == ("INCONSISTENTE", None) and llamadas(e) == 1


@pytest.mark.parametrize("hasta", [2, 3])  # [RESERVADO, INTENTO] / [..., CALCULO_INICIADO]
def test_truncar_la_cola_del_diario_con_ancla_se_detecta(tmp_path: Path, hasta: int) -> None:
    e = preparar(tmp_path, "nodet")
    correr(e, True)
    ruta = Path(e["dir"]) / U.DIARIO
    ruta.write_bytes(b"".join(x + b"\n" for x in ruta.read_bytes().split(b"\n")[:hasta]))
    (Path(e["dir"]) / U.RESULTADO).unlink()
    assert correr(e, True).estado == "INCONSISTENTE" and llamadas(e) == 1


def test_truncar_hasta_un_calculo_iniciado_sin_ancla_va_a_revision_humana(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    correr(e)
    ruta = Path(e["dir"]) / U.DIARIO
    ruta.write_bytes(b"".join(x + b"\n" for x in ruta.read_bytes().split(b"\n")[:3]))
    (Path(e["dir"]) / U.RESULTADO).unlink()
    assert correr(e).estado == "REVISION_HUMANA" and llamadas(e) == 1


def test_borrar_el_estado_con_ancla_no_permite_repetir(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    correr(e, True)
    shutil.rmtree(e["dir"])
    s = correr(e, True)
    assert s.estado == "RECHAZADO" and "falta el estado local" in s.detalle and llamadas(e) == 1
    s = correr(e, True, dir=tmp_path / "otro", experimento="SINTETICO-1-v2", semilla=8)
    assert s.estado == "RECHAZADO" and "mismas entradas" in s.detalle and llamadas(e) == 1


def test_borrar_el_estado_antes_de_calcular_con_ancla_permite_reanudar(tmp_path: Path) -> None:
    """Caída tras reservar (el ancla tiene la reserva pero ningún cálculo iniciado): nada pudo observarse."""
    e = preparar(tmp_path)
    caer(e, "tras_reservar", con_ancla=True)
    shutil.rmtree(e["dir"])
    assert correr(e, True).resultado_sha256 == referencia(tmp_path)


def _reescribir(e: dict, nuevo: bytes) -> None:
    d = Path(e["dir"])
    (d / U.RESULTADO).write_bytes(nuevo)
    evs = [json.loads(x) for x in (d / U.DIARIO).read_bytes().split(b"\n")[:-1]]
    anterior, salida = None, b""
    for ev in evs:
        if "resultado_sha256" in ev["datos"]:
            ev["datos"]["resultado_sha256"] = U._sha(nuevo)
        ev["anterior"] = anterior
        crudo = U._canon(ev)
        anterior = U._sha(crudo)
        salida += crudo + b"\n"
    (d / U.DIARIO).write_bytes(salida)


def test_reescritura_coherente_del_estado_local_con_ancla_se_detecta(e: dict) -> None:
    correr(e, True)
    _reescribir(e, b'{"media":1.0,"n":40,"p_mayor_que_cero":1.0}')
    s = correr(e, True)
    assert (s.estado, s.resultado) == ("INCONSISTENTE", None)


@pytest.mark.parametrize("edicion", ["borrar_linea", "reordenar", "espacios", "basura"])
def test_diario_editado_es_inconsistente_y_no_se_escribe(e: dict, edicion: str) -> None:
    correr(e)
    ruta = Path(e["dir"]) / U.DIARIO
    lineas = ruta.read_bytes().split(b"\n")[:-1]
    if edicion == "borrar_linea":
        del lineas[2]
    elif edicion == "reordenar":
        lineas[1], lineas[2] = lineas[2], lineas[1]
    elif edicion == "espacios":
        lineas[1] = lineas[1].replace(b",", b", ", 1)
    else:
        lineas.insert(2, b"{}")
    ruta.write_bytes(b"\n".join(lineas) + b"\n")
    antes = ruta.read_bytes()
    assert correr(e).estado == "INCONSISTENTE" and ruta.read_bytes() == antes


def test_resultado_alterado_es_corrupto_y_terminal(e: dict) -> None:
    correr(e)
    ruta = Path(e["dir"]) / U.RESULTADO
    original = ruta.read_bytes()
    ruta.write_bytes(original.replace(b'"n":40', b'"n":41'))
    assert correr(e).estado == "CORRUPTO"
    ruta.write_bytes(original)
    assert correr(e).estado == "CORRUPTO" and llamadas(e) == 1


def test_temporal_huerfano_nunca_se_lee(tmp_path: Path) -> None:
    e = preparar(tmp_path)
    ref = referencia(tmp_path)
    caer(e, "tras_presellado", con_ancla=True)
    falso = Path(e["dir"]) / ".resultado.json.99999.tmp"
    falso.write_bytes(b'{"media":1.0,"n":40,"p_mayor_que_cero":1.0}')
    s = correr(e, True)
    assert (s.estado, s.resultado_sha256) == ("REGISTRADO", ref) and not falso.exists()


# ---------- pérdida del ancla durante la persistencia ----------
class AnclaIntermitente(U.AnclaArchivo):
    """Falla (como una conexión perdida) en el método indicado, una vez."""

    def __init__(self, ruta: str, metodo: str):
        self.metodo, self.fallos = metodo, 1
        super().__init__(ruta)

    def __getattribute__(self, nombre: str):  # type: ignore[no-untyped-def]
        if nombre == object.__getattribute__(self, "metodo") and object.__getattribute__(self, "fallos"):
            self.fallos -= 1
            def caida(*_a, **_k):  # type: ignore[no-untyped-def]
                raise U.AnclaNoDisponible(f"{nombre}: conexión perdida (simulada)")
            return caida
        return object.__getattribute__(self, nombre)


@pytest.mark.parametrize("metodo,llamadas_total", [("consultar", 1), ("registrar_reserva", 1),
                                                   ("registrar_inicio_calculo", 1), ("registrar_presellado", 2)])
def test_ancla_no_disponible_nunca_deja_un_resultado_escrito(tmp_path: Path, metodo: str, llamadas_total: int) -> None:
    e = preparar(tmp_path)
    ref = referencia(tmp_path)
    s = correr(e, ancla_obj=AnclaIntermitente(e["ancla"], metodo))
    assert s.estado == "ANCLA_NO_DISPONIBLE" and s.resultado is None
    assert not (Path(e["dir"]) / U.RESULTADO).exists()
    r = correr(e, True)  # vuelve la conexión
    assert (r.estado, r.resultado_sha256) == ("REGISTRADO", ref) and llamadas(e) == llamadas_total


# ---------- concurrencia ----------
def test_concurrencia_un_solo_calculo(tmp_path: Path) -> None:
    e = preparar(tmp_path, "lento")
    inicio = time.time() + 1.0
    ps = [hijo(e, con_ancla=True, esperar_hasta=inicio) for _ in range(8)]
    salidas = [json.loads(p.communicate(timeout=120)[0]) for p in ps]
    assert {s["estado"] for s in salidas} <= {"REGISTRADO", "OCUPADO"} and llamadas(e) == 1
    assert len({s["resultado_sha256"] for s in salidas if s["estado"] == "REGISTRADO"}) == 1


def test_concurrencia_dos_directorios_mismas_entradas_con_ancla(tmp_path: Path) -> None:
    e = preparar(tmp_path, "lento")
    inicio = time.time() + 1.0
    a = hijo(e, con_ancla=True, esperar_hasta=inicio)
    b = hijo({**e, "dir": str(tmp_path / "estado_b"), "experimento": "SINTETICO-1-bis", "semilla": 99}, con_ancla=True,
             esperar_hasta=inicio)
    sa, sb = (json.loads(p.communicate(timeout=120)[0]) for p in (a, b))
    assert sorted([sa["estado"], sb["estado"]]) == ["RECHAZADO", "REGISTRADO"] and llamadas(e) == 1


# ---------- durabilidad (inspección ejecutable, no corte de energía real) ----------
def test_fsync_del_directorio_padre_al_crear_estado_y_ancla(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    e = preparar(tmp_path)
    llamados: list[Path] = []
    original = U._fsync_dir
    monkeypatch.setattr(U, "_fsync_dir", lambda d: (llamados.append(Path(d)), original(d)))
    correr(e, True)
    assert Path(e["dir"]).parent in llamados and Path(e["ancla"]).parent in llamados
    assert Path(e["dir"]) in llamados  # reserva (link) y resultado (replace)


# ---------- límites demostrados (pasan cuando el límite EXISTE) ----------
def test_LIMITE_sin_ancla_restaurar_una_copia_antigua_da_otra_extraccion(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    caer(e, "tras_reservar")
    copia = tmp_path / "copia"
    shutil.copytree(e["dir"], copia)
    x = correr(e)
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    y = correr(e)
    assert x.estado == y.estado == "REGISTRADO" and x.resultado_sha256 != y.resultado_sha256


def test_LIMITE_sin_ancla_borrar_todo_permite_repetir(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    x = correr(e)
    shutil.rmtree(e["dir"])
    y = correr(e)
    assert y.estado == "REGISTRADO" and x.resultado_sha256 != y.resultado_sha256


def test_LIMITE_el_ancla_local_no_protege_de_quien_tambien_la_reescribe(tmp_path: Path) -> None:
    """Quien puede escribir el estado local Y el archivo del ancla los restaura juntos: no se detecta. Hace falta un
    ancla externa (fuera del control del operador)."""
    e = preparar(tmp_path, "nodet")
    caer(e, "tras_reservar", con_ancla=True)
    copia, copia_ancla = tmp_path / "copia", tmp_path / "copia_ancla"
    shutil.copytree(e["dir"], copia)
    shutil.copytree(Path(e["ancla"]).parent, copia_ancla)
    x = correr(e, True)
    for origen, destino in ((copia, Path(e["dir"])), (copia_ancla, Path(e["ancla"]).parent)):
        shutil.rmtree(destino)
        shutil.copytree(origen, destino)
    y = correr(e, True)
    assert x.estado == y.estado == "REGISTRADO" and x.resultado_sha256 != y.resultado_sha256
