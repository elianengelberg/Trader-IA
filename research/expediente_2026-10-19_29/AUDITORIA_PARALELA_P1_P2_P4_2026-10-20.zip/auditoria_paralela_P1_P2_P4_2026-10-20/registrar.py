"""Añade una línea encadenada a REGISTRO_ACCIONES_Y_AUTORIZACIONES.jsonl (cada línea lleva el SHA-256 de la anterior)."""
import datetime as dt, hashlib, json, pathlib, sys
R = pathlib.Path(__file__).resolve().parent / "REGISTRO_ACCIONES_Y_AUTORIZACIONES.jsonl"
lineas = R.read_bytes().split(b"\n")[:-1] if R.exists() else []
accion, detalle, autorizacion = sys.argv[1], sys.argv[2], sys.argv[3]
ev = {"n": len(lineas), "utc": dt.datetime.now(dt.UTC).isoformat(timespec="seconds"), "accion": accion,
      "detalle": detalle, "autorizacion": autorizacion,
      "anterior_sha256": hashlib.sha256(lineas[-1]).hexdigest() if lineas else None}
with R.open("ab") as fh:
    fh.write(json.dumps(ev, ensure_ascii=False, sort_keys=True).encode() + b"\n")
