# AUDITORÍA CRUZADA FINAL: P1 v0.3 × P2 v0.3 × P4 v0.3 (2026-10-20)

**Pruebas:** `cruzada/test_interacciones.py`, **14 de 14** (`evidencia/cruzada_pytest.txt`).

**Datos y resultados sintéticos:**
- `cruzada/codigo_oos_sintetico.py` y su variante no determinista generan un resultado con el esquema fuera de muestra, con cifras inventadas.
- Única excepción: X8 lee en solo lectura el resultado real de T.

**Integración:** la función `cadena` de la prueba es una **propuesta de contrato P4 → P1 → P2**, no una integración. P1 exige el hash que **el ancla de P4** registró antes de que el resultado existiera en disco.

## 1. Interacciones

| # | Exigencia | Prueba | Resultado | Clase |
|---|---|---|---|---|
| X1 | P1 rechaza lo que no puede verificar | `test_X1_*` | Sin `--raiz`, COHERENTE_SIN_INTEGRIDAD. Falta un manifiesto: AUSENTE. REPRODUCIDO sin VERIFICADO: error INTEGRIDAD | VERIFICADO_POR_PRUEBA |
| X2 | P1 detecta la discrepancia con el hash autenticado por P4 | `test_X2_*` | Resultado alterado de forma coherente: sin el vínculo pasa (límite); con el hash del ancla, HASH. La cadena se detiene y P4 pasa a CORRUPTO | VERIFICADO_POR_PRUEBA |
| X3 | P2 no toma como evidencia un resultado rechazado por P1 | `test_X3_*` (3) | Validez RECHAZADO, etiqueta nula, NO_CANDIDATA | VERIFICADO_POR_PRUEBA |
| X4 | P2 no autoriza por una etiqueta favorable | `test_X4_*` | RESPALDADA más ROBUSTA (definiciones sintéticas) da CANDIDATA y NO_OTORGADA. Con una autorización externa sintética coherente, REGISTRADA_EXTERNAMENTE: constatada, no otorgada | VERIFICADO_POR_PRUEBA |
| X5 | P4 no presenta como válida una ejecución incompleta | `test_X5_*` (2) | FALLO_CALCULO, luego REVISION_HUMANA; NO_DETERMINISTA. Sin resultado ni archivo; la cadena se detiene | VERIFICADO_POR_PRUEBA |
| X6 | Un fallo técnico no habilita repetir | `test_X6_*` | Después de un rechazo de P1, repetir P4 no recalcula; «arreglar» las entradas da RECHAZADO; P2 da NO_OTORGADA | VERIFICADO_POR_PRUEBA |
| X7 | La recuperación no cambia lo reservado | `test_X7_*` (y `p4/test_v0_3.py::test_recuperacion_*`) | Misma `reserva_sha256`, mismo resultado, primera línea del diario intacta. Los hashes del resultado son los de los archivos reservados | VERIFICADO_POR_PRUEBA |
| X8 | Ningún componente modifica el resultado congelado de T | `test_X8_*` | SHA-256 y `mtime_ns` de 15 archivos reales leídos, iguales antes y después; el JSON sigue en `4f8fafde…` | VERIFICADO_POR_PRUEBA |
| X9 | P1 y P2 no ejecutan ni escriben; P4 solo lanza su hijo | `test_X9_*` (2) | Inspección con `ast`: sin `subprocess`, `exec` ni escrituras en P1 y P2; P4 lanza un único hijo y no nombra a los ejecutores de T | VERIFICADO_POR_INSPECCION (ejecutable) |

## 2. Probado en el prototipo frente a lo que requiere integración real

| Propiedad | En el prototipo | Requiere integración real |
|---|---|---|
| Un único cálculo por reserva y que no se sustituya un resultado presellado | Sí, con el ancla local y los supuestos de P4 | Ancla externa (S-a) y ejecutor protegido real |
| P1 contra el hash autenticado por P4 | Sí, en la cadena sintética | Que el productor real pase por P4 y que el ancla sea externa |
| Autenticidad del árbol de T | **No** | Commits publicados o un ancla externa |
| P2 con definiciones, etapas y autorizaciones reales | Solo con registros sintéticos | Tus decisiones (A1–A8) y un registro aprobado y anclado |
| Corte de energía, NFS, sandbox | No | Pruebas de sistema |
| El resultado histórico de T por la cadena completa | **No aplica:** ya se ejecutó sin P4 y no se repite | — |

## 3. Hallazgos de esta ronda en las interacciones
- **X2:** con P4 v0.3, el hash exigido por P1 se toma del ancla, no del diario local. Un diario local reescrito ya no puede sustituir el hash de referencia.
- **Falso positivo corregido en la prueba estática X9:** la versión anterior tomaba `str.replace` por `os.replace`. Ahora distingue llamadas por nombre completo y modo de apertura.
