# DICTAMEN P1 FINAL: verificador de reproducción de T (cierre técnico, 2026-10-20)

**Clasificaciones usadas:**
- **[INSP]** VERIFICADO_POR_INSPECCION
- **[PRUEBA]** VERIFICADO_POR_PRUEBA
- **[INF]** INFERIDO
- **[NO_VER]** NO_VERIFICADO
- **[AUT]** REQUIERE_AUTORIZACION

**Revisor:** el mismo agente que escribió v0.1 y v0.2. Es una auto-auditoría adversarial, no una revisión por un tercero.

## 1. Estado técnico
La v0.3 (`p1/verificar_reproduccion_T.py`) es una **propuesta aislada; no está aplicada ni aprobada**.

**Propiedad demostrada [PRUEBA]:** el verificador solo emite VERIFICADO si se cumplen las seis condiciones siguientes:
1. el JSON es legible, sin claves duplicadas y con el esquema estricto del productor real;
2. la decisión recalculada con la regla congelada coincide con la registrada;
3. cada hash declarado se recalcula desde los archivos de `--raiz`;
4. el código fijado en el script y el inicio prerregistrado coinciden con el resultado;
5. si se pasan manifiestos o el hash presellado, coinciden;
6. en un corte, también coinciden el registro, los manifiestos de datos del corte y las tablas de decisiones.

**REPRODUCIDO** se emite solo si el original es VERIFICADO, la reproducción pasa la misma validación estructural y `comparar_completo` no encuentra diferencias con una tolerancia explícita.

**Propiedad NO demostrada:** autenticidad. Sin una raíz de confianza independiente, VERIFICADO significa «coherente con los archivos locales», no «auténtico». El informe lo dice siempre en el campo `autenticidad`.

## 2. Respuestas a las comprobaciones del encargo

| Pregunta | Respuesta | Clase | Evidencia |
|---|---|---|---|
| ¿Hashes desde archivos o contra constantes? | Desde archivos: script, prerregistro, cada `src/tendencia/*.py` más su huella, los `MANIFIESTO.json`, el JSON de reglas y los archivos del corte. Las referencias declaradas («esperados») no cuentan para VERIFICADO | [PRUEBA] | `test_v0_2.py::test_D2_*`, `test_v0_3.py::test_S3_*` |
| ¿Contenido, origen declarado y correspondencia entre archivos? | Contenido: sí. Correspondencias: `codigo_sha256` = CODIGO del script (nuevo en v0.3) y `inicio` = prerregistro (nuevo); en el corte, manifiestos y tablas (nuevo). **Origen declarado:** `categoria` solo se exige como texto no vacío. No hay forma local de verificar el origen | [PRUEBA] / [NO_VER] (origen) | `test_S4_*`, `test_S8_*`, `test_S7_*` |
| ¿Puede aceptar un resultado alterado de forma coherente? | **Sí, si no se le da ninguna referencia externa.** Con `--manifiesto` (por ejemplo `EVIDENCIA_T_MULTI.json#cadena_historica_T_fuera_de_muestra`) o con el hash presellado por P4, no lo acepta. Si se alteran juntos el archivo y un manifiesto no autenticado, lo acepta: es un límite y el informe lo declara | [PRUEBA] | `test_S3_resultado_sustituido…`, `test_LIMITE_archivo_y_manifiesto…` |
| ¿REPRODUCIDO con campos ausentes, claves duplicadas, filas faltantes o tipos incorrectos? | No: cada uno es un error previo y REPRODUCIDO exige VERIFICADO. Casos de compuerta en `test_S6_…`: sin VERIFICADO, reproducción con clave inesperada, 4 tolerancias inválidas y una discrepancia | [PRUEBA] | `test_S6_reproducido_solo_tras_verificado…`, suites de ausentes, tipos y duplicadas |
| ¿`contraste_btc_diario_vs_horario`? | **P1 no la lee ni la acepta: no forma parte de ningún resultado que P1 verifica.** Existe solo en `experimentos/calidad_datos.json` (commit 5120d4c, SHA-256 `88644d85…`, listado en `ARTEFACTOS_SHA256.txt`), con `comparados 2435, distintos 0, sin_horaria 0, ejemplos []`. **Su productor no está en el repositorio, en el historial de git ni en el scratchpad**, y ningún verificador la comprueba. **Su semántica no es verificable con la evidencia disponible.** Verificarla exigiría el script productor o volver a derivarla desde datos 1d y 1h, lo que está prohibido en esta fase | [INSP] / [NO_VER] (semántica) | `evidencia/00_preservacion.txt`; búsqueda registrada |
| ¿Número de filas y símbolos? | **Símbolos:** conjuntos exactos `{BTC, ETH, conjunto}`, `{BTCUSDT, ETHUSDT}` y costos ×2 (nuevo; v0.2 aceptaba que faltara ETH). **Filas:** en un corte, cada tabla de decisiones tiene `dias` filas de días consecutivos desde el inicio y su hash reconstruido coincide (nuevo). El resultado fuera de muestra no tiene filas | [PRUEBA] | `test_S2_*`, `test_S7_*` (productor real con fuente simulada: 366 filas) |
| ¿Decisión desde los campos correctos? | Fuera de muestra: `principal.conjunto.p`, `principal.BTC.p`, `secundarios.costes_x2.conjunto`, igual que el script (`decision(principal["conjunto"]["p"], principal["BTC"]["p"], x2["conjunto"]["exceso_anual"])`; `sec["costes_x2"]` guarda el mismo valor). Papel: P del bootstrap; el exceso ×2 diario frente al anual tiene el mismo signo | [INSP] y [PRUEBA] (rejilla contra las funciones congeladas) | `test_reglas_identicas_a_las_congeladas` |
| ¿Valores numéricos, redondeos y tolerancias? | Umbrales con comparación exacta de doble precisión, idéntica a la del código congelado (≥, <, >). **Ningún redondeo.** La identidad `meses = dias / 30,44` tiene tolerancia absoluta 1e-9. La reproducción tiene tolerancia absoluta explícita (0 por defecto), solo para números. Los hashes se calculan sobre los bytes del archivo, sin volver a serializar | [INSP] | Código; `test_S5_*` |
| ¿No verificable, inválido y válido? | `RECHAZADO` (salida 1) = inválido. `NO_EVALUABLE` (4) = corte provisional coherente. `COHERENTE_SIN_INTEGRIDAD` (3) = no verificable. `VERIFICADO` (0). `REPRODUCIDO` (0) y `NO_REPRODUCIDO` (5) | [PRUEBA] | Pruebas de línea de comandos |
| ¿El hash del resultado coincide con el de P4? | Sí, si se pasa (`--resultado-sha256`). En la cadena cruzada se toma del **ancla** de P4 | [PRUEBA] | `cruzada/test_X2_*` |
| ¿Manifiestos inequívocamente relacionados con sus archivos? | Rutas relativas a `--raiz`, contraste por ruta completa. El resultado debe figurar en el manifiesto. Manifiestos en conflicto dan CONTRADICCION. Un resultado fuera de `--raiz` no puede ser descrito | [PRUEBA] | `test_S3_el_manifiesto_debe_describir…`, `test_manifiesto_sha256sum_y_conflicto…` |

## 3. Defectos

| # | Defecto en v0.2 (sonda: `p1/test_sondas_v0_2.py`, 13 de 13) | Estado en v0.3 |
|---|---|---|
| S1 | Acepta claves inesperadas (por ejemplo, un `decision` suelto en el resultado fuera de muestra) | **Corregido** [PRUEBA]: `CLAVE_INESPERADA` en 6 ubicaciones, además de papel y corte |
| S2 | Acepta que falten o sobren símbolos (`principal.ETH` ausente, `SOLUSDT` agregado) | **Corregido** [PRUEBA] |
| S3 | Acepta una falsificación coherente de script y resultado; no consulta los registros del repositorio | **Corregido con referencia** [PRUEBA]: `--manifiesto` (`ARTEFACTOS_SHA256.txt`, `EVIDENCIA_T_MULTI.json#…`). **Permanece sin referencia externa** (límite) |
| S4 | No contrasta `codigo_sha256` con el CODIGO fijado en el script | **Corregido** [PRUEBA] |
| S5 | `comparar` ignora campos (ETH, secundarios, ventana) | **Corregido** [PRUEBA]: además, `comparar_completo` |
| S6 | No hay REPRODUCIDO con integridad previa | **Corregido** [PRUEBA]: `reproducir` |
| S7 | No comprueba las tablas de decisiones ni los manifiestos de datos del corte | **Corregido** [PRUEBA] con el productor real y fuente simulada: fila borrada, valor alterado, columna, día saltado, tabla ausente y manifiesto de datos |
| S8 | No contrasta el inicio del corte con el prerregistro | **Corregido** [PRUEBA]. La rama B se calcula y se cruza con el texto del prerregistro (`2027-04-13`) |
| N1–N3 | Hashes desde archivos; duplicadas y truncados; hash presellado | **Ya correctos en v0.2** [PRUEBA] |

**Defectos de v0.1 (D1–D10), corregidos en v0.2:** siguen corregidos. Su regresión (152 pruebas) pasa con v0.3 [PRUEBA].
- **Ajuste de casos sintéticos:** los cortes provisionales ahora tienen las claves exactas del productor real. Antes conservaban `dias_calendario` y `decisiones_sha256`, que el productor solo escribe en un corte EVALUADO. Diff en `evidencia/diff_v0.2_v0.3_verificar_reproduccion_T.txt`.

**Pendientes (no corregibles con la evidencia disponible):**
1. **Autenticidad** frente a terceros: falta una raíz de confianza independiente; requiere publicar los commits o un ancla [AUT].
2. **Bytes de los archivos de datos** reales frente a sus manifiestos: `--datos` existe, pero solo se probó con datos sintéticos [NO_VER] [AUT].
3. **La huella del código cubre solo `src/tendencia/*.py`:** no cubre `hcarry/lab/estadistica.py` ni el intérprete. Así lo define el protocolo congelado [INSP].
4. **Semántica de `contraste_btc_diario_vs_horario`** [NO_VER].

## 4. Artefacto real (solo lectura)
**VERIFICADO** contra `ARTEFACTOS_SHA256.txt` más `EVIDENCIA_T_MULTI.json#cadena_historica_T_fuera_de_muestra`. Coinciden el JSON (`4f8fafde…`), el script, el prerregistro, los 7 `src/tendencia/*.py` y los 2 `MANIFIESTO.json`; no hay archivos no listados. Autenticidad: NO_VERIFICADA [PRUEBA].

**Límite de la referencia (hallazgo):** `ARTEFACTOS_SHA256.txt` **no lista** los tres artefactos fuera de muestra, ni en HEAD ni en la copia de trabajo, que además tiene cambios sin commit. Solo los lista `EVIDENCIA_T_MULTI.json`, que está en commits locales sin publicar [INSP].

## 5. Compatibilidad del parche
`p1/P1_verificador_v0.3.patch` agrega 5 archivos nuevos en `research/tendencia_btc/verificacion/`. **No se aplicó al repositorio.**

| Base | `git apply --check` | Suite del parche en la copia |
|---|---|---|
| HEAD `692f2b2` (local, sin publicar) | OK | 173 pasan y 14 se omiten |
| origin `c6339e3` | OK | 166 pasan y 21 se omiten |

Las pruebas se omiten donde faltan `corte.py` o los artefactos de T (origin no tiene los artefactos fuera de muestra) [PRUEBA]. Detalle en `evidencia/p1_compatibilidad_parche_v0.3.txt`.

## 6. Supuestos y riesgos residuales
- **Supuesto:** el árbol que se pasa en `--raiz` es el del experimento. P1 no puede saber si alguien lo sustituyó entero [INF].
- **Riesgo:** un usuario que cambie a la vez el resultado, los archivos y los manifiestos locales no es detectado. Es el límite S3, declarado en cada informe.
- **Riesgo:** el esquema estricto puede rechazar un resultado legítimo de un productor futuro que agregue claves. Eso es deliberado: requiere una versión nueva del verificador.
