# DICTAMEN P2 FINAL: política de robustez y avance de T (cierre técnico, 2026-10-20)

**Clasificaciones usadas:**
- **[INSP]** VERIFICADO_POR_INSPECCION
- **[PRUEBA]** VERIFICADO_POR_PRUEBA
- **[INF]** INFERIDO
- **[NO_VER]** NO_VERIFICADO
- **[AUT]** REQUIERE_AUTORIZACION

**Revisor:** auto-auditoría adversarial, no una revisión por un tercero.

## 1. Estado técnico
La v0.3 (`p2/politica_avance_T.py`) es una **propuesta: no aprobada**.

**Propiedades demostradas [PRUEBA]**, en las 3.360 filas de la tabla completa y en pruebas por rama:
- la etiqueta histórica nunca cambia, y sin evidencia válida no se asigna;
- R1 y R3 nunca cambian la clase ni el avance;
- la política nunca otorga una autorización;
- toda entrada faltante o contradictoria produce un estado explícito o un error, nunca un valor por defecto silencioso;
- la salida es determinista.

**Propiedad NO demostrada:** que las reglas sean metodológicamente adecuadas para T. Eso depende de decisiones tuyas: A1–A8 en `MATRIZ_DECISIONES_PENDIENTES.md`.

## 2. Cinco dimensiones separadas (v0.3)
| # | Dimensión | De dónde sale | Qué NO puede cambiarla |
|---|---|---|---|
| 0 | Validez de la evidencia | P1: VERIFICADO, REPRODUCIDO, COHERENTE_SIN_INTEGRIDAD, NO_EVALUABLE, RECHAZADO o NO_REPRODUCIDO. Solo las dos primeras son evidencia | R1, R3, etapa, autorización |
| 1 | Etiqueta estadística histórica | Texto literal del productor congelado, **solo con evidencia válida**; si no, queda como «declarada» | Todo lo demás |
| 2 | Diagnóstico de robustez | R1 y R3: **argumentos obligatorios**. NO_DEFINIDO si no hay definición aprobada para T; NO_EVALUADO si la hay pero no se evaluó; (CUMPLE o NO_CUMPLE, id) solo con una definición aprobada para T. Registro hoy **vacío** | La etiqueta y el avance |
| 3 | Decisión de avance | Solo la clase: RESPALDADA da CANDIDATA_A_REVISION_HUMANA; lo demás, NO_CANDIDATA, **siempre con la etapa nombrada** (hoy `NO_DEFINIDA`, y el texto dice que no es una decisión universal) | R1, R3, el exceso |
| 4 | Autorización de ejecución | **La política nunca la otorga.** Solo constata un registro humano externo: NO_OTORGADA, REGISTRADA_EXTERNAMENTE (coincide etapa, resultado y clase) o CONTRADICTORIA (cualquier incoherencia). Registro hoy **vacío** | La etiqueta y la robustez |

## 3. Comprobaciones del encargo
| Comprobación | Resultado | Clase |
|---|---|---|
| La etiqueta no cambia por R1 o R3 | En las 3.360 filas y en las pruebas de invariancia | [PRUEBA] |
| R1 y R3 en NO_DEFINIDO mientras no exista una definición válida para T | Con el registro vacío, solo NO_DEFINIDO es aceptado; CUMPLE, NO_CUMPLE y NO_EVALUADO se rechazan. Una definición de E3, de otro criterio o con campos de más (por ejemplo, un `umbral`) se rechaza | [PRUEBA] |
| No trasladar métricas ni umbrales de E3 | No hay umbrales numéricos en el código: las únicas constantes son 0, 1, 2 y 64, por índices, la tupla, la longitud del SHA-256 y «≤ 0». No se importa nada de E3. La regla de combinación «todas» viene de E3 y queda como A6 | [INSP] y [PRUEBA] |
| Un resultado inválido o no reproducible no se vuelve evidencia | RECHAZADO, NO_EVALUABLE, COHERENTE y NO_REPRODUCIDO dan etiqueta nula y SIN_EVIDENCIA_VALIDA. Ya no existe la vía `aplicar(etiqueta)` sin evidencia (S1) | [PRUEBA] |
| «No avanza» identifica la etapa | Siempre nombra la etapa o «NO_DEFINIDA»; una etapa inventada se rechaza | [PRUEBA] |
| Política de avance ≠ autorización | Dimensión 4 separada; nunca la otorga | [PRUEBA] |
| Determinismo | La tabla se genera dos veces de forma idéntica; no hay relojes en la salida | [PRUEBA] |
| Faltantes o contradicciones explícitos | R1 y R3 obligatorios; NO_DEFINIDO con una definición existente es un error; NO_EVALUADO sin definición es un error; autorización incoherente da CONTRADICTORIA; fechas no ISO o sin zona son un error | [PRUEBA] |

## 4. Defectos
Las sondas sobre v0.2 están en `p2/test_sondas_v0_2.py` (7 de 7).

| # | Defecto en v0.2 | Estado en v0.3 |
|---|---|---|
| S1 | `aplicar("RESPALDADA FUERA DE MUESTRA")` daba CANDIDATA sin ninguna evidencia detrás | **Corregido**: `aplicar` exige una evidencia construida y validada |
| S2 | Si se omitían R1 y R3 quedaban en NO_DEFINIDO aunque existiera una definición aprobada (valor por defecto silencioso) | **Corregido**: argumentos obligatorios y estado NO_EVALUADO |
| S3 | La autorización era una constante; no podía representar un registro externo ni una contradicción | **Corregido**: dimensión 4 |
| S4 | Las fechas se comparaban como texto: «1» quedaba antes de 2022 y pasaba por prerregistrada | **Corregido**: ISO 8601 estricta, con zona obligatoria |
| S5 | `texto_sha256` de la definición sin validar | **Corregido** |
| N1, N2 | Etiqueta literal y autorización nunca otorgada; determinismo | **Ya correctos en v0.2** |

**Pendiente:** los registros (definiciones, etapas, autorizaciones) son diccionarios en el código. Su autenticidad requiere un documento aprobado con hash anclado externamente [AUT].

## 5. Tabla de decisión completa
- **Archivos:** `p2/TABLA_DECISION_P2_v0.3.csv` (3.360 filas) y `p2/TABLA_DECISION_P2_v0.3.md` (resumen). Una prueba exige que coincidan con la política y compara cada fila con un **oráculo escrito aparte**.
- **Dimensiones:**
  - registro de definiciones: vacío, o con definiciones **sintéticas**;
  - 6 validez × 7 etiquetas;
  - R1 × R3;
  - 2 etapas: no definida, o una **sintética**;
  - 4 autorizaciones: ninguna, coincidente, para otra etapa, para otro resultado.
- **Filas alcanzables hoy: 42** (registros vacíos, etapa no definida, sin autorización).
- **Resultado real** (solo lectura): VERIFICADO / `EVIDENCIA INSUFICIENTE` / INDETERMINADA / NO_CANDIDATA / NO_DEFINIDA / NO_OTORGADA [PRUEBA].

## 6. ¿Está justificado «> 0» para R1/R3 en T? [INF]
Detalle en `p2/analisis_umbral_cero.py` y `evidencia/p2_analisis_umbral_cero.txt`.

**Base del cálculo:** aritmética con supuestos explícitos sobre cifras ya registradas.
- Supuestos: normalidad, error típico deducido del IC90, tercios independientes y efecto constante.
- Resultado: TE implícito ≈ 20,2 %/año.

| Efecto verdadero δ (%/año) | P(R1: > 0) | P(R3: > 0 en ≥ 2 de 3 tercios) |
|---|---|---|
| 0 | 0,50 | 0,50 |
| +3 | 0,62 | 0,61 |
| +7 | 0,77 | 0,73 |
| +10 | 0,85 | 0,82 |

**Lectura (no es una decisión):**
- «> 0» es un **control de signo**, no de robustez económica. Sin ventaja se cumple la mitad de las veces y distingue mal una ventaja moderada.
- Para las etiquetas RESPALDADA, el prerregistro **ya exige** costos ×2 > 0, así que R1 transpuesto tal cual sería redundante.
- **No está justificado específicamente para T**: solo existe en E3.

**Alternativas (decide el propietario; ninguna se adopta ni se presenta como prerregistrada):**

| Opción | Ventaja | Riesgo |
|---|---|---|
| (a) Mantener R1 y R3 como NO_DEFINIDO para T | Sin decisiones post hoc | Sin diagnóstico de robustez |
| (b) «> 0» | Simple | Débil e informativo; no distingue una ventaja moderada |
| (c) «> δ», con δ = efecto mínimo relevante | Económicamente interpretable | δ es tuyo (A8); con TE ≈ 20 %, la probabilidad de cumplirlo es baja aun con una ventaja real |
| (d) Cota inferior de un intervalo > 0 | Incorpora la incertidumbre | Muy exigente con esta potencia |

Cualquier opción aplicada a 2022–2026 sería post hoc (A4, A7).
