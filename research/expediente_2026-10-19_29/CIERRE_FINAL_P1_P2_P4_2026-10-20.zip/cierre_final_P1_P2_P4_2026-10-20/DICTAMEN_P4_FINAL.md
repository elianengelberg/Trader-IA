# DICTAMEN P4 FINAL: ejecución de uso único (cierre técnico, 2026-10-20)

**Clasificaciones usadas:**
- **[INSP]** VERIFICADO_POR_INSPECCION
- **[PRUEBA]** VERIFICADO_POR_PRUEBA
- **[INF]** INFERIDO
- **[NO_VER]** NO_VERIFICADO
- **[AUT]** REQUIERE_AUTORIZACION

**No es inviolable ni una garantía absoluta de ejecución única.** Es un prototipo aislado, **no integrado** en `papel/corte.py` ni en ningún ejecutor.

## 1. Qué repetición impide, bajo qué supuestos y qué queda fuera

**Impide [PRUEBA]**, siempre que se cumplan los supuestos S-a a S-e:
1. Que una misma reserva se calcule dos veces de forma concurrente, en el mismo directorio o en dos directorios distintos.
2. Que se repita el cálculo después de que un cálculo **iniciado** no llegara al presellado. Solo se permite si la reserva fija `reintentos_tras_inicio` > 0.
3. Que se sustituya un resultado presellado por otro, sea por recálculo o por alteración del archivo.
4. Que se calcule con entradas, código, semilla, ejecutor, entorno, ancla, punto de entrada o reintentos distintos de los reservados.
5. Que se calcule después de restaurar o truncar el estado local, o con el ancla perdida o vaciada (detectado contra el ancla).
6. Que un cálculo no determinista se preselle, si `verificar_determinismo` está fijado en la reserva.

**Supuestos:**
- **S-a:** el ancla está fuera del control de quien opera el estado local. **`AnclaArchivo` NO cumple S-a:** está en la misma máquina.
- **S-b:** sistema de archivos local con `flock` y `link` POSIX; no es NFS.
- **S-c:** el código reservado no se ejecuta por fuera del mecanismo (ver más abajo).
- **S-d:** el núcleo libera el cerrojo cuando el proceso muere.
- **S-e:** fsync durable en el hardware.

**Fuera de su protección [PRUEBA cuando se indica]:**

| Amenaza | Estado | Evidencia |
|---|---|---|
| Quien puede reescribir el estado local **y** el ancla local juntos | No protegido | `test_LIMITE_el_ancla_local_no_protege…` [PRUEBA] |
| Sin ancla: restaurar una copia antigua o borrar todo | No protegido | `test_LIMITE_sin_ancla_*` [PRUEBA] |
| **Ejecutar el código reservado por fuera del mecanismo** | No protegido | `test_LIMITE_el_codigo_reservado_puede_ejecutarse…` [PRUEBA]. Mitigación posible, no implementada: que los datos solo sean accesibles a través del ejecutor, por ejemplo cifrados con una clave entregada por un servicio externo |
| Canales laterales del cálculo (archivos, red) | No protegido | El hijo corre sin salida visible, con entorno vacío y en un directorio vacío, pero sin sandbox de sistema [INSP] |
| Corte de energía o reinicio de la máquina | Orden de fsync revisado, pero sin inyección de fallos de disco | [INSP] / [NO_VER] |
| Varios equipos o NFS | No probado | [NO_VER] |

## 2. Defectos
Las sondas sobre v0.2 están en `p4/test_sondas_v0_2.py` (7 de 7) y usan **pausas deterministas** (FIFO), sin retardos.

| # | Defecto en v0.2 | Estado en v0.3 |
|---|---|---|
| S1 | **Dos cálculos de la misma reserva:** el inicio de cálculo en el ancla era idempotente (`n > iniciados`). Un proceso con una conciliación desactualizada podía «iniciar» de nuevo | **Corregido** [PRUEBA]: comparación-y-escritura (`n = iniciados + 1`). En el mismo intercalado, el segundo proceso queda INCONSISTENTE sin calcular; hay 1 solo cálculo |
| S2 | **El ancla se reparaba en silencio:** si el ancla desaparecía, v0.2 volvía a anotar reserva y presellado. Combinado con un estado local restaurado, daba **otra extracción** | **Corregido** [PRUEBA]: ancla sin la reserva, o con menos inicios que el diario → INCONSISTENTE. La identidad del ancla está en la reserva |
| S3 | El ejecutor (incluido el código del proceso hijo) no estaba en la reserva: una versión modificada podía reanudar y registrar | **Corregido** [PRUEBA]: `ejecutor_sha256` en la reserva → RECHAZADO |
| S4 | El cálculo heredaba variables de entorno, incluidas secretas, y el directorio de trabajo del padre | **Corregido** [PRUEBA]: `env={}` y un directorio temporal vacío |
| S5 | Un cálculo no determinista se registraba sin advertencia | **Corregido como opción** [PRUEBA]: `verificar_determinismo` en la reserva → NO_DETERMINISTA terminal, sin presellar. Cuesta dos cálculos. **El valor por defecto (falso) es una decisión** [AUT] |
| Pruebas | La concurrencia de v0.2 dependía de retardos | **Corregido**: 4 pruebas con pausas por FIFO dentro de la sección crítica. Las de v0.2 se conservan como regresión |

**Regresión:** las 98 pruebas de v0.2 pasan con v0.3 (2 omitidas por diseño: el punto `tras_ancla` no existe sin ancla). Las 14 nuevas son estables en 3 corridas [PRUEBA].

## 3. Máquina de estados revisada (v0.3)
```
NUEVO ─[ancla: RESERVA (conflicto → RECHAZADO)]→ RESERVADO ─[ancla: INICIO n, con CAS]→ CALCULANDO (hijo aislado)
  └─ CALCULO_INICIADO sin PRESELLADO = CALCULO_INTERRUMPIDO → reintento solo si n ≤ reintentos; si no, REVISION_HUMANA
CALCULANDO ─(verificar_determinismo: 2 hijos, deben coincidir; si no → NO_DETERMINISTA)→ PRESELLADO (diario + fsync)
  ─[ancla: PRESELLADO (escritura única)]→ archivo atómico → SELLADO → REGISTRADO
Terminales: CONFLICTO · CORRUPTO · INCONSISTENTE · REVISION_HUMANA · NO_DETERMINISTA
Conciliación en cada llamada: el ancla debe conocer la reserva; sus inicios ≥ los inicios del diario;
  ancla con presellado y diario sin él (o distinto) → INCONSISTENTE.
```
Las salidas OCUPADO, RECHAZADO, FALLO_CALCULO y ANCLA_NO_DISPONIBLE no son estados. **Toda salida lleva su `reserva_sha256`.**

## 4. Invariantes (cambios respecto de v0.2)
- **I1′:** la reserva liga entradas, código, punto de entrada, semilla, entorno, reintentos, **ejecutor, identidad del ancla y verificación de determinismo** [PRUEBA].
- **I5′:** los inicios se registran en el ancla con comparación-y-escritura. Nunca hay dos cálculos iniciados con el mismo número para una reserva, ni siquiera desde dos directorios [PRUEBA].
- **I7′:** el ancla nunca se repara de forma implícita. La única reparación admitida es la del presellado: el diario local puede ir un paso adelante por una caída entre el diario y el ancla [PRUEBA].
- **I13:** el cálculo corre con entorno vacío y en un directorio vacío [PRUEBA].
- **I14:** con `verificar_determinismo`, dos resultados distintos impiden el presellado [PRUEBA].

El resto (I2–I12 de v0.2) sigue vigente; las pruebas de v0.2 pasan.

## 5. Interfaz mínima de un ancla externa
| Operación | Semántica exigida | Si el servicio falla |
|---|---|---|
| `consultar(reserva) → {reserva, iniciados, presellado}` | Lectura linealizable | ANCLA_NO_DISPONIBLE; no se calcula ni se escribe nada |
| `registrar_reserva(reserva, datos)` | Escritura única y atómica con verificación de conflicto (nombre o entradas) | ANCLA_NO_DISPONIBLE antes de crear el estado local |
| `registrar_inicio_calculo(reserva, n)` | **Comparación-y-escritura:** solo n = actual + 1; rechazo después de un presellado | ANCLA_NO_DISPONIBLE; el cálculo no se inicia |
| `registrar_presellado(reserva, sha)` | Escritura única; otro valor se rechaza | ANCLA_NO_DISPONIBLE; el resultado **no** se escribe en disco |
| Propiedad del servicio | Solo de añadidos; no reescribible ni borrable por el operador; con identidad estable | — |

Ejemplos de servicios: un registro de transparencia, un sellado de tiempo encadenado, un repositorio remoto con historial protegido.

**Elegirlo, implementarlo o publicar hashes en él requiere tu autorización** [AUT]. No se hizo.

## 6. Escenarios del encargo y su prueba
| Escenario | Pruebas |
|---|---|
| Caída antes de reservar; después de reservar y antes de calcular; durante el cálculo; tras observar y antes de persistir; después de persistir; reinicio | `test_uso_unico.py::test_caida_reinicio_e_idempotencia`: 13 puntos × con y sin ancla × reintentos 0 y 1 (50 casos), más SIGKILL |
| Concurrencia con sincronización determinista | `test_v0_3.py::test_S1_*` (2), `test_concurrencia_determinista_*` (2) |
| Restauración de un estado antiguo, truncamiento del diario | `test_uso_unico.py::test_restaurar_*` (4), `test_truncar_*` (3); `test_v0_3.py::test_S2_*` (3) |
| Ancla ausente o no disponible | `test_S2_ancla_perdida…`, `test_la_identidad_del_ancla…`, `test_ancla_no_disponible…` (4 operaciones) |
| Entradas, código, ejecutor, entorno o configuración alterados | `test_entradas_codigo_entorno_o_configuracion…` (6), `test_S3_*`, `test_S5_determinista_pasa…` |
| Recuperación tras interrupción sin cambiar lo reservado | `test_recuperacion_conserva_la_reserva_original` (3 puntos), `cruzada/test_X7_*` |
