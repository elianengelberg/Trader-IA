# MATRIZ DE DECISIONES PENDIENTES: cierre técnico P1, P2 y P4 (2026-10-20)

**Cómo leerla:**
- Nada de esto se decidió en tu nombre; las recomendaciones son juicios técnicos.
- Las decisiones metodológicas son tuyas.
- Las acciones operativas siguen bloqueadas hasta que las autorices.

## A. Decisiones metodológicas (tuyas)
| ID | Decisión | Alternativas | Consecuencias |
|---|---|---|---|
| A1 / A2 | Definición de R1 y R3 **para T** | (a) mantener NO_DEFINIDO; (b) «> 0»; (c) «> δ»; (d) cota inferior del intervalo > 0 | (a) sin diagnóstico; (b) control de signo débil (0,50 sin ventaja, 0,77 con +7 %/año) y redundante con RESPALDADA; (c) depende de A8 y tiene baja probabilidad de cumplirse con TE ≈ 20 %; (d) muy exigente. Ver `DICTAMEN_P2_FINAL.md` §6 |
| A3 | ¿R1 o R3 pueden vetar la candidatura? | No (actual) / sí | Con «no», son informativos (tu indicación). Con «sí», un diagnóstico débil podría bloquear una ventaja |
| A4 / A7 | Uso de R1 y R3 sobre 2022–2026 y fecha de corte de lo post hoc | Prohibido o post hoc (actual: inicio de la ventana) / fecha de ejecución | Toda definición de hoy es post hoc para 2022–2026 |
| **A5** | **Qué es la «etapa siguiente» de T** | Por definir | Sin ella, toda decisión de avance es «NO_DEFINIDA» |
| A6 | Regla de combinación «todas» (de E3) | Adoptar / otra / ninguna | Hoy sin efecto |
| **A8** | **Efecto mínimo relevante δ, pérdida máxima tolerable y definición económica de robustez** | Por definir | Condiciona A1, A2 y la duración del papel |
| A9 | ¿VERIFICADO alcanza como evidencia, o se exige REPRODUCIDO? | VERIFICADO (actual) / REPRODUCIDO | REPRODUCIDO exige una reproducción independiente. Para T fuera de muestra implicaría recalcular, y eso **no se hace** |
| A10 | `reintentos_tras_inicio` y `verificar_determinismo` para usos reales de P4 | 0 y verdadero (recomendado) / otros | Con 0, cualquier interrupción del cálculo va a revisión humana. Verdadero duplica el costo del cálculo |
| A11 | Reabrir hipótesis descartadas (D-G5) | — | No se decidió ni se tocó |

## B. Cambios técnicos que sugiero aprobar (no aplicados)
| ID | Cambio | Estado técnico | Requisito previo |
|---|---|---|---|
| C-P1 | `p1/P1_verificador_v0.3.patch`: 5 archivos nuevos en `research/tendencia_btc/verificacion/` | Corregido y probado; parche aplicable en `692f2b2` y `c6339e3` | Revisión por un tercero; tu autorización para el commit |
| C-P2 | Política v0.3 (`p2/`) como base de redacción | Técnicamente lista; **metodológicamente incompleta** (A1–A9) | Tus decisiones de la sección A |
| C-P4 | Prototipo v0.3 (`p4/`) como especificación de referencia | Técnicamente revisado; **no apto para uso real sin un ancla externa** | Ancla externa (B-2), pruebas de sistema, decisión de integración |

## C. Autorizaciones operativas que siguen bloqueadas
| ID | Acción | Estado |
|---|---|---|
| B-1 | Commits, push y aplicar parches al repositorio; versionar `corte.py` | **Bloqueada** |
| B-2 | Elegir o implementar un ancla externa y publicar hashes; publicar `f518ac1` y `692f2b2` | **Bloqueada** |
| B-3 | Integrar P4 en `papel/corte.py` u otro ejecutor | **Bloqueada** |
| B-4 | Leer los bytes de los archivos de datos reales (`--datos`) | **Bloqueada** (interpretación conservadora de la restricción 1) |
| B-5 | Calibración estadística del expediente v0.2 | **Bloqueada** |
| B-6 | Backtests, evaluaciones históricas, descargas, repetir T, dinero real, despliegues | **Prohibidas** |
| B-7 | Revisión por un tercero (persona u otro modelo) | Pendiente; no se hizo |
| B-8 | Preservar este paquete fuera del scratchpad efímero | **Tuya:** descargar el ZIP |
