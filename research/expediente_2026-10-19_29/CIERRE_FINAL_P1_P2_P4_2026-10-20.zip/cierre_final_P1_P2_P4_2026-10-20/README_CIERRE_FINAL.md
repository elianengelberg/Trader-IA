# Cierre técnico final de P1, P2 y P4 (Trader-IA, 2026-10-20)

**Cerrar esta auditoría no equivale a aprobar, integrar ni desplegar nada.**
- Las v0.3 son **propuestas aisladas**.
- El repositorio no se modificó: el SHA-256 de `git status --porcelain --ignored` es `87b9585d…`, antes y después (`evidencia/99_estado_final_git.txt`).
- Las entregas anteriores siguen intactas (`evidencia/98_integridad_final.txt`).
- **Persistencia:** el paquete está en el scratchpad **efímero**; no hay un directorio persistente autorizado. Se preserva solo si descargás el ZIP.

## Estado por componente
| Componente | Estado técnico | Propiedad demostrada (VERIFICADO_POR_PRUEBA) | Lo que no está demostrado |
|---|---|---|---|
| **P1** v0.3 | Defectos demostrables corregidos | VERIFICADO solo con integridad desde archivos, esquema estricto, correspondencias, manifiestos y tablas del corte. REPRODUCIDO solo tras VERIFICADO y comparación completa | Autenticidad (no hay raíz independiente); bytes de los datos reales; semántica de `contraste_btc_diario_vs_horario` |
| **P2** v0.3 | Técnicamente correcta; metodológicamente incompleta | Cinco dimensiones separadas; tabla de 3.360 filas contra un oráculo; sin valores por defecto silenciosos; nunca otorga autorización | Adecuación de las reglas para T (A1–A9 son tuyas) |
| **P4** v0.3 | Defectos demostrables corregidos; no apto para uso real sin un ancla externa | Un único cálculo por reserva (también entre directorios); sin sustitución de un resultado presellado; ejecutor, entorno y configuración ligados; restauración, truncamiento y pérdida del ancla detectados | Protección frente a quien controla el estado y el ancla locales; ejecución por fuera; corte de energía |
| **Cruzada** | 9 interacciones probadas | P4 → P1 (hash del ancla) → P2 sin convertir fallos en evidencia ni en autorización | La integración real |

## Contenido
| Ruta | Qué es |
|---|---|
| `DICTAMEN_P1_FINAL.md`, `DICTAMEN_P2_FINAL.md`, `DICTAMEN_P4_FINAL.md`, `AUDITORIA_CRUZADA_FINAL.md` | Dictámenes con cada afirmación clasificada |
| `MATRIZ_DECISIONES_PENDIENTES.md` | Decisiones tuyas, cambios sugeridos y acciones bloqueadas |
| `CAMBIOS_PROPUESTOS.diff` | Diferencias exactas v0.1 → v0.3 del código de cada componente. Las v0.2 → v0.3 están en `evidencia/diff_v0.2_v0.3_*.txt` |
| `p1/` | Verificador v0.3, fábricas sintéticas, sondas sobre v0.2, regresión y pruebas de v0.3, y `P1_verificador_v0.3.patch` (**no aplicado**) |
| `p2/` | Política v0.3, generador y tabla completa (CSV y MD), análisis de «> 0», sondas y pruebas |
| `p4/` | Prototipo v0.3, conductor con pausas deterministas, `sincro.py`, códigos sintéticos, sondas, regresión v0.2 y pruebas de v0.3 |
| `cruzada/` | Interacciones X1–X9 y códigos sintéticos de la cadena |
| `referencia_v0_2/` | Copia exacta del código v0.2 (hashes verificados contra la auditoría paralela) |
| `00_preservado/` | ZIP de la entrega original, ZIP de la auditoría paralela y ZIP del expediente metodológico, sin modificar |
| `evidencia/` | Salidas originales de cada ejecución, compatibilidad del parche, diffs, preservación, integridad y estado de Git |
| `REGISTRO_ACCIONES_Y_AUTORIZACIONES.jsonl` | Registro encadenado (cada línea lleva el SHA-256 de la anterior) |
| `ejecutar_todo.sh` | Reproduce todas las ejecuciones |
| `SHA256SUMS.txt` | Hash de **todos los archivos salvo él mismo**. No hay ancla externa: su hash está en la respuesta de la sesión |

## Reproducir
```
F=<esta carpeta> T=<repo>/research/tendencia_btc REPO=<repo> \
PY=<repo>/research/hcarry_next/.venv/bin/python HC=<repo>/research/hcarry_next/src bash ejecutar_todo.sh
sha256sum -c SHA256SUMS.txt
```

## Lo que NO se hizo
- No hubo backtests, evaluaciones históricas, descargas ni lectura de bytes de datos de mercado.
- No se repitió ni se modificó T, ni se invocó `fuera_de_muestra_T.py` o su cerrojo.
- No se ejecutó la calibración v0.2.
- No hubo commits, push, integraciones ni despliegues, ni se publicaron hashes.
- No se eligió ninguna definición de R1 o R3, etapa, δ ni autorización.
- `papel/corte.py` solo se ejecutó en directorios temporales con la fuente **simulada** de sus propias pruebas.
- **Revisión por un tercero: no realizada.**
