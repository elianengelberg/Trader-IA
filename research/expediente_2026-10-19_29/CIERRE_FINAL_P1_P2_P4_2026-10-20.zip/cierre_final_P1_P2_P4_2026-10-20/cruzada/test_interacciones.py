"""Auditoría cruzada FINAL P1 v0.3 × P2 v0.3 × P4 v0.3, solo con datos y resultados SINTÉTICOS (más una lectura de
solo lectura del resultado real de T para X8). Cadena: P4 reserva y ejecuta un código sintético que produce un resultado
con el esquema fuera de muestra → P1 lo verifica contra un árbol de T sintético, exigiendo el hash que el ANCLA de P4
registró → P2 lo clasifica. X1–X9 en AUDITORIA_CRUZADA_FINAL.md."""
from __future__ import annotations

import ast
import hashlib
import json
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent
for sub in ("p1", "p2", "p4"):
    sys.path.insert(0, str(RAIZ / sub))
import fabricas as F  # noqa: E402
import politica_avance_T as PA  # noqa: E402
import uso_unico as U  # noqa: E402
import verificar_reproduccion_T as V  # noqa: E402

T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.py").is_file(), reason="T no disponible")
INSUF = {"p_conj": 0.755, "p_btc": 0.8355, "x2": 0.0438, "exceso": 0.07, "decision": "EVIDENCIA INSUFICIENTE"}
RESP = {"p_conj": 0.97, "p_btc": 0.95, "x2": 0.02, "exceso": 0.12, "decision": "RESPALDADA FUERA DE MUESTRA"}
DEFS = {f"{c}-SINT": {"id": f"{c}-SINT", "criterio": c, "aplica_a": "T", "texto_sha256": "0" * 64,
                      "aprobada_utc": "2000-01-01T00:00:00Z", "aprobada_por": "PRUEBA SINTÉTICA"} for c in ("R1", "R3")}


def montar(tmp: Path, parametros: dict, codigo: Path = AQUI / "codigo_oos_sintetico.py") -> dict:
    raiz = F.arbol_t(tmp / "T")
    (tmp / "parametros.json").write_text(json.dumps(parametros), encoding="utf-8")
    (tmp / "contador.txt").write_text(str(tmp / "llamadas.txt"), encoding="utf-8")
    archivos = {"codigo": codigo, "parametros": tmp / "parametros.json", "contador": tmp / "contador.txt",
                "prerregistro": raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                "script": raiz / "experimentos" / "fuera_de_muestra_T.py",
                **{f"src/{p.name}": p for p in sorted((raiz / "src" / "tendencia").glob("*.py"))},
                **{f"manifiesto_{s}": raiz / "datos" / s / "MANIFIESTO.json" for s in ("BTCUSDT", "ETHUSDT")}}
    return {"raiz": raiz, "dir": tmp / "estado", "archivos": {k: str(v) for k, v in archivos.items()},
            "ancla": U.AnclaArchivo(tmp / "ancla" / "ANCLA.jsonl"), "llamadas": tmp / "llamadas.txt"}


def p4(m: dict, **kw) -> U.Salida:  # type: ignore[no-untyped-def]
    s = U.ejecutar(m["dir"], "CRUZADA-1", m["archivos"], 7, ancla=m["ancla"], **kw)
    m["reserva_sha256"] = s.reserva_sha256
    return s


def n_calculos(m: dict) -> int:
    return len(m["llamadas"].read_text().splitlines()) if m["llamadas"].exists() else 0


def cadena(m: dict, r1: object = "NO_DEFINIDO", r3: object = "NO_DEFINIDO", **kw) -> dict:  # type: ignore[no-untyped-def]
    """Integración mínima PROPUESTA (no integrada): solo un REGISTRADO de P4 con archivo coincidente pasa a P1, y P1
    exige el hash que el ANCLA de P4 registró antes de que el resultado existiera en disco."""
    st = U.leer(m["dir"])
    if st.get("estado") != "REGISTRADO" or not st.get("archivo_coincide"):
        raise RuntimeError(f"P4 no entregó un resultado válido ({st.get('estado')})")
    presellado_ancla = m["ancla"].consultar(m["reserva_sha256"])["presellado"]
    return PA.desde_resultado(Path(m["dir"]) / U.RESULTADO, m["raiz"], r1, r3,
                              resultado_sha256_esperado=presellado_ancla, **kw)


def test_cadena_valida(tmp_path: Path) -> None:
    m = montar(tmp_path, INSUF)
    assert p4(m).estado == "REGISTRADO"
    s = cadena(m)
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"], s["decision_avance"]["resultado"],
            s["autorizacion_ejecucion"]["estado"]) == ("VERIFICADO", "EVIDENCIA INSUFICIENTE", "NO_CANDIDATA", "NO_OTORGADA")


# X1: P1 rechaza lo que no puede verificar; REPRODUCIDO exige VERIFICADO
def test_X1_sin_integridad_no_hay_verificado_ni_reproducido(tmp_path: Path) -> None:
    m = montar(tmp_path, INSUF)
    p4(m)
    ruta = Path(m["dir"]) / U.RESULTADO
    assert V.verificar_archivo(ruta)["nivel"] == "COHERENTE_SIN_INTEGRIDAD"
    with pytest.raises(V.ErrorVerificacion, match="INTEGRIDAD"):
        V.reproducir(ruta, json.loads(ruta.read_text()))
    (m["raiz"] / "datos" / "ETHUSDT" / "MANIFIESTO.json").unlink()
    with pytest.raises(V.ErrorVerificacion, match="AUSENTE"):
        V.verificar_archivo(ruta, raiz=m["raiz"])


# X2: P1 detecta una discrepancia con el hash autenticado por el ancla de P4
def test_X2_p1_contra_el_hash_del_ancla(tmp_path: Path) -> None:
    m = montar(tmp_path, INSUF)
    p4(m)
    ruta = Path(m["dir"]) / U.RESULTADO
    pre = m["ancla"].consultar(m["reserva_sha256"])["presellado"]
    ruta.write_bytes(ruta.read_bytes().replace(b"0.755", b"0.999"))  # sigue siendo coherente
    assert V.verificar_archivo(ruta, raiz=m["raiz"])["nivel"] == "VERIFICADO"  # sin el vínculo, pasa
    with pytest.raises(V.ErrorVerificacion, match="HASH"):
        V.verificar_archivo(ruta, raiz=m["raiz"], resultado_sha256_esperado=pre)
    with pytest.raises(RuntimeError):
        cadena(m)
    assert p4(m).estado == "CORRUPTO"


# X3: P2 no toma como evidencia un resultado rechazado por P1
@pytest.mark.parametrize("caso", ["codigo_cambiado", "contradictorio", "archivo_ausente"])
def test_X3_p2_no_clasifica_lo_rechazado_por_p1(tmp_path: Path, caso: str) -> None:
    m = montar(tmp_path, {**INSUF, "decision": "RESPALDADA FUERA DE MUESTRA"} if caso == "contradictorio" else INSUF)
    p4(m)
    if caso == "codigo_cambiado":
        (m["raiz"] / "src" / "tendencia" / "a.py").write_text("X = 7\n", encoding="utf-8")
    if caso == "archivo_ausente":
        (m["raiz"] / "experimentos" / "fuera_de_muestra_T.py").unlink()
    s = PA.desde_resultado(Path(m["dir"]) / U.RESULTADO, m["raiz"], "NO_DEFINIDO", "NO_DEFINIDO")
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"], s["decision_avance"]["resultado"]) == (
        "RECHAZADO", None, "NO_CANDIDATA")


# X4: una etiqueta favorable (y robusta) no genera autorización
def test_X4_etiqueta_favorable_no_autoriza(tmp_path: Path) -> None:
    m = montar(tmp_path, RESP)
    p4(m)
    s = cadena(m, ("CUMPLE", "R1-SINT"), ("CUMPLE", "R3-SINT"), definiciones=DEFS)
    assert (s["robustez"]["resumen"], s["decision_avance"]["resultado"], s["autorizacion_ejecucion"]["estado"]) == (
        "ROBUSTA", "CANDIDATA_A_REVISION_HUMANA", "NO_OTORGADA")
    aut = {"A-1": {"id": "A-1", "etapa": "ETAPA_X", "resultado_sha256": s["evidencia"]["resultado_sha256"],
                   "otorgada_por": "PRUEBA SINTÉTICA", "otorgada_utc": "2030-01-01T00:00:00Z", "texto_sha256": "1" * 64}}
    s = cadena(m, ("CUMPLE", "R1-SINT"), ("CUMPLE", "R3-SINT"), definiciones=DEFS, etapa="ETAPA_X",
               etapas={"ETAPA_X": "sintética"}, autorizacion="A-1", autorizaciones=aut)
    assert s["autorizacion_ejecucion"]["estado"] == "REGISTRADA_EXTERNAMENTE"  # constatada, no otorgada
    assert "autoriz" not in json.dumps(U.Salida("REGISTRADO").__dict__)  # P4 no tiene noción de autorización


# X5: P4 no presenta una ejecución incompleta como válida
@pytest.mark.parametrize("codigo,esperado", [(RAIZ / "p4" / "codigos_sinteticos" / "falla.py", "FALLO_CALCULO"),
                                            (AQUI / "codigo_oos_nodet.py", "NO_DETERMINISTA")])
def test_X5_ejecucion_incompleta_no_pasa(tmp_path: Path, codigo: Path, esperado: str) -> None:
    m = montar(tmp_path, INSUF, codigo=codigo)
    s = p4(m, verificar_determinismo=(esperado == "NO_DETERMINISTA"))
    assert (s.estado, s.resultado) == (esperado, None) and not (Path(m["dir"]) / U.RESULTADO).exists()
    with pytest.raises(RuntimeError):
        cadena(m)
    if esperado == "FALLO_CALCULO":
        assert p4(m).estado == "REVISION_HUMANA"


# X6: un fallo técnico no habilita repetir la evaluación
def test_X6_un_rechazo_no_habilita_otra_evaluacion(tmp_path: Path) -> None:
    m = montar(tmp_path, INSUF)
    p4(m)
    (m["raiz"] / "src" / "tendencia" / "a.py").write_text("X = 7\n", encoding="utf-8")
    s = PA.desde_resultado(Path(m["dir"]) / U.RESULTADO, m["raiz"], "NO_DEFINIDO", "NO_DEFINIDO")
    assert s["evidencia"]["validez"] == "RECHAZADO" and s["autorizacion_ejecucion"]["estado"] == "NO_OTORGADA"
    assert p4(m).calculado is False and n_calculos(m) == 1  # repetir no recalcula
    Path(m["archivos"]["parametros"]).write_text(json.dumps(RESP), encoding="utf-8")  # «arreglar» y repetir
    assert p4(m).estado == "RECHAZADO" and n_calculos(m) == 1


# X7: una recuperación no cambia entradas, código ni configuración reservados
def test_X7_recuperacion_conserva_lo_reservado(tmp_path: Path) -> None:
    m = montar(tmp_path, INSUF)  # las caídas reales en cada punto se prueban en p4/; aquí, pérdida del resultado
    primera = p4(m)
    reserva_inicial = json.loads((Path(m["dir"]) / U.DIARIO).read_bytes().split(b"\n")[0])["datos"]
    (Path(m["dir"]) / U.RESULTADO).unlink()  # pérdida del resultado: recuperación
    s = p4(m)
    assert s.estado == "REGISTRADO" and s.reserva_sha256 == primera.reserva_sha256
    assert s.resultado_sha256 == primera.resultado_sha256
    assert json.loads((Path(m["dir"]) / U.DIARIO).read_bytes().split(b"\n")[0])["datos"] == reserva_inicial
    inf = V.verificar_archivo(Path(m["dir"]) / U.RESULTADO, raiz=m["raiz"])
    assert inf["hashes_declarados"]["script"] == reserva_inicial["archivos_sha256"]["script"]


# X8: ningún componente modifica el resultado congelado de T
@con_t
def test_X8_artefactos_congelados_intactos() -> None:
    leidos = [T / "experimentos" / "fuera_de_muestra_T.json", T / "experimentos" / "fuera_de_muestra_T.py",
              T / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md", *sorted((T / "src" / "tendencia").glob("*.py")),
              T / "datos" / "BTCUSDT" / "MANIFIESTO.json", T / "datos" / "ETHUSDT" / "MANIFIESTO.json",
              T / "papel" / "prerregistro_papel.json", T / "ARTEFACTOS_SHA256.txt", T / "EVIDENCIA_T_MULTI.json"]
    huella = lambda: [(str(p), hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns) for p in leidos]  # noqa: E731
    antes = huella()
    man = V.cargar_manifiesto(T / "ARTEFACTOS_SHA256.txt") | V.cargar_manifiesto(
        f"{T / 'EVIDENCIA_T_MULTI.json'}#cadena_historica_T_fuera_de_muestra")
    V.verificar_archivo(leidos[0], raiz=T, manifiesto=man)
    PA.desde_resultado(leidos[0], T, "NO_DEFINIDO", "NO_DEFINIDO", manifiesto=man)
    assert huella() == antes
    assert hashlib.sha256(leidos[0].read_bytes()).hexdigest() == (
        "4f8fafde372931aab29b94612eb658f5fac9259e51cdf7dace7a1b30fc633c45")


# X9: P1 y P2 no pueden ejecutar ni escribir; P4 solo lanza su propio hijo
def _peligrosas(ruta: Path) -> set[str]:
    arbol = ast.parse(ruta.read_bytes())
    mods = {a.name.split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        (n.module or "").split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    out = mods & {"subprocess", "runpy", "importlib", "shutil", "socket", "urllib", "http"}
    for n in ast.walk(arbol):
        if isinstance(n, ast.Call):
            f = ast.unparse(n.func)
            if f in ("exec", "eval", "compile", "__import__") or f.startswith("os.") and f.split(".")[1] in (
                    "replace", "rename", "remove", "unlink", "system", "popen", "write", "makedirs", "mkdir"):
                out.add(f)
            if f.split(".")[-1] in ("write_text", "write_bytes", "unlink", "rename", "mkdir", "rmdir", "touch"):
                out.add(f)
            if f == "open" and len(n.args) > 1 and any(c in ast.unparse(n.args[1]) for c in "wax+"):
                out.add("open(escritura)")
    return out


def test_X9_p1_y_p2_no_ejecutan_ni_escriben() -> None:
    assert _peligrosas(RAIZ / "p1" / "verificar_reproduccion_T.py") == set()
    assert _peligrosas(RAIZ / "p2" / "politica_avance_T.py") == set()


def test_X9_p4_solo_lanza_su_hijo_y_no_nombra_ejecutores_de_t() -> None:
    arbol = ast.parse((RAIZ / "p4" / "uso_unico.py").read_bytes())
    lanz = [ast.unparse(n.args[0]) for n in ast.walk(arbol) if isinstance(n, ast.Call)
            and ast.unparse(n.func) in ("subprocess.Popen", "subprocess.run")]
    assert lanz == ["[sys.executable, '-I', '-S', '-B', '-c', _HIJO, str(w)]"]
    textos = [n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and isinstance(n.value, str)
              and n is not arbol.body[0].value]
    assert not any("fuera_de_muestra_T" in t or "corte.py" in t for t in textos)
