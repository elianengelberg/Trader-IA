#!/usr/bin/env bash
# Reproduce todas las ejecuciones del cierre final (solo pruebas sintéticas y lecturas de solo lectura del árbol de T).
# Uso: F=<esta carpeta> T=<repo>/research/tendencia_btc REPO=<repo> PY=<python con pytest> HC=<repo>/research/hcarry_next/src bash ejecutar_todo.sh
set -u
cd "$F"
export PYTHONDONTWRITEBYTECODE=1
corre() { echo "\$ (cd $1 && python -B -m pytest -v -p no:cacheprovider -rs ${*:2})"; (cd "$F/$1" && PYTHONPATH="$T/src:$HC" "$PY" -B -m pytest -v -p no:cacheprovider -rs "${@:2}" 2>&1); echo "exit=$?"; }
{ echo "# P1 ($(date -u +%FT%TZ)); sondas sobre v0.2 y suites de v0.3 en procesos separados"
  corre p1 test_sondas_v0_2.py; corre p1 test_verificar_reproduccion_T.py test_v0_2.py test_v0_3.py; } > evidencia/p1_pytest.txt
{ echo "# P2 ($(date -u +%FT%TZ))"; corre p2 test_sondas_v0_2.py; corre p2 test_politica_avance_T.py
  echo "\$ (cd p2 && python3 -I -B analisis_umbral_cero.py)"; (cd p2 && python3 -I -B analisis_umbral_cero.py); } > evidencia/p2_pytest.txt
{ echo "# P4 ($(date -u +%FT%TZ))"; corre p4 test_sondas_v0_2.py; corre p4 test_uso_unico.py test_v0_3.py; } > evidencia/p4_pytest.txt
{ echo "# P4 v0.3: 3 repeticiones de las pruebas con sincronización determinista"
  for i in 1 2 3; do (cd p4 && "$PY" -B -m pytest -q -p no:cacheprovider test_v0_3.py 2>&1 | tail -1); done; } > evidencia/p4_repeticiones.txt
{ echo "# Auditoría cruzada ($(date -u +%FT%TZ))"; corre cruzada test_interacciones.py; } > evidencia/cruzada_pytest.txt
# diffs exactos
O=00_preservado/_original; R=referencia_v0_2
rm -rf "$O"; mkdir -p "$O" && unzip -q -o 00_preservado/ENTREGA_ORIGINAL_P1_P2_P4_2026-10-20.zip -d "$O"
B="$O/00_entrega_original"
{ echo "# CAMBIOS PROPUESTOS (no aplicados). Diferencias exactas v0.1 (entrega original) → v0.3 (este cierre) del código"
  echo "# de cada componente. Las diferencias v0.2 → v0.3 están en evidencia/diff_v0.2_v0.3_*.txt. Generado $(date -u +%FT%TZ)."
  diff -u --label "v0.1/p1/verificar_reproduccion_T.py" --label "v0.3/p1/verificar_reproduccion_T.py" "$B/p1/verificar_reproduccion_T.py" p1/verificar_reproduccion_T.py
  diff -u --label "v0.1/p2/politica_avance_T.py" --label "v0.3/p2/politica_avance_T.py" "$B/p2/politica_avance_T.py" p2/politica_avance_T.py
  diff -u --label "v0.1/p4/uso_unico.py" --label "v0.3/p4/uso_unico.py" "$B/p4/uso_unico.py" p4/uso_unico.py
} > CAMBIOS_PROPUESTOS.diff
for c in "p1/verificar_reproduccion_T.py" "p2/politica_avance_T.py" "p4/uso_unico.py" "p4/_conductor.py"; do
  diff -u --label "v0.2/$c" --label "v0.3/$c" "$R/$c" "$c" > "evidencia/diff_v0.2_v0.3_$(basename $c .py).txt"; done
rm -rf "$O"
# parche de P1 v0.3 (archivos nuevos) y compatibilidad en copias exportadas (nunca en el repositorio)
rm -rf p1/_arbol && mkdir -p p1/_arbol/research/tendencia_btc/verificacion
cp p1/verificar_reproduccion_T.py p1/fabricas.py p1/test_verificar_reproduccion_T.py p1/test_v0_2.py p1/test_v0_3.py p1/_arbol/research/tendencia_btc/verificacion/
(cd p1/_arbol && for f in verificar_reproduccion_T.py fabricas.py test_verificar_reproduccion_T.py test_v0_2.py test_v0_3.py; do git diff --no-index /dev/null research/tendencia_btc/verificacion/$f; done) > p1/P1_verificador_v0.3.patch
rm -rf p1/_arbol
{ echo "# Compatibilidad del parche P1 v0.3 ($(date -u +%FT%TZ)); copias con git archive; el parche NO se aplica al repositorio"
  for c in 692f2b2 c6339e3; do
    W="$F/evidencia/_copia_$c"; rm -rf "$W"; mkdir -p "$W"
    git -C "$REPO" archive "$c" research/tendencia_btc research/hcarry_next/src | tar -x -C "$W"
    echo "== $c: $(git -C "$REPO" log -1 --format='%s' "$c")"
    for f in experimentos/fuera_de_muestra_T.py experimentos/fuera_de_muestra_T.json papel/corte.py EVIDENCIA_T_MULTI.json; do
      printf "   %-40s %s\n" "$f" "$([ -f "$W/research/tendencia_btc/$f" ] && echo presente || echo AUSENTE)"; done
    (cd "$W" && git apply --check "$F/p1/P1_verificador_v0.3.patch" && echo "   git apply --check: OK" && git apply "$F/p1/P1_verificador_v0.3.patch")
    (cd "$W/research/tendencia_btc" && echo "   pytest verificacion/ (TRADER_IA_T=copia): $(TRADER_IA_T=$PWD PYTHONPATH=src:../hcarry_next/src "$PY" -B -m pytest -q -p no:cacheprovider verificacion/ 2>&1 | tail -1)")
    rm -rf "$W"
  done; } > evidencia/p1_compatibilidad_parche_v0.3.txt 2>&1
grep -hE "^=+ .*(passed|failed).*=+$|^[0-9]+ passed|pytest verificacion|apply --check" evidencia/p1_pytest.txt evidencia/p2_pytest.txt evidencia/p4_pytest.txt evidencia/p4_repeticiones.txt evidencia/cruzada_pytest.txt evidencia/p1_compatibilidad_parche_v0.3.txt
