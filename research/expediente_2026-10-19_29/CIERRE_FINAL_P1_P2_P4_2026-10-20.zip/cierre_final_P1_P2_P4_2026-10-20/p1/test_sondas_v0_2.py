"""SONDAS sobre el verificador v0.2 (copia de referencia sin modificar). Una prueba S* PASA si el defecto EXISTE en
v0.2; una N* comprueba algo que v0.2 ya hace bien. Datos sintéticos; productor real de cortes solo con fuente simulada."""
from __future__ import annotations

import copy
import csv
import importlib.util
import json
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import fabricas as F  # noqa: E402


def _cargar():  # type: ignore[no-untyped-def]
    ruta = AQUI.parent / "referencia_v0_2" / "p1" / "verificar_reproduccion_T.py"
    spec = importlib.util.spec_from_file_location("verificador_v0_2_ref", ruta)
    m = importlib.util.module_from_spec(spec)
    sys.modules["verificador_v0_2_ref"] = m
    spec.loader.exec_module(m)  # type: ignore[union-attr]
    return m


V2 = _cargar()
con_corte = pytest.mark.skipif(not (F.T_REAL / "papel" / "corte.py").is_file(), reason="corte.py no disponible")


def escribir(tmp: Path, obj: dict, nombre: str = "r.json") -> Path:
    p = tmp / nombre
    p.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")
    return p


def test_S1_clave_inesperada_se_acepta(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz) | {"decision": "RESPALDADA FUERA DE MUESTRA"}  # un lector podría tomarla por la decisión
    assert V2.verificar(o, raiz=raiz)["nivel"] == "VERIFICADO"


def test_S2_simbolos_faltantes_o_sobrantes_se_aceptan(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    del o["principal"]["ETH"]
    o["manifiestos_sha256"]["SOLUSDT"] = "f" * 64
    assert V2.verificar(o, raiz=raiz)["nivel"] == "VERIFICADO"


def test_S3_falsificacion_coherente_de_script_y_resultado(tmp_path: Path) -> None:
    """Se cambia el script y se actualiza su hash en el resultado: v0.2 verifica. El registro del repositorio
    (forma de EVIDENCIA_T_MULTI.json) lo revelaría, pero v0.2 no puede consultarlo."""
    raiz = F.arbol_t(tmp_path / "T")
    ruta = escribir(raiz / "experimentos", F.oos(raiz=raiz), "fuera_de_muestra_T.json")
    registro = F.cadena(raiz)
    script = raiz / "experimentos" / "fuera_de_muestra_T.py"
    script.write_text(script.read_text() + "# cambio posterior\n", encoding="utf-8")
    o = json.loads(ruta.read_text())
    o["script_sha256"] = F.sha(script.read_bytes())
    ruta.write_text(json.dumps(o), encoding="utf-8")
    assert V2.verificar_archivo(ruta, raiz=raiz)["nivel"] == "VERIFICADO"
    assert registro["experimentos/fuera_de_muestra_T.py"]["sha256"] != o["script_sha256"]
    assert "manifiesto" not in V2.verificar.__code__.co_varnames


def test_S4_codigo_del_resultado_no_se_contrasta_con_el_codigo_fijado_en_el_script(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    script = raiz / "experimentos" / "fuera_de_muestra_T.py"
    script.write_text(script.read_text().replace('CODIGO = "', 'CODIGO = "0', 1)[:-1] + "\n", encoding="utf-8")
    o = F.oos(raiz=raiz)  # codigo_sha256 = huella del src; el script fija otro CODIGO
    assert V2.verificar(o, raiz=raiz)["nivel"] == "VERIFICADO"


def test_S5_comparar_ignora_campos(tmp_path: Path) -> None:
    a = F.oos()
    b = copy.deepcopy(a)
    b["principal"]["ETH"]["p"] = 0.01
    b["secundarios"]["costes_x2"]["BTC"] = -9.0
    b["ventana"] = b["principal"]["ventana"] = ["2021-01-01", "2026-06-01"]
    assert V2.comparar(a, b) == []


def test_S6_comparar_no_exige_integridad() -> None:
    """Dos resultados falsos idénticos «coinciden»: no hay nivel REPRODUCIDO que exija integridad previa."""
    assert V2.comparar(F.oos(), F.oos()) == [] and "REPRODUCIDO" not in V2.SALIDAS


@con_corte
@pytest.mark.parametrize("alteracion", ["fila_borrada", "valor_cambiado", "manifiesto_de_datos"])
def test_S7_tablas_y_datos_del_corte_no_se_comprueban(tmp_path: Path, alteracion: str) -> None:
    raiz = F.corte_real_simulado(tmp_path)
    d = raiz / "2027-10-19"
    if alteracion == "manifiesto_de_datos":
        p = d / "datos" / "BTCUSDT" / "MANIFIESTO.json"
        m = json.loads(p.read_text())
        m["archivos"] = m["archivos"][:-1]
        p.write_text(json.dumps(m), encoding="utf-8")
    else:
        p = d / "decisiones_BTCUSDT.csv"
        filas = list(csv.DictReader(p.open(encoding="utf-8")))
        if alteracion == "fila_borrada":
            filas = filas[:-1]
        else:
            filas[10]["equity_cierre"] = str(float(filas[10]["equity_cierre"]) * 1.5)
        with p.open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(filas[0]))
            w.writeheader()
            w.writerows(filas)
    inf = V2.verificar_archivo(d / "resultado.json", raiz=F.T_REAL, registro=raiz / "REGISTRO.jsonl")
    assert inf["nivel"] == "VERIFICADO"


def test_S8_inicio_del_corte_no_se_contrasta_con_el_prerregistro() -> None:
    import datetime as dt
    ev = F.evaluar()
    ev["inicio"] = "2027-01-02"
    c = F.corte(ev)
    c["dias_calendario"] = (dt.date.fromisoformat(c["corte_exclusivo"]) - dt.date.fromisoformat("2027-01-02")).days
    assert V2.verificar(c)["esquema"] == "papel_corte"  # rama B en el prerregistro empieza el 2027-04-13


# ---------- lo que v0.2 ya hace bien ----------
def test_N1_hashes_desde_archivos(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    (raiz / "src" / "tendencia" / "a.py").write_text("X = 3\n", encoding="utf-8")
    with pytest.raises(V2.ErrorVerificacion):
        V2.verificar(o, raiz=raiz)


def test_N2_duplicadas_y_truncado(tmp_path: Path) -> None:
    p = tmp_path / "d.json"
    p.write_text(json.dumps(F.oos())[:-1] + ', "dias": 1612}', encoding="utf-8")
    with pytest.raises(V2.ErrorVerificacion, match="CLAVE_DUPLICADA"):
        V2.verificar_archivo(p)
    p.write_text(json.dumps(F.oos())[:-30], encoding="utf-8")
    with pytest.raises(V2.ErrorVerificacion, match="LECTURA"):
        V2.verificar_archivo(p)


def test_N3_hash_presellado_por_p4(tmp_path: Path) -> None:
    p = escribir(tmp_path, F.oos())
    with pytest.raises(V2.ErrorVerificacion, match="HASH"):
        V2.verificar_archivo(p, resultado_sha256_esperado="0" * 64)
