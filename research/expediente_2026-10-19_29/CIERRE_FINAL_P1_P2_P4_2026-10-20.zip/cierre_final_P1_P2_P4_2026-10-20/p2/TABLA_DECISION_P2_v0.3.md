# Tabla de decisión completa: POLITICA_AVANCE_T v0.3 (PROPUESTA: no aprobada)

`TABLA_DECISION_P2_v0.3.csv`: **3360 filas**, generadas por `generar_tabla.py`. Una prueba exige que
el archivo coincida con la política y compara cada fila con un oráculo escrito aparte.
Las definiciones, la etapa y las autorizaciones de las filas con «no» en «alcanzable_hoy» son SINTÉTICAS.
Alcanzables hoy: **42 filas** (registros vacíos, etapa no definida, sin autorización).

| ¿Evidencia válida? | Clase | Avance | Autorización | Filas |
|---|---|---|---|---|
| no | SIN_EVIDENCIA_VALIDA | NO_CANDIDATA | CONTRADICTORIA | 1680 |
| no | SIN_EVIDENCIA_VALIDA | NO_CANDIDATA | NO_OTORGADA | 560 |
| sí | INFORMATIVO | NO_CANDIDATA | CONTRADICTORIA | 120 |
| sí | INFORMATIVO | NO_CANDIDATA | NO_OTORGADA | 40 |
| sí | INSUFICIENTE | NO_CANDIDATA | CONTRADICTORIA | 240 |
| sí | INSUFICIENTE | NO_CANDIDATA | NO_OTORGADA | 80 |
| sí | NO_RESPALDADA | NO_CANDIDATA | CONTRADICTORIA | 240 |
| sí | NO_RESPALDADA | NO_CANDIDATA | NO_OTORGADA | 80 |
| sí | RESPALDADA | CANDIDATA_A_REVISION_HUMANA | CONTRADICTORIA | 200 |
| sí | RESPALDADA | CANDIDATA_A_REVISION_HUMANA | NO_OTORGADA | 80 |
| sí | RESPALDADA | CANDIDATA_A_REVISION_HUMANA | REGISTRADA_EXTERNAMENTE | 40 |

Invariantes comprobados en todas las filas: la etiqueta estadística es la literal o vacía (sin evidencia válida); R1/R3 nunca cambian la clase ni el avance; la autorización nunca es otorgada por la política (solo NO_OTORGADA, REGISTRADA_EXTERNAMENTE o CONTRADICTORIA).
