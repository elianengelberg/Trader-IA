"""¿Está justificado «> 0» como umbral de R1/R3 para T? Aritmética con supuestos EXPLÍCITOS sobre cifras YA registradas
(fuera_de_muestra_T.json); no lee datos de mercado, no simula y no es la calibración pendiente. Resultado: INFERIDO.

Supuestos: (s1) el exceso anual medio es aproximadamente normal; (s2) el error típico se deduce del IC90 registrado del
conjunto como ancho / (2 × 1,645); (s3) los tercios de la ventana son independientes y de igual longitud; (s4) el efecto
verdadero δ es constante en la ventana. Ninguno está verificado."""
import math

PHI = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))  # noqa: E731
ic90 = (-0.08820041316896611, 0.22869689090470152)   # principal.conjunto.ic90_anual (registrado)
dias = 1612                                           # registrado
anos = dias / 365.25
se = (ic90[1] - ic90[0]) / (2 * 1.6449)               # error típico del exceso anual medio (s1, s2)
te = se * math.sqrt(anos)                             # «tracking error» anual implícito
se_tercio = te / math.sqrt(anos / 3)
print(f"años = {anos:.3f}; error típico del exceso anual = {se:.4f}; TE implícito = {te:.4f}; "
      f"error típico por tercio = {se_tercio:.4f}")
print("δ (exceso anual verdadero) | P(R1: exceso > 0 en la ventana) | P(R3: > 0 en ≥ 2 de 3 tercios)")
for d in (0.0, 0.03, 0.05, 0.07, 0.10, 0.20):
    p1 = PHI(d / se)
    p = PHI(d / se_tercio)
    p3 = 3 * p**2 - 2 * p**3
    print(f"  {d:+.2f} | {p1:.3f} | {p3:.3f}")
print("Lectura: con δ = 0 (sin ventaja), «> 0» se cumple la mitad de las veces en R1 y en R3; con δ = +7 %/año, R1 se "
      "cumple ~77 % y R3 ~73 %. «> 0» distingue poco una ventaja moderada de ninguna: es un control de SIGNO, no de "
      "robustez económica. Además, para las etiquetas RESPALDADA el prerregistro ya exige exceso con costos ×2 > 0, así "
      "que R1 transpuesto literalmente sería redundante justo donde podría importar.")
