"""Genera la tabla de decisión COMPLETA de la política v0.3 (TABLA_DECISION_P2_v0.3.csv y su resumen .md).
Dimensiones: registro de definiciones (vacío, como hoy, o con definiciones SINTÉTICAS) × validez de la evidencia (6) ×
etiqueta (7) × R1 × R3 × etapa (no definida o una etapa SINTÉTICA) × autorización (ninguna, coincidente, para otra etapa,
para otro resultado). Los registros sintéticos solo recorren ramas: no son propuestas ni definiciones aprobadas."""
from __future__ import annotations

import csv
import io
import itertools
import sys
from collections import Counter
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import politica_avance_T as PA  # noqa: E402

SHA_A, SHA_B = "a" * 64, "b" * 64
DEF_SINTETICAS = {f"{c}-SINTETICA": {"id": f"{c}-SINTETICA", "criterio": c, "aplica_a": "T", "texto_sha256": "0" * 64,
                                     "aprobada_utc": "2000-01-01T00:00:00Z",
                                     "aprobada_por": "PRUEBA SINTÉTICA (no es una propuesta)"} for c in ("R1", "R3")}
ETAPA = "ETAPA_SINTETICA"
ETAPAS = {ETAPA: "solo para recorrer ramas; no es una etapa propuesta"}
AUTORIZACIONES = {nombre: {"id": nombre, "etapa": etapa, "resultado_sha256": sha, "otorgada_por": "PRUEBA SINTÉTICA",
                           "otorgada_utc": "2030-01-01T00:00:00Z", "texto_sha256": "1" * 64}
                  for nombre, etapa, sha in (("COINCIDENTE", ETAPA, SHA_A), ("OTRA_ETAPA", "OTRA", SHA_A),
                                             ("OTRO_RESULTADO", ETAPA, SHA_B))}
COLUMNAS = ("escenario", "validez", "etiqueta_declarada", "R1", "R3", "etapa", "autorizacion", "etiqueta_estadistica",
            "clase", "robustez", "avance", "etapa_salida", "autorizacion_estado", "alcanzable_hoy")


def valor_r(criterio: str, estado: str) -> object:
    return (estado, f"{criterio}-SINTETICA") if estado in ("CUMPLE", "NO_CUMPLE") else estado


def filas() -> list[dict]:
    out = []
    escenarios = (("SIN_DEFINICIONES", {}, ("NO_DEFINIDO",)),
                  ("CON_DEFINICIONES_SINTETICAS", DEF_SINTETICAS, ("CUMPLE", "NO_CUMPLE", "NO_EVALUADO")))
    for (esc, defs, estados_r), validez, etiqueta in itertools.product(escenarios, PA.VALIDEZ, PA.ETIQUETAS):
        ev = PA.evidencia(validez, etiqueta, SHA_A, "2022-01-01") if validez in PA.VALIDA else PA.evidencia(
            validez, etiqueta, motivo="sintético")
        for r1, r3, etapa, aut in itertools.product(estados_r, estados_r, (None, ETAPA),
                                                    (None, "COINCIDENTE", "OTRA_ETAPA", "OTRO_RESULTADO")):
            s = PA.aplicar(ev, valor_r("R1", r1), valor_r("R3", r3), etapa=etapa, autorizacion=aut, definiciones=defs,
                           etapas=ETAPAS, autorizaciones=AUTORIZACIONES)
            out.append({"escenario": esc, "validez": validez, "etiqueta_declarada": etiqueta, "R1": r1, "R3": r3,
                        "etapa": etapa or "NO_DEFINIDA", "autorizacion": aut or "NINGUNA",
                        "etiqueta_estadistica": s["etiqueta_estadistica"] or "", "clase": s["clase_estadistica"],
                        "robustez": s["robustez"]["resumen"], "avance": s["decision_avance"]["resultado"],
                        "etapa_salida": s["decision_avance"]["etapa"],
                        "autorizacion_estado": s["autorizacion_ejecucion"]["estado"],
                        "alcanzable_hoy": "sí" if (esc == "SIN_DEFINICIONES" and etapa is None and aut is None) else "no"})
    return out


def texto_csv() -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=COLUMNAS, lineterminator="\n")
    w.writeheader()
    w.writerows(filas())
    return buf.getvalue()


def resumen_md() -> str:
    f = filas()
    cuenta = Counter((x["validez"] in PA.VALIDA, x["clase"], x["avance"], x["autorizacion_estado"]) for x in f)
    lineas = [f"# Tabla de decisión completa: {PA.VERSION} ({PA.ESTADO_VERSION})", "",
              f"`TABLA_DECISION_P2_v0.3.csv`: **{len(f)} filas**, generadas por `generar_tabla.py`. Una prueba exige que",
              "el archivo coincida con la política y compara cada fila con un oráculo escrito aparte.",
              "Las definiciones, la etapa y las autorizaciones de las filas con «no» en «alcanzable_hoy» son SINTÉTICAS.",
              f"Alcanzables hoy: **{sum(x['alcanzable_hoy'] == 'sí' for x in f)} filas** (registros vacíos, etapa no "
              "definida, sin autorización).", "",
              "| ¿Evidencia válida? | Clase | Avance | Autorización | Filas |", "|---|---|---|---|---|"]
    lineas += [f"| {'sí' if v else 'no'} | {c} | {a} | {z} | {n} |" for (v, c, a, z), n in sorted(cuenta.items())]
    lineas += ["", "Invariantes comprobados en todas las filas: la etiqueta estadística es la literal o vacía (sin "
               "evidencia válida); R1/R3 nunca cambian la clase ni el avance; la autorización nunca es otorgada por la "
               "política (solo NO_OTORGADA, REGISTRADA_EXTERNAMENTE o CONTRADICTORIA)."]
    return "\n".join(lineas) + "\n"


if __name__ == "__main__":
    (AQUI / "TABLA_DECISION_P2_v0.3.csv").write_text(texto_csv(), encoding="utf-8")
    (AQUI / "TABLA_DECISION_P2_v0.3.md").write_text(resumen_md(), encoding="utf-8")
    print(f"{len(filas())} filas")
