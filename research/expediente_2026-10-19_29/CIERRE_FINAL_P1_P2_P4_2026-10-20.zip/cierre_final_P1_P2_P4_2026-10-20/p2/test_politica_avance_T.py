"""Pruebas de la política v0.3: tabla completa contra un oráculo escrito aparte, cada rama y transición relevante,
entradas faltantes o contradictorias como estados explícitos, determinismo, y paso obligado por P1 v0.3."""
from __future__ import annotations

import ast
import csv
import hashlib
import io
import json
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent / "p1"))
import fabricas as F  # noqa: E402
import generar_tabla as G  # noqa: E402
import politica_avance_T as PA  # noqa: E402

T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.py").is_file(), reason="T no disponible")
CLASE = {"RESPALDADA FUERA DE MUESTRA": "RESPALDADA", "VENTAJA RESPALDADA": "RESPALDADA",
         "NO RESPALDADA": "NO_RESPALDADA", "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
         "EVIDENCIA INSUFICIENTE": "INSUFICIENTE", "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
         "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO"}


def oraculo(f: dict) -> dict:
    """Especificación escrita aparte de la implementación (misma semántica, otra redacción)."""
    valida = f["validez"] in ("VERIFICADO", "REPRODUCIDO")
    clase = CLASE[f["etiqueta_declarada"]] if valida else "SIN_EVIDENCIA_VALIDA"
    if not valida:
        rob = "NO_APLICA"
    elif "NO_CUMPLE" in (f["R1"], f["R3"]):
        rob = "NO_ROBUSTA"
    elif f["R1"] == "CUMPLE" and f["R3"] == "CUMPLE":
        rob = "ROBUSTA"
    else:
        rob = "INDETERMINADA"
    avance = "CANDIDATA_A_REVISION_HUMANA" if clase == "RESPALDADA" else "NO_CANDIDATA"
    a = f["autorizacion"]
    if a == "NINGUNA":
        aut = "NO_OTORGADA"
    elif a == "COINCIDENTE" and f["etapa"] == G.ETAPA and valida and clase == "RESPALDADA":
        aut = "REGISTRADA_EXTERNAMENTE"
    else:
        aut = "CONTRADICTORIA"
    return {"etiqueta_estadistica": f["etiqueta_declarada"] if valida else "", "clase": clase, "robustez": rob,
            "avance": avance, "etapa_salida": f["etapa"], "autorizacion_estado": aut}


def test_tabla_completa_contra_el_oraculo() -> None:
    filas = G.filas()
    assert len(filas) == 6 * 7 * 2 * 4 * (1 + 9)  # 6 validez × 7 etiquetas × 2 etapas × 4 autorizaciones × (1 + 9 R1×R3) = 3360
    for f in filas:
        assert {k: f[k] for k in oraculo(f)} == oraculo(f), f
    assert sum(f["alcanzable_hoy"] == "sí" for f in filas) == 6 * 7


def test_archivos_de_tabla_coinciden_con_la_politica() -> None:
    assert (AQUI / "TABLA_DECISION_P2_v0.3.csv").read_text(encoding="utf-8") == G.texto_csv()
    assert (AQUI / "TABLA_DECISION_P2_v0.3.md").read_text(encoding="utf-8") == G.resumen_md()
    filas = list(csv.DictReader(io.StringIO(G.texto_csv())))
    assert {f["autorizacion_estado"] for f in filas} == {"NO_OTORGADA", "REGISTRADA_EXTERNAMENTE", "CONTRADICTORIA"}


def test_determinista() -> None:
    assert G.texto_csv() == G.texto_csv()


# ---------- S1: sin evidencia válida no hay etiqueta ----------
@pytest.mark.parametrize("validez", ["COHERENTE_SIN_INTEGRIDAD", "NO_EVALUABLE", "RECHAZADO", "NO_REPRODUCIDO"])
def test_S1_evidencia_no_valida_no_da_etiqueta(validez: str) -> None:
    s = PA.aplicar(PA.evidencia(validez, "RESPALDADA FUERA DE MUESTRA"), "NO_DEFINIDO", "NO_DEFINIDO")
    assert (s["etiqueta_estadistica"], s["clase_estadistica"], s["decision_avance"]["resultado"]) == (
        None, "SIN_EVIDENCIA_VALIDA", "NO_CANDIDATA")
    assert s["etiqueta_declarada"] == "RESPALDADA FUERA DE MUESTRA"


def test_S1_no_se_puede_pasar_una_etiqueta_suelta() -> None:
    with pytest.raises(PA.ErrorPolitica):
        PA.aplicar("RESPALDADA FUERA DE MUESTRA", "NO_DEFINIDO", "NO_DEFINIDO")  # type: ignore[arg-type]
    with pytest.raises(PA.ErrorPolitica):  # evidencia válida exige hash y fecha
        PA.evidencia("VERIFICADO", "RESPALDADA FUERA DE MUESTRA")
    with pytest.raises(PA.ErrorPolitica):
        PA.aplicar({"validez": "VERIFICADO"}, "NO_DEFINIDO", "NO_DEFINIDO")


# ---------- S2: R1/R3 obligatorios y coherentes con el registro ----------
def test_S2_r1_r3_obligatorios() -> None:
    ev = PA.evidencia("VERIFICADO", "EVIDENCIA INSUFICIENTE", G.SHA_A, "2022-01-01")
    with pytest.raises(TypeError):
        PA.aplicar(ev)  # type: ignore[call-arg]
    with pytest.raises(PA.ErrorPolitica, match="no puede ser NO_DEFINIDO"):
        PA.aplicar(ev, "NO_DEFINIDO", "NO_DEFINIDO", definiciones=G.DEF_SINTETICAS)
    with pytest.raises(PA.ErrorPolitica, match="NO_EVALUADO exige"):
        PA.aplicar(ev, "NO_EVALUADO", "NO_DEFINIDO")
    s = PA.aplicar(ev, "NO_EVALUADO", "NO_EVALUADO", definiciones=G.DEF_SINTETICAS)
    assert s["robustez"]["resumen"] == "INDETERMINADA"


def test_definiciones_de_otro_experimento_o_criterio() -> None:
    ev = PA.evidencia("VERIFICADO", "VENTAJA RESPALDADA", G.SHA_A, "2027-01-01")
    e3 = {"R1-E3": G.DEF_SINTETICAS["R1-SINTETICA"] | {"id": "R1-E3", "aplica_a": "E3"}}
    with pytest.raises(PA.ErrorPolitica, match="no se trasladan"):
        PA.aplicar(ev, ("CUMPLE", "R1-E3"), "NO_DEFINIDO", definiciones=e3)
    with pytest.raises(PA.ErrorPolitica, match="no se trasladan"):
        PA.aplicar(ev, "NO_EVALUADO", ("CUMPLE", "R1-SINTETICA"), definiciones=G.DEF_SINTETICAS)
    extra = {"R1-X": G.DEF_SINTETICAS["R1-SINTETICA"] | {"id": "R1-X", "umbral": 0}}
    with pytest.raises(PA.ErrorPolitica, match="exactamente"):
        PA.aplicar(ev, ("CUMPLE", "R1-X"), "NO_DEFINIDO", definiciones=extra)


# ---------- S4, S5: fechas y hashes de las definiciones ----------
@pytest.mark.parametrize("aprobada", ["1", "ayer", "2021-12-31", "2021-12-31T23:00:00"])
def test_S4_fecha_de_aprobacion_invalida_se_rechaza(aprobada: str) -> None:
    ev = PA.evidencia("VERIFICADO", "EVIDENCIA INSUFICIENTE", G.SHA_A, "2022-01-01")
    d = {"R1-S": G.DEF_SINTETICAS["R1-SINTETICA"] | {"id": "R1-S", "aprobada_utc": aprobada}}
    with pytest.raises(PA.ErrorPolitica):
        PA.aplicar(ev, ("CUMPLE", "R1-S"), "NO_DEFINIDO", definiciones=d)


@pytest.mark.parametrize("aprobada,post_hoc", [("2021-12-31T23:59:59Z", False), ("2022-01-01T00:00:00Z", True),
                                               ("2026-10-20T10:00:00+02:00", True)])
def test_S4_post_hoc_con_fechas_reales(aprobada: str, post_hoc: bool) -> None:
    ev = PA.evidencia("VERIFICADO", "EVIDENCIA INSUFICIENTE", G.SHA_A, "2022-01-01")
    d = {"R1-S": G.DEF_SINTETICAS["R1-SINTETICA"] | {"id": "R1-S", "aprobada_utc": aprobada}}
    s = PA.aplicar(ev, ("CUMPLE", "R1-S"), "NO_DEFINIDO", definiciones=d)
    assert s["robustez"]["R1"]["post_hoc"] is post_hoc


def test_S4_fecha_de_la_ventana_invalida() -> None:
    with pytest.raises(PA.ErrorPolitica):
        PA.evidencia("VERIFICADO", "EVIDENCIA INSUFICIENTE", G.SHA_A, "ayer")


def test_S5_hash_del_texto_validado() -> None:
    ev = PA.evidencia("VERIFICADO", "EVIDENCIA INSUFICIENTE", G.SHA_A, "2022-01-01")
    d = {"R1-S": G.DEF_SINTETICAS["R1-SINTETICA"] | {"id": "R1-S", "texto_sha256": "cualquier cosa"}}
    with pytest.raises(PA.ErrorPolitica, match="SHA-256"):
        PA.aplicar(ev, ("CUMPLE", "R1-S"), "NO_DEFINIDO", definiciones=d)


# ---------- S3: autorización ----------
def test_S3_la_politica_nunca_otorga_y_las_contradicciones_son_explicitas() -> None:
    ev = PA.evidencia("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", G.SHA_A, "2022-01-01")
    k = {"etapas": G.ETAPAS, "autorizaciones": G.AUTORIZACIONES}
    assert PA.aplicar(ev, "NO_DEFINIDO", "NO_DEFINIDO", etapa=G.ETAPA, **k)["autorizacion_ejecucion"]["estado"] == "NO_OTORGADA"
    s = PA.aplicar(ev, "NO_DEFINIDO", "NO_DEFINIDO", etapa=G.ETAPA, autorizacion="COINCIDENTE", **k)
    assert s["autorizacion_ejecucion"]["estado"] == "REGISTRADA_EXTERNAMENTE" and "no ejecuta" in s["autorizacion_ejecucion"]["motivo"]
    s = PA.aplicar(PA.evidencia("VERIFICADO", "EVIDENCIA INSUFICIENTE", G.SHA_A, "2022-01-01"), "NO_DEFINIDO",
                   "NO_DEFINIDO", etapa=G.ETAPA, autorizacion="COINCIDENTE", **k)
    assert s["autorizacion_ejecucion"]["estado"] == "CONTRADICTORIA"  # autorizar algo NO_CANDIDATA: revisión
    with pytest.raises(PA.ErrorPolitica, match="desconocida"):
        PA.aplicar(ev, "NO_DEFINIDO", "NO_DEFINIDO", etapa=G.ETAPA, autorizacion="INVENTADA", **k)
    assert PA.AUTORIZACIONES == {} and PA.DEFINICIONES_APROBADAS == {} and PA.ETAPAS_DEFINIDAS == {}


def test_etapa_inventada_se_rechaza() -> None:
    ev = PA.evidencia("VERIFICADO", "VENTAJA RESPALDADA", G.SHA_A, "2027-01-01")
    with pytest.raises(PA.ErrorPolitica, match="no definida"):
        PA.aplicar(ev, "NO_DEFINIDO", "NO_DEFINIDO", etapa="DINERO_REAL")


# ---------- paso por P1 v0.3 ----------
def test_desde_resultado_estados_explicitos(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO")
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"]) == ("VERIFICADO", "EVIDENCIA INSUFICIENTE")
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", reproduccion=F.oos(raiz=raiz))
    assert s["evidencia"]["validez"] == "REPRODUCIDO"
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", reproduccion=F.oos(p_conj=0.7, raiz=raiz))
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"]) == ("NO_REPRODUCIDO", None)
    (raiz / "src" / "tendencia" / "a.py").write_text("X = 9\n", encoding="utf-8")
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO")
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"]) == ("RECHAZADO", None)
    assert s["evidencia"]["motivo"].startswith("HASH")
    ruta.write_text(json.dumps(F.corte_provisional()), encoding="utf-8")
    assert PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO")["evidencia"]["validez"] == "NO_EVALUABLE"


@con_t
def test_resultado_historico_real() -> None:
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    antes = hashlib.sha256(ruta.read_bytes()).hexdigest()
    s = PA.desde_resultado(ruta, T, "NO_DEFINIDO", "NO_DEFINIDO")
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"], s["robustez"]["resumen"],
            s["decision_avance"]["resultado"], s["decision_avance"]["etapa"], s["autorizacion_ejecucion"]["estado"]) == (
        "VERIFICADO", "EVIDENCIA INSUFICIENTE", "INDETERMINADA", "NO_CANDIDATA", "NO_DEFINIDA", "NO_OTORGADA")
    assert hashlib.sha256(ruta.read_bytes()).hexdigest() == antes


# ---------- estáticas ----------
def test_sin_umbrales_ni_importaciones_de_t() -> None:
    arbol = ast.parse((AQUI / "politica_avance_T.py").read_bytes())
    numeros = sorted({n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and type(n.value) in (int, float)})
    assert numeros == [0, 1, 2, 64]  # índices, tamaño de la tupla (estado, id), longitud de un SHA-256, «≤ 0»
    modulos = {a.name for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        n.module for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    assert modulos == {"__future__", "datetime", "sys", "pathlib", "verificar_reproduccion_T"}


@con_t
def test_etiquetas_iguales_a_los_return_del_codigo_congelado() -> None:
    textos = set()
    for ruta, nombre in ((T / "experimentos" / "fuera_de_muestra_T.py", "decision"),
                         (T / "src" / "tendencia" / "papel.py", "decidir")):
        f = next(n for n in ast.parse(ruta.read_bytes()).body if isinstance(n, ast.FunctionDef) and n.name == nombre)
        textos |= {n.value.value for n in ast.walk(f) if isinstance(n, ast.Return)}
    assert textos == set(PA.ETIQUETAS)
