"""SONDAS sobre la política v0.2 (copia de referencia). S* pasa si el defecto EXISTE en v0.2; N* comprueba lo correcto."""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

REF = Path(__file__).resolve().parents[1] / "referencia_v0_2"
sys.path.insert(0, str(REF / "p1"))  # la v0.2 importa el verificador v0.2 desde ../p1


def _cargar(nombre: str, ruta: Path):  # type: ignore[no-untyped-def]
    spec = importlib.util.spec_from_file_location(nombre, ruta)
    m = importlib.util.module_from_spec(spec)
    sys.modules[nombre] = m
    spec.loader.exec_module(m)  # type: ignore[union-attr]
    return m


PA2 = _cargar("politica_v0_2_ref", REF / "p2" / "politica_avance_T.py")
DEF = {f"{c}-S": {"id": f"{c}-S", "criterio": c, "aplica_a": "T", "texto_sha256": "0" * 64,
                  "aprobada_utc": "2000-01-01T00:00:00Z", "aprobada_por": "SINTÉTICO"} for c in ("R1", "R3")}


def test_S1_aplicar_clasifica_sin_evidencia() -> None:
    """Cualquiera puede pasar una etiqueta favorable sin resultado verificado detrás: no hay dimensión de validez."""
    s = PA2.aplicar("RESPALDADA FUERA DE MUESTRA")
    assert s["decision_avance"]["resultado"] == "CANDIDATA_A_REVISION_HUMANA" and "evidencia" not in json.dumps(s)


def test_S2_no_definido_por_defecto_aunque_exista_definicion() -> None:
    s = PA2.aplicar("VENTAJA RESPALDADA", definiciones=DEF)  # R1/R3 omitidos: valor por defecto silencioso
    assert s["robustez"]["R1"]["estado"] == "NO_DEFINIDO" and "R1-S" in DEF


def test_S3_autorizacion_constante_sin_estado_contradictorio() -> None:
    texto = (REF / "p2" / "politica_avance_T.py").read_text(encoding="utf-8")
    assert texto.count('"NO_OTORGADA"') == 1 and "autorizacion" not in PA2.aplicar.__code__.co_varnames


def test_S4_fechas_comparadas_como_texto() -> None:
    """Una fecha de aprobación mal formada («1») queda «antes» de 2022-01-01 y pasa por prerregistrada."""
    d = {"R1-S": DEF["R1-S"] | {"aprobada_utc": "1"}}
    s = PA2.aplicar("EVIDENCIA INSUFICIENTE", ("CUMPLE", "R1-S"), fecha_inicio_ventana="2022-01-01", definiciones=d)
    assert s["robustez"]["R1"]["post_hoc"] is False
    s = PA2.aplicar("EVIDENCIA INSUFICIENTE", ("CUMPLE", "R1-S"), fecha_inicio_ventana="ayer", definiciones=DEF)
    assert s["robustez"]["R1"]["post_hoc"] is False  # «ayer» > «2000-01-01» como texto


def test_S5_hash_del_texto_de_la_definicion_sin_validar() -> None:
    d = {"R1-S": DEF["R1-S"] | {"texto_sha256": "cualquier cosa"}}
    assert PA2.aplicar("EVIDENCIA INSUFICIENTE", ("CUMPLE", "R1-S"), definiciones=d)["robustez"]["R1"]["estado"] == "CUMPLE"


def test_N1_etiqueta_literal_y_autorizacion_nunca_otorgada() -> None:
    for e in PA2.ETIQUETAS:
        s = PA2.aplicar(e, ("CUMPLE", "R1-S"), ("CUMPLE", "R3-S"), definiciones=DEF)
        assert s["etiqueta_estadistica"] == e and s["autorizacion_fase_posterior"]["estado"] == "NO_OTORGADA"


def test_N2_resultado_determinista() -> None:
    a = [json.dumps(PA2.aplicar(e), sort_keys=True) for e in PA2.ETIQUETAS]
    assert a == [json.dumps(PA2.aplicar(e), sort_keys=True) for e in PA2.ETIQUETAS]
