"""Utilidades de prueba para P4: preparación de entradas sintéticas, procesos hijo con caída o pausa determinista
(FIFO), y recuento de cálculos. Compartidas por las sondas sobre v0.2 y las pruebas de v0.3."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
CONDUCTOR = AQUI / "_conductor.py"
CODIGOS = AQUI / "codigos_sinteticos"
DATOS = [0.01, -0.02, 0.03, 0.005, -0.01, 0.02, 0.015, -0.005] * 5


def preparar(tmp: Path, codigo: str = "det", nombre: str = "e", dir_estado: str | None = None) -> dict:
    ent = tmp / f"entradas_{nombre}"
    ent.mkdir(parents=True)
    (ent / "protocolo.md").write_text("protocolo sintético v1\n", encoding="utf-8")
    (ent / "codigo.py").write_bytes((CODIGOS / f"{codigo}.py").read_bytes())
    (ent / "datos.txt").write_text(" ".join(map(str, DATOS)), encoding="utf-8")
    contador = tmp / f"llamadas_{nombre}.txt"
    (ent / "contador.txt").write_text(str(contador), encoding="utf-8")
    return {"dir": dir_estado or str(tmp / f"estado_{nombre}"), "experimento": "SINTETICO-1", "semilla": 7,
            "contador": str(contador), "tmp": tmp, "ancla": str(tmp / "ancla" / "ANCLA.jsonl"),
            "archivos": {k: str(ent / f) for k, f in (("protocolo", "protocolo.md"), ("codigo", "codigo.py"),
                                                      ("datos", "datos.txt"), ("contador", "contador.txt"))}}


def llamadas(e: dict) -> int:
    p = Path(e["contador"])
    return len(p.read_text(encoding="utf-8").splitlines()) if p.exists() else 0


class Hijo:
    """Proceso hijo que corre el conductor. Con ``pausa``, ``esperar_pausa()`` bloquea hasta que el hijo llegue al punto
    (lectura de la FIFO «listo») y ``seguir()`` lo libera (escritura en la FIFO «seguir»). Sin tiempos."""

    def __init__(self, e: dict, con_ancla: bool = False, modulo: Path | None = None, pausa: str | None = None,
                 env: dict | None = None, **extra: object):
        args = {k: e[k] for k in ("dir", "experimento", "semilla", "archivos")} | (
            {"ancla": e["ancla"]} if con_ancla else {}) | ({"modulo": str(modulo)} if modulo else {}) | extra
        if pausa:
            base = Path(e["tmp"]) / f"fifo_{os.getpid()}_{id(self)}"
            args |= {"pausa": pausa, "listo": f"{base}_listo", "seguir": f"{base}_seguir"}
            os.mkfifo(args["listo"])
            os.mkfifo(args["seguir"])
        self.args = args
        self.p = subprocess.Popen([sys.executable, "-B", str(CONDUCTOR), json.dumps(args)], stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, text=True,
                                  env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1", **(env or {})})

    def esperar_pausa(self) -> str:
        with open(self.args["listo"]) as fh:
            return fh.read()

    def seguir(self) -> None:
        with open(self.args["seguir"], "w") as fh:
            fh.write("x")

    def fin(self) -> dict:
        out, err = self.p.communicate(timeout=120)
        if self.p.returncode != 0:
            return {"estado": f"MURIO({self.p.returncode})", "stderr": err[-400:]}
        return json.loads(out)
