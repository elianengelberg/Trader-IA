"""SONDAS sobre el prototipo de uso único v0.2 (copia de referencia sin modificar). S* pasa si el defecto EXISTE en
v0.2; LIMITE_* documenta lo que ningún prototipo local puede impedir. Concurrencia con pausas DETERMINISTAS (FIFO)."""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
from sincro import Hijo, llamadas, preparar  # noqa: E402

REF = AQUI.parent / "referencia_v0_2" / "p4" / "uso_unico.py"


def _cargar(ruta: Path, nombre: str):  # type: ignore[no-untyped-def]
    spec = importlib.util.spec_from_file_location(nombre, ruta)
    m = importlib.util.module_from_spec(spec)
    sys.modules[nombre] = m
    spec.loader.exec_module(m)  # type: ignore[union-attr]
    return m


U2 = _cargar(REF, "uso_unico_v0_2_ref")


def correr(e: dict, con_ancla: bool = False, modulo=None, **kw):  # type: ignore[no-untyped-def]
    U = modulo or U2
    return U.ejecutar(kw.get("dir", e["dir"]), e["experimento"], e["archivos"], e["semilla"],
                      ancla=U.AnclaArchivo(e["ancla"]) if con_ancla else None)


def test_S1_dos_calculos_de_la_misma_reserva_en_dos_directorios(tmp_path: Path) -> None:
    """Misma reserva (mismo experimento, entradas y semilla) en dos directorios, intercalados de forma determinista:
    A concilia con el ancla (0 inicios) y se detiene; B reserva, registra el inicio 1 y se detiene antes de calcular;
    A sigue: su «inicio 1» es idempotente y calcula; luego B también calcula. Dos cálculos de una reserva."""
    e = preparar(tmp_path, "det")
    a = Hijo(e, con_ancla=True, modulo=REF, pausa="tras_reservar")
    a.esperar_pausa()
    b = Hijo(e | {"dir": str(tmp_path / "estado_b")}, con_ancla=True, modulo=REF, pausa="tras_iniciar_calculo")
    b.esperar_pausa()
    a.seguir()
    sa = a.fin()
    b.seguir()
    sb = b.fin()
    assert sa["estado"] == "REGISTRADO" and llamadas(e) == 2, (sa, sb)


def test_S2_ancla_perdida_se_repara_en_silencio(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    x = correr(e, True)
    shutil.rmtree(Path(e["ancla"]).parent)  # el ancla desaparece (o se configura otra)
    assert correr(e, True).estado == "REGISTRADO"  # v0.2 vuelve a anotar reserva y presellado sin avisar


def test_S2b_ancla_perdida_mas_estado_restaurado_da_otra_extraccion(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    a = Hijo(e, con_ancla=True, modulo=REF, punto="tras_reservar")
    a.fin()
    copia = tmp_path / "copia"
    shutil.copytree(e["dir"], copia)
    x = correr(e, True)
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    shutil.rmtree(Path(e["ancla"]).parent)
    y = correr(e, True)
    assert x.estado == y.estado == "REGISTRADO" and x.resultado_sha256 != y.resultado_sha256


def test_S3_el_ejecutor_no_esta_ligado_a_la_reserva(tmp_path: Path) -> None:
    """Tras una caída antes del cálculo, se reanuda con un EJECUTOR modificado (otro _HIJO): v0.2 lo acepta."""
    e = preparar(tmp_path, "det")
    Hijo(e, modulo=REF, punto="tras_reservar").fin()
    otro = tmp_path / "uso_unico_modificado.py"
    otro.write_text(REF.read_text(encoding="utf-8").replace(
        'res = ns[e["punto_entrada"]](contenidos, e["semilla"])',
        'res = ns[e["punto_entrada"]](contenidos, e["semilla"]); res["inyectado"] = 1'), encoding="utf-8")
    U_otro = _cargar(otro, "uso_unico_modificado")
    s = correr(e, modulo=U_otro)
    assert s.estado == "REGISTRADO" and s.resultado.get("inyectado") == 1


def test_S4_el_calculo_hereda_el_entorno_del_proceso(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    e = preparar(tmp_path, "entorno")
    monkeypatch.setenv("SECRETO_DE_PRUEBA", "valor-secreto")
    s = correr(e)
    assert s.resultado["secreto"] == "valor-secreto" and s.resultado["directorio"] == os.getcwd()


def test_S5_un_calculo_no_determinista_se_registra_sin_detectarlo(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    s = correr(e, True)
    assert s.estado == "REGISTRADO" and "ruido" in s.resultado  # nadie advierte que no es reproducible


def test_LIMITE_el_codigo_reservado_puede_ejecutarse_fuera_del_mecanismo(tmp_path: Path) -> None:
    """Nada impide correr el código y los datos reservados por fuera (y ver el resultado antes del presellado)."""
    e = preparar(tmp_path, "det")
    ns: dict = {}
    exec(compile(Path(e["archivos"]["codigo"]).read_bytes(), "fuera", "exec"), ns)
    contenidos = {k: Path(v).read_bytes() for k, v in e["archivos"].items() if k != "codigo"}
    fuera = ns["calcular"](contenidos, e["semilla"])
    assert correr(e).resultado == fuera
