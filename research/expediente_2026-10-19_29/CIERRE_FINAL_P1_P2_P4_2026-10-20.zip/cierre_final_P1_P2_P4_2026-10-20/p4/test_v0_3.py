"""Pruebas de P4 v0.3: corrección de S1–S5, concurrencia con sincronización DETERMINISTA (pausas por FIFO, sin
retardos), ancla perdida, ejecutor y entorno ligados a la reserva, determinismo, y recuperación que no cambia la reserva.
Datos y códigos sintéticos. test_LIMITE_* pasa cuando el límite EXISTE."""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import uso_unico as U  # noqa: E402
from sincro import CODIGOS, Hijo, llamadas, preparar  # noqa: E402


def correr(e: dict, con_ancla: bool = False, modulo=None, **kw) -> U.Salida:  # type: ignore[no-untyped-def]
    M = modulo or U
    return M.ejecutar(kw.pop("dir", e["dir"]), kw.pop("experimento", e["experimento"]), e["archivos"],
                      kw.pop("semilla", e["semilla"]), ancla=M.AnclaArchivo(e["ancla"]) if con_ancla else None, **kw)


# ---------- S1: un solo cálculo por reserva, también entre directorios (sincronización determinista) ----------
def test_S1_dos_directorios_misma_reserva_intercalados(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    a = Hijo(e, con_ancla=True, pausa="tras_reservar")
    a.esperar_pausa()  # A ya concilió con el ancla (0 inicios)
    b = Hijo(e | {"dir": str(tmp_path / "estado_b")}, con_ancla=True, pausa="tras_iniciar_calculo")
    b.esperar_pausa()  # B registró el inicio 1 en el ancla
    a.seguir()
    sa = a.fin()
    b.seguir()
    sb = b.fin()
    assert sa["estado"] == "INCONSISTENTE" and "inicio 1 rechazado" in sa["detalle"]
    assert sb["estado"] == "REGISTRADO" and llamadas(e) == 1


def test_S1_segundo_directorio_tras_un_inicio_se_rechaza(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    a = Hijo(e, con_ancla=True, pausa="tras_iniciar_calculo")
    a.esperar_pausa()
    sb = correr(e, True, dir=tmp_path / "estado_b")
    assert sb.estado == "RECHAZADO" and "cálculo iniciado" in sb.detalle
    a.seguir()
    assert a.fin()["estado"] == "REGISTRADO" and llamadas(e) == 1


def test_concurrencia_determinista_mismo_directorio(tmp_path: Path) -> None:
    """A tiene el cerrojo y está detenido dentro de la sección crítica: los otros 7 reciben OCUPADO sin depender de
    tiempos; al liberar a A hay exactamente un cálculo."""
    e = preparar(tmp_path, "det")
    a = Hijo(e, con_ancla=True, pausa="tras_iniciar_calculo")
    a.esperar_pausa()
    otros = [Hijo(e, con_ancla=True) for _ in range(7)]
    assert {o.fin()["estado"] for o in otros} == {"OCUPADO"}
    a.seguir()
    assert a.fin()["estado"] == "REGISTRADO" and llamadas(e) == 1
    assert correr(e, True).calculado is False


def test_concurrencia_determinista_otro_nombre_mismas_entradas(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    a = Hijo(e, con_ancla=True, pausa="antes_de_reservar")  # A ya registró la reserva en el ancla
    a.esperar_pausa()
    sb = correr(e, True, dir=tmp_path / "estado_b", experimento="OTRO-NOMBRE", semilla=99)
    assert sb.estado == "RECHAZADO" and "mismas entradas" in sb.detalle
    a.seguir()
    assert a.fin()["estado"] == "REGISTRADO" and llamadas(e) == 1


# ---------- S2: el ancla no se repara en silencio ----------
def test_S2_ancla_perdida_es_inconsistente(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    assert correr(e, True).estado == "REGISTRADO"
    shutil.rmtree(Path(e["ancla"]).parent)
    s = correr(e, True)
    assert (s.estado, s.resultado) == ("INCONSISTENTE", None) and "no se repara" in s.detalle


def test_S2_ancla_perdida_mas_estado_restaurado(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    Hijo(e, con_ancla=True, punto="tras_reservar").fin()
    copia = tmp_path / "copia"
    shutil.copytree(e["dir"], copia)
    correr(e, True)
    shutil.rmtree(e["dir"])
    shutil.copytree(copia, e["dir"])
    shutil.rmtree(Path(e["ancla"]).parent)
    n = llamadas(e)
    assert correr(e, True).estado == "INCONSISTENTE" and llamadas(e) == n


def test_S2_ancla_antigua_con_menos_inicios(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    Hijo(e, con_ancla=True, punto="tras_reservar", reintentos=1).fin()  # misma reserva en las tres llamadas
    vieja = tmp_path / "ancla_vieja"
    shutil.copytree(Path(e["ancla"]).parent, vieja)  # el ancla antes del inicio de cálculo
    Hijo(e, con_ancla=True, punto="durante_calculo", reintentos=1).fin()
    shutil.rmtree(Path(e["ancla"]).parent)
    shutil.copytree(vieja, Path(e["ancla"]).parent)
    s = correr(e, True, reintentos_tras_inicio=1)
    assert s.estado == "INCONSISTENTE" and "perdió registros" in s.detalle


def test_la_identidad_del_ancla_forma_parte_de_la_reserva(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    Hijo(e, punto="tras_reservar").fin()  # reservado SIN ancla
    assert correr(e, True).estado == "RECHAZADO"  # pasar a otra configuración de ancla = otra reserva


# ---------- S3: el ejecutor está ligado a la reserva ----------
def test_S3_ejecutor_modificado_se_rechaza(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    Hijo(e, punto="tras_reservar").fin()
    otro = tmp_path / "uso_unico_modificado.py"
    otro.write_text((AQUI / "uso_unico.py").read_text(encoding="utf-8").replace(
        'res = ns[e["punto_entrada"]](contenidos, e["semilla"])',
        'res = ns[e["punto_entrada"]](contenidos, e["semilla"]); res["inyectado"] = 1'), encoding="utf-8")
    spec = importlib.util.spec_from_file_location("uso_unico_modificado_v3", otro)
    M = importlib.util.module_from_spec(spec)
    sys.modules["uso_unico_modificado_v3"] = M
    spec.loader.exec_module(M)  # type: ignore[union-attr]
    s = correr(e, modulo=M)
    assert s.estado == "RECHAZADO" and llamadas(e) == 0


# ---------- S4: entorno del cálculo ----------
def test_S4_el_calculo_no_hereda_entorno_ni_directorio(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    e = preparar(tmp_path, "entorno")
    monkeypatch.setenv("SECRETO_DE_PRUEBA", "valor-secreto")
    s = correr(e)
    assert s.estado == "REGISTRADO" and s.resultado["secreto"] is None
    assert s.resultado["directorio"] != os.getcwd() and Path(s.resultado["directorio"]).name.startswith("calculo_")
    assert s.resultado["variables"] <= 2  # a lo sumo las que el propio intérprete fija (p. ej. LC_CTYPE)


# ---------- S5: determinismo ----------
def test_S5_no_determinista_se_detecta_antes_de_presellar(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    s = correr(e, True, verificar_determinismo=True)
    assert (s.estado, s.resultado) == ("NO_DETERMINISTA", None) and llamadas(e) == 2
    assert not (Path(e["dir"]) / U.RESULTADO).exists() and U.leer(e["dir"])["presellado"] is None
    assert correr(e, True, verificar_determinismo=True).estado == "NO_DETERMINISTA" and llamadas(e) == 2  # terminal


def test_S5_determinista_pasa_y_cuesta_dos_calculos(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    s = correr(e, True, verificar_determinismo=True)
    assert s.estado == "REGISTRADO" and llamadas(e) == 2
    assert correr(e, True, verificar_determinismo=False).estado == "RECHAZADO"  # la opción está en la reserva


# ---------- la recuperación no cambia lo reservado ----------
def test_recuperacion_conserva_la_reserva_original(tmp_path: Path) -> None:
    for punto in ("tras_reservar", "tras_presellado", "tras_archivo"):
        e = preparar(tmp_path / punto, "det")
        Hijo(e, con_ancla=True, punto=punto).fin()
        primera = (Path(e["dir"]) / U.DIARIO).read_bytes().split(b"\n")[0]
        s = correr(e, True)
        assert s.estado == "REGISTRADO"
        assert (Path(e["dir"]) / U.DIARIO).read_bytes().split(b"\n")[0] == primera
        assert s.reserva_sha256 == U._sha(U._canon(json.loads(primera)["datos"]))


def test_LIMITE_el_codigo_reservado_puede_ejecutarse_fuera_del_mecanismo(tmp_path: Path) -> None:
    """Ningún prototipo local impide correr el código y los datos reservados por fuera. Mitigación posible (no
    implementada): que los datos solo sean accesibles a través del ejecutor (p. ej., cifrados con una clave que solo él
    recibe de un servicio externo)."""
    e = preparar(tmp_path, "det")
    ns: dict = {}
    exec(compile((CODIGOS / "det.py").read_bytes(), "fuera", "exec"), ns)
    contenidos = {k: Path(v).read_bytes() for k, v in e["archivos"].items() if k != "codigo"}
    assert correr(e).resultado == ns["calcular"](contenidos, e["semilla"])
