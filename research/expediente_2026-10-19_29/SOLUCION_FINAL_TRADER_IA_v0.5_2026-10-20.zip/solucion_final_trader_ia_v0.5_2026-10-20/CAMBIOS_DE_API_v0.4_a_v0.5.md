# Cambios de API de v0.4 a v0.5 y su justificación

**Diffs completos:**
- `diffs/codigo_v0_4_a_v0_5.diff`: código de los cuatro módulos, más el ejecutor nuevo;
- `diffs/codigo_v0_3_a_v0_5.diff`;
- `diffs/pruebas_v0_4_a_v0_5.diff`: todas las pruebas.

**Efecto de cada cambio en las suites anteriores, sin modificarlas:**
- `evidencia/27_*`: la suite completa de v0.4 contra v0.5;
- `evidencia/22_*` a `26_*`: las suites de v0.3 contra v0.5.

**Regla:** solo se cambió una API cuando el defecto no se podía corregir sin cambiarla. Ningún cambio relaja un rechazo.
Todos convierten algo que v0.4 aceptaba en INCONCLUSO, CORRUPTO o un error explícito.

## confianza.py
| Cambio | Antes (v0.4) | Ahora (v0.5) | Por qué (defecto) |
|---|---|---|---|
| `verificar_firma` rechaza claves y R de orden pequeño o mixto | Aceptaba la firma trivial con la clave neutra o `00…00` | False | **F1**: falsificación sin clave privada (`evidencia/71_*`) |
| `validar_raiz` | Aceptaba esas claves | RAIZ_INVALIDA | F1 |
| `validar_clave_publica(hex)` (nueva) | — | ErrorConfianza CLAVE | La usa P4 para la clave fijada del ancla (F1) |
| `canonico` y `cargar_json_estricto` | UnicodeEncodeError y RecursionError escapaban | ErrorConfianza FORMATO | **F4**, **F5**, **F6** |
| `_utc` | Aceptaba cinco formas no canónicas | Solo `AAAA-MM-DDTHH:MM:SS[.ffffff]Z` | **F11** |
| `recibo_de_ancla`, `identidad_ancla` (nuevas) | — | Auxiliares de la ligadura recibo ↔ reserva ↔ ancla | F2 |

## P1 — verificar_reproduccion_T.py
| Cambio | Antes | Ahora | Por qué |
|---|---|---|---|
| `evaluar`, `evaluar_archivo`: parámetro `reserva` (documento de reserva de P4) | Un recibo de cualquier reserva autenticaba | El recibo solo cuenta para la reserva esperada, que nombra a esa ancla y no es una reproducción. Otro presellado para ella es CORRUPTO (`RECIBO_CONTRADICE`) | **F2** |
| `evaluar_reproduccion(ruta, ruta_reproduccion, …, reserva, reserva_reproduccion)` | La reproducción era un **objeto en memoria** sin autenticar | Un **archivo** leído una vez, autenticado como reproducción de ESTE original. Un objeto en memoria es USO (INCONCLUSO). Nuevos códigos: REPRODUCCION_NO_AUTENTICADA, REPRODUCCION_CONTRADICHA | **F3** |
| `reproducir(ruta, ruta_reproduccion, …)` (comparación local) | Objeto en memoria | Ruta. Informa que no autentica | F3 (coherencia: nada compara un objeto que no salió de un archivo) |
| `evaluar_reproduccion` evalúa el original ANTES de validar la tolerancia o la reproducción | Una tolerancia inválida devolvía INCONCLUSO aunque el original fuera CORRUPTO | CORRUPTO | **F12** |
| `contrastar_declaraciones` | Una excepción de una declaración daba ERROR_INTERNO (ocultaba CORRUPTO) | Cada declaración se procesa aparte. Las no procesables van a `no_validas` | **F4** |
| Línea de órdenes: `--reserva`, `--reserva-reproduccion`; `--reproduccion` es una ruta | — | Un error inesperado sale con 3 (INCONCLUSO), nunca con 1 (CORRUPTO) | F2, F3, **F5** |
| Informe: `ejecucion`, `autenticidad.vias`, `autenticidad.no_aplican`, `reproduccion` | — | Trazabilidad de **por qué** algo autentica o no | §6 de la orden: estados separados |

## P2 — politica_avance_T.py
| Cambio | Antes | Ahora | Por qué |
|---|---|---|---|
| `desde_resultado(…, reserva, reproduccion=<ruta>, reserva_reproduccion)` | `reproduccion` era un objeto: una copia del original daba REPRODUCIDO, es decir, evidencia **válida** | P1 exige la reproducción autenticada | **F3** (P2) |
| Salida: `resultado_verificado.ejecucion` y `.reproduccion` | — | Trazabilidad | — |
| La regla de decisión | — | **Sin cambios** (oráculo de 86.400 combinaciones; 11 de 11 mutaciones) | — |

## P4 — uso_unico.py
| Cambio | Antes | Ahora | Por qué |
|---|---|---|---|
| Esquema estricto de cada evento del diario y del ancla local | KeyError, TypeError o AttributeError sin salida | INCONSISTENTE (diario) o ancla en conflicto | **F7** |
| `AnclaFirmada` valida la clave y encapsula cualquier excepción al verificar | Clave neutra aceptada; UnicodeEncodeError sin salida | ErrorConfianza al construir; ANCLA_NO_AUTENTICA | **F1**, **F6** |
| `ejecutar(…, limite_segundos=None)`, parte de la reserva | Esperaba indefinidamente | FALLO_CALCULO al vencer el límite. La siguiente llamada da REVISION_HUMANA | **F8** |
| `ejecutar(…, reproduccion_de=None)`, parte de la reserva | Una reproducción se rechazaba por «mismas entradas» | Convive solo con el original que registró ESE presellado (G5b) | Hace falta para F3: sin esto no hay reproducción con recibo |
| Validación de los argumentos de `ejecutar` | Semilla booleana, flotante o texto, nombre vacío, etc. aceptados | ValueError antes de tocar estado | **F14** (una reserva con un flotante no se puede ligar en P1) |
| El proceso de cálculo borra su directorio vacío | Quedaba huérfano si el padre moría | Se borra | **F10** |
| `leer` devuelve `reserva` y `reserva_sha256` | — | Lo que P1 necesita para la ligadura | F2 |
| Formato de la reserva | `version` v0.4 | v0.5, más `limite_segundos` y `reproduccion_de` | Un diario o un ancla de v0.4 no se reutilizan con v0.5: da RECHAZADO o conflicto, nunca un cálculo nuevo |

## Nuevo: ejecutor_aislado.py
`ejecutar_encargo(encargo, dir_trabajo, ancla, *, declaraciones, rutas_protegidas)` y la línea de órdenes. Detalle en
su docstring y en `ESTADO_POR_MODULO_Y_ETAPA.md`. No hay una API anterior que cambie.

## Pruebas portadas y regresión con la suite de v0.4 SIN modificar (`evidencia/27_*`)
Las reglas de portado de v0.3 están en `evidencia/20_*` (las tres nuevas de v0.5 van marcadas F3) y su diff en
`evidencia/21_*`.

La suite completa de v0.4 (359 pruebas), **sin modificar**, contra el código de v0.5 da **350 pasan y 9 fallan**
(`evidencia/27_regresion_suite_v0_4_fallidas.txt`). Las 9 son cambios de expectativa **deliberados**:

| Prueba de v0.4 | Por qué falla contra v0.5 | Defecto | En la suite de v0.5 |
|---|---|---|---|
| `p1/test_p1_defectos.py::test_P1_S6_*`, `test_P1_N2_*`, `test_P1_N4_*` | El adaptador de v0.4 pasa la reproducción como objeto en memoria → v0.5 da INCONCLUSO (USO) | F3 | Pasan: el adaptador de v0.5 la escribe en un archivo y la autentica, y comparan lo mismo que antes |
| `p1/test_p1_v04.py::test_linea_de_ordenes_codigos_de_salida` | `--reproduccion` sin autenticar → INCONCLUSO, no NO_REPRODUCIDO | F3 | Actualizada: sin autenticar da 3; autenticada da 5 o 0 |
| `p2/test_p2_v04.py::test_desde_resultado_con_cada_estado_de_p1` | Exige el texto literal «v0.4» en el origen; además usa una reproducción en memoria | F3, versión | Actualizada |
| `cruzada/test_cruzada_v04.py::test_cadena_valida_con_recibo_firmado`, `test_X4_*`, `test_X7_*` | La cadena no pasa la reserva → el recibo del ancla ya no autentica → INCONCLUSO | F2 | Actualizadas: `referencias()` pasa `U.leer(dir)["reserva"]`; X16 también la pasa |
| `regresion/p1_v0_3_portadas/test_v0_3.py::test_S6_*` | `reproducir` recibe un objeto | F3 | Portada con las tres reglas nuevas |

**Ninguna** prueba de v0.4 falla por otra causa: las 112 de P4 de v0.3 y las 350 restantes de v0.4 pasan sin cambios.
