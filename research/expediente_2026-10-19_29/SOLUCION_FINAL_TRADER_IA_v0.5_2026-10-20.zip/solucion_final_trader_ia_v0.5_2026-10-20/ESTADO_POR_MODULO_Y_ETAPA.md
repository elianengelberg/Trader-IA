# Estado por módulo y etapa (v0.5)

**Etapas:**
| Etapa | Significado |
|---|---|
| Implementado | El código existe en `codigo/verificacion/` |
| Probado en aislamiento | Con datos, claves y anclas **sintéticos**, en temporales |
| Integrado | En el ejecutor aislado (no en un ejecutor real) |
| Reproducido | Toda la evidencia se volvió a generar desde una extracción limpia del ZIP de origen y se comparó archivo por archivo (`evidencia/95_*`); la ejecución no cambió el paquete (`evidencia/97_*`) |
| Bloqueado | Requiere algo que no está en este equipo ni en los permisos actuales |

| Módulo | Implementado | Probado en aislamiento | Integrado | Reproducido | Bloqueado por |
|---|---|---|---|---|---|
| `confianza.py` v0.5 (Ed25519, declaraciones) | Sí | Sí: RFC 8032, OpenSSL por línea de órdenes, `cryptography` (807 casos diferenciales) y claves de orden pequeño o mixto | Sí (P1, P4, ejecutor) | Sí | — |
| P1 v0.5 (estados, recibos ligados, reproducción autenticada) | Sí | Sí: oráculos de 720, 80 y 210 combinaciones; 300 mutaciones aleatorias; matriz F1–F12 | Sí | Sí | VERIFICADO real: una raíz aprobada (B-2/A12) |
| P2 v0.5 (política) | Sí | Sí: oráculo de 86.400 combinaciones; 11 de 11 mutaciones | Sí | Sí | Etapas, definiciones y autorizaciones: decisiones tuyas (A1–A14) |
| P4 v0.5 (uso único) | Sí | Sí: concurrencia, caídas, 72 fallos de escritura por código, 102 cortes de energía simulados por código, mutaciones aleatorias del diario, contrato C1–C8 | Sí | Sí | Ancla externa real (B-2) |
| Ancla externa | Solo el **cliente** (`AnclaFirmada`) y el contrato | Contra un **doble de prueba** con clave sintética | Sí (con el doble) | Sí | **No existe** el servicio (B-2) |
| Ejecutor aislado y registro de decisiones | Sí | Sí: 32 pruebas de contrato y de extremo a extremo; 10 de 10 mutaciones | Es la integración | Sí | Integración en un ejecutor real (B-3), después de B-2 |
| Trazabilidad de T y declaración a firmar | Sí | Regenerada y comparada en cada ejecución | — | Sí | Tu firma fuera de este equipo (B-2/A12) |
| Estado real de T (6 dimensiones) | `evaluar_T_real.py` | En solo lectura: INCONCLUSO, `SIN_REFERENCIA_INDEPENDIENTE` | — | Sí | A12 |
| Procedencia de `contraste_btc` | Productor localizado; cobertura explicada | Con metadatos (manifiestos) | — | Sí | Reproducirlo: leer datos (B-4) |
| Calibración estadística (MEC §5) | Diseñada (expediente) | **No ejecutada** | — | — | A-S1 y D-S1 a D-S3 |
| Parches `parches/v0.5/` 0001–0007 | Sí | Aplicados y probados sobre HEAD y origin exportados (`evidencia/60_*`, `61_*`) | — | Sí | Aplicarlos al repositorio (B-1) |

**Qué se demostró, qué solo se simuló y qué requiere condiciones externas:**
| Clase | Elementos |
|---|---|
| Demostrado (prueba ejecutada, con salida real) | Estados de P1; ligadura recibo ↔ reserva ↔ ancla; reproducción autenticada; política P2; uso único y conciliación de P4; rechazos del ejecutor; idempotencia del registro; interoperabilidad de Ed25519 y rechazo de claves degeneradas |
| Solo simulado | Corte de energía (sin mkdir y sin orden entre archivos dentro de un intervalo); disco lleno, E/S y escrituras cortas (sustituto de `os`); servicio de ancla externo (doble de prueba con almacenamiento local); concurrencia en una sola máquina |
| Requiere condiciones externas | Autenticidad real de T (tu clave); ancla externa y su durabilidad; corte de energía real, NFS y varias máquinas; reproducción por un tercero; revisión independiente (B-7) |
