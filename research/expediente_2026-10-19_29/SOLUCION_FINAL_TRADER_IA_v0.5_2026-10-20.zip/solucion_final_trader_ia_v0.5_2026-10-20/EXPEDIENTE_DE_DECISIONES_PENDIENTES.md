# Expediente de decisiones pendientes (v0.5, 2026-10-20)

Reemplaza a `DECISIONES_METODOLOGICAS_SIN_DEFINIR.md` (v0.4, conservado en `00_preservado/`).

**Cómo leerlo.** Para cada pendiente:
1. si se puede resolver con la evidencia y los permisos actuales;
2. lo que se hizo;
3. lo que falta, con su dependencia externa concreta;
4. la recomendación, las alternativas y sus consecuencias;
5. la pregunta exacta que lo destraba.

**Lo que no se hizo:**
- Ninguna recomendación está aplicada: el código mantiene todo sin definir (registros vacíos, NO_DEFINIDO, NO_DEFINIDA,
  NO_OTORGADA).
- No se eligió ninguna metodología.
- No se creó ni aprobó ninguna clave.
- No se leyó ningún byte de datos de mercado.

## Resumen
| ID | Pendiente | ¿Resoluble ahora? | Estado al cierre | Dependencia externa concreta |
|---|---|---|---|---|
| R-1 | Procedencia de `contraste_btc_diario_vs_horario` | En parte | Productor **localizado** (v0.4) y cobertura **explicada** (v0.5, solo con manifiestos). Procedencia: **NO_VERIFICADA** | Leer bytes de datos para reproducirlo (B-4) |
| R-2 | Datos fuera de cobertura (775 días sin vela horaria) | Sí, la causa | **Resuelto:** la descarga horaria de H-CARRY empieza en 2019-10. Ningún manifiesto local tiene horas de BTCUSDT anteriores. La ventana fuera de muestra de T está entera cubierta | Ampliar la cobertura exige descargar datos (B-6) o una fuente independiente (B-4) |
| R-3 | Referencia de confianza independiente (A12, B-2) | No | Declaración a firmar y procedimiento **probados** con una clave sintética. T sigue **INCONCLUSO** | Una clave Ed25519 **fuera** de este equipo y tu aprobación de la raíz (cambio de código revisado) |
| R-4 | Integración real (B-3) | No | Ejecutor **aislado** implementado y probado de extremo a extremo con un ancla de prueba | Tu autorización, después de R-5 |
| R-5 | Ancla externa (B-2) | No | Cliente, contrato, recibos ligados y reproducciones **probados** contra un doble de prueba | Elegir y operar un servicio fuera de tu control operativo |
| R-6 | Calibración estadística (A-S1) | No | **No ejecutada.** Diseño completo en el expediente (MEC §5) | A-S1 y la aprobación de D-S1 a D-S3 (D-S4 solo para la potencia) |
| A1–A14 | Decisiones metodológicas | No (son tuyas) | Sin definir en el código | Tu decisión. Cada una tiene una pregunta abajo |
| B-1 | Commits, push, aplicar parches | No | Serie `parches/v0.5/` comprobada sobre HEAD y origin exportados | Tu autorización |
| B-7 | Revisión por un tercero | No | No realizada | Un revisor distinto del autor |
| B-8 | Conservar este paquete | No | ZIP generado en el scratchpad efímero | Descargarlo |

---

## R-1. Procedencia de `contraste_btc_diario_vs_horario`
- **Evidencia:**
  - `contraste_btc/PROCEDENCIA_CALIDAD_DATOS.md`: el productor está en la transcripción local, línea 3244, con el SHA-256 de esa línea.
  - `evidencia/03_*` y `06_cobertura_contraste_btc_manifiestos.txt`.
- **Hecho en v0.5:** se determinó, solo con metadatos, qué archivos leyó el productor (velas spot horarias mensuales
  de H-CARRY: 80 archivos, de 2019-10 a 2026-05) y por qué la cobertura es parcial (R-2).
- **No se puede resolver sin leer datos:** reproducirlo exige leer las velas diarias de T y las horarias de H-CARRY,
  y eso requiere B-4. Aun reproducido, ambas series vienen de **Binance**: no sería un contraste con una fuente
  independiente.
- **Recomendación:** mantenerlo como `PROCEDENCIA_NO_VERIFICADA`. No es evidencia de T y P1 ya lo trata así.
  Autorizar su reproducción solo si algún documento va a apoyarse en él.
- **Alternativas:**
  - (a) reproducirlo en un temporal, en solo lectura, sin sobrescribir `calidad_datos.json`: confirma el cálculo, pero no la independencia;
  - (b) contrastar con un segundo proveedor: daría independencia real, pero es una descarga (B-6).
- **Pregunta:** ¿autorizás leer (sin descargar ni escribir en el repositorio) los bytes de esas velas para reproducir el
  contraste en un temporal, o lo dejamos como NO_VERIFICADO?

## R-2. Datos fuera de cobertura
- **Resuelto (causa):**
  - el manifiesto de H-CARRY declara `desde: 2019-10`;
  - ninguno de los 10 manifiestos locales lista velas horarias de BTCUSDT anteriores a 2019-10;
  - los 775 días de T del 2017-08-17 al 2019-09-30 no tienen vela horaria local, y por eso no figuran ni como «comparados» ni como «sin_horaria» (`evidencia/06_*`).
- **Consecuencia para T:**
  - la ventana fuera de muestra (2022-01-01 → 2026-05-31) está entera en el tramo comparado;
  - el tramo de desarrollo solo desde 2019-10;
  - el nombre `sin_horaria = 0` sugiere una cobertura completa que no existe (documentado; P1 lo informa).
- **Recomendación:** (a) aceptar y documentar. Para T fuera de muestra no cambia nada.
- **Alternativas:**
  - (b) descargar las velas horarias spot de 2017-08 a 2019-09: prohibido sin autorización;
  - (c) un proveedor independiente para todo el período.
- **Pregunta:** ¿aceptás la cobertura parcial documentada, o querés autorizar (b) o (c)?

## R-3. Referencia de confianza independiente (A12, B-2)
- **Evidencia:**
  - `trazabilidad_T/DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json` y `.bin`: sus bytes canónicos coinciden y la declaración es válida en v0.5;
  - `INSTRUCCIONES_FIRMA.md`: el procedimiento con OpenSSL está probado con una clave sintética;
  - `evidencia/80_estado_real_de_T.json`: T es INCONCLUSO con un único motivo, `SIN_REFERENCIA_INDEPENDIENTE`.
- **Por qué no se puede resolver aquí:** una raíz creada o aprobada en este equipo no es independiente. La orden
  también lo prohíbe.
- **Recomendación:**
  - firmar la declaración con una clave generada y guardada **fuera** de este equipo;
  - aprobar la raíz con un cambio de código revisado;
  - **además** publicar los commits `f518ac1` y `692f2b2` (D-G6), para que exista un sello externo de fecha.
- **Qué significa firmar:** «acepto estos artefactos» en la fecha de la firma. No prueba que no cambiaran antes.
- **Alternativas y consecuencias:**
  - (a) no firmar: T queda INCONCLUSO para siempre (no se repite);
  - (b) firmar sin publicar: VERIFICADO, sin prueba pública de fecha;
  - (c) firmar y publicar: la opción más fuerte disponible.
- **Pregunta:** ¿vas a generar una clave Ed25519 fuera de este equipo y firmar `DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.bin`?
  Y por separado: ¿autorizás publicar `f518ac1` y `692f2b2`?

## R-4. Integración real (B-3)
- **Hecho:** `codigo/verificacion/ejecutor_aislado.py`, probado de extremo a extremo (P4 → P1 → P2) con:
  - registro de decisiones encadenado;
  - reanudación idempotente;
  - caídas en 5 puntos;
  - fallos de escritura del registro;
  - concurrencia;
  - archivos protegidos;
  - mutaciones (`evidencia/54_*`).

  No toca `papel/corte.py` ni `fuera_de_muestra_T.py`, y rechaza el script de T por su hash.
- **No hecho:** integrarlo en un ejecutor real. Requiere autorización. Además, sin un ancla externa (R-5) y una raíz
  aprobada (R-3), todo lo que produzca será INCONCLUSO **a propósito**.
- **Recomendación:** no integrar antes de R-5.
- **Pregunta:** cuando exista el ancla, ¿autorizás reemplazar el cálculo directo de un ejecutor (¿cuál?) por
  `ejecutar_encargo`, en un entorno de prueba primero?

## R-5. Ancla externa (B-2)
- **Hecho:**
  - cliente, recibos ligados a la reserva (G7b), reproducciones (G5b) y claves válidas (G12);
  - corte de energía simulado del lado local;
  - contrato C1–C8 sobre el doble de prueba (`DISENO_ANCLA_EXTERNA.md`).
- **Recomendación:** O1 (servicio mínimo con escritura condicional y clave en KMS/HSM) u O2 (repositorio git remoto
  con rama protegida, administrado por otra persona), más O3 u O4 si se quiere una prueba pública de fecha.
- **Pregunta:** ¿qué opción (O1–O4) y qué custodio de la clave del ancla elegís?

## R-6. Calibración estadística (A-S1)
- **Evidencia:**
  - el expediente metodológico (`00_preservado/EXPEDIENTE_METODOLOGICO_2026-10-20.zip`, SHA256SUMS verificados) dice «**no ejecutada**, requiere A-S1» (MEC §5);
  - la matriz del expediente (fila A-S1) la clasifica como una decisión de **autorización**.
- **Por qué no se ejecutó:**
  - la orden v0.4 la prohibía expresamente («No ejecutes la calibración estadística pendiente»);
  - la orden final no la autoriza de forma explícita;
  - además depende de D-S1 a D-S3 (prueba primaria, multiplicidad, regla de respaldo), que son decisiones tuyas.
- **Diseño ya fijado:**
  - seis procesos sintéticos: C1 t₃, C2 GARCH-t₄, C3 AR(1), C4 disperso, C5 intradía y C6 cambio de régimen;
  - n ∈ {1612, 366, 731, 1096};
  - 2000 réplicas, B = 1999, semilla 20261103;
  - bandas: 5 % en [4,03 %, 5,97 %] y 2,5 % en [1,80 %, 3,20 %].
- **No toca datos reales.**
- **Qué se necesita:**
  - el **tamaño** requiere D-S1 (y D-S3 si se activa la regla de respaldo);
  - la **potencia** requiere además δ (D-S4).
- **Alcance:** no afecta a T. Sus reglas congeladas no cambian (MEC §1.3), y su decisión registrada no depende del defecto de P.
- **Recomendación** (la del expediente): aprobar D-S1 = bootstrap-t con ℓ = 20 y B = 9999, D-S2 = Bonferroni y
  D-S3 = máx(p_ℓ20, p_ℓ40, p_NW). Después, autorizar A-S1 solo para el tamaño. La potencia, cuando fijes δ.
- **Pregunta:** ¿aprobás D-S1 a D-S3 y autorizás A-S1 (calibración de tamaño, sintética)?

---

## Decisiones metodológicas (tuyas)
Recordatorio de potencia (aritmética pura, `expediente/evidencia/02_*`): con el TE implícito de T (≈ 20 %/año), detectar
con 80 % de potencia y α = 0,025 un exceso de:

| δ (exceso anual) | Años de datos necesarios |
|---|---|
| 7 % | ≈ 65 |
| 10 % | ≈ 32 |
| 19 % | ≈ 9 |

| ID | Decisión | Estado en el código | Recomendación | Alternativas y consecuencias | Pregunta concreta |
|---|---|---|---|---|---|
| A1/A2 | Definición de R1 y R3 **para T** | `DEFINICIONES_APROBADAS = {}`; solo NO_DEFINIDO | **Dejarlas sin definir para T.** Cualquier definición hoy es post hoc (2022–2026) y no cambia nada: T es EVIDENCIA INSUFICIENTE | «> 0»: control de signo débil. «> δ»: depende de A8. «Cota inferior > 0»: muy exigente. Todas se marcarían post hoc | ¿Dejamos R1/R3 de T como NO_DEFINIDO permanente y las definimos solo para hipótesis futuras, antes de su ventana? |
| A3 | ¿R1/R3 vetan la candidatura? | No; solo advierten | **No vetar** (diagnóstico) | Con veto, un diagnóstico mal calibrado bloquea una ventaja real | ¿Confirmás que la robustez es solo informativa? |
| A4/A7 | Definiciones posteriores a la ventana | Se permiten, marcadas `post_hoc` | **Permitirlas solo marcadas y sin efecto en la candidatura** (como hoy) | Prohibirlas las vuelve un error de entrada | ¿Mantenemos «permitidas y marcadas»? |
| A5 | Etapa siguiente de T | `ETAPAS_DEFINIDAS = {}` | **No definirla ahora:** T es NO_CANDIDATA. El papel sigue con su protocolo congelado (D-T1 a D-T3) | Definirla sin candidata solo agrega una regla sin uso | ¿Posponemos A5 hasta que haya una candidata? |
| A6 | Regla de combinación de R1 y R3 | «Todas» | **«Todas»** | «Alguna»: más permisiva (la mutación «alguna» se detecta) | ¿Confirmás «todas»? |
| **A8** | **δ, pérdida máxima tolerable y robustez económica** | Ningún umbral económico en el código | **No es técnica; no la recomiendo.** Fijala antes de mirar nada nuevo. Ver la tabla de potencia | δ chico: décadas de papel. δ grande: solo detecta efectos enormes | ¿Qué δ (exceso neto anual) y qué pérdida máxima fijás? |
| **A9** | ¿VERIFICADO alcanza o se exige REPRODUCIDO? | Ambos son válidos | Para resultados **futuros** que puedan llevar a capital: exigir REPRODUCIDO, con la reproducción hecha por **otra persona o entorno** (A14). Para T histórico, VERIFICADO (con tu firma) es el máximo posible | Exigir REPRODUCIDO para T = nunca válido (no se repite) | ¿Exigimos REPRODUCIDO para resultados futuros y aceptamos VERIFICADO para T histórico? |
| A10 | Parámetros de P4 para usos reales | Por defecto 0 reintentos, sin verificación de determinismo y sin límite. El ejecutor exige límite | **0 reintentos, verificación de determinismo y un límite de tiempo explícito** | Más reintentos: riesgo de elegir entre resultados | ¿Aprobás esos tres valores para cualquier uso real? |
| A11 | Reabrir hipótesis descartadas | No se tocó | Sin recomendación (D-G5 del expediente) | Reabrir = nuevo intento sobre una familia descartada (multiplicidad) | ¿Reabrís alguna familia descartada? |
| **A12** | ¿Basta tu firma de los artefactos históricos de T? | Sin raíz, INCONCLUSO | **Sí, con publicación de commits** (R-3) | Ver R-3 | Ver R-3 |
| **A13 (nueva)** | Política de raíces: claves, custodia, rotación y revocación | Registro vacío; revocar = quitar la raíz (cambio de código) | Una clave del propietario guardada fuera de línea y otra del ancla en KMS. Ninguna en este equipo. Rotación con solapamiento. Revocación por cambio de código revisado | Una sola clave para todo: si se compromete, cae todo | ¿Aprobás esta política de raíces? |
| **A14 (nueva)** | Política de reproducción: quién reproduce, cuántas veces y qué se presenta | P1 acepta una reproducción autenticada (propietario o recibo del ancla ligado a la reserva) | La reproducción la hace **otra persona o entorno**, con código determinista. Se presentan **todas** las reproducciones registradas de un resultado | Sin esto, con código no determinista, un operador podría elegir la reproducción favorable (`DISENO_ANCLA_EXTERNA.md` §9) | ¿Aprobás exigir determinismo, independencia del reproductor y presentar todas las reproducciones? |

## Acciones bloqueadas
| ID | Acción | Qué la desbloquea |
|---|---|---|
| B-1 | Commits, push, aplicar `parches/v0.5/`, versionar `corte.py` | Tu autorización. Los parches aplican limpio en HEAD y en origin, y su suite pasa en ambas copias (`evidencia/60_*`, `61_*`) |
| B-2 | Ancla externa, claves, aprobar raíces, publicar hashes o commits | R-3, R-5 |
| B-3 | Integración real | R-4 |
| B-4 | Leer bytes de datos reales (`--datos`) o reproducir `calidad_datos.json` | R-1 |
| B-5 | Calibración | R-6 |
| B-6 | Backtests, descargas, repetir T, dinero real, despliegues | Prohibidas |
| B-7 | Revisión por un tercero | Un revisor distinto del autor de todas las versiones |
| B-8 | Conservar el paquete fuera del scratchpad efímero | Descargar el ZIP |

## Preguntas, en una lista
1. R-3/A12: ¿generás una clave fuera de este equipo y firmás la declaración de T? ¿Autorizás publicar `f518ac1` y `692f2b2`?
2. R-5: ¿qué opción de ancla externa (O1–O4) y qué custodio de su clave?
3. R-6: ¿aprobás D-S1 a D-S3 y autorizás la calibración sintética de tamaño (A-S1)?
4. A8: ¿qué δ y qué pérdida máxima?
5. A9 y A14: ¿exigís REPRODUCIDO, hecho por un tercero o en otro entorno, para resultados futuros, presentando todas las reproducciones?
6. A1–A6, A10, A11, A13: ¿confirmás las recomendaciones de la tabla, o cuáles cambiás?
7. R-1, R-2: ¿dejamos `contraste_btc` como NO_VERIFICADO con cobertura documentada, o autorizás reproducirlo en solo lectura?
8. R-4 y B-1: ¿cuándo y dónde se aplican los parches y se integra el ejecutor?
