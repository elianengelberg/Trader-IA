# Garantías demostradas y riesgos residuales (v0.5)

**Clasificación de cada afirmación:**
| Etiqueta | Significado |
|---|---|
| [PRUEBA] | Verificado por una prueba ejecutada (se nombra) |
| [SIM] | Probado solo en una **simulación** (se dice cuál) |
| [INSP] | Verificado por inspección |
| [INF] | Inferido |
| [NO_VER] | No verificado |
| [EXT] | Requiere una condición externa: clave, servicio, autorización o tercero |

**Advertencias:**
- Todo lo que sigue usa datos, claves y anclas **sintéticos**, salvo las lecturas en solo lectura de los artefactos reales de T.
- Ninguna prueba es evidencia histórica ni de rentabilidad.
- Todo lo hizo el mismo agente que escribió las versiones anteriores. **No hay revisión de un tercero** (B-7).

## P1 — Evidencia: integridad ≠ autenticidad ≠ reproducción
- [PRUEBA] Exactamente un estado por evaluación; las condiciones coinciden con oráculos escritos aparte:
  - 720 combinaciones de raíz, falta, corrupción, manifiesto, declaración y presellado (`test_p1_v04`);
  - 80 de declaración, reserva y corrupción para los recibos del ancla (`test_p1_v05::test_v5_*`);
  - 210 para la reproducción (`test_p1_v05::test_reproduccion_*`).
- [PRUEBA] **La integridad local no se vuelve autenticidad:** sin una declaración de una raíz aprobada no hay VERIFICADO,
  aunque archivos y manifiestos se alteren juntos (N1). El estado real de T es INCONCLUSO (`evidencia/80_*`).
- [PRUEBA] **Un recibo solo autentica la ejecución esperada** (F2):
  - el recibo debe ser de la reserva ESPERADA, que nombra a esa ancla y no es una reproducción;
  - un recibo de otra reserva, sin reserva esperada, de otra ancla o de una reproducción no aplica;
  - un recibo de la reserva esperada con otro hash es CORRUPTO (`RECIBO_CONTRADICE`);
  - dos recibos del ancla para la misma reserva con hashes distintos también son CORRUPTO (oráculo de reproducción).
- [PRUEBA] **Una reproducción no se acepta desde un JSON no autenticado** (F3):
  - debe ser un archivo leído una vez y autenticado COMO reproducción de este original: declaración del propietario con
    `reproduccion_de`, o recibo del ancla para una reserva de reproducción con el mismo código, las mismas entradas y
    la misma semilla;
  - la declaración o el recibo del ORIGINAL no autentican una copia;
  - X21–X24 lo prueban con reproducciones ejecutadas por P4.
- [PRUEBA] Ligadura **bytes verificados ↔ sello esperado ↔ bytes reproducidos**:
  - P1 lee el resultado una vez, lo compara con el presellado de P4 (`resultado_sha256_esperado`) y con el recibo, y compara la reproducción con esos mismos bytes;
  - el ejecutor además comprueba, antes de evaluar, que el archivo, el diario, el recibo y las entradas son los de la reserva.
- [PRUEBA] Ninguna entrada hace escapar una excepción ni oculta un CORRUPTO (F4, F5, F12):
  - declaraciones mal formadas, JSON muy anidado, error de uso o error interno;
  - 300 mutaciones aleatorias del árbol, del resultado y de las declaraciones: nunca una excepción y nunca VERIFICADO sin los bytes firmados ni el árbol leído intacto (`test_fuzzing_*`).
- [PRUEBA] Ed25519 coincide con OpenSSL (`cryptography`) en todos los casos ordinarios de una prueba diferencial de 807 casos. Rechaza **siempre** las claves de orden pequeño o mixto y las R de orden pequeño, que OpenSSL acepta a veces (34 de 128 y 7 de 40). Nunca aceptamos algo que OpenSSL rechaza (`evidencia/70_*`).

**Riesgos residuales:**
- [EXT] La independencia de una raíz depende de **dónde está la clave privada**: el código no puede comprobarlo.
  Quien pueda editar el verificador puede agregar su clave a `RAICES_CONFIANZA`; el verificador mismo debe venir de una
  fuente confiable (commit publicado y revisado: B-1, B-2).
- [INF] **Un recibo prueba registro, no cálculo:** quien opera el ejecutor puede presellar un hash sin calcularlo. Lo
  detecta una reproducción independiente con código determinista (A14), o nada.
- [INF] La `reserva` esperada la aporta quien verifica. El ejecutor la toma de la ejecución que él mismo hizo y comprueba
  sus entradas. Un verificador externo debe obtenerla de su propio registro, no del árbol evaluado.
- [EXT] Sin la reserva original, el recibo de una reproducción no se acepta (no se puede comprobar el mismo código).
  Para T histórico solo vale una declaración de reproducción del propietario.

## P2 — Política
- [PRUEBA] La regla de decisión no cambió: oráculo de 86.400 combinaciones y 11 de 11 mutaciones detectadas.
- [PRUEBA] Validez, etiqueta, robustez, avance y autorización están separadas. P2 **nunca otorga** una autorización: solo
  constata una registrada y coherente (X4, X16, X26). Una reproducción no autenticada no hace válida la evidencia (F3).
- [INSP] Python no impide llamar a funciones privadas. La garantía es de interfaz, y toda salida declara su `origen`.

## P4 — Uso único y persistencia
- [PRUEBA] Un solo cálculo por reserva, también entre procesos y directorios. Una restauración, un truncamiento o la pérdida
  del ancla se detectan. Ejecutor, entorno, configuración, límite de tiempo y reproducción quedan ligados a la reserva.
- [PRUEBA] **Escrituras con fallos** (sustituto de `os`): 72 escenarios por código, con ENOSPC, EIO, escritura corta y corta seguida de ENOSPC en cada operación. Ninguno viola los invariantes I1–I7.
- [SIM] **Corte de energía:**
  - 102 escenarios por código: cada operación de E/S × 3 modelos de pérdida, más un corte después de informar la salida;
  - ninguna violación de los invariantes, comprobados por un verificador **independiente** que no importa P4;
  - un REGISTRADO informado sobrevive a un corte posterior;
  - la prueba detecta 4 de 4 mutaciones que quitan un fsync (`evidencia/53_*`);
  - no simula mkdir, el orden entre archivos dentro de un intervalo ni el hardware que miente sobre fsync.
- [PRUEBA] Eventos encadenados pero mal formados (diario o ancla): un estado terminal, nunca una excepción (F7). 120 mutaciones aleatorias del diario, del ancla y del resultado no producen violaciones.
- [PRUEBA] Un cálculo colgado se detiene con `limite_segundos` (F8); el ejecutor lo exige.
- [PRUEBA] Reproducciones (G5b): conviven solo con su original presellado; nunca lo sustituyen.
- [SIM] Ancla externa: probada contra un **doble de prueba**. Las respuestas firmadas, el desafío, los recibos, la clave
  válida (F1) y las respuestas hostiles (F6) se prueban en el cliente; el servicio real no existe.

**Supuestos:**
- S-a: un ancla fuera del control del operador. **No existe** (B-2); `AnclaArchivo` no lo cumple.
- S-b: `flock` y `link` locales.
- S-c: el código reservado no se ejecuta por fuera del mecanismo ni lanza procesos propios (el límite detiene solo su proceso).
- S-d: el núcleo libera los cerrojos de un proceso muerto.
- S-e: fsync durable.

**Riesgos residuales:**
- [EXT] Corte de energía real, NFS y varias máquinas: no probados.
- [INF] Selección entre reproducciones con código no determinista (`DISENO_ANCLA_EXTERNA.md` §9; decisión A14).

## Ejecutor aislado y registro de decisiones
- [PRUEBA] 32 pruebas de contrato y de extremo a extremo. Cubren:
  - cadena válida, con reproducción y con código no determinista;
  - evidencia local nunca auténtica;
  - archivos protegidos (por nombre del código, por hash en cualquier papel y por ruta);
  - encargos inválidos sin efectos;
  - alteraciones entre P4 y P1;
  - caídas reales en 5 puntos con reanudación idempotente (una sola decisión, un solo cálculo);
  - registro roto o incoherente;
  - fallos de escritura del registro;
  - dos ejecutores a la vez;
  - errores de P2 y autorizaciones solo constatadas;
  - límite de tiempo obligatorio;
  - línea de órdenes.
- [PRUEBA] Cada registro se comprueba con un verificador **independiente**: cadena, forma, y coherencia entre P4, P1 y P2.
- [PRUEBA] `accion_ejecutada` es siempre "NINGUNA"; el ejecutor no importa `subprocess`, `socket` ni `http`.
- [PRUEBA] Mutaciones: cada control quitado del ejecutor hace fallar al menos una prueba (`evidencia/54_*`).
- [PRUEBA de límite] **Registro local:** una entrada inyectada con la cadena recalculada y un contenido **coherente** no
  se detecta; una incoherente sí (`test_inyeccion_en_el_registro`). Detectar lo primero exige anclar la cabeza del
  registro en el ancla externa (B-2). El registro **no autoriza nada**: P2 recalcula cada decisión desde la evidencia.

## Reproducibilidad del paquete
- [PRUEBA] Toda la evidencia se regeneró con `ejecutar_todo.sh` desde una extracción limpia del ZIP de origen. Coincide
  con la guardada: semánticamente y, archivo por archivo, byte a byte o salvo tiempos, rutas y direcciones
  (`evidencia/95_*`).
- [PRUEBA] La ejecución no cambia ni agrega nada fuera de `evidencia/`: etapa 13 (`evidencia/97_*`). La primera
  reproducción (`evidencia/94_*`) encontró que sí lo hacía (`__pycache__`). Se corrigió, y la etapa se probó con un
  `.pyc` y con un byte agregados.
- [INF] Es la misma máquina y el mismo agente: no prueba la reproducción en otro entorno ni por un tercero (B-7).

## Auditoría cruzada
- [PRUEBA] X1–X26: ninguna reserva inválida, hash inconsistente, evidencia corrupta, recibo ajeno o falso, recibo de otra
  ejecución, reproducción no autenticada, ancla local ni archivo no admitido termina en una evidencia válida, y ninguna
  evidencia válida se convierte en una autorización.
- [PRUEBA] 20 de 20 mutaciones que quitan un control de la cadena se detectan (`evidencia/52_*`).
- [PRUEBA] Los artefactos congelados de T no cambian: hash y mtime antes y después (X8, `evaluar_T_real.py`).
- [EXT] **La integración real** (un ejecutor real con un ancla externa) no existe: B-2 y B-3.
