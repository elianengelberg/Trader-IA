# Informe de defectos y correcciones — P1, P2, P4 y ejecutor aislado (v0.5)

## Cómo está demostrado cada defecto
- **Antes:** la MISMA prueba se ejecuta contra la versión anterior y FALLA. Salida real de pytest en
  `evidencia/10_matriz_antes_despues/pytest_defectos_v0_*.txt`; matriz de cuatro versiones en `MATRIZ_ANTES_DESPUES.md`.
- **Además, sondas directas fuera de pytest** (`evidencia/71_*`): el comportamiento observable de v0.4 frente a v0.5.
  Por ejemplo, la declaración falsificada que v0.4 acepta, la excepción, el REPRODUCIDO desde una copia o el cálculo que
  no termina.
- **Corrección:** el cambio en `codigo/verificacion/`. Diffs completos en `diffs/`; serie versionada en `parches/v0.5/`.
- **Después:** la prueba PASA en v0.5.
- **Regresión:**
  - la suite completa de v0.4 y las de v0.3 se ejecutan **sin modificar** contra v0.5 (`evidencia/22_*` a `27_*`);
  - cada expectativa que v0.5 cambia a propósito está en `CAMBIOS_DE_API_v0.4_a_v0.5.md`.
- **Refutación:** mutaciones que quitan cada control y comprueban que alguna prueba lo detecta:
  - cadena: 20 (`evidencia/52_*`);
  - durabilidad: 4 (`53_*`);
  - ejecutor: 10 (`54_*`);
  - oráculo de P2: 11 (`31_*`).
- **Clases de defecto:** S* (corregidos en v0.3), N* (en v0.4) y **F*** (encontrados en la revisión adversarial de v0.4
  y corregidos en v0.5).

## Defectos F (revisión adversarial de v0.4, corregidos en v0.5)
| ID | Componente | Defecto | Demostración (v0.4 → v0.5) | Corrección | Refutación y límite |
|---|---|---|---|---|---|
| **F1** | confianza, P1, P4 | **Claves de orden pequeño:** con la clave neutra `01 00…00` (o `00…00`, de orden 4) la firma trivial R = neutro, s = 0 verifica cualquier mensaje (o 1 de cada 8). Una raíz o una clave fijada de ancla así permite **falsificar declaraciones y respuestas sin clave privada** | `test_P1_F1_*` (VERIFICADO con 128 declaraciones falsificadas → INCONCLUSO), `test_P4_F1_*`, sonda `71_*` («declaración FALSIFICADA aceptada») | Clave aceptable = punto del subgrupo de orden primo distinto del neutro, en `verificar_firma`, `validar_raiz` y `AnclaFirmada`. También se rechaza una R de orden pequeño | Diferencial contra `cryptography`: OpenSSL **acepta** 34 de 128 firmas con clave de orden pequeño y 7 de 40 con clave de orden mixto; v0.5 ninguna. Mutación «acepta claves de orden pequeño» detectada |
| **F2** | P1 | **Recibo de ancla no ligado a la ejecución:** v0.4 aceptaba como referencia independiente un recibo de CUALQUIER reserva; con acceso al ancla se obtiene un recibo para cualquier hash | `test_P1_F2_*` (VERIFICADO → INCONCLUSO), sonda D4 | Parámetro `reserva` (y `--reserva`). El recibo cuenta solo si su `contexto.reserva_sha256` es el de la reserva esperada, que nombra a esa ancla y no es una reproducción. Otro presellado para ella es CORRUPTO | Oráculo de 80 combinaciones; X20; 4 mutaciones de la ligadura detectadas. **Límite:** un recibo prueba registro, no cálculo |
| **F3** | P1, P2 | **REPRODUCIDO desde un JSON no autenticado:** una copia del original en memoria daba REPRODUCIDO, y P2 la tomaba como evidencia válida | `test_P1_F3_*` (3 casos), `test_P2_F3_*`, sonda D5 | La reproducción es un ARCHIVO autenticado como reproducción de ESTE original: declaración del propietario con `reproduccion_de`, o recibo para una reserva de reproducción con el mismo código, las mismas entradas y la misma semilla. P4 admite esas reservas (G5b) | Oráculo de 210 combinaciones; X21–X24 con reproducciones ejecutadas por P4; 3 mutaciones detectadas |
| **F4** | P1 | Una declaración mal formada (sustituto UTF-16 suelto, anidamiento extremo) **ocultaba un CORRUPTO** como INCONCLUSO ERROR_INTERNO | `test_P1_F4_*` (2) | `canonico` da ErrorConfianza; cada declaración se procesa por separado; un error interno ya no corta la búsqueda de contradicciones | Fuzzing de 300 casos con declaraciones basura |
| **F5** | P1, confianza | Un JSON muy anidado lanzaba RecursionError en `evaluar_archivo` («nunca lanza»). Por la línea de órdenes terminaba con la **salida 1, la de CORRUPTO** | `test_P1_F5_*` (2), sonda `sonda_anidado` | JSON_INVALIDO (resultado) o FORMATO (declaración). La línea de órdenes da INCONCLUSO (3) ante cualquier error inesperado | — |
| **F6** | P4 | Una respuesta hostil del ancla (sustituto suelto, anidamiento) hacía escapar UnicodeEncodeError o RecursionError de `ejecutar`: **ninguna salida** | `test_P4_F6_*` (2), sonda D3-P4 | ANCLA_NO_AUTENTICA (encapsulado en el cliente y en `canonico`) | — |
| **F7** | P4 | Eventos **encadenados pero mal formados** en el diario o en el ancla local (sin `evento`, `datos` que no es un objeto, PRESELLADO sin hash) hacían escapar KeyError, TypeError o AttributeError | `test_P4_F7_*` (5), sonda `sonda_diario` | Esquema estricto por tipo de evento: INCONSISTENTE | 120 mutaciones aleatorias del diario, del ancla y del resultado con un verificador de invariantes independiente; mutación «no valida el esquema» detectada |
| **F8** | P4 | **Sin límite de tiempo:** un cálculo colgado bloqueaba la reserva para siempre | `test_P4_F8_*`, sonda D6 («sin respuesta tras 8 s») | `limite_segundos` (parte de la reserva): FALLO_CALCULO, y la siguiente llamada da REVISION_HUMANA. El ejecutor lo exige | **Límite:** detiene solo el proceso de cálculo, no los procesos que lance el código reservado (S-c) |
| **F10** | P4 | El directorio de trabajo del cálculo quedaba **huérfano** si el padre moría durante el cálculo | `test_P4_F10_*`: falla en v0.3 y v0.4; **pasa en v0.2**, que no usaba ese directorio (lo introdujo v0.3, con el entorno aislado) | El proceso de cálculo borra su directorio al terminar | — |
| **F11** | confianza | `_utc` aceptaba cinco formas no canónicas de fecha (`2026-10-20Z`, `20261020T000000Z`, semanas ISO, …) | `test_P1_F11_*` (4) | Una sola forma | — |
| **F12** | P1 | En `evaluar_reproduccion`, un **error de uso** (tolerancia inválida) devolvía INCONCLUSO **antes** de evaluar el original, ocultando un CORRUPTO | `test_P1_F12_*` | Se evalúa primero el original | — |
| **F14** | P4 | `ejecutar` aceptaba una semilla booleana, flotante o de texto, un nombre vacío, un punto de entrada no válido o archivos no textuales. Una reserva con un flotante **no se puede ligar en P1** | `test_P4_F14_*` (6) | ValueError antes de tocar ningún estado | — |

(F9 y F13 no se usan: F9 fue una capacidad nueva, las reservas de reproducción, y F13 un defecto cosmético del
ejecutor de evidencia; ambos están abajo.)

**Capacidades nuevas de v0.5, que no son defectos:**
- reservas de reproducción en P4 (G5b);
- `leer` con la reserva;
- el **ejecutor aislado** con su registro de decisiones;
- el estado real de T en seis dimensiones separadas (`trazabilidad_T/evaluar_T_real.py`);
- la cobertura de `contraste_btc` explicada con metadatos.

**Hallazgos durante esta ronda, corregidos antes de entregar** (no llegaron a ninguna entrega):
| Hallazgo | Cómo apareció | Corrección |
|---|---|---|
| El límite de tiempo ponía el cálculo en **su propia sesión**: matar al padre ya no lo mataba (quedaron dos procesos colgados de las sondas) | Inspección de procesos tras las sondas | Se volvió al grupo del padre; el límite mata solo el proceso de cálculo. Los dos procesos se detuvieron |
| El ejecutor rechazaba por **nombre** el script del árbol sintético, que P4 solo lee como dato | Pruebas de integración | La protección por nombre vale solo para `codigo`; la de hash, para todo papel |
| El ejecutor usaba **un único** directorio de P4 por directorio de trabajo, así que dos cálculos distintos no podían convivir | Pruebas de integración | Directorio por huella del CÁLCULO (solo los campos que P4 reserva) |
| Una entrada **inyectada e incoherente** en el registro (cadena recalculada) se aceptaba | Revisión adversarial del ejecutor | Coherencia P4 ↔ P1 ↔ P2 por entrada. **Límite:** una inyección coherente no se detecta localmente |
| F13: el paso 5 de `ejecutar_todo.sh` de v0.4 imprimía líneas vacías | FX-0 (reproducción limpia de v0.4) | Se imprime la última línea de cada archivo de mutaciones |
| `ejecutar_todo.sh` **modificaba el paquete**: dejaba `__pycache__` de `confianza` y `uso_unico` en `codigo/verificacion/` y `referencia/v0_4/`. El hijo de `sonda_p4.py` se lanzaba con `-I` sin `-B`, y `-I` ignora `PYTHONDONTWRITEBYTECODE`. No afectaba a ningún resultado | FX-4: la reproducción completa desde la extracción limpia del primer ZIP (ZIP A) comparó cada archivo de la extracción con su SHA256SUMS (`evidencia/94_*`) | `-B` en ese hijo. Nueva etapa 13 de `ejecutar_todo.sh` (`evidencia/97_*`): falla si cambia un byte o aparece un archivo fuera de `evidencia/`. Se probó con un `.pyc` y con un byte agregados (detecta los dos). Con la corrección, la reproducción se **repitió completa** desde un ZIP nuevo (`evidencia/95_*`) |
| `diffs/pruebas_v0_4_a_v0_5.diff` del ZIP A estaba **incompleto**: no incluía `pruebas/estado_repositorio.sh`, que se creó después de generar el diff | FX-4: al regenerar el diff por el cambio de `sonda_p4.py` | Diff regenerado con el mismo comando. Los dos diffs de código se regeneraron y son idénticos a los guardados. Los parches 0001–0007 no incluyen ninguno de los dos archivos |

**Correcciones de las PRUEBAS** (no son defectos del producto, pero cambian lo que se prueba):
| Cambio | Motivo |
|---|---|
| Oráculo de reproducción: faltaba el caso de **dos recibos de la misma reserva con hashes distintos** | P1 lo daba (correctamente) por CORRUPTO, y el oráculo esperaba INCONCLUSO. Se corrigió el oráculo, no el código |
| Invariante del fuzzing de P4: «resultado.json igual al presellado» | Un tercero puede alterar el archivo; lo que P4 nunca debe hacer es darlo por REGISTRADO. Se reformuló así, y se agregó «REGISTRADO con otro hash» |
| La prueba de corte de energía dejaba sobrevivir 1 de 4 mutaciones (falta de fsync del directorio tras `replace`) | Solo cortaba durante la ejecución. Se agregó un corte **después** de informar la salida y la invariante de durabilidad de lo informado: 4 de 4 |
| X20 no ejercitaba la rama de contradicción (los dos resultados eran iguales) | Ahora usa resultados distintos y lo exige |
| Prueba de concurrencia del ejecutor: podía bloquearse si el hijo moría antes de la pausa | Espera la FIFO sin bloqueo y comprueba que el hijo sigue vivo |
| Prueba diferencial: solo 3 de los 8 puntos de torsión | Se generan los 8 (múltiplos de q de puntos aleatorios) |
| Seis pruebas de v0.4 actualizadas a la API de v0.5, más tres reglas nuevas de portado de v0.3 | `CAMBIOS_DE_API_v0.4_a_v0.5.md`; sin modificar fallan solo donde v0.5 cambió una expectativa a propósito (`evidencia/27_*`) |

## Defectos no corregibles en este alcance
| Defecto o límite | Por qué no se corrige aquí | Qué lo resolvería |
|---|---|---|
| Sin raíz de confianza, nada es VERIFICADO (incluido T) | No se puede crear ni aprobar una raíz en este equipo (orden) | Tu firma fuera de este equipo (R-3) |
| Un recibo prueba registro, no cálculo | Es la naturaleza del ancla | Reproducción independiente (A14) |
| Inyección coherente en el registro local | Sin firma ni ancla, un archivo local se puede reescribir | Anclar la cabeza del registro en el ancla externa (B-2) |
| Código reservado ejecutado por fuera de P4 | No es un sandbox | Datos cifrados con una clave que solo entrega el ancla (diseño) |
| Corte de energía real, NFS, varias máquinas | Solo simulable aquí | Pruebas en el entorno real |

---

# Defectos de rondas anteriores (sin cambios en v0.5; siguen corregidos)

## P1 — Verificador de evidencia
| ID | Defecto | Prueba (antes → después) | Corrección | Refutación y límite |
|---|---|---|---|---|
| S1 | Aceptaba claves inesperadas | `test_P1_S1_*` (6): v0.2 falla → v0.3 y v0.4 pasan | Esquema estricto | — |
| S2 | Aceptaba símbolos o campos faltantes | `test_P1_S2_*` (8) | Ídem | v0.2 ya detectaba 1 de los 8 casos |
| S3 | Falsificación coherente de script y resultado | `test_P1_S3_*` (2) | Manifiestos y hash presellado | En v0.4 los manifiestos son referencias **locales**: ver N1 |
| S4 | No contrastaba `codigo_sha256` con el CODIGO del script | `test_P1_S4_*` | ast sobre el script verificado | — |
| S5 | `comparar` ignoraba campos | `test_P1_S5_*` | `comparar_completo` | — |
| S6 | REPRODUCIDO sin integridad previa | `test_P1_S6_*` | Exige VERIFICADO | — |
| S7 | No comprobaba las tablas ni los datos del corte | `test_P1_S7_*` (7, productor real con fuente simulada) | Reconstrucción de las tablas | — |
| S8 | No contrastaba el inicio con el prerregistro | `test_P1_S8_*` (3) | Rama A literal y rama B derivada | — |
| **N1** | **Autenticidad:** v0.3 daba VERIFICADO aunque el archivo, el script y el manifiesto se alteraran **juntos**, porque los manifiestos son locales | `test_P1_N1_*` (5): v0.3 da VERIFICADO → v0.4 da INCONCLUSO (`SIN_REFERENCIA_INDEPENDIENTE`) o, con una declaración firmada del original, CORRUPTO (`HASH_REFERENCIA`) | `confianza.py` (Ed25519, declaraciones firmadas). VERIFICADO exige una declaración de una **raíz aprobada** (`RAICES_CONFIANZA`, vacío); ninguna API pública acepta raíces | Clave intrusa, emisor no aprobado, firma alterada o maleable, raíz mal formada, recibo falso (X14) y recibo de otra reserva: todos rechazados. Interoperabilidad con OpenSSL y cryptography. **Límite:** el código no puede comprobar dónde está la clave privada |
| **N2** | **Estados imprecisos:** v0.3 daba RECHAZADO (salida 1) tanto a lo inválido como a lo no verificable; una falta podía ocultar una corrupción; una reproducción inválida marcaba CORRUPTO al original; un manifiesto ilegible rechazaba el resultado | `test_P1_N2_*` (4) | Cinco estados con condiciones disjuntas (docstring, `CODIGOS_CORRUPTO` / `CODIGOS_INCONCLUSO`). Las faltas se difieren hasta terminar las comprobaciones independientes | Oráculo de 720 combinaciones. Prueba estática: cada código tiene una sola clase |
| **N3** | **Excepciones no controladas:** un script con `CODIGO` no literal (ValueError), un CSV del corte no UTF-8 (UnicodeDecodeError) o una rama B sin `RESERVADO_FIN` (StopIteration) terminaban con un rastro y salida 1, igual que un rechazo | `test_P1_N3_*` (3) | NO_DERIVABLE (INCONCLUSO), TIPO (CORRUPTO), y defensa `ERROR_INTERNO` en `evaluar` | — |
| **N4** | **Doble lectura:** `reproducir` verificaba el archivo y lo **releía** para comparar; un cambio entre ambas lecturas comparaba otros bytes | `test_P1_N4_*` | Una sola lectura; se comparan los bytes evaluados | [INSP] Además, cada archivo del árbol se lee una vez (`_Arbol`) |
| M1 | *(requisito, no defecto)* `calidad_datos.json` y `contraste_btc_diario_vs_horario` | `test_p1_v04::test_calidad_datos_real_*`, X18 | INCONCLUSO `PROCEDENCIA_NO_VERIFICADA`; productor localizado (`contraste_btc/`) | La procedencia sigue NO_VERIFICADA (B-4) |

**Hallazgos internos de esta ronda, corregidos antes de entregar:**
- `confianza.validar_raiz` daba FORMATO en lugar de RAIZ_INVALIDA. Lo detectó `test_raices_mal_formadas_se_rechazan`; se corrigió el código.
- `{"decision": <texto de T>}` sin otras claves pasa a ser ESQUEMA (CORRUPTO), no TIPO_NO_ADMITIDO.

## P2 — Política de decisiones
| ID | Defecto | Prueba (antes → después) | Corrección | Refutación y límite |
|---|---|---|---|---|
| S1–S5 | Etiqueta sin evidencia; valor por defecto silencioso de R; autorización constante; fechas como texto; hash sin validar | `test_P2_S*` (14): v0.2 falla (su API era otra; las sondas, 7 de 7, muestran el defecto) → v0.3 y v0.4 pasan | v0.3 | — |
| **N1** | **Evidencia fabricada:** `aplicar(evidencia("VERIFICADO", …))` daba CANDIDATA **sin pasar por P1** | `test_P2_N1_*`: v0.3 da CANDIDATA → en v0.4 no hay atajo | Evidencia **sellada** (`_Evidencia`); la única entrada pública es `desde_resultado`, que pasa por P1 | X16 (dict, imitación de la clase, declaración que «autoriza»). **Límite:** las funciones privadas se pueden llamar; la salida declara su `origen` |
| **N2** | **Doble lectura:** la fecha de la ventana se leía de nuevo del archivo **después** de verificarlo | `test_P2_N2_*` (sustitución entre lecturas) | La fecha sale del informe de P1 | — |
| **N3** | **Registros inyectables:** `desde_resultado(..., autorizaciones=…, etapas=…)` aceptaba registros de cualquier llamador | `test_P2_N3_*` | Solo valen los registros del módulo (vacíos); no hay `**kw` | X16 |
| **N4** | Una evaluación de R1 o R3 **no decía sobre qué resultado** se hizo | `test_P2_N4_*` | Registro `{estado, definicion, resultado_sha256}`; debe coincidir con la evidencia | — |
| **N5** | **Registros incoherentes aceptados:** una definición registrada con otra clave; una autorización para una etapa no definida | `test_P2_N5_*` (2) | `_validar_registros` (dependencias) | — |

**Oráculo:**
- La implementación coincide con un oráculo independiente en 86.400 combinaciones.
- Mutaciones detectadas: 11 de 11.
- **Hallazgo:** en la primera corrida sobrevivía la mutación «post hoc con > en vez de ≥». El espacio no tenía el caso límite. Se agregaron aprobaciones exactamente en el día de inicio y con zona horaria, y la mutación pasó a detectarse.

## P4 — Reserva, ancla e integridad
| ID | Defecto | Prueba (antes → después) | Corrección | Refutación y límite |
|---|---|---|---|---|
| S1–S5 | Doble cálculo (inicio idempotente), reparación silenciosa del ancla, ejecutor no ligado, entorno heredado, no determinismo no detectado | `test_P4_S*` (8): v0.2 falla → v0.3 y v0.4 pasan | v0.3 | Pausas deterministas por FIFO |
| **N1** | **Escritura corta ignorada:** `os.write` puede escribir menos bytes; v0.3 seguía hasta REGISTRADO con el diario ilegible, y una escritura corta en el ancla **perdía el presellado** del ancla | `test_P4_N1_*` y la sistemática: v0.3 viola invariantes en 57 de 60 escenarios | `_escribir_todo`; toda escritura usa os.* | — |
| **N2** | **Disco lleno o error de E/S:** la excepción escapaba sin salida | `test_P4_N2_*` (2) y la sistemática (72 escenarios por código en v0.4, 0 violaciones) | FALLO_ALMACENAMIENTO (no terminal); la siguiente llamada concilia | Con código no determinista, un resultado presellado que no llegó a escribirse termina en CONFLICTO: es un costo de disponibilidad, no un riesgo de seguridad |
| **N3** | **E/S del ancla local:** la excepción escapaba | `test_P4_N3_*` | ANCLA_NO_DISPONIBLE, sin estado local | — |
| **N4** | **Entrada ilegible:** la excepción escapaba | `test_P4_N4_*` | RECHAZADO antes de tocar estado | — |
| N5 | *(documento)* El dictamen de v0.3 decía «toda salida lleva su reserva»; OCUPADO no la lleva | [INSP] | Documentado con precisión en `Salida` | — |
| — | *(capacidad nueva)* Cliente `AnclaFirmada`, recibos y contrato | `test_ancla_firmada`, `test_contrato_ancla` (C1–C8 en las dos anclas) | `uso_unico.py` | El servicio externo **no existe** (B-2) |

## Auditoría cruzada
- **Pruebas:** X1–X18 (20 pruebas). Ver `GARANTIAS_Y_RIESGOS.md`.
- **Hallazgo:** con la mutación «P4 no rechaza una reserva cuyo cálculo ya inició en el ancla» ninguna prueba fallaba. X6 borraba el estado con entradas **cambiadas**, y el rechazo venía de otro control (el conflicto de nombre). X6 se reforzó para borrar el estado con las **mismas** entradas; la mutación ahora se detecta.

## Correcciones de la infraestructura de pruebas
No son defectos del producto, pero quedan registradas porque cambian lo que se prueba.

| Cambio | Motivo |
|---|---|
| El doble de prueba `estado_falso_tras_firma` alteraba un valor que ya era 0 | La prueba no alteraba nada. Ahora invierte `reserva` |
| La carrera C6 usaba `multiprocessing.Manager` | El socket UNIX superaba el límite de longitud con el TMPDIR de la sesión. Ahora usa una barrera heredada por `fork` |
| Suites de P1 de v0.3 portadas | 46 reglas de reemplazo exacto (53 apariciones; cada regla exige su número de apariciones): 29 R (renombre) y 17 S (cambio deliberado, con el defecto que lo motiva), en `evidencia/20_*`. Diff completo en `evidencia/21_*`. Ninguna regla relaja un rechazo |
| Suite de P2 de v0.3 no portada | Prueba la API pública eliminada por N1 y N3. Su cobertura queda subsumida por el oráculo (86.400 ⊇ 3.360) y por `test_P2_S*`. Sin modificar falla por la API (`evidencia/24_*`) |
| Cruzada de v0.3 | Sin modificar, falla por la API (`evidencia/26_*`). Sus X1–X9 están reescritas en `test_cruzada_v04.py` |
