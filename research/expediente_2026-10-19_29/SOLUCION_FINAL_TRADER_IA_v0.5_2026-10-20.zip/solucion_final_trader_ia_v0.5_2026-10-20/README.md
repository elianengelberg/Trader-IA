# Trader-IA — Solución final v0.5 de P1, P2, P4 y del ejecutor aislado (2026-10-20)

**Qué es:**
- La revisión adversarial de v0.4: 12 defectos nuevos (F1–F14), cada uno demostrado en v0.4 y corregido en v0.5.
- La integración técnica **aislada** P4 → P1 → P2 con un registro de decisiones.
- El expediente de todo lo que queda pendiente.

Todo se hizo en una copia aislada.

**Qué no es:**
- **No** está aplicado al repositorio, aprobado ni integrado en ningún ejecutor real.
- El estado de git del repositorio no cambió: el SHA-256 de `git status --porcelain --ignored` es `87b9585d…` antes y después (`evidencia/90_*`, `91_*`, `99_*`).
- T no se ejecutó, sus resultados congelados están intactos (`evidencia/98_*`, `80_*`) y **T sigue INCONCLUSO**.

## Resultado por componente
| Componente | Qué cambió en v0.5 | Evidencia principal |
|---|---|---|
| `confianza.py` | Rechaza claves y R de orden pequeño o mixto (F1). Todo documento mal formado es un error controlado (F4–F6). Una sola forma de fecha (F11) | Prueba diferencial de 807 casos contra OpenSSL (`cryptography`); sondas de v0.4 vs v0.5 |
| **P1** | Un recibo del ancla solo autentica la **reserva esperada** (F2). REPRODUCIDO exige una reproducción **en archivo y autenticada** (F3). Nada oculta un CORRUPTO (F4, F12) ni termina en excepción (F5) | Oráculos de 80 y 210 combinaciones (más el de 720 de v0.4); 300 mutaciones aleatorias; matriz F* |
| **P2** | La reproducción es un archivo que P1 autentica (F3). La regla de decisión no cambió | Oráculo de 86.400 combinaciones; 11 de 11 mutaciones |
| **P4** | Esquemas estrictos del diario y del ancla (F7), clave del ancla válida (F1), respuestas hostiles (F6), **límite de tiempo** (F8), **reservas de reproducción**, argumentos validados (F14), sin directorios huérfanos (F10) | 72 fallos de escritura por código; **corte de energía simulado**: 102 escenarios por código, 4 de 4 mutaciones de durabilidad detectadas; 120 mutaciones aleatorias del estado con un verificador de invariantes independiente |
| **Ejecutor aislado** (nuevo) | P4 → P1 → P2 con ligadura previa, registro de decisiones encadenado e idempotente, archivos protegidos (el script de T, por hash), `accion_ejecutada = "NINGUNA"` | 32 pruebas de contrato y de extremo a extremo (caídas en 5 puntos, registro roto o incoherente, fallos de escritura, concurrencia); mutaciones del ejecutor |
| Cruzada | X1–X26 | 20 de 20 mutaciones de la cadena detectadas |

**Estado real de T** (`evidencia/80_estado_real_de_T.json`), en seis dimensiones separadas:
- integridad de archivos: COMPLETA;
- autenticidad del origen: **NO_CONTRASTADA**;
- reproducción: NO_INTENTADA;
- suficiencia de datos: NO_VERIFICADA;
- cumplimiento metodológico: decisión coherente con la regla congelada;
- autorización: NO_OTORGADA.

**P1 da INCONCLUSO** (`SIN_REFERENCIA_INDEPENDIENTE`) y P2 da NO_CANDIDATA. Solo tu firma, con una clave **fuera** de este
equipo, puede cambiar la autenticidad (`EXPEDIENTE_DE_DECISIONES_PENDIENTES.md`, R-3).

## Documentos
| Archivo | Contenido |
|---|---|
| `INFORME_DEFECTOS_Y_CORRECCIONES.md` | Cada defecto (F*, N*, S*): demostración, corrección, refutación y límite; hallazgos de esta ronda; lo que no se puede corregir aquí |
| `GARANTIAS_Y_RIESGOS.md` | Qué está demostrado, qué solo simulado y qué requiere condiciones externas |
| `ESTADO_POR_MODULO_Y_ETAPA.md` | Implementado, probado en aislamiento, integrado, reproducido y bloqueado, por módulo |
| `EXPEDIENTE_DE_DECISIONES_PENDIENTES.md` | R-1 a R-6, A1–A14 y B-1 a B-8: si se resuelve, qué se hizo, recomendación, alternativas y **la pregunta concreta** |
| `CAMBIOS_DE_API_v0.4_a_v0.5.md` | Cada cambio de API y su defecto; las pruebas anteriores que cambian |
| `DISENO_ANCLA_EXTERNA.md` | Amenazas, garantías G1–G12 (G5b reproducciones, G7b recibos ligados), protocolo, opciones y riesgos |
| `TRAZABILIDAD_T_Y_CONTRASTE_BTC.md` | Trazabilidad de T, procedencia y cobertura de `contraste_btc`, estado de T por dimensiones |
| `REGISTRO_ACCIONES.jsonl` | Registro encadenado de las acciones de esta ronda y de las que no se ejecutaron por falta de autorización |

## Carpetas
| Carpeta | Contenido |
|---|---|
| `codigo/verificacion/` | `confianza.py`, `verificar_reproduccion_T.py` (P1), `politica_avance_T.py` (P2), `uso_unico.py` (P4), `ejecutor_aislado.py` |
| `diffs/` | Diffs completos: código de v0.4 a v0.5 y de v0.3 a v0.5; pruebas de v0.4 a v0.5 |
| `parches/v0.5/` | Serie 0001–0007 y `TODO_v0.5.patch`, solo archivos nuevos. Aplicada y probada sobre HEAD y origin **exportados**; **no aplicada** al repositorio |
| `pruebas/` | p1, p2, p4, cruzada, integracion (ejecutor). Defectos que corren contra v0.2–v0.5. Mutaciones. Regresión portada. Sondas de v0.4. Matriz |
| `trazabilidad_T/` | Trazabilidad, declaración a firmar, instrucciones de firma y `evaluar_T_real.py` |
| `contraste_btc/`, `tablas/` | Procedencia de `calidad_datos.json`; tabla de decisión de P2 (86.400 filas) |
| `referencia/` | Código exacto de v0.2, v0.3 y v0.4, para las pruebas «antes» |
| `00_preservado/` | Los ZIP de las cinco entregas anteriores, incluida la v0.4, sin modificar |
| `evidencia/` | Salidas reales de todas las ejecuciones (índice abajo) |

## Reproducir desde cero
```
unzip SOLUCION_FINAL_TRADER_IA_v0.5_2026-10-20.zip && cd solucion_final_trader_ia_v0.5_2026-10-20
sha256sum -c SHA256SUMS.txt
REPO=<raíz del repositorio> PY=<python 3.11 con pytest> [PY_CRYPTOGRAPHY=<python con cryptography>] bash ejecutar_todo.sh
```
Notas:
- `ejecutar_todo.sh` extrae él mismo los paquetes v0.3 y v0.4 desde `00_preservado/` y verifica sus SHA256SUMS.
- Comprueba que el estado de git no cambie; no ejecuta T, no lee bytes de datos de mercado y no usa la red.
- Tarda alrededor de una hora; la mayor parte son las mutaciones.
- En esta sesión, `PY` es `/home/user/Trader-IA/research/hcarry_next/.venv/bin/python` y la prueba diferencial usa `python3.12`.
- `evidencia/95_*` documenta la reproducción completa hecha desde una extracción limpia del ZIP de origen, una
  construcción anterior de este mismo paquete cuyo SHA-256 figura en el 95:
  - la evidencia de este paquete **es** la de esa reproducción;
  - `python3 -I verificar_reproduccion_limpia.py <ZIP de origen> <extracción reproducida> <este paquete>` comprueba
    que todo lo que no es evidencia es idéntico al del ZIP de origen y compara toda la evidencia;
  - después del ZIP de origen solo cambiaron `evidencia/95_*`, `REGISTRO_ACCIONES.jsonl` y `SHA256SUMS.txt`.
- `evidencia/94_*` es la primera reproducción limpia (desde el ZIP A). Encontró que la ejecución dejaba `__pycache__`
  en el paquete. Se corrigió y se repitió todo (`INFORME_DEFECTOS_Y_CORRECCIONES.md`).
- `evidencia/97_*` (etapa 13) comprueba que la ejecución no cambió el paquete fuera de `evidencia/`.

## Índice de `evidencia/`
| Archivo | Contenido |
|---|---|
| `00_*` | Reproducción limpia de v0.4 (FX-0), estado de git inicial, preservación de las entregas |
| `01_*` | Paquetes previos extraídos y verificados |
| `02_*` a `04_*` | Investigación de `contraste_btc` y cronología de T (de v0.4) |
| `05_*` | Trazabilidad regenerada |
| `06_*` | Cobertura de `contraste_btc` (solo manifiestos) |
| `10_*` | Matriz antes/después de v0.2 a v0.5 |
| `11_*` | Suite completa |
| `12_*` | ruff |
| `13_*` | Estabilidad (3 corridas) |
| `14_corte_energia/` | Corte de energía por escenario |
| `20_*` a `27_*` | Regresiones |
| `31_*`, `32_*` | P2 |
| `40_*`, `41_*` | Sondas de v0.2 y paquetes previos intactos |
| `52_*` a `54_*` | Mutaciones de cadena, durabilidad y ejecutor |
| `60_*`, `61_*` | Parches |
| `70_*` | Ed25519 diferencial |
| `71_*` | Sondas de v0.4 vs v0.5 |
| `80_*` | Estado real de T |
| `90_*`, `91_*`, `98_*`, `99_*` | Integridad final y estado de git (huella fuerte: `pruebas/estado_repositorio.sh`) |
| `94_*` | Primera reproducción limpia (ZIP A): encontró el `__pycache__` |
| `95_*` | Reproducción completa desde el ZIP de origen, comparada archivo por archivo |
| `97_*` | El paquete no cambió durante la ejecución (etapa 13) |

## Lo que NO se hizo
- No se hicieron commits, push, despliegues ni integraciones. No se aplicó ningún parche al repositorio.
- No se usó dinero real, no se descargaron datos, no se leyeron bytes de datos de mercado y no se hicieron backtests.
- No se repitió T, no se invocó `fuera_de_muestra_T.py` ni se tocó su cerrojo, y no se ejecutó la calibración (A-S1).
- No se publicaron hashes. No se creó, aprobó ni usó ninguna clave real: todas son sintéticas y están en las fábricas de prueba.
- No se eligió ninguna definición, etapa, umbral, δ ni autorización.
- **Revisión por un tercero: no realizada** (B-7).
