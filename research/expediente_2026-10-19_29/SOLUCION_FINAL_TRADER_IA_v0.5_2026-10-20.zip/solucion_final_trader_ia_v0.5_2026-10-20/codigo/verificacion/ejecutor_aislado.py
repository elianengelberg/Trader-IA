"""Ejecutor AISLADO de la cadena P4 → P1 → P2, v0.5. PROPUESTA: no está integrado en ``papel/corte.py`` ni en
``fuera_de_muestra_T.py``, no ejecuta T, no opera y no autoriza nada. Solo biblioteca estándar.

Qué hace, en este orden, y nada más:
1. Valida el ENCARGO y rechaza, antes de tocar ningún estado, uno que use un archivo protegido: cualquier entrada
   cuyo SHA-256 sea el del script congelado de T o que esté bajo una ruta protegida, y un ``codigo`` (lo que P4
   ejecuta) llamado ``fuera_de_muestra_T.py`` o ``corte.py``.
2. P4 (``uso_unico.ejecutar``): calcula una sola vez el código reservado, con un límite de tiempo OBLIGATORIO, en
   ``DIR_TRABAJO/p4/<huella del cálculo>/`` (la huella cubre solo lo que P4 reserva: ver ``dir_calculo``).
3. LIGA lo que P4 produjo antes de evaluarlo: la reserva del diario es la de la salida; sus archivos son los del
   encargo; el SHA-256 de ``resultado.json`` es el presellado del diario y el informado; el recibo guardado es el
   informado. Cualquier diferencia: INCONSISTENTE y no se evalúa.
4. Si el encargo lo pide, REPRODUCE con otra reserva de P4 (``reproduccion_de`` = presellado del original), en su
   propio directorio, y la liga igual.
5. P2 (que pasa por P1) con la reserva (para que el recibo del ancla cuente), el sello esperado (presellado), los
   recibos y las declaraciones que aporte el llamador. P1 decide si la evidencia es auténtica: una evidencia local
   NUNCA se vuelve auténtica sola (sin una raíz aprobada en P1 el resultado es INCONCLUSO) y una reproducción solo
   cuenta con su propio recibo o declaración. P2 nunca otorga autorizaciones.
6. Registra el resultado en ``REGISTRO_DECISIONES.jsonl``: encadenado (cada línea lleva el SHA-256 de la anterior),
   escrito completo, con fsync del archivo y del directorio, bajo cerrojo. Una vez por contenido: repetir el mismo
   encargo sin cambios no añade nada (reanudación idempotente); si algo cambió (p. ej. una declaración nueva), se
   añade otra entrada que remite a la anterior. Nunca se reescribe una entrada: una cola desgarrada por una caída se
   descarta dejando constancia (su hash y su texto). ``accion_ejecutada`` es siempre "NINGUNA".

Estados del ejecutor: DECIDIDO (P4, P1 y P2 corrieron; la validez y la decisión son las de P2), SIN_RESULTADO (P4 no
dio un resultado registrado: su estado se informa; la siguiente llamada lo retoma), INCONSISTENTE (lo producido no
está ligado), ERROR_POLITICA (P2 rechazó la consulta), RECHAZADO_PROTEGIDO, ENCARGO_INVALIDO (sin registro: no hay
encargo que identificar), OCUPADO (otro ejecutor tiene el registro), REGISTRO_INCONSISTENTE (la cadena del registro
está rota: no se ejecuta nada) y FALLO_ALMACENAMIENTO_REGISTRO (no se pudo escribir la entrada: se reintenta en la
siguiente llamada, que no recalcula).

Uso: python3 -I ejecutor_aislado.py ENCARGO.json DIR_TRABAJO --ancla-local ANCLA.jsonl [--declaracion RUTA]...
        [--protegida RUTA]...
Salida: 0 DECIDIDO · 1 INCONSISTENTE o REGISTRO_INCONSISTENTE · 2 uso · 3 cualquier otro estado.
El ancla de la línea de órdenes es LOCAL (AnclaArchivo): no emite recibos, así que P1 dará INCONCLUSO. Un ancla
externa (AnclaFirmada) solo se puede pasar desde Python: el servicio no existe (DISENO_ANCLA_EXTERNA.md)."""
from __future__ import annotations

import datetime as dt
import errno
import fcntl
import hashlib
import json
import math
import os
import sys
from collections.abc import Callable
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import confianza as C  # noqa: E402
import politica_avance_T as PA  # noqa: E402
import uso_unico as U  # noqa: E402

V = PA.V
VERSION = "ejecutor_aislado v0.5"
REGISTRO = "REGISTRO_DECISIONES.jsonl"
ACCION = "NINGUNA"
SALIDAS = {"DECIDIDO": 0, "INCONSISTENTE": 1, "REGISTRO_INCONSISTENTE": 1}
# Nunca se usan como entrada, en ningún papel (el código reservado podría ejecutar cualquier entrada).
PROTEGIDOS_SHA256 = {
    "941b6e11f6566319b93614ee671b184d60c7b5fbc64a3931a6ff2c8da17fe0fa": "experimentos/fuera_de_muestra_T.py (T)",
}
NOMBRES_PROTEGIDOS = frozenset({"fuera_de_muestra_T.py", "corte.py"})  # como ``codigo``, aunque su contenido cambie
CAMPOS_ENCARGO = {"experimento": str, "archivos": dict, "semilla": int, "limite_segundos": int, "raiz_t": str}
OPCIONALES = {"punto_entrada": "calcular", "reproducir": False, "tolerancia": 0.0, "r1": "NO_DEFINIDO",
              "r3": "NO_DEFINIDO", "etapa": None, "autorizacion": None, "verificar_determinismo": False}
TIPOS_ENTRADA = ("DECIDIDO", "SIN_RESULTADO", "INCONSISTENTE", "ERROR_POLITICA", "RECHAZADO_PROTEGIDO",
                 "COLA_ROTA_DESCARTADA")


def _nada(_punto: str) -> None:
    return None


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _ahora() -> str:
    return dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class EncargoInvalido(ValueError):
    pass


def validar_encargo(encargo: object) -> dict:
    """Encargo completo (con opcionales) o EncargoInvalido. Sin floats salvo la tolerancia (va solo a P1)."""
    if not isinstance(encargo, dict):
        raise EncargoInvalido("el encargo debe ser un objeto")
    desconocidas = set(encargo) - set(CAMPOS_ENCARGO) - set(OPCIONALES)
    if desconocidas:
        raise EncargoInvalido(f"claves desconocidas: {sorted(desconocidas)}")
    for k, tipo in CAMPOS_ENCARGO.items():
        if k not in encargo or not isinstance(encargo[k], tipo) or isinstance(encargo[k], bool):
            raise EncargoInvalido(f"{k}: obligatorio, de tipo {tipo.__name__}")
    e = OPCIONALES | encargo
    if not e["experimento"] or not e["raiz_t"] or e["limite_segundos"] < 1:
        raise EncargoInvalido("experimento y raiz_t no vacíos; limite_segundos ≥ 1 (obligatorio en este ejecutor)")
    if "codigo" not in e["archivos"] or not all(isinstance(k, str) and k and isinstance(v, str) and v
                                                for k, v in e["archivos"].items()):
        raise EncargoInvalido("archivos: {nombre: ruta} con 'codigo'")
    if not isinstance(e["reproducir"], bool) or not isinstance(e["verificar_determinismo"], bool):
        raise EncargoInvalido("reproducir y verificar_determinismo: true o false")
    t = e["tolerancia"]
    if isinstance(t, bool) or not isinstance(t, (int, float)) or not math.isfinite(t) or t < 0:
        raise EncargoInvalido("tolerancia: número finito ≥ 0")
    for k in ("etapa", "autorizacion"):
        if e[k] is not None and not isinstance(e[k], str):
            raise EncargoInvalido(f"{k}: texto o null")
    try:
        C.canonico({k: v for k, v in e.items() if k != "tolerancia"})
    except C.ErrorConfianza as x:
        raise EncargoInvalido(f"el encargo no admite forma canónica: {x.detalle}") from None
    return e


def huella_encargo(e: dict) -> str:
    return _sha(json.dumps(e, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())


CAMPOS_CALCULO = ("experimento", "archivos", "semilla", "punto_entrada", "limite_segundos", "verificar_determinismo")


def dir_calculo(d: Path, e: dict) -> Path:
    """Estado de P4 de ESTE cálculo: lo identifican solo los campos que P4 reserva (no los de P1 y P2), así que
    reevaluar el mismo cálculo con otra etapa, autorización o R1/R3 no recalcula."""
    return d / "p4" / huella_encargo({k: e[k] for k in CAMPOS_CALCULO})[:24]


def _protegido(e: dict, rutas_protegidas: tuple[Path, ...]) -> list[str]:
    motivos = []
    for nombre, ruta in sorted(e["archivos"].items()):
        p = Path(ruta)
        if nombre == "codigo" and p.name in NOMBRES_PROTEGIDOS:
            motivos.append(f"codigo: {p.name} no se ejecuta en este ejecutor (protegido por nombre)")
        try:
            real = p.resolve()
        except OSError:
            real = p
        for r in rutas_protegidas:
            try:
                real.relative_to(r.resolve())
                motivos.append(f"{nombre}: {ruta} está bajo la ruta protegida {r}")
            except ValueError:
                pass
        try:
            h = _sha(p.read_bytes())
        except OSError:
            continue  # ilegible: P4 lo rechazará sin tocar estado
        if h in PROTEGIDOS_SHA256:
            motivos.append(f"{nombre}: su contenido es {PROTEGIDOS_SHA256[h]}")
    return motivos


# ---------- registro de decisiones (encadenado, append-only) ----------
class _RegistroRoto(Exception):
    pass


VALIDAS = ("VERIFICADO", "REPRODUCIDO")
AUTORIZACIONES_POSIBLES = ("NO_OTORGADA", "CONTRADICTORIA", "REGISTRADA_EXTERNAMENTE")


def _incoherencias(x: dict) -> list[str]:
    """Contradicciones INTERNAS de una entrada DECIDIDO entre P4, P1 y P2. Una entrada inyectada con hashes de cadena
    correctos pero incoherente se detecta; una inyección coherente NO (el registro es local: ver el límite en
    GARANTIAS_Y_RIESGOS.md)."""
    if x["tipo"] != "DECIDIDO":
        return []
    try:
        c = x["contenido"]
        p4, p1, p2 = c["p4"], c["p1"], c["p2"]
        malas = []
        if p4["estado"] != "REGISTRADO":
            malas.append("P4 no registró el resultado")
        if p1["estado"] != p2["validez"]:
            malas.append("la validez de P2 no es el estado de P1")
        if p1["resultado_sha256"] != p4["resultado_sha256"]:
            malas.append("P1 evaluó otro resultado que el de P4")
        if "RECIBO_ANCLA" in p1["vias"] and p1["reserva_sha256"] != p4["reserva_sha256"]:
            malas.append("el recibo aceptado por P1 es de otra reserva")
        if p2["validez"] not in VALIDAS and (p2["etiqueta_estadistica"] is not None or p2["avance"] != "NO_CANDIDATA"):
            malas.append("etiqueta o candidatura sin evidencia válida")
        if p2["autorizacion"] not in AUTORIZACIONES_POSIBLES:
            malas.append("estado de autorización desconocido")
        repro = c.get("reproduccion") or {}
        if p2["validez"] in ("REPRODUCIDO", "NO_REPRODUCIDO") and repro.get("estado") != "REGISTRADO":
            malas.append("reproducción declarada sin ejecución registrada")
        return malas
    except (KeyError, TypeError, AttributeError):
        return ["entrada DECIDIDO mal formada"]


def leer_registro(ruta: Path) -> tuple[list[dict], list[bytes], bytes]:
    """(entradas, líneas, cola sin salto de línea). _RegistroRoto si la cadena o el esquema no cuadran."""
    if not ruta.exists():
        return [], [], b""
    *completas, cola = ruta.read_bytes().split(b"\n")
    entradas, anterior = [], None
    for i, crudo in enumerate(completas):
        try:
            x = json.loads(crudo)
        except (ValueError, RecursionError) as e:
            raise _RegistroRoto(f"línea {i + 1} ilegible") from e
        if not isinstance(x, dict) or set(x) != {"n", "utc", "anterior", "tipo", "encargo_sha256", "contenido",
                                                 "contenido_sha256", "accion_ejecutada", "version"}:
            raise _RegistroRoto(f"línea {i + 1}: claves inesperadas")
        if x["n"] != i or x["anterior"] != anterior or x["tipo"] not in TIPOS_ENTRADA or x["accion_ejecutada"] != ACCION:
            raise _RegistroRoto(f"línea {i + 1}: cadena, tipo o acción no válidos")
        try:
            canon = C.canonico(x)
        except C.ErrorConfianza as e:
            raise _RegistroRoto(f"línea {i + 1}: no canónica") from e
        if canon != crudo or _sha(C.canonico(x["contenido"])) != x["contenido_sha256"]:
            raise _RegistroRoto(f"línea {i + 1}: forma o hash del contenido no coinciden")
        malas = _incoherencias(x)
        if malas:
            raise _RegistroRoto(f"línea {i + 1}: entrada incoherente ({'; '.join(malas)})")
        entradas.append(x)
        anterior = _sha(crudo)
    return entradas, completas, cola


def _escribir_todo(fd: int, datos: bytes) -> None:
    vista = memoryview(datos)
    while vista:
        n = os.write(fd, vista)
        if n <= 0:
            raise OSError(errno.EIO, "escritura sin avance")
        vista = vista[n:]


def _fsync_dir(d: Path) -> None:
    fd = os.open(d, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _anexar(ruta: Path, lineas: list[bytes], entradas: list[dict], tipo: str, encargo_sha: str | None, contenido: dict,
            fallo: Callable[[str], None] = _nada) -> dict:
    x = {"n": len(lineas), "utc": _ahora(), "anterior": _sha(lineas[-1]) if lineas else None, "tipo": tipo,
         "encargo_sha256": encargo_sha, "contenido": contenido, "contenido_sha256": _sha(C.canonico(contenido)),
         "accion_ejecutada": ACCION, "version": VERSION}
    linea = C.canonico(x)
    nuevo = not ruta.exists()
    fd = os.open(ruta, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        _escribir_todo(fd, linea[: len(linea) // 2])
        fallo("durante_registro")
        _escribir_todo(fd, linea[len(linea) // 2:] + b"\n")
        os.fsync(fd)
    finally:
        os.close(fd)
    if nuevo:
        _fsync_dir(ruta.parent)
    lineas.append(linea)
    entradas.append(x)
    return x


def _registrar(ruta: Path, lineas: list[bytes], entradas: list[dict], tipo: str, encargo_sha: str | None,
               contenido: dict, fallo: Callable[[str], None]) -> tuple[dict, bool]:
    """(entrada, nueva). Si la última entrada de este encargo tiene el mismo contenido, no se añade nada."""
    previas = [x for x in entradas if x["encargo_sha256"] == encargo_sha and x["tipo"] != "COLA_ROTA_DESCARTADA"]
    if previas and previas[-1]["tipo"] == tipo and {
            k: v for k, v in previas[-1]["contenido"].items() if k != "sustituye_a"} == contenido:
        return previas[-1], False
    if previas:
        contenido = contenido | {"sustituye_a": previas[-1]["n"]}
    return _anexar(ruta, lineas, entradas, tipo, encargo_sha, contenido, fallo), True


# ---------- ligadura de lo que produjo P4 ----------
def _ligar(dir_estado: Path, salida: U.Salida, archivos: dict[str, str], emite_recibos: bool) -> tuple[dict, list[str]]:
    problemas = []
    leido = U.leer(dir_estado)
    reserva = leido.get("reserva")
    if leido.get("estado") != "REGISTRADO":
        problemas.append(f"el diario está en {leido.get('estado')}, no REGISTRADO")
    if leido.get("reserva_sha256") != salida.reserva_sha256:
        problemas.append("la reserva del diario no es la de la salida de P4")
    if leido.get("presellado") != salida.resultado_sha256:
        problemas.append("el presellado del diario no es el hash informado")
    try:
        actuales = {k: _sha(Path(v).read_bytes()) for k, v in archivos.items()}
        if not isinstance(reserva, dict) or reserva.get("archivos_sha256") != actuales:
            problemas.append("las entradas del encargo ya no son las reservadas")
    except OSError as e:
        problemas.append(f"entrada ilegible al ligar: {e}")
    try:
        en_disco = (dir_estado / U.RESULTADO).read_bytes()
        if _sha(en_disco) != salida.resultado_sha256:
            problemas.append("resultado.json no es el presellado")
    except OSError as e:
        problemas.append(f"resultado.json ilegible: {e}")
    recibo = None
    if emite_recibos:
        try:
            recibo = json.loads((dir_estado / U.RECIBO).read_bytes())
            if salida.recibo_ancla is None or C.canonico(recibo) != C.canonico(salida.recibo_ancla):
                problemas.append("el recibo guardado no es el informado por P4")
        except (OSError, ValueError, C.ErrorConfianza) as e:
            problemas.append(f"recibo ilegible: {type(e).__name__}")
    return {"reserva": reserva, "reserva_sha256": salida.reserva_sha256, "resultado_sha256": salida.resultado_sha256,
            "recibo": recibo}, problemas


def _p4(salida: U.Salida) -> dict:
    return {"estado": salida.estado, "reserva_sha256": salida.reserva_sha256, "resultado_sha256": salida.resultado_sha256,
            "detalle": salida.detalle[:300], "ancla": salida.ancla}


# ---------- entrada pública ----------
def ejecutar_encargo(encargo: object, dir_trabajo: str | Path, ancla: U.AnclaArchivo | U.AnclaFirmada | None, *,
                     declaraciones: list[tuple[str, object]] = (),  # type: ignore[assignment]
                     rutas_protegidas: tuple[str | Path, ...] = (),
                     fallo: Callable[[str], None] = _nada) -> dict:
    """Ver el docstring del módulo. Nunca ejecuta una acción; ``accion_ejecutada`` es siempre "NINGUNA"."""
    base = {"version": VERSION, "accion_ejecutada": ACCION}
    try:
        e = validar_encargo(encargo)
    except EncargoInvalido as x:
        return base | {"estado": "ENCARGO_INVALIDO", "detalle": str(x)}
    huella = huella_encargo(e)
    base["encargo_sha256"] = huella
    d = Path(dir_trabajo)
    try:
        U._crear_dir(d)
        fd = os.open(d / ".cerrojo_registro", os.O_CREAT | os.O_RDWR, 0o644)
    except OSError as x:
        return base | {"estado": "FALLO_ALMACENAMIENTO_REGISTRO", "detalle": f"directorio de trabajo: {x}"}
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return base | {"estado": "OCUPADO", "detalle": "otro ejecutor tiene el registro"}
        return _bajo_cerrojo(e, huella, d, ancla, list(declaraciones),
                             tuple(Path(r) for r in rutas_protegidas), fallo, base)
    finally:
        os.close(fd)


def _bajo_cerrojo(e: dict, huella: str, d: Path, ancla: U.AnclaArchivo | U.AnclaFirmada | None,  # noqa: C901
                  declaraciones: list[tuple[str, object]], protegidas: tuple[Path, ...],
                  fallo: Callable[[str], None], base: dict) -> dict:
    ruta = d / REGISTRO
    try:
        entradas, lineas, cola = leer_registro(ruta)
    except _RegistroRoto as x:
        return base | {"estado": "REGISTRO_INCONSISTENTE", "detalle": f"{x}: no se ejecuta nada"}
    except OSError as x:
        return base | {"estado": "FALLO_ALMACENAMIENTO_REGISTRO", "detalle": f"registro ilegible: {x}"}

    def registrar(tipo: str, contenido: dict, **extra: object) -> dict:
        try:
            x, nueva = _registrar(ruta, lineas, entradas, tipo, huella, contenido, fallo)
        except OSError as err:
            return base | {"estado": "FALLO_ALMACENAMIENTO_REGISTRO", "estado_previsto": tipo, "contenido": contenido,
                           "detalle": f"{type(err).__name__}: {err}; se reintenta en la siguiente llamada", **extra}
        fallo("tras_registro")
        return base | {"estado": tipo, "contenido": contenido, "registro": {"n": x["n"], "nueva": nueva,
                                                                            "linea_sha256": _sha(lineas[x["n"]])},
                       **extra}

    try:
        if cola:  # una caída a mitad de la escritura: se descarta la cola dejando constancia
            fdr = os.open(ruta, os.O_WRONLY)
            try:
                os.ftruncate(fdr, sum(len(x) + 1 for x in lineas))
                os.fsync(fdr)
            finally:
                os.close(fdr)
            _anexar(ruta, lineas, entradas, "COLA_ROTA_DESCARTADA", None,
                    {"bytes": len(cola), "sha256": _sha(cola), "texto": cola.decode("utf-8", "replace")})
    except OSError as x:
        return base | {"estado": "FALLO_ALMACENAMIENTO_REGISTRO", "detalle": f"cola del registro: {x}"}

    motivos = _protegido(e, protegidas)
    if motivos:
        return registrar("RECHAZADO_PROTEGIDO", {"motivos": motivos})
    comun = {"punto_entrada": e["punto_entrada"], "ancla": ancla, "limite_segundos": e["limite_segundos"],
             "verificar_determinismo": e["verificar_determinismo"]}
    dc = dir_calculo(d, e)
    s = U.ejecutar(dc / "original", e["experimento"], e["archivos"], e["semilla"], **comun)
    fallo("tras_p4")
    if s.estado != "REGISTRADO":
        return registrar("SIN_RESULTADO", {"p4": _p4(s)})
    emite = bool(ancla is not None and ancla.emite_recibos)
    lig, problemas = _ligar(dc / "original", s, e["archivos"], emite)
    if problemas:
        return registrar("INCONSISTENTE", {"p4": _p4(s), "problemas": problemas})
    decl = ([("recibo_ancla_original", lig["recibo"])] if lig["recibo"] is not None else []) + declaraciones
    repro, lig_r = None, None
    if e["reproducir"]:
        repro = U.ejecutar(dc / "reproduccion", e["experimento"], e["archivos"], e["semilla"], **comun,
                           reproduccion_de=s.resultado_sha256)
        fallo("tras_reproduccion")
        if repro.estado != "REGISTRADO":
            return registrar("SIN_RESULTADO", {"p4": _p4(s), "reproduccion": _p4(repro)})
        lig_r, problemas = _ligar(dc / "reproduccion", repro, e["archivos"], emite)
        if problemas:
            return registrar("INCONSISTENTE", {"p4": _p4(s), "reproduccion": _p4(repro), "problemas": problemas})
        if lig_r["recibo"] is not None:
            decl.append(("recibo_ancla_reproduccion", lig_r["recibo"]))
    try:
        salida = PA.desde_resultado(
            dc / "original" / U.RESULTADO, e["raiz_t"], e["r1"], e["r3"],
            resultado_sha256_esperado=s.resultado_sha256, declaraciones=decl, reserva=lig["reserva"],
            reproduccion=(dc / "reproduccion" / U.RESULTADO) if lig_r else None,
            reserva_reproduccion=lig_r["reserva"] if lig_r else None, tolerancia=e["tolerancia"], etapa=e["etapa"],
            autorizacion=e["autorizacion"])
    except PA.ErrorPolitica as x:
        return registrar("ERROR_POLITICA", {"p4": _p4(s), "error": str(x)})
    fallo("tras_p2")
    rv = salida["resultado_verificado"]
    contenido = {
        "p4": _p4(s), "reproduccion": _p4(repro) if repro else None,
        "p1": {"estado": rv["estado"], "motivos": [m["codigo"] for m in rv["motivos"]],
               "vias": (rv.get("autenticidad") or {}).get("vias", []),
               "reserva_sha256": (rv.get("ejecucion") or {}).get("reserva_sha256"),
               "resultado_sha256": rv["resultado_sha256"]},
        "p2": {"validez": salida["evidencia"]["validez"], "etiqueta_estadistica": salida["etiqueta_estadistica"],
               "clase": salida["clase_estadistica"], "avance": salida["decision_avance"]["resultado"],
               "etapa": salida["decision_avance"]["etapa"], "autorizacion": salida["autorizacion_ejecucion"]["estado"],
               "autorizacion_id": salida["autorizacion_ejecucion"]["id"], "robustez": salida["robustez"]["resumen"],
               "version": salida["version"]}}
    return registrar("DECIDIDO", contenido, salida_p2=salida)


# ---------- línea de órdenes ----------
def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[0].startswith("--") or argv[1].startswith("--"):
        print(__doc__)
        return 2
    encargo, dir_trabajo = argv[0], argv[1]
    ancla, declaraciones, protegidas, i = None, [], [], 2
    while i < len(argv):
        if argv[i] == "--ancla-local" and i + 1 < len(argv) and ancla is None:
            ancla, i = U.AnclaArchivo(argv[i + 1]), i + 2
        elif argv[i] == "--declaracion" and i + 1 < len(argv):
            try:
                declaraciones.append((argv[i + 1], C.cargar_json_estricto(argv[i + 1])))
            except C.ErrorConfianza as e:
                declaraciones.append((argv[i + 1], {"no_legible": f"{e.codigo}: {e.detalle}"}))
            i += 2
        elif argv[i] == "--protegida" and i + 1 < len(argv):
            protegidas.append(argv[i + 1])
            i += 2
        else:
            print(__doc__)
            return 2
    if ancla is None:
        print(__doc__)
        return 2
    try:
        obj = C.cargar_json_estricto(encargo)
    except C.ErrorConfianza as e:
        obj = {"no_legible": f"{e.codigo}: {e.detalle}"}
    informe = ejecutar_encargo(obj, dir_trabajo, ancla, declaraciones=declaraciones, rutas_protegidas=tuple(protegidas))
    print(json.dumps(informe, ensure_ascii=False, indent=1, default=str))
    return SALIDAS.get(informe["estado"], 3)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
