"""Prototipo AISLADO de ejecución de uso único, v0.5 (P4). Solo biblioteca estándar. PROPUESTA: no está integrado en
``papel/corte.py`` ni en ``fuera_de_muestra_T.py`` y no debe integrarse sin autorización.

Garantía buscada: un experimento se calcula con entradas, código y entorno fijados de antemano, y un resultado que pudo
observarse no puede sustituirse por otro repitiendo, borrando, truncando, restaurando o alterando el estado LOCAL,
siempre que exista un ancla que el atacante no controle. ``AnclaArchivo`` (local) NO cumple esa condición frente a
quien puede escribirla. ``AnclaFirmada`` es el CLIENTE de un ancla externa (respuestas firmadas, desafío contra
repeticiones, recibos verificables por P1); el servicio externo NO existe todavía: ver DISENO_ANCLA_EXTERNA.md.

Cambios de v0.5 respecto de v0.4 (INFORME_DEFECTOS_Y_CORRECCIONES.md, defectos F*):
- Eventos ENCADENADOS pero mal formados (sin ``evento``, ``datos`` que no es un objeto, PRESELLADO sin hash…) en el
  diario o en el ancla local hacían escapar KeyError/TypeError/AttributeError sin salida; ahora cada evento se valida
  con un esquema estricto y el diario es INCONSISTENTE (el ancla, en conflicto).
- ``AnclaFirmada`` rechaza una clave fijada de orden pequeño (con ella cualquiera falsificaba las respuestas) y nunca
  deja escapar otra excepción que las del ancla al verificar una respuesta (v0.4: UnicodeEncodeError sin salida).
- Límite de tiempo opcional del cálculo (``limite_segundos``, parte de la reserva): al vencer se detiene el proceso de
  cálculo y la salida es FALLO_CALCULO (el inicio ya consta: la siguiente llamada da REVISION_HUMANA). v0.4 esperaba
  indefinidamente.
- Reservas de REPRODUCCIÓN (``reproduccion_de`` = SHA-256 del resultado que se reproduce): el ancla las admite junto
  al original que registró ESE presellado (y junto a otras reproducciones de él) aunque repitan nombre y entradas; una
  reproducción nunca sustituye al original. v0.4 las rechazaba por «mismas entradas», así que no había forma de
  producir una reproducción con recibo.
- Validación de los argumentos de ``ejecutar`` (nombre, semilla entera, punto de entrada, archivos).
- El proceso de cálculo borra su directorio de trabajo vacío al terminar (v0.4 lo dejaba huérfano si el padre moría).
- ``leer`` devuelve también la reserva y su SHA-256 (lo que P1 necesita para ligar un recibo a la ejecución).

Cambios de v0.4 respecto de v0.3:
- Escrituras completas: v0.3 ignoraba el número de bytes que devuelve ``os.write``; una escritura corta dejaba una línea
  partida en el diario y la ejecución seguía hasta REGISTRADO con el diario ilegible. Ahora se reintenta hasta escribir
  todo y una escritura sin avance es un error.
- Fallos de almacenamiento (disco lleno, E/S): v0.3 dejaba escapar la excepción (sin salida ni reserva). Ahora la salida
  es FALLO_ALMACENAMIENTO (no terminal) y la siguiente llamada concilia el estado como tras una caída. Un fallo de E/S
  del ancla local es ANCLA_NO_DISPONIBLE (sin confirmación, nada avanza).
- Una entrada ilegible es RECHAZADO antes de tocar ningún estado.
- Ancla externa: interfaz con recibo (``registrar_presellado`` devuelve un recibo firmado o None) y cliente
  ``AnclaFirmada``; el recibo se guarda en RECIBO_ANCLA.json ANTES que el resultado y P1 lo acepta como referencia
  independiente si la clave del ancla es una raíz aprobada. Respuesta no auténtica: ANCLA_NO_AUTENTICA (no terminal).
- El ejecutor que se liga a la reserva incluye confianza.py (verifica las firmas del ancla).

Cambios de v0.3 y v0.2: CAS del inicio de cálculo en el ancla; el ancla no se repara en silencio; ejecutor ligado a la
reserva; hijo con entorno vacío en un directorio vacío; ``verificar_determinismo``; ancla anotada antes del disco;
conciliación en cada llamada; CALCULO_INICIADO separa fallos previos y posteriores al inicio; fsync de directorios.
"""
from __future__ import annotations

import base64
import datetime as dt
import errno
import fcntl
import hashlib
import json
import os
import platform
import re
import select
import subprocess
import sys
import tempfile
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import confianza as C  # noqa: E402

VERSION = "uso_unico v0.5"
EJECUTOR_SHA256 = hashlib.sha256(Path(__file__).read_bytes() + b"\0" + Path(C.__file__).read_bytes()).hexdigest()
DIARIO, RESULTADO, CERROJO, RECIBO = "DIARIO.jsonl", "resultado.json", ".cerrojo", "RECIBO_ANCLA.json"
ERRORES_TERMINALES = ("CONFLICTO", "CORRUPTO", "INCONSISTENTE", "REVISION_HUMANA", "NO_DETERMINISTA")
SALIDAS_NO_TERMINALES = ("OCUPADO", "RECHAZADO", "FALLO_CALCULO", "ANCLA_NO_DISPONIBLE", "ANCLA_NO_AUTENTICA",
                         "FALLO_ALMACENAMIENTO")
PUNTOS_DE_FALLO = ("antes_del_cerrojo", "antes_de_reservar", "durante_reserva", "tras_reservar", "tras_iniciar_calculo",
                   "durante_calculo", "tras_calculo", "durante_presellado", "tras_presellado", "tras_ancla",
                   "durante_escritura", "tras_archivo", "durante_registro")
SIN_ANCLA = "NINGUNA: no protege contra borrado, truncamiento ni restauración del estado local"


@dataclass
class Salida:
    # REGISTRADO o una de ERRORES_TERMINALES / SALIDAS_NO_TERMINALES. Solo REGISTRADO trae resultado.
    estado: str
    resultado: dict | None = None
    resultado_sha256: str | None = None
    calculado: bool = False
    detalle: str = ""
    ancla: str = SIN_ANCLA
    reserva_sha256: str | None = None  # None solo en OCUPADO y en una entrada ilegible (antes de armar la reserva)
    recibo_ancla: dict | None = None   # recibo firmado del ancla externa (None con el ancla local o sin ancla)


class _CadenaRota(Exception):
    pass


class AnclaNoDisponible(Exception):
    """El ancla no respondió o no confirmó. Nunca se calcula ni se escribe el resultado sin su confirmación."""


class AnclaNoAutentica(AnclaNoDisponible):
    """La respuesta no está firmada por la clave fijada, no responde al desafío o no corresponde a la operación."""


class AnclaConflicto(Exception):
    """El ancla ya tiene otra reserva del mismo experimento o de las mismas entradas, otro presellado, o rechaza el
    inicio (comparación-y-escritura)."""


def _nada(_punto: str) -> None:
    return None


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _canon(x: object) -> bytes:
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def _ahora() -> str:
    return dt.datetime.now(dt.UTC).isoformat(timespec="microseconds")


# ---------- E/S de bajo nivel: todo pasa por os.* (escrituras completas, fsync) ----------
def _escribir_todo(fd: int, datos: bytes) -> None:
    """Escribe TODOS los bytes (os.write puede escribir menos de los pedidos). Sin avance: OSError."""
    vista = memoryview(datos)
    while vista:
        n = os.write(fd, vista)
        if n <= 0:
            raise OSError(errno.EIO, "escritura sin avance")
        vista = vista[n:]


def _fsync_dir(d: Path) -> None:
    fd = os.open(d, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _crear_dir(d: Path) -> None:
    """mkdir con fsync del padre, para que la entrada del directorio sobreviva a un corte de energía."""
    if not d.is_dir():
        d.mkdir(parents=True, exist_ok=True)
        _fsync_dir(d.parent)


def _entorno() -> dict:
    return {"python": sys.version, "implementacion": platform.python_implementation()}


# ---------- diario encadenado (local y del ancla de archivo) ----------
_HEX64 = re.compile(r"[0-9a-f]{64}")


def _es_hex64(v: object) -> bool:
    return isinstance(v, str) and _HEX64.fullmatch(v) is not None


def _es_entero(v: object, minimo: int = 0) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and v >= minimo


# v0.5: esquema de los ``datos`` de cada evento. Una cadena con hashes correctos pero eventos mal formados la puede
# escribir quien controla el archivo: debe dar INCONSISTENTE, no una excepción.
_HASH_RESULTADO = {"resultado_sha256": _es_hex64}
ESQUEMA_DIARIO: dict[str, dict | None] = {
    "RESERVADO": None,  # la reserva entera: se compara con la reserva actual
    "INTENTO": {"pid": _es_entero, "estado_previo": lambda v: isinstance(v, str)},
    "CALCULO_INICIADO": {"n": lambda v: _es_entero(v, 1)},
    "CALCULO_FALLIDO": {"motivo": lambda v: isinstance(v, str)},
    "PRESELLADO": _HASH_RESULTADO, "SELLADO": _HASH_RESULTADO, "RESTAURADO": _HASH_RESULTADO,
    "REGISTRADO": _HASH_RESULTADO,
    "RECALCULO_DE_VERIFICACION": {"resultado_sha256_exigido": _es_hex64},
    "RECHAZADO_ENTRADAS_DISTINTAS": {"ofrecidas": lambda v: isinstance(v, dict)},
    "COLA_ROTA_DESCARTADA": {"bytes": _es_entero, "sha256": _es_hex64, "contenido": lambda v: isinstance(v, str)},
}
ESQUEMA_ANCLA: dict[str, dict | None] = {
    "RESERVA": {"reserva_sha256": _es_hex64, "experimento": lambda v: isinstance(v, str), "semilla": _es_entero,
                "archivos_sha256": lambda v: isinstance(v, dict),
                "reproduccion_de": lambda v: v is None or _es_hex64(v)},
    "INICIO_CALCULO": {"reserva_sha256": _es_hex64, "n": lambda v: _es_entero(v, 1)},
    "PRESELLADO": {"reserva_sha256": _es_hex64, "resultado_sha256": _es_hex64},
    "COLA_ROTA_DESCARTADA": ESQUEMA_DIARIO["COLA_ROTA_DESCARTADA"],
}


def _validar_evento(ev: dict, esquema: dict[str, dict | None], donde: str) -> None:
    if set(ev) != {"n", "evento", "utc", "datos", "anterior"} or not isinstance(ev["utc"], str):
        raise _CadenaRota(f"{donde}: evento con claves inesperadas")
    tipo, datos = ev["evento"], ev["datos"]
    if not isinstance(datos, dict):
        raise _CadenaRota(f"{donde}: 'datos' no es un objeto")
    if tipo in ERRORES_TERMINALES and esquema is ESQUEMA_DIARIO:
        if not isinstance(datos.get("motivo"), str):
            raise _CadenaRota(f"{donde}: {tipo} sin motivo")
        return
    if not isinstance(tipo, str) or tipo not in esquema:
        raise _CadenaRota(f"{donde}: evento desconocido {tipo!r}")
    campos = esquema[tipo]
    if campos is not None and (set(datos) != set(campos) or not all(f(datos[k]) for k, f in campos.items())):
        raise _CadenaRota(f"{donde}: datos de {tipo} mal formados")


def _leer_cadena(ruta: Path, esquema: dict[str, dict | None] = ESQUEMA_DIARIO) -> tuple[list[dict], list[bytes], bytes]:
    if not ruta.exists():
        return [], [], b""
    *completas, cola = ruta.read_bytes().split(b"\n")
    eventos: list[dict] = []
    anterior = None
    for i, crudo in enumerate(completas):
        try:
            ev = json.loads(crudo)
        except (ValueError, RecursionError) as e:
            raise _CadenaRota(f"{ruta.name}: línea {i + 1} ilegible") from e
        if not isinstance(ev, dict) or ev.get("n") != i or ev.get("anterior") != anterior or _canon(ev) != crudo:
            raise _CadenaRota(f"{ruta.name}: cadena rota en la línea {i + 1}")
        _validar_evento(ev, esquema, f"{ruta.name}: línea {i + 1}")
        eventos.append(ev)
        anterior = _sha(crudo)
    return eventos, completas, cola


def _anotar(ruta: Path, lineas: list[bytes], eventos: list[dict], evento: str, datos: dict,
            fallo: Callable[[str], None] = _nada, punto: str | None = None, crear: bool = False) -> None:
    ev = {"n": len(lineas), "evento": evento, "utc": _ahora(), "datos": datos,
          "anterior": _sha(lineas[-1]) if lineas else None}
    linea = _canon(ev)
    nuevo = crear and not ruta.exists()
    fd = os.open(ruta, os.O_WRONLY | os.O_APPEND | (os.O_CREAT if crear else 0), 0o644)
    try:
        if punto:
            _escribir_todo(fd, linea[: len(linea) // 2])
            os.fsync(fd)
            fallo(punto)
            _escribir_todo(fd, linea[len(linea) // 2:] + b"\n")
        else:
            _escribir_todo(fd, linea + b"\n")
        os.fsync(fd)
    finally:
        os.close(fd)
    if nuevo:
        _fsync_dir(ruta.parent)
    lineas.append(linea)
    eventos.append(ev)


def _descartar_cola(ruta: Path, lineas: list[bytes], eventos: list[dict], cola: bytes) -> None:
    fd = os.open(ruta, os.O_WRONLY)
    try:
        os.ftruncate(fd, sum(len(x) + 1 for x in lineas))
        os.fsync(fd)
    finally:
        os.close(fd)
    _anotar(ruta, lineas, eventos, "COLA_ROTA_DESCARTADA",
            {"bytes": len(cola), "sha256": _sha(cola), "contenido": cola.decode("utf-8", "replace")})


# ---------- anclas ----------
class AnclaArchivo:
    """Implementación LOCAL de la interfaz de ancla: un diario encadenado en otro archivo, con su propio cerrojo. NO es
    un ancla externa: detecta el borrado, el truncamiento o la restauración del directorio de estado, pero no a quien
    puede reescribir también este archivo. No emite recibos (``registrar_presellado`` devuelve None)."""

    emite_recibos = False

    def __init__(self, ruta: str | Path):
        self.ruta = Path(ruta)
        self.descripcion = f"AnclaArchivo LOCAL ({self.ruta.name}): no es un ancla externa"
        self.identidad = f"archivo:{self.ruta.resolve()}"

    def _con_cerrojo(self, f: Callable[[list[dict], list[bytes]], object]) -> object:
        try:
            _crear_dir(self.ruta.parent)
            fd = os.open(f"{self.ruta}.cerrojo", os.O_CREAT | os.O_RDWR, 0o644)
        except OSError as e:
            raise AnclaNoDisponible(f"ancla local inaccesible: {e}") from e
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            eventos, lineas, cola = _leer_cadena(self.ruta, ESQUEMA_ANCLA)
            if cola:
                _descartar_cola(self.ruta, lineas, eventos, cola)
            return f(eventos, lineas)
        except _CadenaRota as e:
            raise AnclaConflicto(f"ancla ilegible o alterada: {e}") from e
        except OSError as e:  # v0.4: sin confirmación del ancla, nada avanza
            raise AnclaNoDisponible(f"error de E/S del ancla local: {e}") from e
        finally:
            os.close(fd)

    @staticmethod
    def _estado(eventos: list[dict], reserva_sha: str) -> dict:
        propios = [e for e in eventos if e["datos"].get("reserva_sha256") == reserva_sha]
        pres = [e["datos"]["resultado_sha256"] for e in propios if e["evento"] == "PRESELLADO"]
        return {"reserva": any(e["evento"] == "RESERVA" for e in propios),
                "iniciados": max((e["datos"]["n"] for e in propios if e["evento"] == "INICIO_CALCULO"), default=0),
                "presellado": pres[0] if pres else None, "recibo": None}

    def consultar(self, reserva_sha: str) -> dict:
        return self._con_cerrojo(lambda ev, _l: self._estado(ev, reserva_sha))  # type: ignore[return-value]

    def registrar_reserva(self, reserva_sha: str, reserva: dict) -> None:
        repro = reserva.get("reproduccion_de")

        def f(eventos: list[dict], lineas: list[bytes]) -> None:
            for e in eventos:
                x = e["datos"]
                if e["evento"] != "RESERVA" or x["reserva_sha256"] == reserva_sha:
                    continue
                if repro is not None and (x["reproduccion_de"] == repro or (
                        x["reproduccion_de"] is None and self._estado(eventos, x["reserva_sha256"])["presellado"] == repro)):
                    continue  # v0.5: una reproducción convive con el original que registró ESE presellado y con otras
                if x["experimento"] == reserva["experimento"] or x["archivos_sha256"] == reserva["archivos_sha256"]:
                    que = "ese nombre" if x["experimento"] == reserva["experimento"] else "las mismas entradas"
                    raise AnclaConflicto(f"el ancla ya tiene {x['experimento']} con {que} (semilla {x['semilla']})"
                                         + ("; una reproducción solo convive con el original que registró ese "
                                            "presellado" if repro is not None else ""))
            if not self._estado(eventos, reserva_sha)["reserva"]:
                _anotar(self.ruta, lineas, eventos, "RESERVA",
                        {"reserva_sha256": reserva_sha, "experimento": reserva["experimento"],
                         "semilla": reserva["semilla"], "archivos_sha256": reserva["archivos_sha256"],
                         "reproduccion_de": repro}, crear=True)
        self._con_cerrojo(f)

    def registrar_inicio_calculo(self, reserva_sha: str, n: int) -> None:
        def f(eventos: list[dict], lineas: list[bytes]) -> None:
            st = self._estado(eventos, reserva_sha)
            if not st["reserva"]:
                raise AnclaConflicto("inicio de cálculo sin reserva en el ancla")
            if st["presellado"] is not None:
                raise AnclaConflicto("inicio de cálculo después de un presellado")
            if n != st["iniciados"] + 1:  # comparación-y-escritura
                raise AnclaConflicto(f"inicio {n} rechazado: el ancla ya registra {st['iniciados']} inicio(s) de esta "
                                     "reserva (otro proceso o un estado local desactualizado)")
            _anotar(self.ruta, lineas, eventos, "INICIO_CALCULO", {"reserva_sha256": reserva_sha, "n": n})
        self._con_cerrojo(f)

    def registrar_presellado(self, reserva_sha: str, resultado_sha: str) -> dict | None:
        def f(eventos: list[dict], lineas: list[bytes]) -> None:
            st = self._estado(eventos, reserva_sha)
            if not st["reserva"]:
                raise AnclaConflicto("presellado sin reserva en el ancla")
            if st["presellado"] not in (None, resultado_sha):
                raise AnclaConflicto("el ancla ya tiene otro presellado para esta reserva")
            if st["presellado"] is None:
                _anotar(self.ruta, lineas, eventos, "PRESELLADO",
                        {"reserva_sha256": reserva_sha, "resultado_sha256": resultado_sha})
        self._con_cerrojo(f)
        return None


class AnclaFirmada:
    """CLIENTE de un ancla externa (DISENO_ANCLA_EXTERNA.md). ``transporte(solicitud) -> documento firmado`` lleva la
    solicitud al servicio (red, cola, etc.). Cada respuesta debe estar firmada con la clave FIJADA al construir el
    cliente, nombrar la operación y la reserva pedidas y devolver el DESAFÍO aleatorio de esta solicitud (una respuesta
    vieja repetida no sirve). Los recibos de presellado son declaraciones firmadas que P1 acepta como referencia
    independiente si esa clave es una raíz aprobada. Este módulo no implementa ningún servicio."""

    emite_recibos = True

    def __init__(self, transporte: Callable[[dict], object], clave_publica_hex: str, emisor: str):
        C.validar_clave_publica(clave_publica_hex, "clave pública del ancla")  # v0.5: sin claves de orden pequeño
        if not isinstance(emisor, str) or not emisor:
            raise ValueError("emisor del ancla vacío")
        self.transporte, self.clave, self.emisor = transporte, clave_publica_hex, emisor
        self.identidad = f"firmada:{emisor}:{C.huella_clave(clave_publica_hex)}"
        self.descripcion = f"AnclaFirmada ({emisor}, {C.huella_clave(clave_publica_hex)})"

    def _llamar(self, op: str, reserva_sha: str, **datos: object) -> dict:
        desafio = os.urandom(16).hex()
        try:
            respuesta = self.transporte({"op": op, "reserva_sha256": reserva_sha, "desafio": desafio, **datos})
        except AnclaNoDisponible:
            raise
        except Exception as e:  # noqa: BLE001  red, servicio caído, tiempo agotado
            raise AnclaNoDisponible(f"el ancla no respondió: {type(e).__name__}: {e}") from e
        try:
            c = C.verificar_documento(respuesta, self.clave)
        except C.ErrorConfianza as e:
            raise AnclaNoAutentica(f"respuesta del ancla no auténtica: {e.codigo}: {e.detalle}") from e
        except Exception as e:  # noqa: BLE001  v0.5: una respuesta hostil nunca escapa como otra excepción
            raise AnclaNoAutentica(f"respuesta del ancla no procesable: {type(e).__name__}") from None
        esperado = {"formato": C.FORMATO_RESPUESTA_ANCLA, "op": op, "reserva_sha256": reserva_sha, "desafio": desafio,
                    "emisor": self.emisor}
        if any(c.get(k) != v for k, v in esperado.items()):
            raise AnclaNoAutentica(f"la respuesta firmada no corresponde a esta solicitud ({op}, desafío)")
        st = c.get("estado")
        if not (isinstance(st, dict) and set(st) == {"reserva", "iniciados", "presellado"}
                and isinstance(st["reserva"], bool) and isinstance(st["iniciados"], int)
                and not isinstance(st["iniciados"], bool) and st["iniciados"] >= 0
                and (st["presellado"] is None or (isinstance(st["presellado"], str) and len(st["presellado"]) == 64))):
            raise AnclaNoAutentica("estado del ancla mal formado")
        if c.get("resultado") == "CONFLICTO":
            raise AnclaConflicto(f"el ancla rechaza {op}: {c.get('motivo', '')}")
        if c.get("resultado") != "ACEPTADO":
            raise AnclaNoAutentica(f"resultado desconocido: {c.get('resultado')!r}")
        recibo = c.get("recibo")
        if st["presellado"] is not None:
            self._validar_recibo(recibo, reserva_sha, st["presellado"])
        elif recibo is not None:
            raise AnclaNoAutentica("recibo sin presellado")
        return {**st, "recibo": recibo}

    def _validar_recibo(self, recibo: object, reserva_sha: str, presellado: str) -> None:
        try:
            contenido = C.validar_declaracion(C.verificar_documento(recibo, self.clave))
        except C.ErrorConfianza as e:
            raise AnclaNoAutentica(f"recibo no auténtico: {e.codigo}: {e.detalle}") from e
        except Exception as e:  # noqa: BLE001
            raise AnclaNoAutentica(f"recibo no procesable: {type(e).__name__}") from None
        if contenido["emisor"] != self.emisor or contenido["contexto"].get("reserva_sha256") != reserva_sha or not any(
                a["sha256"] == presellado for a in contenido["artefactos"]):
            raise AnclaNoAutentica("el recibo no corresponde a esta reserva y este presellado")

    def consultar(self, reserva_sha: str) -> dict:
        return self._llamar("consultar", reserva_sha)

    def registrar_reserva(self, reserva_sha: str, reserva: dict) -> None:
        self._llamar("registrar_reserva", reserva_sha, reserva=reserva)

    def registrar_inicio_calculo(self, reserva_sha: str, n: int) -> None:
        self._llamar("registrar_inicio_calculo", reserva_sha, n=n)

    def registrar_presellado(self, reserva_sha: str, resultado_sha: str) -> dict | None:
        st = self._llamar("registrar_presellado", reserva_sha, resultado_sha256=resultado_sha)
        if st["presellado"] != resultado_sha:
            raise AnclaConflicto("el ancla tiene otro presellado para esta reserva")
        return st["recibo"]


# ---------- cálculo aislado ----------
_HIJO = r"""
import base64, json, os, sys
fd = int(sys.argv[1])
vacio = os.getcwd()
try:
    e = json.loads(sys.stdin.buffer.read())
    contenidos = {k: base64.b64decode(v) for k, v in e["contenidos"].items()}
    ns = {"__name__": "calculo_reservado"}
    exec(compile(contenidos.pop("codigo"), "codigo_reservado", "exec"), ns)
    res = ns[e["punto_entrada"]](contenidos, e["semilla"])
    datos = json.dumps(res, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    with os.fdopen(fd, "wb") as fh:
        fh.write(datos)
finally:
    try:
        os.rmdir(vacio)  # v0.5: el directorio vacío no queda huérfano aunque el padre haya muerto
    except OSError:
        pass
"""


def _detener(p: subprocess.Popen) -> None:
    # Solo el proceso de cálculo: sigue en el grupo del padre, para que detener al padre (p. ej. con un límite externo
    # sobre el grupo) lo detenga también. Los procesos que lance el código reservado no se siguen (supuesto S-c).
    p.kill()
    p.wait()


def _calcular_aislado(contenidos: dict[str, bytes], semilla: int, punto_entrada: str,
                      fallo: Callable[[str], None], limite: int | None = None) -> tuple[bytes | None, str]:
    """Ejecuta los bytes RESERVADOS de ``codigo`` en un proceso hijo sin salida visible. ``limite`` (segundos, v0.5):
    al vencer se detiene el proceso de cálculo y no hay resultado. (bytes canónicos, motivo)."""
    r, w = os.pipe()
    vacio = tempfile.mkdtemp(prefix="calculo_")  # directorio de trabajo vacío y entorno vacío
    try:
        p = subprocess.Popen([sys.executable, "-I", "-S", "-B", "-c", _HIJO, str(w)], stdin=subprocess.PIPE,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, pass_fds=(w,), close_fds=True,
                             env={}, cwd=vacio)
    finally:
        os.close(w)
    entrada = json.dumps({"contenidos": {k: base64.b64encode(v).decode() for k, v in contenidos.items()},
                          "semilla": semilla, "punto_entrada": punto_entrada}).encode()
    try:
        p.stdin.write(entrada)  # type: ignore[union-attr]
        p.stdin.close()  # type: ignore[union-attr]
    except BrokenPipeError:
        pass
    fallo("durante_calculo")  # el padre muere con el hijo ya calculando
    fin = None if limite is None else time.monotonic() + limite
    trozos: list[bytes] = []
    agotado = False
    with os.fdopen(r, "rb", buffering=0) as fh:
        while True:
            espera = None if fin is None else max(0.0, fin - time.monotonic())
            if not select.select([fh], [], [], espera)[0]:
                agotado = True
                break
            b = fh.read(1 << 16)
            if not b:
                break
            trozos.append(b)
    datos = b"".join(trozos)
    if not agotado:
        try:
            codigo = p.wait(None if fin is None else max(0.0, fin - time.monotonic()))
        except subprocess.TimeoutExpired:
            agotado = True
    if agotado:
        _detener(p)
    try:
        os.rmdir(vacio)
    except OSError:
        pass  # el hijo ya lo borró, o el cálculo dejó archivos: se conserva para inspección
    if agotado:
        return None, f"límite de tiempo superado ({limite} s): el cálculo se detuvo y no hay resultado"
    if codigo != 0:
        return None, f"el proceso de cálculo terminó con código {codigo}"
    try:
        obj = json.loads(datos)
    except ValueError:
        return None, "el cálculo no devolvió JSON"
    if not isinstance(obj, dict):
        return None, "el cálculo no devolvió un objeto JSON"
    return _canon(obj), ""


# ---------- escrituras atómicas ----------
def _escribir_nuevo(ruta: Path, datos: bytes, fallo: Callable[[str], None] = _nada, punto: str | None = None) -> None:
    fd = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        if punto:
            _escribir_todo(fd, datos[: len(datos) // 2])
            os.fsync(fd)
            fallo(punto)
            _escribir_todo(fd, datos[len(datos) // 2:])
        else:
            _escribir_todo(fd, datos)
        os.fsync(fd)
    finally:
        os.close(fd)


def _reservar(d: Path, reserva: dict, fallo: Callable[[str], None]) -> None:
    tmp = d / f".{DIARIO}.{os.getpid()}.tmp"
    _escribir_nuevo(tmp, _canon({"n": 0, "evento": "RESERVADO", "utc": _ahora(), "datos": reserva, "anterior": None})
                    + b"\n")
    fallo("durante_reserva")
    try:
        os.link(tmp, d / DIARIO)
    finally:
        tmp.unlink()
    _fsync_dir(d)


def _escribir_atomico(ruta: Path, datos: bytes, fallo: Callable[[str], None], punto: str | None = None) -> None:
    tmp = ruta.with_name(f".{ruta.name}.{os.getpid()}.tmp")
    _escribir_nuevo(tmp, datos, fallo, punto)
    os.replace(tmp, ruta)
    _fsync_dir(ruta.parent)


# ---------- estados ----------
def _validar_secuencia(eventos: list[dict]) -> None:
    if not eventos:
        return
    tipos = [e["evento"] for e in eventos]
    if tipos[0] != "RESERVADO" or tipos.count("RESERVADO") != 1:
        raise _CadenaRota("el diario no empieza por una única reserva")
    pres = [e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"]
    if len(pres) > 1:
        raise _CadenaRota("más de un presellado")
    for i, e in enumerate(eventos):
        t = e["evento"]
        if t == "PRESELLADO" and "CALCULO_INICIADO" not in tipos[:i]:
            raise _CadenaRota(f"PRESELLADO sin CALCULO_INICIADO previo (línea {i + 1})")
        if t in ("SELLADO", "RESTAURADO", "REGISTRADO") and (
                not pres or e["datos"]["resultado_sha256"] != pres[0] or "PRESELLADO" not in tipos[:i]):
            raise _CadenaRota(f"{t} sin presellado coherente (línea {i + 1})")
        if t == "REGISTRADO" and "SELLADO" not in tipos[:i]:
            raise _CadenaRota(f"REGISTRADO sin SELLADO previo (línea {i + 1})")
    terminal = next((i for i, t in enumerate(tipos) if t in ERRORES_TERMINALES), None)
    if terminal is not None and any(t != "INTENTO" for t in tipos[terminal + 1:]):
        raise _CadenaRota("hay eventos después de un estado terminal")


def estado_actual(eventos: list[dict]) -> str:
    if not eventos:
        return "NUEVO"
    tipos = {e["evento"] for e in eventos}
    for t in (*ERRORES_TERMINALES, "REGISTRADO", "SELLADO", "PRESELLADO"):
        if t in tipos:
            return t
    return "CALCULO_INTERRUMPIDO" if "CALCULO_INICIADO" in tipos else "RESERVADO"


# ---------- ejecución ----------
def _validar_argumentos(experimento: object, archivos: object, semilla: object, punto_entrada: object,
                        reintentos: object, determinismo: object, limite: object, reproduccion_de: object) -> None:
    """Errores de PROGRAMACIÓN del llamador (ValueError), antes de tocar ningún estado. v0.5: también nombre, semilla,
    punto de entrada, archivos, límite de tiempo y reproducción."""
    if not isinstance(experimento, str) or not experimento:
        raise ValueError("experimento debe ser un texto no vacío")
    if not isinstance(archivos, dict) or not all(isinstance(k, str) and k and isinstance(v, (str, Path))
                                                 for k, v in archivos.items()):
        raise ValueError("archivos debe ser {nombre: ruta}")
    if "codigo" not in archivos:
        raise ValueError("archivos debe incluir 'codigo': el código que se ejecuta forma parte de la reserva")
    if not _es_entero(semilla, -(2 ** 63)) or abs(semilla) >= 2 ** 63:  # type: ignore[arg-type]
        raise ValueError("semilla debe ser un entero de 64 bits")
    if not isinstance(punto_entrada, str) or not punto_entrada.isidentifier():
        raise ValueError("punto_entrada debe ser un identificador de Python")
    if not _es_entero(reintentos):
        raise ValueError("reintentos_tras_inicio debe ser un entero ≥ 0")
    if not isinstance(determinismo, bool):
        raise ValueError("verificar_determinismo debe ser true o false")
    if limite is not None and not _es_entero(limite, 1):
        raise ValueError("limite_segundos debe ser None o un entero ≥ 1")
    if reproduccion_de is not None and not _es_hex64(reproduccion_de):
        raise ValueError("reproduccion_de debe ser None o el SHA-256 (hex) del resultado que se reproduce")


def ejecutar(dir_estado: str | Path, experimento: str, archivos: dict[str, str | Path], semilla: int,
             punto_entrada: str = "calcular", ancla: AnclaArchivo | AnclaFirmada | None = None,
             reintentos_tras_inicio: int = 0, fallo: Callable[[str], None] = _nada,
             verificar_determinismo: bool = False, limite_segundos: int | None = None,
             reproduccion_de: str | None = None) -> Salida:
    """``archivos["codigo"]`` es el código que se ejecuta (``punto_entrada(contenidos, semilla)`` en un proceso hijo).
    El cálculo debe ser determinista. ``ancla``: AnclaArchivo (local), AnclaFirmada (cliente externo) o None.
    ``limite_segundos`` y ``reproduccion_de`` (v0.5) forman parte de la reserva."""
    _validar_argumentos(experimento, archivos, semilla, punto_entrada, reintentos_tras_inicio, verificar_determinismo,
                        limite_segundos, reproduccion_de)
    desc = ancla.descripcion if ancla else SIN_ANCLA
    d = Path(dir_estado)
    try:
        _crear_dir(d)
        fallo("antes_del_cerrojo")
        fd = os.open(d / CERROJO, os.O_CREAT | os.O_RDWR, 0o644)
    except OSError as e:
        return Salida("FALLO_ALMACENAMIENTO", detalle=f"directorio de estado inaccesible: {e}", ancla=desc)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return Salida("OCUPADO", detalle="otra ejecución tiene el cerrojo; no se calcula", ancla=desc)
        return _bajo_cerrojo(d, experimento, archivos, semilla, punto_entrada, ancla, reintentos_tras_inicio, fallo,
                             verificar_determinismo, limite_segundos, reproduccion_de)
    finally:
        os.close(fd)


def _bajo_cerrojo(d: Path, experimento: str, archivos: dict[str, str | Path], semilla: int, punto_entrada: str,
                  ancla: AnclaArchivo | AnclaFirmada | None, reintentos: int, fallo: Callable[[str], None],
                  determinismo: bool = False, limite: int | None = None, reproduccion_de: str | None = None) -> Salida:
    desc = ancla.descripcion if ancla else SIN_ANCLA
    try:  # v0.4: una entrada ilegible se rechaza ANTES de tocar ningún estado
        contenidos = {k: Path(p).read_bytes() for k, p in sorted(archivos.items())}
    except OSError as e:
        return Salida("RECHAZADO", detalle=f"entrada ilegible: {e}; no se toca ningún estado", ancla=desc)
    reserva = {"version": VERSION, "experimento": experimento, "semilla": semilla, "punto_entrada": punto_entrada,
               "reintentos_tras_inicio": reintentos, "entorno": _entorno(),
               "archivos_sha256": {k: _sha(v) for k, v in contenidos.items()},
               "ejecutor_sha256": EJECUTOR_SHA256, "ancla": ancla.identidad if ancla else None,
               "verificar_determinismo": determinismo, "limite_segundos": limite, "reproduccion_de": reproduccion_de}
    reserva_sha = _sha(_canon(reserva))
    try:
        return _ciclo(d, reserva, reserva_sha, contenidos, semilla, punto_entrada, ancla, reintentos, fallo,
                      determinismo, desc, limite)
    except OSError as e:  # v0.4: disco lleno, E/S: salida explícita; la próxima llamada concilia como tras una caída
        return Salida("FALLO_ALMACENAMIENTO", detalle=f"{type(e).__name__}: {e}; el estado se concilia en la próxima "
                      "llamada", ancla=desc, reserva_sha256=reserva_sha)


def _ciclo(d: Path, reserva: dict, reserva_sha: str, contenidos: dict[str, bytes], semilla: int,  # noqa: C901
           punto_entrada: str, ancla: AnclaArchivo | AnclaFirmada | None, reintentos: int,
           fallo: Callable[[str], None], determinismo: bool, desc: str, limite: int | None = None) -> Salida:
    ruta = d / DIARIO

    def _s(*a: object, **k: object) -> Salida:  # toda salida lleva su reserva
        k.setdefault("reserva_sha256", reserva_sha)
        k.setdefault("ancla", desc)
        return Salida(*a, **k)  # type: ignore[arg-type]

    def no_disponible(e: AnclaNoDisponible, extra: str = "") -> Salida:
        return _s("ANCLA_NO_AUTENTICA" if isinstance(e, AnclaNoAutentica) else "ANCLA_NO_DISPONIBLE",
                  detalle=f"{e}{extra}")

    try:
        eventos, lineas, cola = _leer_cadena(ruta)
        if cola:
            _descartar_cola(ruta, lineas, eventos, cola)
        _validar_secuencia(eventos)
    except _CadenaRota as e:
        return _s("INCONSISTENTE", detalle=str(e))
    for t in d.glob(".*.tmp"):
        t.unlink()

    def terminal(evento: str, motivo: str, **datos: object) -> Salida:
        _anotar(ruta, lineas, eventos, evento, {"motivo": motivo, **datos})
        return _s(evento, detalle=motivo)

    if not eventos:
        if (d / RESULTADO).exists():
            return _s("INCONSISTENTE", detalle="hay un resultado sin diario")
        if ancla is not None:  # el ancla primero: una reserva en conflicto se rechaza sin dejar estado local
            try:
                st = ancla.consultar(reserva_sha)
                if st["reserva"] and (st["iniciados"] or st["presellado"]):
                    return _s("RECHAZADO", detalle="el ancla registra un cálculo iniciado para esta reserva y falta el "
                                                   "estado local (¿borrado o restaurado?): no se calcula")
                ancla.registrar_reserva(reserva_sha, reserva)
            except AnclaNoDisponible as e:
                return no_disponible(e)
            except AnclaConflicto as e:
                return _s("RECHAZADO", detalle=str(e))
        fallo("antes_de_reservar")
        _reservar(d, reserva, fallo)
        eventos, lineas, _ = _leer_cadena(ruta)

    estado = estado_actual(eventos)
    if estado in ERRORES_TERMINALES:
        _anotar(ruta, lineas, eventos, "INTENTO", {"pid": os.getpid(), "estado_previo": estado})
        return _s(estado, detalle=next(e["datos"].get("motivo", "") for e in eventos if e["evento"] == estado))
    if eventos[0]["datos"] != reserva:
        _anotar(ruta, lineas, eventos, "RECHAZADO_ENTRADAS_DISTINTAS", {"ofrecidas": reserva})
        return _s("RECHAZADO", detalle="entradas, código, semilla, entorno o configuración distintos de los reservados; "
                                       "no se calcula")
    pre = next((e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"), None)
    iniciados_ancla, recibo = 0, None
    if ancla is not None:  # conciliación con el ancla ANTES de calcular o de escribir nada
        try:
            st = ancla.consultar(reserva_sha)
            pre_ancla, iniciados_ancla, recibo = st["presellado"], st["iniciados"], st.get("recibo")
        except AnclaNoDisponible as e:
            return no_disponible(e)
        except AnclaConflicto as e:
            return terminal("INCONSISTENTE", str(e))
        if not st["reserva"]:  # el ancla se registró ANTES que el diario local; si no la conoce, se perdió
            return terminal("INCONSISTENTE", "el ancla no conoce la reserva de un diario local existente: ancla perdida, "
                                             "sustituida o vaciada; no se repara en silencio")
        locales = sum(e["evento"] == "CALCULO_INICIADO" for e in eventos)
        if iniciados_ancla < locales:
            return terminal("INCONSISTENTE", f"el ancla registra {iniciados_ancla} inicio(s) y el diario {locales}: el "
                                             "ancla perdió registros")
        if pre_ancla is not None and pre is None:
            return terminal("INCONSISTENTE", "el ancla tiene un presellado que el diario local no tiene: retroceso, "
                                             "truncamiento o restauración del estado local; no se calcula",
                            presellado_ancla=pre_ancla)
        if pre_ancla is not None and pre_ancla != pre:
            return terminal("INCONSISTENTE", "el presellado del ancla y el del diario local difieren",
                            presellado_ancla=pre_ancla)
    fallo("tras_reservar")
    _anotar(ruta, lineas, eventos, "INTENTO", {"pid": os.getpid(), "estado_previo": estado})

    calculado, crudo = False, None
    if pre is None:
        # el mayor de los dos recuentos: un diario local restaurado no «olvida» cálculos que el ancla registró
        iniciados = max(sum(e["evento"] == "CALCULO_INICIADO" for e in eventos), iniciados_ancla)
        if iniciados > reintentos:
            return terminal("REVISION_HUMANA", f"{iniciados} cálculo(s) iniciado(s) sin presellado: pudieron observar un "
                                               "resultado; otro intento permitiría elegir entre resultados")
        if ancla is not None:
            try:
                ancla.registrar_inicio_calculo(reserva_sha, iniciados + 1)
            except AnclaNoDisponible as e:
                return no_disponible(e, "; no se inicia el cálculo")
            except AnclaConflicto as e:
                return terminal("INCONSISTENTE", str(e))
        _anotar(ruta, lineas, eventos, "CALCULO_INICIADO", {"n": iniciados + 1})
        fallo("tras_iniciar_calculo")
        crudo, motivo = _calcular_aislado(contenidos, semilla, punto_entrada, fallo, limite)
        if crudo is not None and determinismo:  # segundo cálculo independiente ANTES de presellar
            otro, motivo = _calcular_aislado(contenidos, semilla, punto_entrada, _nada, limite)
            if otro is not None and otro != crudo:
                return terminal("NO_DETERMINISTA", "dos cálculos de la misma reserva dieron resultados distintos; no se "
                                                   "presella ninguno", hashes=sorted({_sha(crudo), _sha(otro)}))
            crudo = crudo if otro is not None else None
        if crudo is None:
            _anotar(ruta, lineas, eventos, "CALCULO_FALLIDO", {"motivo": motivo})
            return _s("FALLO_CALCULO", detalle=motivo)
        calculado = True
        fallo("tras_calculo")
        pre = _sha(crudo)
        _anotar(ruta, lineas, eventos, "PRESELLADO", {"resultado_sha256": pre}, fallo, "durante_presellado")
        fallo("tras_presellado")
    if ancla is not None:  # el ancla conoce el hash ANTES de que el resultado exista en disco
        try:
            recibo = ancla.registrar_presellado(reserva_sha, pre) or recibo
        except AnclaNoDisponible as e:
            return no_disponible(e, "; el resultado no se escribe hasta que el ancla confirme el presellado")
        except AnclaConflicto as e:
            return terminal("INCONSISTENTE", str(e))
        fallo("tras_ancla")
        if ancla.emite_recibos:  # v0.4: el recibo firmado se guarda ANTES que el resultado
            if recibo is None:
                return _s("ANCLA_NO_AUTENTICA", detalle="el ancla externa no entregó el recibo del presellado")
            if not (d / RECIBO).exists() or (d / RECIBO).read_bytes() != _canon(recibo):
                _escribir_atomico(d / RECIBO, _canon(recibo), _nada)
    archivo = d / RESULTADO
    if archivo.exists():
        en_disco = archivo.read_bytes()
        if _sha(en_disco) != pre:
            return terminal("CORRUPTO", f"resultado.json ({_sha(en_disco)[:12]}…) no coincide con el presellado "
                                        f"({pre[:12]}…)", encontrado_sha256=_sha(en_disco))
        crudo = en_disco
    else:
        if crudo is None:  # resultado perdido tras el presellado: solo vale el MISMO resultado
            _anotar(ruta, lineas, eventos, "RECALCULO_DE_VERIFICACION", {"resultado_sha256_exigido": pre})
            crudo, motivo = _calcular_aislado(contenidos, semilla, punto_entrada, fallo, limite)
            calculado = True
            if crudo is None or _sha(crudo) != pre:
                return terminal("CONFLICTO", motivo or f"el recálculo ({_sha(crudo)[:12]}…) no reproduce el presellado "  # type: ignore[arg-type]
                                                       f"({pre[:12]}…)")
        _escribir_atomico(archivo, crudo, fallo, "durante_escritura")
        fallo("tras_archivo")
        if any(e["evento"] == "SELLADO" for e in eventos):
            _anotar(ruta, lineas, eventos, "RESTAURADO", {"resultado_sha256": pre})
    if not any(e["evento"] == "SELLADO" for e in eventos):
        _anotar(ruta, lineas, eventos, "SELLADO", {"resultado_sha256": pre})
    if estado != "REGISTRADO":
        _anotar(ruta, lineas, eventos, "REGISTRADO", {"resultado_sha256": pre}, fallo, "durante_registro")
    return _s("REGISTRADO", json.loads(crudo), pre, calculado, recibo_ancla=recibo)


def leer(dir_estado: str | Path) -> dict:
    """Solo lectura: estado del diario, eventos, si resultado.json coincide con el presellado y (v0.5) la reserva y su
    SHA-256, que P1 necesita para ligar un recibo del ancla a ESTA ejecución."""
    d = Path(dir_estado)
    try:
        eventos, _, cola = _leer_cadena(d / DIARIO)
        _validar_secuencia(eventos)
        archivo = d / RESULTADO
        en_disco = archivo.read_bytes() if archivo.exists() else None
    except _CadenaRota as e:
        return {"estado": "INCONSISTENTE", "detalle": str(e)}
    except OSError as e:
        return {"estado": "ILEGIBLE", "detalle": f"{type(e).__name__}: {e}"}
    pre = next((e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"), None)
    reserva = eventos[0]["datos"] if eventos else None
    return {"estado": estado_actual(eventos), "eventos": [e["evento"] for e in eventos], "cola_rota": bool(cola),
            "presellado": pre, "archivo_coincide": en_disco is not None and _sha(en_disco) == pre,
            "reserva": reserva, "reserva_sha256": _sha(_canon(reserva)) if reserva is not None else None}
