"""Compara dos ejecuciones de ``ejecutar_todo.sh`` (dos carpetas ``evidencia/``) por su CONTENIDO SEMÁNTICO: los
resúmenes de pytest, las matrices, las mutaciones, los escenarios de fallos y de corte de energía, las regresiones,
los parches, la integridad y el estado de git. Ignora tiempos, rutas temporales, fechas y direcciones de memoria.
Uso: python3 comparar_evidencias.py <evidencia_A> <evidencia_B>   (salida 0 si coinciden)"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

RESUMENES = ["11_suite_v0_5.txt", "13_repeticiones.txt", "22_regresion_p1_v0_3_sin_modificar_contra_v0_5.txt",
             "23_regresion_p1_v0_3_portadas_contra_v0_5.txt", "24_regresion_p2_v0_3_sin_modificar_contra_v0_5.txt",
             "25_regresion_p4_v0_3_sin_modificar_contra_v0_5.txt", "26_regresion_cruzada_v0_3_sin_modificar_contra_v0_5.txt",
             "27_regresion_suite_v0_4_sin_modificar_contra_v0_5.txt", "61_parche_aplicado_en_HEAD_pytest.txt",
             "61_parche_aplicado_en_origin_pytest.txt", "70_ed25519_diferencial.txt"]
TEXTOS = ["12_ruff.txt", "05_trazabilidad_regenerada.txt", "27_regresion_suite_v0_4_fallidas.txt",
          "31_p2_mutaciones_oraculo.txt", "32_p2_tabla_resumen.txt", "41_paquetes_previos_intactos.txt",
          "60_parches_comprobacion.txt", "98_integridad_final.txt", "99_estado_git_comparado.txt"]
# 90/91 (huella del repositorio antes y después) se comparan DENTRO de cada ejecución (99_*): su formato puede variar.
MUTACIONES = ["52_cruzada_mutaciones.txt", "53_durabilidad_mutaciones.txt", "54_ejecutor_mutaciones.txt"]


def _norm(t: str) -> str:
    t = re.sub(r" in [0-9.]+s( \([0-9:]+\))?", "", t)
    t = re.sub(r"/tmp/\S*|/home/\S*", "<ruta>", t)
    t = re.sub(r"\d{4}-\d{2}-\d{2}T[0-9:.]+Z?", "<fecha>", t)
    return re.sub(r"0x[0-9a-f]+", "0x…", t)


def _resumen(p: Path) -> str:
    lineas = [x for x in p.read_text(encoding="utf-8", errors="replace").splitlines()
              if re.search(r"\b(passed|failed|skipped|error)\b", x) or x.startswith("código de salida")]
    return _norm("\n".join(lineas))


def _mutaciones(p: Path) -> list[tuple[str, str]]:
    return [(x.split("\t")[0], x.split("\t")[1]) for x in p.read_text(encoding="utf-8").splitlines() if "\t" in x]


def _escenarios(p: Path) -> list:
    return [(json.dumps(r.get("plan") or [r.get(k) for k in ("op", "n", "datos", "directorio")], sort_keys=True),
             tuple(r["salidas"]), r["calculos"], bool(r["violaciones"])) for r in json.loads(p.read_text())]


def main(a: Path, b: Path) -> int:
    filas, malas = [], 0

    def comparar(nombre: str, x: object, y: object) -> None:
        nonlocal malas
        igual = x == y
        malas += not igual
        filas.append(f"{'IGUAL ' if igual else 'DIFIERE'}  {nombre}")

    for f in RESUMENES:
        comparar(f, _resumen(a / f), _resumen(b / f))
    for f in TEXTOS:
        comparar(f, _norm((a / f).read_text(encoding="utf-8")), _norm((b / f).read_text(encoding="utf-8")))
    for f in MUTACIONES:
        comparar(f, _mutaciones(a / f), _mutaciones(b / f))
    m = "10_matriz_antes_despues"
    comparar(f"{m}/filas", [x for x in (a / m / "MATRIZ_ANTES_DESPUES.md").read_text().splitlines() if x.startswith("| P")
                            and "(" in x], [x for x in (b / m / "MATRIZ_ANTES_DESPUES.md").read_text().splitlines()
                                            if x.startswith("| P") and "(" in x])
    for d, patron in ((m, "fallos_es_*.json"), ("14_corte_energia", "corte_*.json")):
        nombres = sorted(p.name for p in (a / d).glob(patron))
        comparar(f"{d}/{patron} (archivos)", nombres, sorted(p.name for p in (b / d).glob(patron)))
        for n in nombres:
            comparar(f"{d}/{n}", _escenarios(a / d / n), _escenarios(b / d / n))
    ea, eb = json.loads((a / "80_estado_real_de_T.json").read_text()), json.loads((b / "80_estado_real_de_T.json").read_text())
    comparar("80_estado_real_de_T.json", {k: ea[k] for k in ("estado_p1", "motivos_p1", "estado_p2", "dimensiones",
                                                              "archivos_leidos_sin_cambios", "resultado_sha256")},
             {k: eb[k] for k in ("estado_p1", "motivos_p1", "estado_p2", "dimensiones", "archivos_leidos_sin_cambios",
                                 "resultado_sha256")})
    print("\n".join(filas))
    print(f"{len(filas) - malas} de {len(filas)} comparaciones iguales")
    return 1 if malas else 0


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]), Path(sys.argv[2])))
