# Procedencia de `experimentos/calidad_datos.json` y de `contraste_btc_diario_vs_horario`

**Estado: productor LOCALIZADO, procedencia NO VERIFICADA.** No es evidencia de T. P1 v0.4 lo informa como
INCONCLUSO (`PROCEDENCIA_NO_VERIFICADA`) y P2 no lo acepta.

## El archivo
| Dato | Valor | Cómo se obtuvo |
|---|---|---|
| Ruta | `research/tendencia_btc/experimentos/calidad_datos.json` | — |
| SHA-256 | `88644d85d82af3c91b851b33864a5caefb4e1c73fa12c6c4fee0febef7640f83` | `sha256sum` (solo lectura) |
| Blob de git | `2a169f3bc0da8d5c7cec67cc4be438427b1ee20c`, el mismo en 5120d4c, 89278f7, c6339e3, f518ac1 y 692f2b2 | `git rev-parse <commit>:<ruta>` |
| Commit que lo introdujo | `5120d4c` (2026-10-17T05:19:16Z) | `git log --all -- <ruta>` |
| Código que lo produce en git | **ninguno**: ningún archivo de ningún commit contiene `contraste_btc`, `diario_vs_horario` ni `sin_horaria` | `git log --all -S`, `git grep` en todos los commits |

## El productor (recuperado de la transcripción LOCAL de la sesión)
Fue una orden ad hoc ejecutada el **2026-10-17T01:27:24Z** (línea 3244 de la transcripción; SHA-256 de esa línea
`c6e6f6779ffcbbc32f76c310ec215b96fb16585bee76e3fa822916bd18cba570`; salida en la línea 3245, SHA-256
`769e856c4dc7a2509fd7f748f0c517ca96846c82d23ccdced32a86062d0bcaf5`). La transcripción es un registro local y modificable:
sirve para la trazabilidad, **no** es una raíz de confianza.

Las auditorías anteriores (v0.1–v0.3) dijeron que el productor «no está en el repositorio, en el historial de git ni en
el scratchpad». Era cierto pero incompleto: no se había buscado en la transcripción.

**El código se transcribe solo para documentarlo. NO debe ejecutarse:** leería datos de mercado y sobrescribiría el
archivo congelado.

```
cd /home/user/Trader-IA/research/tendencia_btc; PYTHONPATH=src:../hcarry_next/src ../hcarry_next/.venv/bin/python -B - <<'EOF'
import json
from pathlib import Path
from tendencia.datos import leer
from hcarry.data.binance_vision import leer_manifiesto, leer_klines
out = {}
for s in ("BTCUSDT", "ETHUSDT"):
    v, inf = leer(Path(f"datos/{s}"))
    out[s] = inf
    print(s, {k: (len(x) if isinstance(x, list) else x) for k, x in inf.items() if k != "manifiesto_sha256"}, inf["duracion_irregular"][:10])
# contraste: cierre diario BTC = cierre de la vela horaria de las 23:00 (pipeline de H-CARRY, archivos distintos)
v, _ = leer(Path("datos/BTCUSDT")); diarias = {x.dia: x for x in v}
d = Path("../hcarry_next/datos/binance_vision"); man = leer_manifiesto(d)
horas = {}
for a in man["archivos"]:
    if a["tipo"] == "spot" and a.get("granularidad") != "diaria":
        horas.update(leer_klines((d / a["ruta"]).read_bytes(), irregulares=[]))
import datetime as dt
comp = dif = sin = 0; ejemplos = []
for dia, x in diarias.items():
    t23 = int(dt.datetime.fromisoformat(dia + "T23:00:00+00:00").timestamp() * 1000)
    t00 = int(dt.datetime.fromisoformat(dia + "T00:00:00+00:00").timestamp() * 1000)
    if t23 in horas and t00 in horas:
        comp += 1
        if abs(horas[t23][3] - x.c) > 1e-9 or abs(horas[t00][0] - x.o) > 1e-9:
            dif += 1; ejemplos.append((dia, x.o, horas[t00][0], x.c, horas[t23][3]))
    elif dia >= "2019-10-01":
        sin += 1
print("contraste diario vs horario: días comparados", comp, "· distintos", dif, "· sin vela 00h o 23h", sin, ejemplos[:5])
out["contraste_btc_diario_vs_horario"] = {"comparados": comp, "distintos": dif, "sin_horaria": sin, "ejemplos": ejemplos[:10]}
Path("experimentos/calidad_datos.json").write_text(json.dumps(out, indent=1, ensure_ascii=False))
EOF
```

Salida registrada:
```
BTCUSDT {'simbolo': 'BTCUSDT', 'archivos': 106, 'meses_no_publicados': 0, 'primer_dia': '2017-08-17', 'ultimo_dia': '2026-05-31', 'dias': 3210, 'dias_ausentes': 0, 'duracion_irregular': 0, 'repetidas': 0, 'ohlc_incoherente': 0, 'precio_no_positivo': 0, 'apto': True} []
ETHUSDT {'simbolo': 'ETHUSDT', 'archivos': 106, 'meses_no_publicados': 0, 'primer_dia': '2017-08-17', 'ultimo_dia': '2026-05-31', 'dias': 3210, 'dias_ausentes': 0, 'duracion_irregular': 0, 'repetidas': 0, 'ohlc_incoherente': 0, 'precio_no_positivo': 0, 'apto': True} []
contraste diario vs horario: días comparados 2435 · distintos 0 · sin vela 00h o 23h 0 []
```

## Qué mide realmente
- Para cada vela diaria de BTCUSDT (3.210 días, 2017-08-17 → 2026-05-31) compara la **apertura diaria** con la apertura
  de la vela horaria de las 00:00 y el **cierre diario** con el cierre de la vela horaria de las 23:00. Las velas horarias
  salen del pipeline de H-CARRY (`hcarry_next/datos/binance_vision`, solo archivos mensuales). La tolerancia absoluta es 1e-9.
- `comparados = 2435` son los días que tienen ambas velas horarias: exactamente del 2019-10-01 al 2026-05-31.
- `distintos = 0`.
- `sin_horaria = 0` cuenta **solo los días desde el 2019-10-01** que no tienen alguna de esas velas. Los **775 días**
  del 2017-08-17 al 2019-09-30 no se cuentan ni como comparados ni como `sin_horaria`. El nombre sugiere una cobertura
  completa que no existe.
- No compara máximos, mínimos ni volumen.
- Ambas series vienen del mismo proveedor (Binance): **no es un contraste con una fuente independiente**.
- La ventana fuera de muestra de T (2022-01-01 → 2026-06-01) está dentro del tramo comparado. El tramo de desarrollo
  anterior a 2019-10-01 no lo está.

## Por qué la cobertura empieza en 2019-10 (v0.5, solo metadatos)
- El productor lee las velas horarias **spot** mensuales de `hcarry_next/datos/binance_vision`: 80 archivos, de 2019-10
  a 2026-05. Su manifiesto declara `desde: 2019-10`: la descarga de H-CARRY se pidió desde esa fecha.
- **Ninguno** de los 10 manifiestos locales lista velas horarias de BTCUSDT anteriores a 2019-10.
- Por eso no hay con qué comparar los 775 días del 2017-08-17 al 2019-09-30.
- Evidencia, con el SHA-256 de cada manifiesto: `evidencia/06_cobertura_contraste_btc_manifiestos.txt` del paquete v0.5.
  No se leyó ningún byte de datos de mercado.

## Qué haría falta para verificarlo (requiere autorización)
1. **B-4:** autorizar la lectura de los datos y ejecutar el código recuperado en una copia aislada, comparando los
   bytes de su salida con el SHA-256 de arriba.
2. **B-1:** versionar el productor (por ejemplo, como experimento con su propio prerregistro).

Hasta entonces, el valor es **NO_VERIFICADO** y no se usa como evidencia.
