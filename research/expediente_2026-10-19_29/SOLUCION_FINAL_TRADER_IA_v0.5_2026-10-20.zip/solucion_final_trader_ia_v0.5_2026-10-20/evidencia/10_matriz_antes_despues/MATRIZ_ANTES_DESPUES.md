# Matriz antes / después de los defectos (salida real de pytest)

Patrón: S* falla en v0.2 y pasa en v0.3–v0.5 · N* falla en v0.3 y pasa en v0.4–v0.5 · F* falla en v0.4 y pasa en v0.5 (en v0.2–v0.3: «*», sin exigencia) · control pasa.

| Defecto | v0.2 | v0.3 | v0.4 | v0.5 | Cumple el patrón |
|---|---|---|---|---|---|
| P1-F1 | FALLA (0/2 pasan) | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | sí |
| P1-F11 | FALLA (0/4 pasan) | FALLA (0/4 pasan) | FALLA (0/4 pasan) | PASA (4/4 pasan) | sí |
| P1-F12 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | sí |
| P1-F2 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | sí |
| P1-F3 | FALLA (0/3 pasan) | FALLA (0/3 pasan) | FALLA (0/3 pasan) | PASA (3/3 pasan) | sí |
| P1-F4 | FALLA (0/2 pasan) | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | sí |
| P1-F5 | FALLA (0/2 pasan) | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | sí |
| P1-N1 | FALLA (0/5 pasan) | FALLA (0/5 pasan) | PASA (5/5 pasan) | PASA (5/5 pasan) | sí |
| P1-N2 | FALLA (0/4 pasan) | FALLA (0/4 pasan) | PASA (4/4 pasan) | PASA (4/4 pasan) | sí |
| P1-N3 | FALLA (0/3 pasan) | FALLA (0/3 pasan) | PASA (3/3 pasan) | PASA (3/3 pasan) | sí |
| P1-N4 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P1-S1 | FALLA (0/6 pasan) | PASA (6/6 pasan) | PASA (6/6 pasan) | PASA (6/6 pasan) | sí |
| P1-S2 | MIXTO (1/8 pasan) | PASA (8/8 pasan) | PASA (8/8 pasan) | PASA (8/8 pasan) | sí |
| P1-S3 | MIXTO (1/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | sí |
| P1-S4 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P1-S5 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P1-S6 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P1-S7 | MIXTO (1/7 pasan) | PASA (7/7 pasan) | PASA (7/7 pasan) | PASA (7/7 pasan) | sí |
| P1-S8 | MIXTO (1/3 pasan) | PASA (3/3 pasan) | PASA (3/3 pasan) | PASA (3/3 pasan) | sí |
| P1-control | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P2-F3 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | sí |
| P2-N1 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P2-N2 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P2-N3 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P2-N4 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P2-N5 | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | sí |
| P2-S1 | FALLA (0/3 pasan) | PASA (3/3 pasan) | PASA (3/3 pasan) | PASA (3/3 pasan) | sí |
| P2-S2 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P2-S3 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P2-S4 | FALLA (0/8 pasan) | PASA (8/8 pasan) | PASA (8/8 pasan) | PASA (8/8 pasan) | sí |
| P2-S5 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P4-F1 | FALLA (0/2 pasan) | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | sí |
| P4-F10 | PASA (1/1 pasan) | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | sí |
| P4-F14 | FALLA (0/6 pasan) | FALLA (0/6 pasan) | FALLA (0/6 pasan) | PASA (6/6 pasan) | sí |
| P4-F6 | FALLA (0/2 pasan) | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | sí |
| P4-F7 | FALLA (0/5 pasan) | FALLA (0/5 pasan) | FALLA (0/5 pasan) | PASA (5/5 pasan) | sí |
| P4-F8 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | sí |
| P4-N1 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P4-N1/N2 (sistemática) | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | sí |
| P4-N2 | FALLA (0/2 pasan) | FALLA (0/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | sí |
| P4-N3 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P4-N4 | FALLA (0/1 pasan) | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P4-S1 | MIXTO (1/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | sí |
| P4-S2 | FALLA (0/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | PASA (2/2 pasan) | sí |
| P4-S3 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P4-S4 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P4-S5 | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |
| P4-control | FALLA (0/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | PASA (1/1 pasan) | sí |

## Detalle por prueba

| Prueba | v0.2 | v0.3 | v0.4 | v0.5 |
|---|---|---|---|---|
| `test_P1_F11_fecha_utc_en_una_sola_forma[2026-10-20T00:00Z]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P1_F11_fecha_utc_en_una_sola_forma[2026-10-20Z]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P1_F11_fecha_utc_en_una_sola_forma[2026-W43-2T00:00:00Z]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P1_F11_fecha_utc_en_una_sola_forma[20261020T000000Z]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'C' | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P1_F12_un_error_de_uso_no_oculta_un_corrupto` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AssertionError: ['USO'] | PASA |
| `test_P1_F1_raiz_de_orden_pequeno_no_autentica_una_falsificacion[ceros]` | FALLA: AttributeError: <module 'verificar_reproduccion_T' from '/tmp/claude-0/-home-user-Trader-IA/adb27888-5c6a-556a-b45b-2427c90ef46b/scratchpad/ | FALLA: AttributeError: <module 'verificar_reproduccion_T' from '/tmp/claude-0/-home-user-Trader-IA/adb27888-5c6a-556a-b45b-2427c90ef46b/scratchpad/ | FALLA: AssertionError: ['falsa_2 (emisor R, propietario, ed25519:66687aadf862bd776c8fc18b8e9f8e20)', 'falsa_5 (emisor R, propietario, ed25519:66687 | PASA |
| `test_P1_F1_raiz_de_orden_pequeno_no_autentica_una_falsificacion[neutro]` | FALLA: AttributeError: <module 'verificar_reproduccion_T' from '/tmp/claude-0/-home-user-Trader-IA/adb27888-5c6a-556a-b45b-2427c90ef46b/scratchpad/ | FALLA: AttributeError: <module 'verificar_reproduccion_T' from '/tmp/claude-0/-home-user-Trader-IA/adb27888-5c6a-556a-b45b-2427c90ef46b/scratchpad/ | FALLA: AssertionError: ['falsa_0 (emisor R, propietario, ed25519:01d0fabd251fcbbe2b93b4b927b26ad2)', 'falsa_1 (emisor R, propietario, ed25519:01d0f | PASA |
| `test_P1_F2_recibo_de_una_reserva_cualquiera_no_autentica` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: AssertionError: assert 'VERIFICADO' == 'INCONCLUSO' | PASA |
| `test_P1_F3_reproduccion_no_autenticada_no_da_reproducido[copia_del_original]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AssertionError: REPRODUCIDO | PASA |
| `test_P1_F3_reproduccion_no_autenticada_no_da_reproducido[inventada_distinta]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AssertionError: NO_REPRODUCIDO | PASA |
| `test_P1_F3_reproduccion_no_autenticada_no_da_reproducido[inventada_igual]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_reproduccion' | FALLA: AssertionError: REPRODUCIDO | PASA |
| `test_P1_F4_declaracion_mal_formada_no_oculta_un_corrupto[anidamiento_extremo]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: AssertionError: assert ('INCONCLUSO'...RROR_INTERNO') == ('CORRUPTO', ...H_REFERENCIA') | PASA |
| `test_P1_F4_declaracion_mal_formada_no_oculta_un_corrupto[sustituto_suelto]` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: AssertionError: assert ('INCONCLUSO'...RROR_INTERNO') == ('CORRUPTO', ...H_REFERENCIA') | PASA |
| `test_P1_F5_linea_de_ordenes_no_termina_con_la_salida_de_corrupto_por_un_error` | FALLA: assert (2 == 3) | FALLA: assert (2 == 3) | FALLA: RecursionError: maximum recursion depth exceeded while decoding a JSON array from a unicode string | PASA |
| `test_P1_F5_resultado_anidado_en_exceso_es_un_estado` | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: AttributeError: module 'verificar_reproduccion_T' has no attribute 'evaluar_archivo' | FALLA: RecursionError: maximum recursion depth exceeded while decoding a JSON array from a unicode string | PASA |
| `test_P1_N1_alteracion_conjunta_de_archivos_y_manifiesto_no_es_verificado` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | PASA | PASA |
| `test_P1_N1_declaracion_firmada_del_original_detecta_la_sustitucion` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._REFERENCIA']) | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._REFERENCIA']) | PASA | PASA |
| `test_P1_N1_sin_firma_de_una_raiz_aprobada_no_hay_verificado[clave_intrusa]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | PASA | PASA |
| `test_P1_N1_sin_firma_de_una_raiz_aprobada_no_hay_verificado[emisor_no_aprobado]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | PASA | PASA |
| `test_P1_N1_sin_firma_de_una_raiz_aprobada_no_hay_verificado[sin_raices_aprobadas]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | FALLA: AssertionError: assert ('VERIFICADO', []) == ('INCONCLUSO'...DEPENDIENTE']) | PASA | PASA |
| `test_P1_N2_cli_distingue_corrupto_de_inconcluso` | FALLA: AssertionError: assert (1, 'RECHAZADO') == (3, 'INCONCLUSO') | FALLA: AssertionError: assert (1, 'RECHAZADO') == (3, 'INCONCLUSO') | PASA | PASA |
| `test_P1_N2_manifiesto_ilegible_es_inconcluso_no_corrupto` | FALLA: AssertionError: assert (2, None) == (3, 'INCONCLUSO') | FALLA: AssertionError: assert (1, 'RECHAZADO') == (3, 'INCONCLUSO') | PASA | PASA |
| `test_P1_N2_reproduccion_invalida_no_marca_corrupto_al_original` | FALLA: AssertionError: assert ('EXCEPCION',...ributeError']) == ('INCONCLUSO'...N_NO_VALIDA']) | FALLA: AssertionError: assert ('CORRUPTO', ..._INESPERADA']) == ('INCONCLUSO'...N_NO_VALIDA']) | PASA | PASA |
| `test_P1_N2_una_falta_no_oculta_una_corrupcion` | FALLA: AssertionError: assert ('INCONCLUSO'...IVO_AUSENTE']) == ('CORRUPTO', ['HASH']) | FALLA: AssertionError: assert ('INCONCLUSO'...IVO_AUSENTE']) == ('CORRUPTO', ['HASH']) | PASA | PASA |
| `test_P1_N3_rama_b_sin_reservado_fin` | FALLA: AssertionError: assert ('VERIFICADO' == 'INCONCLUSO' | FALLA: AssertionError: assert ('EXCEPCION' == 'INCONCLUSO' | PASA | PASA |
| `test_P1_N3_script_con_codigo_no_literal` | FALLA: AssertionError: assert (0, 'VERIFICADO') == (3, 'INCONCLUSO') | FALLA: AssertionError: assert (1, None) == (3, 'INCONCLUSO') | PASA | PASA |
| `test_P1_N3_tabla_del_corte_no_utf8` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ['TIPO']) | FALLA: AssertionError: assert ('EXCEPCION',...DecodeError']) == ('CORRUPTO', ['TIPO']) | PASA | PASA |
| `test_P1_N4_reproduccion_compara_los_bytes_evaluados` | FALLA: AssertionError: assert 'EXCEPCION' == 'REPRODUCIDO' | FALLA: AssertionError: assert 'NO_REPRODUCIDO' == 'REPRODUCIDO' | PASA | PASA |
| `test_P1_S1_clave_inesperada[costes_SOL]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._INESPERADA']) | PASA | PASA | PASA |
| `test_P1_S1_clave_inesperada[decision_suelta]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._INESPERADA']) | PASA | PASA | PASA |
| `test_P1_S1_clave_inesperada[manifiesto_SOL]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._INESPERADA']) | PASA | PASA | PASA |
| `test_P1_S1_clave_inesperada[p_alternativa]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._INESPERADA']) | PASA | PASA | PASA |
| `test_P1_S1_clave_inesperada[secundario_extra]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._INESPERADA']) | PASA | PASA | PASA |
| `test_P1_S1_clave_inesperada[simbolo_SOL]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._INESPERADA']) | PASA | PASA | PASA |
| `test_P1_S2_simbolo_eth_validado[principal.ETH.ic90_anual-valor1-RANGO]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ['RANGO']) | PASA | PASA | PASA |
| `test_P1_S2_simbolo_eth_validado[principal.ETH.p-1.5-RANGO]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ['RANGO']) | PASA | PASA | PASA |
| `test_P1_S2_simbolo_eth_validado[secundarios.costes_x2.BTC-0.06-TIPO]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ['TIPO']) | PASA | PASA | PASA |
| `test_P1_S2_simbolo_o_campo_faltante[categoria]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ...AVE_AUSENTE']) | PASA | PASA | PASA |
| `test_P1_S2_simbolo_o_campo_faltante[manifiestos_sha256.ETHUSDT]` | PASA | PASA | PASA | PASA |
| `test_P1_S2_simbolo_o_campo_faltante[principal.ETH.p]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ...AVE_AUSENTE']) | PASA | PASA | PASA |
| `test_P1_S2_simbolo_o_campo_faltante[principal.ETH]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ...AVE_AUSENTE']) | PASA | PASA | PASA |
| `test_P1_S2_simbolo_o_campo_faltante[secundarios.costes_x2.ETH]` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ...AVE_AUSENTE']) | PASA | PASA | PASA |
| `test_P1_S3_resultado_sustituido_frente_al_presellado` | PASA | PASA | PASA | PASA |
| `test_P1_S3_script_y_resultado_falsificados_frente_al_manifiesto` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ..._MANIFIESTO']) | PASA | PASA | PASA |
| `test_P1_S4_codigo_del_resultado_igual_al_fijado_en_el_script` | FALLA: AssertionError: assert ('VERIFICADO', []) == ('CORRUPTO', ...NTRADICCION']) | PASA | PASA | PASA |
| `test_P1_S5_comparar_mira_todas_las_hojas` | FALLA: assert False | PASA | PASA | PASA |
| `test_P1_S6_reproducido_solo_tras_verificado_y_comparacion_completa` | FALLA: AssertionError: assert 'EXCEPCION' == 'REPRODUCIDO' | PASA | PASA | PASA |
| `test_P1_S7_control_corte_real_simulado_verificado` | PASA | PASA | PASA | PASA |
| `test_P1_S7_tablas_y_datos_del_corte[columna_cambiada-CORRUPTO-ESQUEMA]` | FALLA: AssertionError: assert ('VERIFICADO' == 'CORRUPTO' | PASA | PASA | PASA |
| `test_P1_S7_tablas_y_datos_del_corte[dia_saltado-CORRUPTO-CONTRADICCION]` | FALLA: AssertionError: assert ('VERIFICADO' == 'CORRUPTO' | PASA | PASA | PASA |
| `test_P1_S7_tablas_y_datos_del_corte[fila_borrada-CORRUPTO-CONTRADICCION]` | FALLA: AssertionError: assert ('VERIFICADO' == 'CORRUPTO' | PASA | PASA | PASA |
| `test_P1_S7_tablas_y_datos_del_corte[manifiesto_de_datos-CORRUPTO-HASH]` | FALLA: AssertionError: assert ('VERIFICADO' == 'CORRUPTO' | PASA | PASA | PASA |
| `test_P1_S7_tablas_y_datos_del_corte[tabla_ausente-INCONCLUSO-ARCHIVO_AUSENTE]` | FALLA: AssertionError: assert ('VERIFICADO' == 'INCONCLUSO' | PASA | PASA | PASA |
| `test_P1_S7_tablas_y_datos_del_corte[valor_cambiado-CORRUPTO-HASH]` | FALLA: AssertionError: assert ('VERIFICADO' == 'CORRUPTO' | PASA | PASA | PASA |
| `test_P1_S8_inicio_contra_el_prerregistro[A-2026-10-19-CORRUPTO]` | FALLA: AssertionError: assert ('VERIFICADO' == 'CORRUPTO' | PASA | PASA | PASA |
| `test_P1_S8_inicio_contra_el_prerregistro[B-2027-01-01-CORRUPTO]` | FALLA: AssertionError: assert ('VERIFICADO' == 'CORRUPTO' | PASA | PASA | PASA |
| `test_P1_S8_inicio_contra_el_prerregistro[B-2027-04-13-VERIFICADO]` | PASA | PASA | PASA | PASA |
| `test_P1_control_resultado_valido_y_firmado_es_verificado` | PASA | PASA | PASA | PASA |
| `test_P2_F3_reproduccion_no_autenticada_no_es_evidencia_valida` | FALLA: TypeError: aplicar() got an unexpected keyword argument 'declaraciones' | FALLA: TypeError: aplicar() got an unexpected keyword argument 'declaraciones' | FALLA: AssertionError: assert 'REPRODUCIDO' not in ('VERIFICADO', 'REPRODUCIDO', 'NO_REPRODUCIDO') | PASA |
| `test_P2_N1_no_hay_evidencia_publica_sin_pasar_por_P1` | FALLA: AssertionError: assert {'aplicar', '...', 'robustez'} == {'desde_resul...', 'robustez'} | FALLA: Failed: DID NOT RAISE any of (AttributeError, ErrorPolitica) | PASA | PASA |
| `test_P2_N2_inicio_de_ventana_de_los_bytes_verificados` | FALLA: AttributeError: module 'politica_avance_T' has no attribute 'AUTORIZACIONES' | FALLA: assert False is True | PASA | PASA |
| `test_P2_N3_registros_no_inyectables` | FALLA: assert not True | FALLA: assert not True | PASA | PASA |
| `test_P2_N4_evaluacion_ligada_al_resultado` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | FALLA: Failed: DID NOT RAISE ErrorPolitica | PASA | PASA |
| `test_P2_N5_autorizacion_para_una_etapa_no_definida` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | FALLA: Failed: DID NOT RAISE ErrorPolitica | PASA | PASA |
| `test_P2_N5_definicion_registrada_con_otra_clave` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | FALLA: Failed: DID NOT RAISE ErrorPolitica | PASA | PASA |
| `test_P2_S1_evidencia_no_valida_no_da_etiqueta[CORRUPTO]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S1_evidencia_no_valida_no_da_etiqueta[INCONCLUSO]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S1_evidencia_no_valida_no_da_etiqueta[NO_REPRODUCIDO]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S2_r1_r3_obligatorios_y_coherentes` | FALLA: politica_avance_T.ErrorPolitica: etiqueta estadística desconocida (se exige el texto literal del productor): None | PASA | PASA | PASA |
| `test_P2_S3_autorizacion_constatada_nunca_otorgada` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_fecha_de_aprobacion_invalida[1]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_fecha_de_aprobacion_invalida[2021-12-31T23:00:00]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_fecha_de_aprobacion_invalida[2021-12-31]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_fecha_de_aprobacion_invalida[ayer]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_post_hoc_con_fechas_reales[2021-12-31T23:59:59Z-False]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_post_hoc_con_fechas_reales[2022-01-01T00:00:00Z-True]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_post_hoc_con_fechas_reales[2022-01-01T01:00:00+02:00-False]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S4_post_hoc_con_fechas_reales[2026-10-20T10:00:00+02:00-True]` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P2_S5_hash_del_texto_validado` | FALLA: NotImplementedError: la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia | PASA | PASA | PASA |
| `test_P4_F10_sin_directorio_huerfano_si_el_padre_muere` | PASA | FALLA: AssertionError: assert [PosixPath('/...lo_zhl1lqh1')] == [] | FALLA: AssertionError: assert [PosixPath('/...lo_wa4_juds')] == [] | PASA |
| `test_P4_F14_argumentos_invalidos[cambio0]` | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P4_F14_argumentos_invalidos[cambio1]` | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P4_F14_argumentos_invalidos[cambio2]` | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P4_F14_argumentos_invalidos[cambio3]` | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P4_F14_argumentos_invalidos[cambio4]` | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | FALLA: Failed: DID NOT RAISE ValueError | PASA |
| `test_P4_F14_argumentos_invalidos[cambio5]` | FALLA: TypeError: expected str, bytes or os.PathLike object, not int | FALLA: TypeError: expected str, bytes or os.PathLike object, not int | FALLA: TypeError: expected str, bytes or os.PathLike object, not int | PASA |
| `test_P4_F1_ancla_firmada_no_acepta_clave_de_orden_pequeno[0000000000000000000000000000000000000000000000000000000000000000]` | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: AssertionError: 40 respuestas falsificadas aceptadas | PASA |
| `test_P4_F1_ancla_firmada_no_acepta_clave_de_orden_pequeno[0100000000000000000000000000000000000000000000000000000000000000]` | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: AssertionError: 128 respuestas falsificadas aceptadas | PASA |
| `test_P4_F6_respuesta_hostil_del_ancla_da_una_salida[anidamiento_extremo]` | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: RecursionError: maximum recursion depth exceeded while calling a Python object | PASA |
| `test_P4_F6_respuesta_hostil_del_ancla_da_una_salida[sustituto_suelto]` | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: AttributeError: module 'uso_unico' has no attribute 'AnclaFirmada' | FALLA: UnicodeEncodeError: 'utf-8' codec can't encode character '\ud800' in position 6: surrogates not allowed | PASA |
| `test_P4_F7_eventos_mal_formados_dan_un_estado_terminal[ancla_datos_no_objeto]` | FALLA: AttributeError: 'str' object has no attribute 'get' | FALLA: AttributeError: 'str' object has no attribute 'get' | FALLA: AttributeError: 'str' object has no attribute 'get' | PASA |
| `test_P4_F7_eventos_mal_formados_dan_un_estado_terminal[ancla_presellado_sin_hash]` | FALLA: KeyError: 'resultado_sha256' | FALLA: KeyError: 'resultado_sha256' | FALLA: KeyError: 'resultado_sha256' | PASA |
| `test_P4_F7_eventos_mal_formados_dan_un_estado_terminal[diario_datos_no_objeto]` | FALLA: TypeError: list indices must be integers or slices, not str | FALLA: TypeError: list indices must be integers or slices, not str | FALLA: TypeError: list indices must be integers or slices, not str | PASA |
| `test_P4_F7_eventos_mal_formados_dan_un_estado_terminal[diario_presellado_sin_hash]` | FALLA: KeyError: 'resultado_sha256' | FALLA: KeyError: 'resultado_sha256' | FALLA: KeyError: 'resultado_sha256' | PASA |
| `test_P4_F7_eventos_mal_formados_dan_un_estado_terminal[diario_sin_evento]` | FALLA: KeyError: 'evento' | FALLA: KeyError: 'evento' | FALLA: KeyError: 'evento' | PASA |
| `test_P4_F8_limite_de_tiempo_del_calculo` | FALLA: AssertionError: {'estado': 'MURIO(1)', 'stderr': 'Traceback (most recent call last): | FALLA: AssertionError: {'estado': 'MURIO(1)', 'stderr': 'Traceback (most recent call last): | FALLA: AssertionError: {'estado': 'MURIO(1)', 'stderr': 'Traceback (most recent call last): | PASA |
| `test_P4_N1_escritura_corta_del_diario` | FALLA: AssertionError: assert 'INCONSISTENTE' == 'REGISTRADO' | FALLA: AssertionError: assert 'INCONSISTENTE' == 'REGISTRADO' | PASA | PASA |
| `test_P4_N2_disco_lleno_al_presellar_va_a_revision_humana` | FALLA: AssertionError: assert ('MURIO(1)' == 'FALLO_ALMACENAMIENTO' | FALLA: AssertionError: assert ('MURIO(1)' == 'FALLO_ALMACENAMIENTO' | PASA | PASA |
| `test_P4_N2_disco_lleno_antes_de_iniciar_el_calculo` | FALLA: AssertionError: assert ('MURIO(1)' == 'FALLO_ALMACENAMIENTO' | FALLA: AssertionError: assert ('MURIO(1)' == 'FALLO_ALMACENAMIENTO' | PASA | PASA |
| `test_P4_N3_ancla_local_inaccesible` | FALLA: AssertionError: assert ('MURIO(1)' == 'ANCLA_NO_DISPONIBLE' | FALLA: AssertionError: assert ('MURIO(1)' == 'ANCLA_NO_DISPONIBLE' | PASA | PASA |
| `test_P4_N4_entrada_ilegible` | FALLA: AssertionError: assert ('MURIO(1)' == 'RECHAZADO' | FALLA: AssertionError: assert ('MURIO(1)' == 'RECHAZADO' | PASA | PASA |
| `test_P4_S1_concurrencia_determinista_mismo_directorio` | PASA | PASA | PASA | PASA |
| `test_P4_S1_dos_directorios_misma_reserva_intercalados` | FALLA: AssertionError: assert ('REGISTRADO' == 'INCONSISTENTE' | PASA | PASA | PASA |
| `test_P4_S2_ancla_antigua_con_menos_inicios` | FALLA: AssertionError: assert ('REGISTRADO' == 'INCONSISTENTE' | PASA | PASA | PASA |
| `test_P4_S2_ancla_perdida_es_inconsistente` | FALLA: AssertionError: assert (('REGISTRADO'...b16d82e6a4b'}) == ('INCONSISTENTE', None) | PASA | PASA | PASA |
| `test_P4_S3_ejecutor_modificado_se_rechaza` | FALLA: AssertionError: assert ('REGISTRADO' == 'RECHAZADO' | PASA | PASA | PASA |
| `test_P4_S4_el_calculo_no_hereda_entorno_ni_directorio` | FALLA: AssertionError: assert ('REGISTRADO' == 'REGISTRADO' | PASA | PASA | PASA |
| `test_P4_S5_no_determinista_se_detecta_antes_de_presellar` | FALLA: KeyError: 'resultado' | PASA | PASA | PASA |
| `test_P4_control_recuperacion_conserva_la_reserva` | FALLA: KeyError: 'reserva_sha256' | PASA | PASA | PASA |
| `test_fallos_de_escritura_sistematicos[det]` | FALLA: assert False | FALLA: assert False | PASA | PASA |
| `test_fallos_de_escritura_sistematicos[nodet]` | FALLA: assert False | FALLA: assert False | PASA | PASA |
