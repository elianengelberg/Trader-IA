# verificacion/ — P1, P2, P4 y ejecutor aislado, v0.5 (PROPUESTA: no aprobada ni integrada en ningún ejecutor)

| Módulo | Qué hace |
|---|---|
| `confianza.py` | Ed25519 (RFC 8032) y documentos firmados (declaraciones, respuestas y recibos del ancla). Rechaza claves y R de orden pequeño o mixto |
| `verificar_reproduccion_T.py` (P1) | Evalúa un resultado de T y da exactamente un estado: VERIFICADO, REPRODUCIDO, NO_REPRODUCIDO, CORRUPTO o INCONCLUSO. VERIFICADO exige una declaración firmada por una raíz aprobada (`RAICES_CONFIANZA`, hoy vacío). Un recibo del ancla solo cuenta con la reserva ESPERADA. REPRODUCIDO exige una reproducción en archivo autenticada como tal |
| `politica_avance_T.py` (P2) | Separa validez, etiqueta, robustez, avance y autorización. Nunca otorga autorizaciones; sus registros están vacíos y no se inyectan |
| `uso_unico.py` (P4) | Ejecución de uso único con un ancla local o el cliente `AnclaFirmada` (el ancla externa no existe: ver `DISENO_ANCLA_EXTERNA.md`). Límite de tiempo y reservas de reproducción |
| `ejecutor_aislado.py` | Cadena P4 → P1 → P2 con un registro de decisiones encadenado. No ejecuta T, no opera y no autoriza: `accion_ejecutada` es siempre "NINGUNA" |

**Pruebas:**
- Se ejecutan desde `research/tendencia_btc` con `python -m pytest verificacion/pruebas`.
- Son sintéticas. Las lecturas del árbol real de T son de solo lectura y no leen bytes de datos de mercado.
- La prueba diferencial de Ed25519 necesita un intérprete con `cryptography`: variable `PY_CRYPTOGRAPHY` o `python3.12`. Si no lo hay, se omite.

**Estado de T hoy:** el resultado fuera de muestra es INCONCLUSO, con un único motivo, `SIN_REFERENCIA_INDEPENDIENTE`.
Ver `../INSTRUCCIONES_FIRMA_FUERA_DE_MUESTRA_T.md`.
