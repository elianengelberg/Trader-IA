"""Adaptador de P1 para ejecutar LAS MISMAS pruebas de defectos contra v0.2, v0.3, v0.4 y v0.5.

Devuelve un veredicto con los estados de v0.4/v0.5 (VERIFICADO, CORRUPTO, INCONCLUSO, REPRODUCIDO, NO_REPRODUCIDO) y, si
la versión antigua no da un informe, EXCEPCION (un fallo sin estado: también es un defecto). Para v0.2 y v0.3:
- su «VERIFICADO» (integridad local) se informa como VERIFICADO: es lo que esas versiones afirmaban;
- sus códigos se traducen a los de v0.4 solo cuando el nombre cambió (tabla TRADUCCION, sin reinterpretar el fondo);
- los argumentos que la versión no admite se descartan (p. ej. ``declaraciones``), como haría su línea de órdenes.
En v0.5 la reproducción es un ARCHIVO autenticado: ``reproducir`` simula una reproducción LEGÍTIMA (escribe el objeto
en un archivo temporal y añade una declaración de reproducción del propietario SINTÉTICO que nombra esos bytes), para
que las pruebas de comparación (S5, S6, N4…) sigan probando lo mismo; ``autenticar=False`` la omite. Las pruebas de la
autenticación de la reproducción (F3) no usan el adaptador.
Las pruebas que dependen de la SALIDA real de la línea de órdenes (código de salida y JSON) no usan este adaptador."""
from __future__ import annotations

import hashlib
import inspect
import json
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import version

CORRUPTO = {"JSON_INVALIDO", "CLAVE_DUPLICADA", "TIPO", "RANGO", "VALOR", "CLAVE_AUSENTE", "CLAVE_INESPERADA",
            "HASH_FORMATO", "ESQUEMA", "CONTRADICCION", "HASH", "HASH_MANIFIESTO", "HASH_REFERENCIA", "REGISTRO",
            "RECIBO_CONTRADICE"}


@dataclass
class Veredicto:
    estado: str
    codigos: list[str] = field(default_factory=list)
    informe: dict | None = None


def traducir(codigo: str, detalle: str) -> str:
    """Nombres de v0.2/v0.3 → v0.4 (solo cambios de nombre)."""
    if codigo == "AUSENTE":
        return "CLAVE_AUSENTE" if ("falta la clave" in detalle or "faltan [" in detalle) else "ARCHIVO_AUSENTE"
    if codigo == "LECTURA":
        return "JSON_INVALIDO" if "JSON inválido" in detalle else "ARCHIVO_AUSENTE"
    if codigo == "HASH_SEMANTICA":
        return "USO"
    if codigo == "INTEGRIDAD":
        return "INTEGRIDAD_INCOMPLETA"
    if codigo == "VALOR" and "tolerancia" in detalle:
        return "USO"
    if codigo == "SIN_EVALUACION":
        return "SIN_EVALUACION"
    return codigo


def _filtrar(f, kw: dict) -> dict:  # type: ignore[no-untyped-def]
    admitidos = set(inspect.signature(f).parameters)
    if any(p.kind is p.VAR_KEYWORD for p in inspect.signature(f).parameters.values()):
        admitidos |= set(inspect.signature(version.p1().verificar).parameters)
    return {k: v for k, v in kw.items() if k in admitidos}


def _error(V, e: Exception) -> Veredicto:  # type: ignore[no-untyped-def]
    if isinstance(e, V.ErrorVerificacion):
        c = traducir(e.codigo, e.detalle)
        return Veredicto("CORRUPTO" if c in CORRUPTO else "INCONCLUSO", [c])
    return Veredicto("EXCEPCION", [type(e).__name__])


def evaluar(ruta, *, declaraciones=(), **kw) -> Veredicto:  # type: ignore[no-untyped-def]
    V = version.p1()
    if hasattr(V, "evaluar_archivo"):
        inf = V.evaluar_archivo(ruta, declaraciones=list(declaraciones), **kw)
        return Veredicto(inf["estado"], [m["codigo"] for m in inf["motivos"]], inf)
    try:
        inf = V.verificar_archivo(ruta, **_filtrar(V.verificar, kw))
    except Exception as e:  # noqa: BLE001
        return _error(V, e)
    if inf["nivel"] == "VERIFICADO":
        return Veredicto("VERIFICADO", [], inf)
    return Veredicto("INCONCLUSO", ["INTEGRIDAD_INCOMPLETA"], inf)


def _archivo_de_reproduccion(ruta, reproduccion, autenticar: bool) -> tuple[Path, list]:  # type: ignore[no-untyped-def]
    import fabricas_t as F
    destino = Path(tempfile.mkdtemp(prefix="reproduccion_")) / "reproduccion.json"
    destino.write_text(json.dumps(reproduccion), encoding="utf-8")
    extra = []
    if autenticar and Path(ruta).is_file():
        original = hashlib.sha256(Path(ruta).read_bytes()).hexdigest()
        extra.append(("reproduccion_prueba", F.declarar([{"sha256": hashlib.sha256(destino.read_bytes()).hexdigest()}],
                                                        contexto={"reproduccion_de": original})))
    return destino, extra


def reproducir(ruta, reproduccion, tolerancia=0.0, *, declaraciones=(), autenticar=True, **kw) -> Veredicto:  # type: ignore[no-untyped-def]
    V = version.p1()
    if version.NUMERO >= 3:  # v0.5: archivo autenticado
        archivo, extra = _archivo_de_reproduccion(ruta, reproduccion, autenticar)
        inf = V.evaluar_reproduccion(ruta, archivo, tolerancia, declaraciones=list(declaraciones) + extra, **kw)
        return Veredicto(inf["estado"], [m["codigo"] for m in inf["motivos"]], inf)
    if hasattr(V, "evaluar_reproduccion"):
        inf = V.evaluar_reproduccion(ruta, reproduccion, tolerancia, declaraciones=list(declaraciones), **kw)
        return Veredicto(inf["estado"], [m["codigo"] for m in inf["motivos"]], inf)
    try:
        inf = V.reproducir(ruta, reproduccion, tolerancia, **_filtrar(V.verificar, kw))
    except Exception as e:  # noqa: BLE001
        return _error(V, e)
    return Veredicto(inf["nivel"], [], inf)
