"""DOBLE DE PRUEBA de un ancla externa. NO es un ancla externa ni un prototipo de servicio: guarda el estado en un
archivo LOCAL (con la AnclaArchivo del módulo bajo prueba) y firma las respuestas con una clave SINTÉTICA cuya semilla
está en las fábricas de prueba. Sirve para probar el CLIENTE (AnclaFirmada), el contrato de la interfaz y la cadena
P4 → P1 → P2 con recibos firmados. Las «manipulaciones» simulan un intermediario o un servicio comprometido."""
from __future__ import annotations

import copy
from pathlib import Path

import version

C = version.confianza()


class ServidorAnclaDePrueba:
    def __init__(self, ruta: str | Path, semilla: bytes, emisor: str, modulo=None,  # type: ignore[no-untyped-def]
                 manipulacion: str | None = None):
        self.U = modulo or version.p4()
        self.almacen = self.U.AnclaArchivo(ruta)
        self.semilla, self.emisor, self.manipulacion = semilla, emisor, manipulacion
        self.respuestas: list[dict] = []  # para la manipulación «repetir»
        self.publica = C.clave_publica(semilla).hex()

    def _recibo(self, reserva_sha: str, presellado: str) -> dict:
        return C.firmar_documento(self.semilla, C.declaracion(
            self.emisor, "2026-10-20T00:00:00Z",
            [{"sha256": presellado, "descripcion": "resultado presellado (recibo del ancla)"}],
            {"reserva_sha256": reserva_sha}))

    def __call__(self, solicitud: dict) -> dict:
        op, r = solicitud["op"], solicitud["reserva_sha256"]
        if self.manipulacion == "caida":
            raise ConnectionError("servicio caído (simulado)")
        if self.manipulacion == "repetir" and self.respuestas:
            return copy.deepcopy(self.respuestas[0])  # respuesta vieja, válida y firmada, repetida
        resultado, motivo = "ACEPTADO", ""
        try:
            if op == "registrar_reserva":
                self.almacen.registrar_reserva(r, solicitud["reserva"])
            elif op == "registrar_inicio_calculo":
                self.almacen.registrar_inicio_calculo(r, solicitud["n"])
            elif op == "registrar_presellado":
                self.almacen.registrar_presellado(r, solicitud["resultado_sha256"])
            elif op != "consultar":
                raise ValueError(f"operación desconocida {op!r}")
        except self.U.AnclaConflicto as e:
            resultado, motivo = "CONFLICTO", str(e)
        st = self.almacen.consultar(r)
        estado = {"reserva": st["reserva"], "iniciados": st["iniciados"], "presellado": st["presellado"]}
        contenido = {"formato": C.FORMATO_RESPUESTA_ANCLA, "emisor": self.emisor, "op": op, "reserva_sha256": r,
                     "desafio": solicitud["desafio"], "resultado": resultado, "motivo": motivo, "estado": estado,
                     "recibo": self._recibo(r, st["presellado"]) if st["presellado"] else None}
        if self.manipulacion == "otra_operacion":
            contenido["op"] = "consultar" if op != "consultar" else "registrar_reserva"
        if self.manipulacion == "recibo_de_otra_reserva" and contenido["recibo"]:
            contenido["recibo"] = self._recibo("0" * 64, st["presellado"])
        if self.manipulacion == "estado_falso_tras_firma":
            doc = C.firmar_documento(self.semilla, contenido)
            doc["contenido"]["estado"]["reserva"] = not doc["contenido"]["estado"]["reserva"]  # alterado DESPUÉS de firmar
            return doc
        semilla = bytes(range(64, 96)) if self.manipulacion == "otra_clave" else self.semilla
        doc = C.firmar_documento(semilla, contenido)
        self.respuestas.append(copy.deepcopy(doc))
        return doc
