"""Fábricas SINTÉTICAS de las pruebas (copiadas de las de v0.3, más firmas de prueba para v0.4). Ningún dato es de
mercado. Las claves de firma de este archivo son SINTÉTICAS y públicas: no son raíces aprobadas."""
from __future__ import annotations

import copy
import datetime as dt
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent


def _dir_t() -> Path:
    """TRADER_IA_T manda si está definida; si no, la ubicación del repositorio en esta sesión."""
    if os.environ.get("TRADER_IA_T"):
        return Path(os.environ["TRADER_IA_T"])
    return Path("/home/user/Trader-IA/research/tendencia_btc")


T_REAL = _dir_t()


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def huella(src: Path) -> str:
    h = hashlib.sha256()
    for p in sorted(src.glob("*.py")):
        h.update(p.name.encode() + b"\0" + p.read_bytes())
    return h.hexdigest()


def reglas(ruta: Path) -> str:
    return sha(json.dumps(json.loads(ruta.read_text(encoding="utf-8")), sort_keys=True, ensure_ascii=False,
                          separators=(",", ":")).encode())


def arbol_t(raiz: Path) -> Path:
    """Árbol de T SINTÉTICO con la misma estructura de rutas que el real (contenidos inventados)."""
    (raiz / "experimentos").mkdir(parents=True)
    (raiz / "src" / "tendencia").mkdir(parents=True)
    (raiz / "papel").mkdir()
    (raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md").write_text("# prerregistro sintético\n", encoding="utf-8")
    (raiz / "src" / "tendencia" / "a.py").write_text("X = 1\n", encoding="utf-8")
    (raiz / "src" / "tendencia" / "b.py").write_text("Y = 2\n", encoding="utf-8")
    (raiz / "experimentos" / "fuera_de_muestra_T.py").write_text(  # como el real: CODIGO fijado en el script
        f'CODIGO = "{huella(raiz / "src" / "tendencia")}"\nDESDE, HASTA, DIAS = "2022-01-01", "2026-06-01", 1612\n\n\n'
        'def main():\n    pass\n', encoding="utf-8")
    (raiz / "papel" / "prerregistro_papel.json").write_text(json.dumps({"version": 1, "regla": "sintética"}),
                                                            encoding="utf-8")
    for s in ("BTCUSDT", "ETHUSDT"):
        d = raiz / "datos" / s / "spot"
        d.mkdir(parents=True)
        archivos = []
        for i in range(3):
            contenido = f"{s},{i},sintético\n".encode()
            (d / f"{s}-{i}.zip").write_bytes(contenido)
            archivos.append({"ruta": f"spot/{s}-{i}.zip", "sha256": sha(contenido), "bytes": len(contenido)})
        (raiz / "datos" / s / "MANIFIESTO.json").write_text(json.dumps({"procedencia": "sintética",
                                                                        "archivos": archivos}), encoding="utf-8")
    return raiz


def oos(p_conj: float = 0.755, p_btc: float = 0.8355, x2: float = 0.0438,
        decision: str = "EVIDENCIA INSUFICIENTE", raiz: Path | None = None) -> dict:
    """Forma de fuera_de_muestra_T.json; con ``raiz``, hashes calculados sobre el árbol sintético."""
    o = {"categoria": "SINTÉTICO", "prerregistro_sha256": "a" * 64, "script_sha256": "b" * 64, "codigo_sha256": "c" * 64,
         "manifiestos_sha256": {"BTCUSDT": "d" * 64, "ETHUSDT": "e" * 64}, "ventana": ["2022-01-01", "2026-06-01"],
         "dias": 1612, "decision_prerregistrada": decision,
         "principal": {"ventana": ["2022-01-01", "2026-06-01"],
                       "BTC": {"exceso_anual": 0.09, "ic90_anual": [-0.07, 0.25], "p": p_btc},
                       "ETH": {"exceso_anual": 0.05, "ic90_anual": [-0.13, 0.24], "p": 0.65},
                       "conjunto": {"exceso_anual": 0.07, "ic90_anual": [-0.09, 0.23], "p": p_conj}},
         "secundarios": {"costes_x2": {"BTC": 0.06, "ETH": 0.03, "conjunto": x2}}}
    if raiz is not None:
        o["prerregistro_sha256"] = sha((raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md").read_bytes())
        o["script_sha256"] = sha((raiz / "experimentos" / "fuera_de_muestra_T.py").read_bytes())
        o["codigo_sha256"] = huella(raiz / "src" / "tendencia")
        o["manifiestos_sha256"] = {s: sha((raiz / "datos" / s / "MANIFIESTO.json").read_bytes())
                                   for s in ("BTCUSDT", "ETHUSDT")}
    return o


def _boot(p: float, ic: list[float]) -> dict:
    return {"aplicable": True, "dias": 800, "media_diaria": 0.0003, "media_anual": 0.11, "intervalo_anual": ic,
            "p_mayor_que_cero": p, "bloque": 20, "remuestreos": 2000, "semilla": 20261017, "nivel": 0.9}


def evaluar(dias: int = 800, p_conj: float = 0.97, p_btc: float = 0.93, x2: float = 0.05,
            decision: str = "VENTAJA RESPALDADA", raiz: Path | None = None) -> dict:
    e = {"prerregistro_sha256": "1" * 64, "codigo_sha256": "2" * 64, "rama": "B", "inicio": "2027-01-01",
         "corte": "2029-03-12", "dias": dias, "meses": dias / 30.44, "exceso_anual_conjunto": 0.11,
         "bootstrap_conjunto": _boot(p_conj, [0.01, 0.22]), "bootstrap_btc": _boot(p_btc, [0.0, 0.3]),
         "exceso_anual_conjunto_costes_x2": x2, "decision": decision}
    if raiz is not None:
        e["prerregistro_sha256"] = reglas(raiz / "papel" / "prerregistro_papel.json")
        e["codigo_sha256"] = huella(raiz / "src" / "tendencia")
    return e


def corte(ev: dict | None = None) -> dict:
    ev = ev or evaluar()
    return {"corte_exclusivo": ev["corte"], "rama": ev["rama"], "inicio": ev["inicio"],
            "reglas_sha256": ev["prerregistro_sha256"], "codigo_sha256": ev["codigo_sha256"], "problemas": [],
            "datos_sha256": {"BTCUSDT": "3" * 64, "ETHUSDT": "4" * 64}, "estado": "EVALUADO",
            "evaluacion": {**ev, "metricas": {"T_BTC": {}, "T_ETH": {}}},
            "dias_calendario": (dt.date.fromisoformat(ev["corte"]) - dt.date.fromisoformat(ev["inicio"])).days,
            "decisiones_sha256": {"BTCUSDT": "5" * 64, "ETHUSDT": "6" * 64}, "monitor_carry": {"estado": "x"}}


def poner(obj: dict, ruta: str, valor) -> dict:  # type: ignore[no-untyped-def]
    o = copy.deepcopy(obj)
    *pre, ult = ruta.split(".")
    d = o
    for p in pre:
        d = d[p]
    d[ult] = valor
    return o


def quitar(obj: dict, ruta: str) -> dict:
    o = copy.deepcopy(obj)
    *pre, ult = ruta.split(".")
    d = o
    for p in pre:
        d = d[p]
    del d[ult]
    return o


def corte_real_simulado(tmp: Path, corte_: str = "2027-10-19") -> Path:
    """Ejecuta el productor REAL papel/corte.py en ``tmp`` con la fuente SIMULADA de sus propias pruebas (no son datos de
    mercado). Devuelve la raíz de cortes (con REGISTRO.jsonl y <corte>/resultado.json)."""
    spec = importlib.util.spec_from_file_location("_pruebas_corte", T_REAL / "tests" / "test_papel_corte.py")
    pc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pc)  # type: ignore[union-attr]
    r = pc.C.ejecutar(corte_, raiz=tmp, abrir=pc.abridor(pc.fuente(corte_)), base=None)
    assert r["estado"] == "EVALUADO"
    return tmp


def cadena(raiz: Path, rutas: tuple[str, ...] = ("PRERREGISTRO_FUERA_DE_MUESTRA_T.md", "experimentos/fuera_de_muestra_T.py",
                                                 "experimentos/fuera_de_muestra_T.json")) -> dict:
    """Registro del repositorio con la forma de EVIDENCIA_T_MULTI.json["cadena_historica_T_fuera_de_muestra"]."""
    return {r: {"sha256": sha((raiz / r).read_bytes())} for r in rutas}


def corte_provisional(estado: str = "NO EVALUABLE (ver problemas): no se calcula ningún resultado",
                      problemas: list[str] | None = None, corte_: str = "2029-03-12") -> dict:
    """Corte provisional con las claves EXACTAS que escribe corte.py en ese caso (sin evaluación, sin días de
    calendario ni tablas de decisiones)."""
    base = {k: v for k, v in corte().items() if k not in ("evaluacion", "dias_calendario", "decisiones_sha256")}
    return base | {"estado": estado, "problemas": ["historia incompleta"] if problemas is None else problemas,
                   "corte_exclusivo": corte_}


# ---------- firmas SINTÉTICAS (v0.4) ----------
import version as _version  # noqa: E402

C = _version.confianza()
SEMILLA_PROPIETARIO = bytes(range(32))           # clave de PRUEBA: pública en este archivo, no es una raíz aprobada
SEMILLA_ANCLA = bytes(range(32, 64))
SEMILLA_INTRUSA = bytes(range(64, 96))           # clave que ninguna prueba aprueba


def raiz(ident: str, semilla: bytes, tipo: str = "propietario") -> dict:
    return {"id": ident, "tipo": tipo, "clave_publica_ed25519": C.clave_publica(semilla).hex(),
            "aprobada_por": "PRUEBA SINTÉTICA (no es una aprobación)", "aprobada_utc": "2026-01-01T00:00:00Z",
            "descripcion": "raíz sintética de pruebas"}


RAICES_PRUEBA = {"PRUEBA-PROPIETARIO": raiz("PRUEBA-PROPIETARIO", SEMILLA_PROPIETARIO),
                 "PRUEBA-ANCLA": raiz("PRUEBA-ANCLA", SEMILLA_ANCLA, "ancla")}


def declarar(artefactos: dict[str, bytes | str] | list[dict], emisor: str = "PRUEBA-PROPIETARIO",
             semilla: bytes = SEMILLA_PROPIETARIO, contexto: dict | None = None) -> dict:
    """Documento firmado. ``artefactos``: {ruta: bytes del archivo o su sha256} o una lista ya armada."""
    if isinstance(artefactos, dict):
        lista = [{"ruta": r, "sha256": v if isinstance(v, str) else sha(v)} for r, v in artefactos.items()]
    else:
        lista = artefactos
    return C.firmar_documento(semilla, C.declaracion(emisor, "2026-10-20T00:00:00Z", lista, contexto))


def declarar_archivo(ruta: Path, raiz_: Path, **kw) -> tuple[str, dict]:  # type: ignore[no-untyped-def]
    """(nombre, documento) que cubre ``ruta`` (por su ruta relativa a ``raiz_``), como lo firmaría el propietario."""
    rel = ruta.resolve().relative_to(raiz_.resolve()).as_posix()
    return ("declaracion_prueba", declarar({rel: ruta.read_bytes()}, **kw))


def declarar_reproduccion(original: Path, reproduccion: Path, **kw) -> tuple[str, dict]:  # type: ignore[no-untyped-def]
    """v0.5: declaración del propietario SINTÉTICO que autentica los bytes de ``reproduccion`` COMO reproducción del
    resultado ``original`` (``contexto.reproduccion_de``)."""
    return ("reproduccion_prueba", declarar([{"sha256": sha(reproduccion.read_bytes())}],
                                            contexto={"reproduccion_de": sha(original.read_bytes())}, **kw))


def reproduccion_autenticada(directorio: Path, original: Path, obj: object) -> tuple[Path, tuple[str, dict]]:
    """(archivo con ``obj``, declaración que lo autentica como reproducción de ``original``)."""
    directorio.mkdir(parents=True, exist_ok=True)
    destino = directorio / f"reproduccion_{len(list(directorio.glob('reproduccion_*')))}.json"
    destino.write_text(json.dumps(obj), encoding="utf-8")
    return destino, declarar_reproduccion(original, destino)
