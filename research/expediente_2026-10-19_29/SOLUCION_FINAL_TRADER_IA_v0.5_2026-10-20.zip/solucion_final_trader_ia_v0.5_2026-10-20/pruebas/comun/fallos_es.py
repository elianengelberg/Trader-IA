"""Inyección CONTROLADA de fallos de escritura: un sustituto del módulo ``os`` que se instala SOLO en el módulo bajo
prueba (``U.os = OSConFallos(os, plan)``) dentro de un proceso hijo. Cuenta las llamadas de cada operación y hace
fallar la n-ésima de la operación elegida (con ``contiene``, solo cuentan las escrituras cuyos bytes contienen ese
texto: así el plan no depende del número de escrituras de cada versión):
- ENOSPC / EIO: la llamada lanza OSError sin hacer nada (disco lleno, error de E/S);
- CORTA: os.write escribe la MITAD y devuelve ese número (escritura corta legítima, sin error);
- CORTA_ENOSPC: escritura corta y, en la siguiente escritura, ENOSPC (bytes a medias en disco).
No simula la pérdida de páginas sucias tras un fsync fallido ni un corte de energía (ver límites)."""
from __future__ import annotations

import errno

OPERACIONES = ("write", "fsync", "replace", "link", "ftruncate")
MODOS = {"write": ("ENOSPC", "EIO", "CORTA", "CORTA_ENOSPC"), "fsync": ("EIO",), "replace": ("EIO",),
         "link": ("ENOSPC",), "ftruncate": ("EIO",)}


class OSConFallos:
    def __init__(self, real, plan: dict | None = None):  # type: ignore[no-untyped-def]
        self._real, self._plan = real, plan
        self.conteo = dict.fromkeys(OPERACIONES, 0)
        self._enospc_pendiente = False
        self.inyectado = False

    def __getattr__(self, nombre: str):  # type: ignore[no-untyped-def]
        return getattr(self._real, nombre)

    def _toca(self, op: str, datos: bytes | None = None) -> str | None:
        self.conteo[op] += 1
        if not self._plan or self._plan["op"] != op:
            return None
        if "contiene" in self._plan:
            if datos is None or self._plan["contiene"].encode() not in bytes(datos):
                return None
            self._coincidencias = getattr(self, "_coincidencias", 0) + 1
            n = self._coincidencias
        else:
            n = self.conteo[op]
        if self._plan["n"] == n:
            self.inyectado = True
            return self._plan["modo"]
        return None

    @staticmethod
    def _error(modo: str) -> OSError:
        codigo = errno.ENOSPC if modo == "ENOSPC" else errno.EIO
        return OSError(codigo, f"{modo} inyectado")

    def write(self, fd: int, datos) -> int:  # type: ignore[no-untyped-def]
        if self._enospc_pendiente:
            self._enospc_pendiente = False
            raise self._error("ENOSPC")
        modo = self._toca("write", datos)
        if modo in ("ENOSPC", "EIO"):
            raise self._error(modo)
        if modo in ("CORTA", "CORTA_ENOSPC") and len(datos) > 1:
            self._enospc_pendiente = modo == "CORTA_ENOSPC"
            return self._real.write(fd, bytes(datos[: len(datos) // 2]))
        return self._real.write(fd, datos)

    def fsync(self, fd: int) -> None:
        if self._toca("fsync"):
            raise self._error("EIO")
        self._real.fsync(fd)

    def replace(self, a, b) -> None:  # type: ignore[no-untyped-def]
        if self._toca("replace"):
            raise self._error("EIO")
        self._real.replace(a, b)

    def link(self, a, b) -> None:  # type: ignore[no-untyped-def]
        if self._toca("link"):
            raise self._error("ENOSPC")
        self._real.link(a, b)

    def ftruncate(self, fd: int, n: int) -> None:
        if self._toca("ftruncate"):
            raise self._error("EIO")
        self._real.ftruncate(fd, n)


# ---------- v0.5: corte de energía simulado ----------
class OSConCorte:
    """Sustituto de ``os`` (solo en el módulo bajo prueba, en un proceso hijo) que simula un CORTE DE ENERGÍA justo
    DESPUÉS de la n-ésima operación ``op`` (write, fsync, link, replace, ftruncate) y termina el proceso (os._exit).

    Modelo de durabilidad (el de POSIX, en su versión más desfavorable que se pueda simular aquí):
    - el CONTENIDO de un archivo es durable hasta su último fsync; lo escrito después se pierde (``datos="perder"``) o
      sobrevive a medias (``"mitad"``: escritura desgarrada) o entero (``"conservar"``);
    - una ENTRADA de directorio (crear un archivo, link, replace) es durable solo tras el fsync de ESE directorio; sin él
      se deshace (``directorio="deshacer"``) o se conserva (``"conservar"``).
    No simula: mkdir y Path.unlink (no pasan por ``os`` del módulo; se tratan como durables), el orden de escritura
    entre archivos distintos dentro del mismo intervalo, ni la pérdida de un fsync que el disco haya confirmado."""

    OPERACIONES = ("write", "fsync", "link", "replace", "ftruncate")

    def __init__(self, real, plan: dict | None = None):  # type: ignore[no-untyped-def]
        self._real, self._plan = real, plan
        self.conteo = dict.fromkeys(self.OPERACIONES, 0)
        self._fd: dict[int, tuple[str, str]] = {}      # fd -> (archivo|dir, ruta)
        self._durable: dict[tuple, bytes] = {}         # (dev, ino) -> contenido durable
        self._pendientes: list[tuple] = []             # operaciones de directorio sin fsync del directorio
        self.inyectado = False                         # el corte termina el proceso: nunca se informa True

    def __getattr__(self, nombre: str):  # type: ignore[no-untyped-def]
        return getattr(self._real, nombre)

    def _ino(self, ruta: str) -> tuple:
        st = self._real.stat(ruta)
        return (st.st_dev, st.st_ino)

    def _leer(self, ruta: str) -> bytes:
        with open(ruta, "rb") as fh:
            return fh.read()

    def _conocer(self, ruta: str) -> None:
        clave = self._ino(ruta)
        if clave not in self._durable:  # lo que ya existía se supone durable
            self._durable[clave] = self._leer(ruta)

    def _contar(self, op: str) -> None:  # op = "fin": el conductor corta tras informar la salida
        self.conteo[op] += 1
        if self._plan and self._plan["op"] == op and self._plan["n"] == self.conteo[op]:
            self._cortar()

    def open(self, ruta, flags, modo=0o777, **kw):  # type: ignore[no-untyped-def]
        ruta = self._real.path.abspath(ruta)
        existia = self._real.path.exists(ruta)
        fd = self._real.open(ruta, flags, modo, **kw)
        if self._real.path.isdir(ruta):
            self._fd[fd] = ("dir", ruta)
        else:
            self._fd[fd] = ("archivo", ruta)
            if existia:
                self._conocer(ruta)
            else:
                self._durable[self._ino(ruta)] = b""
                self._pendientes.append((self._real.path.dirname(ruta), "crear", ruta))
        return fd

    def close(self, fd: int) -> None:
        self._fd.pop(fd, None)
        self._real.close(fd)

    def write(self, fd: int, datos) -> int:  # type: ignore[no-untyped-def]
        n = self._real.write(fd, datos)
        self._contar("write")
        return n

    def ftruncate(self, fd: int, n: int) -> None:
        self._real.ftruncate(fd, n)
        self._contar("ftruncate")

    def fsync(self, fd: int) -> None:
        self._real.fsync(fd)
        tipo, ruta = self._fd.get(fd, (None, None))
        if tipo == "archivo":
            self._durable[self._ino(ruta)] = self._leer(ruta)
        elif tipo == "dir":
            self._pendientes = [p for p in self._pendientes if p[0] != ruta]
        self._contar("fsync")

    def link(self, a, b) -> None:  # type: ignore[no-untyped-def]
        a, b = self._real.path.abspath(a), self._real.path.abspath(b)
        self._real.link(a, b)
        self._pendientes.append((self._real.path.dirname(b), "link", b))
        self._contar("link")

    def replace(self, a, b) -> None:  # type: ignore[no-untyped-def]
        a, b = self._real.path.abspath(a), self._real.path.abspath(b)
        viejo = None
        if self._real.path.exists(b):
            self._conocer(b)
            viejo = self._durable[self._ino(b)]
        self._real.replace(a, b)
        self._pendientes.append((self._real.path.dirname(b), "replace", a, b, viejo))
        self._contar("replace")

    def _restaurar(self, ruta: str, datos: str, vistos: set) -> None:
        clave = self._ino(ruta)
        if clave in vistos or clave not in self._durable:
            return
        vistos.add(clave)
        actual, durable = self._leer(ruta), self._durable[clave]
        nuevo = durable
        if datos == "mitad" and actual.startswith(durable):
            extra = actual[len(durable):]
            nuevo = durable + extra[: len(extra) // 2]
        if nuevo != actual:
            with open(ruta, "wb") as fh:
                fh.write(nuevo)

    def _cortar(self) -> None:
        datos, directorio = self._plan.get("datos", "perder"), self._plan.get("directorio", "deshacer")  # type: ignore[union-attr]
        if datos != "conservar":  # 1) contenido: lo durable (+ la mitad de lo añadido después, con «mitad»)
            vistos: set = set()
            rutas = {r for t, r in self._fd.values() if t == "archivo"}
            for d in set(self._plan.get("directorios", [])) | {p[0] for p in self._pendientes}:  # type: ignore[union-attr]
                if self._real.path.isdir(d):
                    rutas |= {self._real.path.join(d, x) for x in self._real.listdir(d)}
            for ruta in sorted(rutas):
                if self._real.path.isfile(ruta):
                    self._restaurar(ruta, datos, vistos)
        if directorio == "deshacer":  # 2) entradas de directorio sin fsync del directorio, en orden inverso
            for p in reversed(self._pendientes):
                if p[1] in ("crear", "link") and self._real.path.exists(p[2]):
                    self._real.unlink(p[2])
                elif p[1] == "replace" and self._real.path.exists(p[3]):
                    _, _, a, b, viejo = p
                    with open(a, "wb") as fh:
                        fh.write(self._leer(b))
                    if viejo is None:
                        self._real.unlink(b)
                    else:
                        with open(b, "wb") as fh:
                            fh.write(viejo)
        self._real._exit(137)
