"""Comprobador INDEPENDIENTE de los invariantes de P4: lee DIARIO.jsonl, el ancla local (o el almacén del doble de
prueba) y resultado.json SIN importar uso_unico (su propia lectura de la cadena, escrita aparte). Lo usan las pruebas de
mutaciones aleatorias del diario y de corte de energía."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

SALIDAS = {"REGISTRADO", "CONFLICTO", "CORRUPTO", "INCONSISTENTE", "REVISION_HUMANA", "NO_DETERMINISTA", "OCUPADO",
           "RECHAZADO", "FALLO_CALCULO", "ANCLA_NO_DISPONIBLE", "ANCLA_NO_AUTENTICA", "FALLO_ALMACENAMIENTO"}


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def cadena(ruta: Path) -> list[dict] | None:
    """Eventos completos de una cadena válida (la cola sin salto de línea se ignora); None si está rota o ilegible."""
    if not ruta.exists():
        return []
    *lineas, _cola = ruta.read_bytes().split(b"\n")
    eventos, anterior = [], None
    for i, b in enumerate(lineas):
        try:
            ev = json.loads(b)
        except ValueError:
            return None
        if not isinstance(ev, dict) or ev.get("n") != i or ev.get("anterior") != anterior or not isinstance(
                ev.get("datos"), dict):
            return None
        if json.dumps(ev, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode() != b:
            return None
        eventos.append(ev)
        anterior = _sha(b)
    return eventos


def violaciones(dir_estado: Path, ancla: Path, salidas: list[dict], calculos: int) -> list[str]:
    v = []
    for s in salidas:
        if s.get("estado", "").startswith("MURIO") and not s.get("muerte_provocada"):
            v.append(f"una ejecución terminó sin salida: {s.get('stderr', '')[-160:]}")
        elif not s.get("estado", "").startswith("MURIO") and s.get("estado") not in SALIDAS:
            v.append(f"salida desconocida {s.get('estado')!r}")
    diario = cadena(dir_estado / "DIARIO.jsonl")
    eventos_ancla = cadena(ancla)
    pres_d = [e["datos"].get("resultado_sha256") for e in diario or [] if e.get("evento") == "PRESELLADO"]
    if len(set(pres_d)) > 1:
        v.append("dos presellados distintos en el diario")
    pres_a: dict[str, set] = {}
    inicios: dict[str, int] = {}
    for e in eventos_ancla or []:
        r = e["datos"].get("reserva_sha256")
        if e.get("evento") == "PRESELLADO":
            pres_a.setdefault(r, set()).add(e["datos"].get("resultado_sha256"))
        if e.get("evento") == "INICIO_CALCULO":
            inicios[r] = inicios.get(r, 0) + 1
    if any(len(x) > 1 for x in pres_a.values()):
        v.append("dos presellados distintos para una reserva en el ancla")
    if any(n > 1 for n in inicios.values()):
        v.append(f"el ancla registra más de un inicio de cálculo: {inicios}")
    registrados = [s for s in salidas if s.get("estado") == "REGISTRADO"]
    for s in registrados:
        if pres_a.get(s.get("reserva_sha256")) not in (None, {s.get("resultado_sha256")}):
            v.append("una salida REGISTRADO con un hash distinto del presellado del ancla")
    res = dir_estado / "resultado.json"
    if res.exists() and pres_d and _sha(res.read_bytes()) != pres_d[0] and registrados:
        # el archivo pudo alterarlo un tercero; lo que P4 nunca debe hacer es darlo por REGISTRADO
        v.append("resultado.json distinto del presellado del diario y una salida REGISTRADO")
    for s in registrados:
        if res.exists() and s.get("resultado_sha256") != _sha(res.read_bytes()):
            v.append("una salida REGISTRADO cuyo hash no es el de resultado.json")
    if pres_d and any(p != {pres_d[0]} for p in pres_a.values()) and len(pres_a) == 1:
        v.append("el presellado del ancla y el del diario difieren")
    recalculos = sum(e.get("evento") == "RECALCULO_DE_VERIFICACION" for e in diario or [])
    if calculos > 1 + recalculos:
        v.append(f"{calculos} cálculos con {recalculos} recálculo(s) de verificación")
    return v
