"""Versión bajo prueba (VERSION_BAJO_PRUEBA = v0_2 | v0_3 | v0_4 | v0_5; por defecto v0_5) y rutas de sus módulos.

Las mismas pruebas de defectos se ejecutan contra cada versión para demostrar que FALLAN antes de la corrección y PASAN
después (matriz en evidencia/). Las pruebas de capacidades que aparecieron en v0.4 se marcan ``desde_v04`` y las de
v0.5 ``desde_v05``: se omiten en las versiones anteriores."""
from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path

import pytest

PAQUETE = Path(__file__).resolve().parents[2]
VERSIONES = ("v0_2", "v0_3", "v0_4", "v0_5")
VERSION = os.environ.get("VERSION_BAJO_PRUEBA", "v0_5")
if VERSION not in VERSIONES:
    raise RuntimeError(f"VERSION_BAJO_PRUEBA desconocida: {VERSION!r}")
# Paquete de entrega: codigo/verificacion; repositorio (parche aplicado): la carpeta verificacion/ que contiene pruebas/.
# CODIGO_ACTUAL_DIR solo para las pruebas de mutaciones (una COPIA mutada del código actual).
_EN_PAQUETE = PAQUETE / "codigo" / "verificacion"
CODIGO_ACTUAL = Path(os.environ.get("CODIGO_ACTUAL_DIR") or (_EN_PAQUETE if _EN_PAQUETE.is_dir() else PAQUETE))
if VERSION == "v0_5":
    DIR_P1 = DIR_P2 = DIR_P4 = CODIGO_ACTUAL
elif VERSION == "v0_4":
    DIR_P1 = DIR_P2 = DIR_P4 = PAQUETE / "referencia" / "v0_4"
else:
    base = PAQUETE / "referencia" / VERSION
    DIR_P1, DIR_P2, DIR_P4 = base / "p1", base / "p2", base / "p4"
if not DIR_P1.is_dir():
    raise RuntimeError(f"{VERSION}: no hay código de referencia en {DIR_P1} (solo en el paquete de entrega)")
MODULO_P4 = DIR_P4 / "uso_unico.py"
NUMERO = VERSIONES.index(VERSION)
desde_v04 = pytest.mark.skipif(NUMERO < 2, reason=f"capacidad de v0.4 (versión bajo prueba: {VERSION})")
desde_v05 = pytest.mark.skipif(NUMERO < 3, reason=f"capacidad de v0.5 (versión bajo prueba: {VERSION})")


def _importar(nombre: str, directorio: Path):  # type: ignore[no-untyped-def]
    if str(directorio) not in sys.path:
        sys.path.insert(0, str(directorio))
    return importlib.import_module(nombre)


def p1():  # type: ignore[no-untyped-def]
    return _importar("verificar_reproduccion_T", DIR_P1)


def p2():  # type: ignore[no-untyped-def]
    p1()  # P2 importa P1 de su propia versión; se carga primero para que coincidan
    return _importar("politica_avance_T", DIR_P2)


def p4():  # type: ignore[no-untyped-def]
    return _importar("uso_unico", DIR_P4)


def ejecutor():  # type: ignore[no-untyped-def]
    """Ejecutor aislado (v0.5): solo existe en la versión actual."""
    return _importar("ejecutor_aislado", CODIGO_ACTUAL)


def confianza():  # type: ignore[no-untyped-def]
    """Módulo de firmas ACTUAL, cargado con otro nombre: las FÁBRICAS lo usan para firmar en cualquier versión (el
    formato de las firmas no cambió entre v0.4 y v0.5)."""
    nombre = "confianza_para_fabricas"
    if nombre not in sys.modules:
        spec = importlib.util.spec_from_file_location(nombre, CODIGO_ACTUAL / "confianza.py")
        m = importlib.util.module_from_spec(spec)
        sys.modules[nombre] = m
        spec.loader.exec_module(m)  # type: ignore[union-attr]
    return sys.modules[nombre]
