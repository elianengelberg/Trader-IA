"""Configuración común: helpers en sys.path y raíces de confianza SINTÉTICAS instaladas solo por monkeypatch."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent / "comun"))
import fabricas_t as F  # noqa: E402
import version  # noqa: E402


@pytest.fixture
def raices(monkeypatch):  # type: ignore[no-untyped-def]
    """Aprueba las raíces SINTÉTICAS de prueba durante la prueba (v0.4). En v0.2/v0.3 no hay registro: no hace nada."""
    V = version.p1()
    if hasattr(V, "RAICES_CONFIANZA"):
        monkeypatch.setattr(V, "RAICES_CONFIANZA", dict(F.RAICES_PRUEBA))
    return F.RAICES_PRUEBA
