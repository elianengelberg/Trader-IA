"""Variante NO DETERMINISTA (ruido en «categoria») del código SINTÉTICO que P4 reserva y ejecuta: arma un resultado con el esquema fuera de muestra de T (cifras inventadas
en «parametros», no datos de mercado) y con los hashes de los archivos del árbol de T sintético también reservados."""
import hashlib
import json
import os


def calcular(contenidos, semilla):
    sha = lambda b: hashlib.sha256(b).hexdigest()  # noqa: E731
    h = hashlib.sha256()
    for nombre in sorted(k for k in contenidos if k.startswith("src/")):
        h.update(nombre.split("/")[-1].encode() + b"\0" + contenidos[nombre])
    with open(contenidos["contador"].decode().strip(), "a") as fh:
        fh.write("calculo\n")
    p = json.loads(contenidos["parametros"])
    return {"categoria": "SINTÉTICO (cruzada) " + os.urandom(4).hex(), "prerregistro_sha256": sha(contenidos["prerregistro"]),
            "script_sha256": sha(contenidos["script"]), "codigo_sha256": h.hexdigest(),
            "manifiestos_sha256": {s: sha(contenidos[f"manifiesto_{s}"]) for s in ("BTCUSDT", "ETHUSDT")},
            "ventana": ["2022-01-01", "2026-06-01"], "dias": 1612, "decision_prerregistrada": p["decision"],
            "principal": {"ventana": ["2022-01-01", "2026-06-01"],
                          "BTC": {"exceso_anual": 0.09, "ic90_anual": [-0.07, 0.25], "p": p["p_btc"]},
                          "ETH": {"exceso_anual": 0.05, "ic90_anual": [-0.13, 0.24], "p": 0.6},
                          "conjunto": {"exceso_anual": p["exceso"], "ic90_anual": [-0.09, 0.23], "p": p["p_conj"]}},
            "secundarios": {"costes_x2": {"BTC": 0.06, "ETH": 0.03, "conjunto": p["x2"]}}}
