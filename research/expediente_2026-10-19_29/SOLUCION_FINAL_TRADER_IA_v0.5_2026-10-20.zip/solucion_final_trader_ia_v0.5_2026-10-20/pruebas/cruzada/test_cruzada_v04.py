"""Auditoría cruzada P4 v0.4 → P1 v0.4 → P2 v0.4 con datos y resultados SINTÉTICOS (y lecturas de solo lectura del
resultado real de T en X8). Cadena propuesta (NO integrada): P4 reserva y ejecuta un código sintético que produce un
resultado con el esquema fuera de muestra → P1 lo evalúa contra un árbol de T sintético exigiendo el hash que el ANCLA
registró y aceptando como referencia independiente solo el RECIBO firmado por un ancla cuya clave sea una raíz aprobada
(aquí, la raíz SINTÉTICA «PRUEBA-ANCLA», instalada por monkeypatch) → P2 decide. Cada prueba X* intenta ELUDIR un
control y comprueba que no lo consigue."""
from __future__ import annotations

import ast
import hashlib
import json
import shutil
from pathlib import Path

import fabricas_t as F
import pytest
import version
from ancla_de_prueba import ServidorAnclaDePrueba
from version import desde_v04

pytestmark = desde_v04
V, PA, U, C = version.p1(), version.p2(), version.p4(), F.C
AQUI = Path(__file__).resolve().parent
T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.json").is_file(), reason="T no disponible")
INSUF = {"p_conj": 0.755, "p_btc": 0.8355, "x2": 0.0438, "exceso": 0.07, "decision": "EVIDENCIA INSUFICIENTE"}
RESP = {"p_conj": 0.97, "p_btc": 0.95, "x2": 0.02, "exceso": 0.12, "decision": "RESPALDADA FUERA DE MUESTRA"}


def montar(tmp: Path, parametros: dict, firmada: bool = True, codigo: str = "codigo_oos_sintetico.py",
           manipulacion: str | None = None) -> dict:
    raiz = F.arbol_t(tmp / "T")
    (tmp / "parametros.json").write_text(json.dumps(parametros), encoding="utf-8")
    (tmp / "contador.txt").write_text(str(tmp / "llamadas.txt"), encoding="utf-8")
    archivos = {"codigo": AQUI / codigo, "parametros": tmp / "parametros.json", "contador": tmp / "contador.txt",
                "prerregistro": raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                "script": raiz / "experimentos" / "fuera_de_muestra_T.py",
                **{f"src/{p.name}": p for p in sorted((raiz / "src" / "tendencia").glob("*.py"))},
                **{f"manifiesto_{s}": raiz / "datos" / s / "MANIFIESTO.json" for s in ("BTCUSDT", "ETHUSDT")}}
    if firmada:
        servidor = ServidorAnclaDePrueba(tmp / "ancla_externa_prueba" / "A.jsonl", F.SEMILLA_ANCLA, "PRUEBA-ANCLA",
                                         modulo=U, manipulacion=manipulacion)
        ancla = U.AnclaFirmada(servidor, servidor.publica, "PRUEBA-ANCLA")
    else:
        ancla = U.AnclaArchivo(tmp / "ancla" / "ANCLA.jsonl")
    return {"raiz": raiz, "dir": tmp / "estado", "archivos": {k: str(v) for k, v in archivos.items()},
            "ancla": ancla, "llamadas": tmp / "llamadas.txt"}


def p4(m: dict, **kw) -> U.Salida:  # type: ignore[no-untyped-def]
    s = U.ejecutar(m["dir"], "CRUZADA-1", m["archivos"], 7, ancla=m["ancla"], **kw)
    m["salida"] = s
    return s


def n_calculos(m: dict) -> int:
    return len(m["llamadas"].read_text().splitlines()) if m["llamadas"].exists() else 0


def referencias(m: dict) -> dict:
    """Lo que la cadena pasa a P1: el presellado CONSULTADO al ancla, el recibo firmado guardado por P4 y (v0.5) la
    RESERVA de esa ejecución, sin la cual P1 no acepta el recibo."""
    st = m["ancla"].consultar(m["salida"].reserva_sha256)
    recibo = Path(m["dir"]) / U.RECIBO
    decl = [("recibo_ancla", json.loads(recibo.read_text(encoding="utf-8")))] if recibo.exists() else []
    return {"resultado_sha256_esperado": st["presellado"], "declaraciones": decl, "reserva": U.leer(m["dir"])["reserva"]}


def cadena(m: dict, r1: object = "NO_DEFINIDO", r3: object = "NO_DEFINIDO", **kw) -> dict:  # type: ignore[no-untyped-def]
    """Integración PROPUESTA: P2 (que pasa por P1) sobre el resultado de P4, con las referencias del ancla."""
    return PA.desde_resultado(Path(m["dir"]) / U.RESULTADO, m["raiz"], r1, r3, **referencias(m), **kw)


def resumen(s: dict) -> tuple:
    return (s["evidencia"]["validez"], s["etiqueta_estadistica"], s["decision_avance"]["resultado"],
            s["autorizacion_ejecucion"]["estado"])


# ---------- cadena válida ----------
def test_cadena_valida_con_recibo_firmado(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, RESP)
    assert p4(m).estado == "REGISTRADO"
    s = cadena(m)
    assert resumen(s) == ("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", "CANDIDATA_A_REVISION_HUMANA", "NO_OTORGADA")
    assert s["resultado_verificado"]["autenticidad"]["cubren"][0].startswith("recibo_ancla (emisor PRUEBA-ANCLA, ancla")


# ---------- X1: P1 no da por válido lo que no puede verificar ----------
def test_X1_sin_raiz_o_sin_referencia_no_hay_verificado(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, INSUF)
    p4(m)
    ruta = Path(m["dir"]) / U.RESULTADO
    ref = referencias(m)
    assert V.evaluar_archivo(ruta, **ref)["estado"] == "INCONCLUSO"  # sin --raiz
    assert V.evaluar_archivo(ruta, raiz=m["raiz"])["estado"] == "INCONCLUSO"  # sin referencia independiente
    assert V.evaluar_reproduccion(ruta, json.loads(ruta.read_text()), raiz=m["raiz"])["estado"] == "INCONCLUSO"


# ---------- X2: P1 contra el hash del ancla; X13: recibo reutilizado para otro resultado ----------
def test_X2_X13_resultado_sustituido_tras_el_registro(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, INSUF)
    p4(m)
    ref = referencias(m)
    ruta = Path(m["dir"]) / U.RESULTADO
    o = json.loads(ruta.read_text())
    o["principal"]["conjunto"]["p"] = 0.80  # coherente: sigue siendo EVIDENCIA INSUFICIENTE
    ruta.write_text(json.dumps(o), encoding="utf-8")
    sin_hash = V.evaluar_archivo(ruta, raiz=m["raiz"], declaraciones=ref["declaraciones"])
    assert sin_hash["estado"] == "INCONCLUSO"  # el recibo viejo no cubre el archivo nuevo
    con_hash = V.evaluar_archivo(ruta, raiz=m["raiz"], **ref)
    assert (con_hash["estado"], con_hash["motivos"][0]["codigo"]) == ("CORRUPTO", "HASH")
    assert cadena(m)["evidencia"]["validez"] == "CORRUPTO"
    assert p4(m).estado == "CORRUPTO"  # y P4 lo detecta por su lado


# ---------- X3: P2 no clasifica lo que P1 no valida ----------
@pytest.mark.parametrize("caso", ["codigo_alterado", "script_alterado", "sin_recibo"])
def test_X3_p2_no_clasifica_evidencia_no_valida(tmp_path: Path, raices, caso: str) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, RESP)
    p4(m)
    if caso == "codigo_alterado":
        (m["raiz"] / "src" / "tendencia" / "a.py").write_text("X = 99\n", encoding="utf-8")
    elif caso == "script_alterado":
        (m["raiz"] / "experimentos" / "fuera_de_muestra_T.py").write_text("# otro\n", encoding="utf-8")
    else:
        (Path(m["dir"]) / U.RECIBO).unlink()
    s = cadena(m)
    assert s["evidencia"]["validez"] in ("CORRUPTO", "INCONCLUSO")
    assert (s["etiqueta_estadistica"], s["decision_avance"]["resultado"]) == (None, "NO_CANDIDATA")


# ---------- X4 y X19: una etiqueta favorable no autoriza; una autorización registrada solo se CONSTATA ----------
def test_X4_etiqueta_favorable_no_autoriza(tmp_path: Path, raices, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, RESP)
    p4(m)
    sha = m["salida"].resultado_sha256
    assert resumen(cadena(m))[3] == "NO_OTORGADA"
    monkeypatch.setattr(PA, "ETAPAS_DEFINIDAS", {"ETAPA_SINTETICA": "solo pruebas"})
    monkeypatch.setattr(PA, "AUTORIZACIONES", {"AUT": {
        "id": "AUT", "etapa": "ETAPA_SINTETICA", "resultado_sha256": sha, "otorgada_por": "PRUEBA SINTÉTICA",
        "otorgada_utc": "2030-01-01T00:00:00Z", "texto_sha256": "1" * 64}})
    s = cadena(m, etapa="ETAPA_SINTETICA", autorizacion="AUT")
    assert s["autorizacion_ejecucion"]["estado"] == "REGISTRADA_EXTERNAMENTE"
    assert "no ejecuta nada" in s["autorizacion_ejecucion"]["motivo"]


# ---------- X5: una ejecución incompleta de P4 no produce evidencia ----------
@pytest.mark.parametrize("caso,esperado", [("nodet", "NO_DETERMINISTA"), ("caida_ancla", "ANCLA_NO_DISPONIBLE"),
                                           ("repeticion", "ANCLA_NO_AUTENTICA")])
def test_X5_ejecucion_incompleta_no_deja_resultado_ni_recibo(tmp_path: Path, caso: str, esperado: str) -> None:
    if caso == "nodet":
        m = montar(tmp_path, INSUF, codigo="codigo_oos_nodet.py")
        s = p4(m, verificar_determinismo=True)
    else:
        m = montar(tmp_path, INSUF, manipulacion={"caida_ancla": "caida", "repeticion": "repetir"}[caso])
        s = p4(m)
    assert s.estado == esperado and s.resultado is None
    assert not (Path(m["dir"]) / U.RESULTADO).exists() and not (Path(m["dir"]) / U.RECIBO).exists()


# ---------- X6: un fallo técnico no habilita repetir; X15: un estado inválido de P4 no llega a P2 como válido ----------
def test_X6_X15_rechazo_y_estado_invalido_no_habilitan_repetir(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, RESP)
    p4(m)
    fuente = m["raiz"] / "src" / "tendencia" / "a.py"
    original = fuente.read_bytes()
    fuente.write_text("X = 99\n", encoding="utf-8")  # P1 rechazará
    assert cadena(m)["evidencia"]["validez"] == "CORRUPTO" and n_calculos(m) == 1
    assert p4(m).estado == "RECHAZADO" and n_calculos(m) == 1  # las entradas cambiaron: otra reserva, no se calcula
    shutil.rmtree(Path(m["dir"]))  # borrar el estado local para «empezar de nuevo»…
    assert p4(m).estado == "RECHAZADO" and n_calculos(m) == 1  # …con otras entradas: el ancla rechaza el nombre
    fuente.write_bytes(original)  # …o con las MISMAS entradas (la misma reserva)
    s = p4(m)
    assert s.estado == "RECHAZADO" and "cálculo iniciado" in s.detalle and n_calculos(m) == 1


# ---------- X7: la recuperación no cambia lo reservado ni el recibo ----------
def test_X7_recuperacion_conserva_reserva_y_recibo(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, INSUF)
    s1 = p4(m)
    recibo = (Path(m["dir"]) / U.RECIBO).read_bytes()
    (Path(m["dir"]) / U.RESULTADO).unlink()
    s2 = p4(m)
    assert (s2.estado, s2.reserva_sha256, s2.resultado_sha256) == ("REGISTRADO", s1.reserva_sha256, s1.resultado_sha256)
    assert (Path(m["dir"]) / U.RECIBO).read_bytes() == recibo and cadena(m)["evidencia"]["validez"] == "VERIFICADO"


# ---------- X11, X12, X14: anclas y recibos que no son referencia independiente ----------
def test_X11_ancla_local_nunca_da_evidencia_valida(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, RESP, firmada=False)
    assert p4(m).estado == "REGISTRADO" and not (Path(m["dir"]) / U.RECIBO).exists()
    s = cadena(m)
    assert resumen(s)[:3] == ("INCONCLUSO", None, "NO_CANDIDATA")
    assert [x["codigo"] for x in s["resultado_verificado"]["motivos"]] == ["SIN_REFERENCIA_INDEPENDIENTE"]


def test_X12_recibo_de_un_ancla_no_aprobada(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.setattr(V, "RAICES_CONFIANZA", {"PRUEBA-PROPIETARIO": F.RAICES_PRUEBA["PRUEBA-PROPIETARIO"]})
    m = montar(tmp_path, RESP)
    p4(m)
    s = cadena(m)
    assert resumen(s)[:3] == ("INCONCLUSO", None, "NO_CANDIDATA")
    assert "EMISOR_NO_APROBADO" in s["evidencia"]["motivo"]


def test_X14_recibo_falsificado_con_otra_clave(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, RESP)
    p4(m)
    falso = C.firmar_documento(F.SEMILLA_INTRUSA, C.declaracion(
        "PRUEBA-ANCLA", "2026-10-20T00:00:00Z", [{"sha256": m["salida"].resultado_sha256}], {}))
    (Path(m["dir"]) / U.RECIBO).write_text(json.dumps(falso), encoding="utf-8")
    s = cadena(m)
    assert s["evidencia"]["validez"] == "INCONCLUSO" and "FIRMA_INVALIDA" in s["evidencia"]["motivo"]


# ---------- X16: P2 no se elude por dentro ni por parámetros ----------
def test_X16_p2_no_acepta_evidencia_ni_registros_ajenos(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, RESP)
    p4(m)
    with pytest.raises(TypeError):
        cadena(m, autorizaciones={"X": {}})
    with pytest.raises(PA.ErrorPolitica):
        PA._decidir({"validez": "VERIFICADO", "etiqueta": "RESPALDADA FUERA DE MUESTRA"}, "NO_DEFINIDO", "NO_DEFINIDO",
                    None, None)  # type: ignore[arg-type]
    # una declaración firmada que «dice» autorizar no cambia nada: P2 solo lee el estado de P1
    ref = referencias(m)
    extra = ("autoriza", F.declarar([{"sha256": m["salida"].resultado_sha256}], contexto={"autorizacion": "TOTAL"}))
    s = PA.desde_resultado(Path(m["dir"]) / U.RESULTADO, m["raiz"], "NO_DEFINIDO", "NO_DEFINIDO",
                           resultado_sha256_esperado=ref["resultado_sha256_esperado"],
                           declaraciones=ref["declaraciones"] + [extra], reserva=ref["reserva"])
    assert s["autorizacion_ejecucion"]["estado"] == "NO_OTORGADA"


# ---------- X18: calidad_datos.json no es evidencia ----------
@con_t
def test_X18_calidad_datos_no_pasa_por_p2() -> None:
    ruta = T / "experimentos" / "calidad_datos.json"
    s = PA.desde_resultado(ruta, T, "NO_DEFINIDO", "NO_DEFINIDO")
    assert resumen(s)[:3] == ("INCONCLUSO", None, "NO_CANDIDATA")
    assert s["evidencia"]["motivo"].startswith("PROCEDENCIA_NO_VERIFICADA")


# ---------- X8: ningún componente modifica los resultados congelados de T ----------
@con_t
def test_X8_artefactos_congelados_intactos() -> None:
    leidos = [T / "experimentos" / "fuera_de_muestra_T.json", T / "experimentos" / "fuera_de_muestra_T.py",
              T / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md", *sorted((T / "src" / "tendencia").glob("*.py")),
              T / "datos" / "BTCUSDT" / "MANIFIESTO.json", T / "datos" / "ETHUSDT" / "MANIFIESTO.json",
              T / "papel" / "prerregistro_papel.json", T / "ARTEFACTOS_SHA256.txt", T / "EVIDENCIA_T_MULTI.json",
              T / "experimentos" / "calidad_datos.json"]

    def huella() -> list:
        return [(str(p), hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns) for p in leidos]

    antes = huella()
    man = V.unir_manifiestos([str(T / "ARTEFACTOS_SHA256.txt"),
                              f"{T / 'EVIDENCIA_T_MULTI.json'}#cadena_historica_T_fuera_de_muestra"])
    V.evaluar_archivo(leidos[0], raiz=T, manifiesto=man)
    PA.desde_resultado(leidos[0], T, "NO_DEFINIDO", "NO_DEFINIDO", manifiesto=man)
    V.evaluar_archivo(leidos[-1], raiz=T)
    assert huella() == antes
    assert antes[0][1] == "4f8fafde372931aab29b94612eb658f5fac9259e51cdf7dace7a1b30fc633c45"


# ---------- X9: P1, P2 y confianza no ejecutan ni escriben; P4 solo lanza su hijo ----------
def _peligrosas(ruta: Path) -> set[str]:
    arbol = ast.parse(ruta.read_bytes())
    mods = {a.name.split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        (n.module or "").split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    out = mods & {"subprocess", "runpy", "importlib", "shutil", "socket", "urllib", "http", "ctypes"}
    for n in ast.walk(arbol):
        if isinstance(n, ast.Call):
            f = ast.unparse(n.func)
            if f in ("exec", "eval", "compile", "__import__") or f.startswith("os.") and f.split(".")[1] in (
                    "replace", "rename", "remove", "unlink", "system", "popen", "write", "makedirs", "mkdir"):
                out.add(f)
            if f.split(".")[-1] in ("write_text", "write_bytes", "unlink", "rename", "mkdir", "rmdir", "touch"):
                out.add(f)
            if f == "open" and len(n.args) > 1 and any(c in ast.unparse(n.args[1]) for c in "wax+"):
                out.add("open(escritura)")
    return out


def test_X9_p1_p2_y_confianza_no_ejecutan_ni_escriben() -> None:
    for nombre in ("verificar_reproduccion_T.py", "politica_avance_T.py", "confianza.py"):
        assert _peligrosas(version.CODIGO_ACTUAL / nombre) == set(), nombre


def test_X9_p4_solo_lanza_su_hijo_y_no_nombra_ejecutores_de_t() -> None:
    arbol = ast.parse((version.CODIGO_ACTUAL / "uso_unico.py").read_bytes())
    lanz = [ast.unparse(n.args[0]) for n in ast.walk(arbol) if isinstance(n, ast.Call)
            and ast.unparse(n.func) in ("subprocess.Popen", "subprocess.run")]
    assert lanz == ["[sys.executable, '-I', '-S', '-B', '-c', _HIJO, str(w)]"]
    textos = [n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and isinstance(n.value, str)
              and n is not arbol.body[0].value]
    assert not any("fuera_de_muestra_T" in t or "corte.py" in t for t in textos)
