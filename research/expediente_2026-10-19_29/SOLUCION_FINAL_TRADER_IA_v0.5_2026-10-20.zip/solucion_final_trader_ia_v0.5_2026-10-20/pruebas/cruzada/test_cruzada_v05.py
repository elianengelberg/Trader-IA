"""Auditoría cruzada v0.5 (P4 → P1 → P2) con datos y resultados SINTÉTICOS. Cada prueba X2x intenta eludir uno de
los controles nuevos y comprueba que no lo consigue:
- X20 un recibo solo vale con la RESERVA de su ejecución; recibos intercambiados entre ejecuciones no autentican;
- X21 una reproducción EJECUTADA por P4 (reserva con ``reproduccion_de``) y autenticada por su propio recibo da
  REPRODUCIDO; con código no determinista, NO_REPRODUCIDO (evidencia no válida para P2);
- X22 una «reproducción» con otro código no se acepta como reproducción;
- X23 una reproducción alterada después de su registro es REPRODUCCION_CONTRADICHA;
- X24 el recibo del ORIGINAL no autentica una copia presentada como reproducción;
- X25 ni el ancla ni las raíces admiten claves de orden pequeño;
- X26 REPRODUCIDO tampoco otorga autorización.
La raíz del ancla es la SINTÉTICA «PRUEBA-ANCLA» (monkeypatch)."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import fabricas_t as F
import pytest
import version
from ancla_de_prueba import ServidorAnclaDePrueba
from version import desde_v05

pytestmark = desde_v05
V, PA, U, C = version.p1(), version.p2(), version.p4(), F.C
AQUI = Path(__file__).resolve().parent
RESP = {"p_conj": 0.97, "p_btc": 0.95, "x2": 0.02, "exceso": 0.12, "decision": "RESPALDADA FUERA DE MUESTRA"}


def montar(tmp: Path, parametros: dict = RESP, codigo: str = "codigo_oos_sintetico.py", experimento: str = "X") -> dict:
    raiz = F.arbol_t(tmp / "T")
    (tmp / "parametros.json").write_text(json.dumps(parametros), encoding="utf-8")
    (tmp / "contador.txt").write_text(str(tmp / "llamadas.txt"), encoding="utf-8")
    archivos = {"codigo": AQUI / codigo, "parametros": tmp / "parametros.json", "contador": tmp / "contador.txt",
                "prerregistro": raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                "script": raiz / "experimentos" / "fuera_de_muestra_T.py",
                **{f"src/{p.name}": p for p in sorted((raiz / "src" / "tendencia").glob("*.py"))},
                **{f"manifiesto_{s}": raiz / "datos" / s / "MANIFIESTO.json" for s in ("BTCUSDT", "ETHUSDT")}}
    servidor = ServidorAnclaDePrueba(tmp / "ancla" / "A.jsonl", F.SEMILLA_ANCLA, "PRUEBA-ANCLA", modulo=U)
    return {"raiz": raiz, "archivos": {k: str(v) for k, v in archivos.items()}, "experimento": experimento,
            "ancla": U.AnclaFirmada(servidor, servidor.publica, "PRUEBA-ANCLA"), "tmp": tmp}


def ejecutar(m: dict, nombre: str, **kw) -> tuple[U.Salida, Path]:  # type: ignore[no-untyped-def]
    d = m["tmp"] / nombre
    return U.ejecutar(d, m["experimento"], m["archivos"], 7, ancla=m["ancla"], **kw), d


def recibo(d: Path) -> tuple[str, dict]:
    return (f"recibo_{d.name}", json.loads((d / U.RECIBO).read_text(encoding="utf-8")))


def evaluar(m: dict, d: Path, **kw) -> dict:  # type: ignore[no-untyped-def]
    return PA.desde_resultado(d / U.RESULTADO, m["raiz"], "NO_DEFINIDO", "NO_DEFINIDO", **kw)


def validez(s: dict) -> tuple:
    return (s["evidencia"]["validez"], [x["codigo"] for x in s["resultado_verificado"]["motivos"]])


# ---------- X20 ----------
def test_X20_recibo_ligado_a_su_reserva(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    a = montar(tmp_path / "a", experimento="A")
    b = montar(tmp_path / "b", RESP | {"exceso": 0.11}, experimento="B")  # otro resultado
    sa, da = ejecutar(a, "estado")
    sb, db = ejecutar(b, "estado")
    assert sa.estado == sb.estado == "REGISTRADO"
    ra, rb = U.leer(da)["reserva"], U.leer(db)["reserva"]
    assert validez(evaluar(a, da, declaraciones=[recibo(da)], reserva=ra))[0] == "VERIFICADO"
    assert validez(evaluar(a, da, declaraciones=[recibo(da)])) == ("INCONCLUSO", ["SIN_REFERENCIA_INDEPENDIENTE"])
    assert validez(evaluar(a, da, declaraciones=[recibo(db)], reserva=ra))[0] == "INCONCLUSO"  # recibo ajeno
    assert validez(evaluar(a, da, declaraciones=[recibo(da)], reserva=rb))[0] == "INCONCLUSO"  # reserva ajena
    assert sa.resultado_sha256 != sb.resultado_sha256
    shutil.copy(db / U.RESULTADO, da / U.RESULTADO)  # el resultado de B con el recibo y la reserva de A: contradicción
    assert validez(evaluar(a, da, declaraciones=[recibo(da)], reserva=ra)) == ("CORRUPTO", ["RECIBO_CONTRADICE"])
    # y con el recibo de B y la reserva de A: el recibo no aplica, sigue sin referencia (no se «presta» un recibo)
    assert validez(evaluar(a, da, declaraciones=[recibo(db)], reserva=ra)) == ("INCONCLUSO", ["SIN_REFERENCIA_INDEPENDIENTE"])


# ---------- X21 ----------
@pytest.mark.parametrize("codigo,esperado", [("codigo_oos_sintetico.py", "REPRODUCIDO"),
                                             ("codigo_oos_nodet.py", "NO_REPRODUCIDO")])
def test_X21_reproduccion_ejecutada_por_p4(tmp_path: Path, raices, codigo: str, esperado: str) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, codigo=codigo)
    so, do = ejecutar(m, "original")
    sr, dr = ejecutar(m, "reproduccion", reproduccion_de=so.resultado_sha256)
    assert so.estado == sr.estado == "REGISTRADO"
    s = evaluar(m, do, declaraciones=[recibo(do), recibo(dr)], reserva=U.leer(do)["reserva"],
                reproduccion=dr / U.RESULTADO, reserva_reproduccion=U.leer(dr)["reserva"])
    assert s["evidencia"]["validez"] == esperado
    assert s["resultado_verificado"]["reproduccion"]["autenticidad"]["vias"] == ["RECIBO_ANCLA"]
    assert (s["etiqueta_estadistica"] is not None) == (esperado == "REPRODUCIDO")
    # sin la reserva de la reproducción, su recibo no la liga: INCONCLUSO
    s = evaluar(m, do, declaraciones=[recibo(do), recibo(dr)], reserva=U.leer(do)["reserva"], reproduccion=dr / U.RESULTADO)
    assert validez(s) == ("INCONCLUSO", ["REPRODUCCION_NO_AUTENTICADA"])


# ---------- X22 ----------
def test_X22_otro_codigo_no_es_una_reproduccion(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)
    so, do = ejecutar(m, "original")
    otro = tmp_path / "otro_codigo.py"
    otro.write_text((AQUI / "codigo_oos_sintetico.py").read_text() + "\n# variante\n", encoding="utf-8")
    m2 = m | {"archivos": m["archivos"] | {"codigo": str(otro)}}
    sr, dr = ejecutar(m2, "reproduccion", reproduccion_de=so.resultado_sha256)
    assert sr.estado == "REGISTRADO"
    s = evaluar(m, do, declaraciones=[recibo(do), recibo(dr)], reserva=U.leer(do)["reserva"],
                reproduccion=dr / U.RESULTADO, reserva_reproduccion=U.leer(dr)["reserva"])
    assert validez(s) == ("INCONCLUSO", ["REPRODUCCION_NO_AUTENTICADA"])
    assert "difiere en ['archivos_sha256']" in s["resultado_verificado"]["motivos"][0]["detalle"]


# ---------- X23 ----------
def test_X23_reproduccion_alterada_tras_su_registro(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)
    so, do = ejecutar(m, "original")
    sr, dr = ejecutar(m, "reproduccion", reproduccion_de=so.resultado_sha256)
    o = json.loads((dr / U.RESULTADO).read_text())
    o["principal"]["conjunto"]["p"] = 0.96  # sigue siendo RESPALDADA: la alteración no cambia la etiqueta
    (dr / U.RESULTADO).write_text(json.dumps(o), encoding="utf-8")
    s = evaluar(m, do, declaraciones=[recibo(do), recibo(dr)], reserva=U.leer(do)["reserva"],
                reproduccion=dr / U.RESULTADO, reserva_reproduccion=U.leer(dr)["reserva"])
    assert validez(s) == ("INCONCLUSO", ["REPRODUCCION_CONTRADICHA"])


# ---------- X24 ----------
def test_X24_el_recibo_del_original_no_autentica_una_copia(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)
    so, do = ejecutar(m, "original")
    copia = tmp_path / "copia.json"
    shutil.copy(do / U.RESULTADO, copia)
    reserva = U.leer(do)["reserva"]
    for rr in (None, reserva, reserva | {"reproduccion_de": so.resultado_sha256}):
        s = evaluar(m, do, declaraciones=[recibo(do)], reserva=reserva, reproduccion=copia, reserva_reproduccion=rr)
        assert validez(s) == ("INCONCLUSO", ["REPRODUCCION_NO_AUTENTICADA"]), rr


# ---------- X25 ----------
def test_X25_claves_de_orden_pequeno(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    for clave in ("01" + "00" * 31, "00" * 32):
        with pytest.raises(ValueError):
            U.AnclaFirmada(lambda s: s, clave, "X")
        r = F.raiz("R", F.SEMILLA_PROPIETARIO) | {"clave_publica_ed25519": clave}
        monkeypatch.setattr(V, "RAICES_CONFIANZA", {"R": r})
        raiz = F.arbol_t(tmp_path / clave[:4] / "T")
        ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
        ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
        falsa = {"contenido": C.declaracion("R", "2026-10-20T00:00:00Z", [{"sha256": F.sha(ruta.read_bytes())}]),
                 "firma_ed25519": ("01" + "00" * 31) + "00" * 32}
        inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=[("falsa", falsa)])
        assert inf["estado"] == "INCONCLUSO" and "RAIZ_INVALIDA" in inf["motivos"][0]["detalle"]


# ---------- X26 ----------
def test_X26_reproducido_no_autoriza(tmp_path: Path, raices, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)
    so, do = ejecutar(m, "original")
    sr, dr = ejecutar(m, "reproduccion", reproduccion_de=so.resultado_sha256)
    kw = {"declaraciones": [recibo(do), recibo(dr)], "reserva": U.leer(do)["reserva"], "reproduccion": dr / U.RESULTADO,
          "reserva_reproduccion": U.leer(dr)["reserva"]}
    s = evaluar(m, do, **kw)
    assert (s["evidencia"]["validez"], s["decision_avance"]["resultado"], s["autorizacion_ejecucion"]["estado"]) == (
        "REPRODUCIDO", "CANDIDATA_A_REVISION_HUMANA", "NO_OTORGADA")
    monkeypatch.setattr(PA, "ETAPAS_DEFINIDAS", {"E": "sintética"})
    monkeypatch.setattr(PA, "AUTORIZACIONES", {"A": {"id": "A", "etapa": "E", "resultado_sha256": "0" * 64,
                                                     "otorgada_por": "PRUEBA", "otorgada_utc": "2030-01-01T00:00:00Z",
                                                     "texto_sha256": "1" * 64}})
    s = evaluar(m, do, etapa="E", autorizacion="A", **kw)  # una autorización para OTRO resultado
    assert s["autorizacion_ejecucion"]["estado"] == "CONTRADICTORIA"
