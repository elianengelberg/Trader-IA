#!/usr/bin/env bash
# Huella del estado del repositorio, en SOLO LECTURA, para comparar antes y después. No lee bytes de datos de mercado:
# - HEAD, origin y todas las referencias (un commit, un push o una rama nueva las cambian);
# - `git status --porcelain --ignored` (última línea: la huella que citan los documentos);
# - el CONTENIDO de los cambios sin commit de archivos versionados (`git diff`) y de los archivos de texto sin
#   seguimiento que no son datos (corte.py, su prueba, la verificación operativa);
# - para los directorios sin seguimiento o ignorados (datos, entornos, entregas): solo METADATOS (ruta, tamaño, mtime).
# Uso: bash estado_repositorio.sh <raíz del repositorio>
set -u
REPO=${1:?}
cd "$REPO"
echo "HEAD $(git rev-parse HEAD)"
echo "origin/claude/algo-trading-simulation-platform-ngf7xo $(git rev-parse origin/claude/algo-trading-simulation-platform-ngf7xo)"
echo "referencias (git for-each-ref): $(git for-each-ref | sha256sum | cut -c1-64)"
echo "contenido de los cambios sin commit (git diff): $(git diff | sha256sum | cut -c1-64)"
git status --porcelain --ignored | while IFS= read -r linea; do
  ruta=${linea:3}
  case "$ruta" in
    */) echo "  ${linea:0:2} $ruta metadatos: $(find "$ruta" -printf '%P %s %T@\n' | LC_ALL=C sort | sha256sum | cut -c1-64)" ;;
    *.md|*.py|*.txt|.gitignore|*/.gitignore) echo "  ${linea:0:2} $ruta contenido: $(sha256sum < "$ruta" | cut -c1-64)" ;;
    *) echo "  ${linea:0:2} $ruta metadatos: $(stat -c '%s %Y' "$ruta")" ;;
  esac
done
git status --porcelain --ignored | sha256sum
