"""Conductor de las pruebas del ejecutor aislado: corre ``ejecutar_encargo`` en un proceso aparte con el doble de
prueba del ancla externa (raíz SINTÉTICA aprobada solo dentro de este proceso), caída real (os._exit) en un punto,
pausa determinista (FIFO) o fallos de escritura inyectados en el módulo del ejecutor."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent / "comun"))
import fabricas_t as F  # noqa: E402
import version  # noqa: E402
from ancla_de_prueba import ServidorAnclaDePrueba  # noqa: E402

if __name__ == "__main__":
    a = json.loads(sys.argv[1])
    E, V, U = version.ejecutor(), version.p1(), version.p4()
    V.RAICES_CONFIANZA = dict(F.RAICES_PRUEBA) if a.get("raices", True) else {}
    servidor = ServidorAnclaDePrueba(a["ancla"], F.SEMILLA_ANCLA, "PRUEBA-ANCLA", modulo=U)
    ancla = U.AnclaFirmada(servidor, servidor.publica, "PRUEBA-ANCLA")
    proxy = None
    if a.get("fallos_es"):
        from fallos_es import OSConFallos
        proxy = OSConFallos(os, a["fallos_es"])
        E.os = proxy

    def fallo(p: str) -> None:
        if p == a.get("punto"):
            os._exit(137)
        if p == a.get("pausa"):
            with open(a["listo"], "w") as fh:
                fh.write(p)
            with open(a["seguir"]) as fh:
                fh.read()

    informe = E.ejecutar_encargo(a["encargo"], a["dir"], ancla, fallo=fallo)
    informe.pop("salida_p2", None)
    if proxy is not None:
        informe["inyectado"] = proxy.inyectado
    print(json.dumps(informe, ensure_ascii=False, default=str))
