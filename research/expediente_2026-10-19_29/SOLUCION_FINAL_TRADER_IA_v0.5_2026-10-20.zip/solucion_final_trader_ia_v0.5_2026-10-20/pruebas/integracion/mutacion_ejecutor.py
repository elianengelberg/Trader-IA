"""Prueba de las pruebas del EJECUTOR AISLADO: cada mutación quita un control de una COPIA de ejecutor_aislado.py y la
suite de integración debe fallar. Uso: python3 mutacion_ejecutor.py <dir_codigo> <salida.txt>"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
MUTACIONES = [
    ("no rechaza archivos protegidos", "    motivos = _protegido(e, protegidas)\n", "    motivos = []\n"),
    ("no liga lo que produjo P4", "    lig, problemas = _ligar(dc / \"original\", s, e[\"archivos\"], emite)\n",
     "    lig, problemas = _ligar(dc / \"original\", s, e[\"archivos\"], emite)\n    problemas = []\n"),
    ("no pasa la reserva a P1 (el recibo no cuenta)", "declaraciones=decl, reserva=lig[\"reserva\"],",
     "declaraciones=decl, reserva=None,"),
    ("no pasa la reproducción a P2", "            reproduccion=(dc / \"reproduccion\" / U.RESULTADO) if lig_r else None,",
     "            reproduccion=None,"),
    ("añade una entrada en cada llamada (sin idempotencia)",
     "    if previas and previas[-1][\"tipo\"] == tipo and {", "    if False and {"),
    ("no valida la cadena del registro", "        if x[\"n\"] != i or x[\"anterior\"] != anterior or x[\"tipo\"] not in TIPOS_ENTRADA or x[\"accion_ejecutada\"] != ACCION:",
     "        if False:"),
    ("no descarta la cola desgarrada del registro", "        if cola:  # una caída", "        if False:  # una caída"),
    ("no exige límite de tiempo", "    if not e[\"experimento\"] or not e[\"raiz_t\"] or e[\"limite_segundos\"] < 1:",
     "    e[\"limite_segundos\"] = None\n    if not e[\"experimento\"] or not e[\"raiz_t\"]:"),
    ("registra una acción ejecutada", 'ACCION = "NINGUNA"', 'ACCION = "EJECUTAR"'),
    ("no comprueba la coherencia de las entradas del registro", "        malas = _incoherencias(x)\n",
     "        malas = []\n"),
]


def main(codigo: Path, salida: Path) -> int:
    lineas, muertas = [], 0
    for desc, viejo, nuevo in MUTACIONES:
        with tempfile.TemporaryDirectory() as tmp:
            for p in codigo.glob("*.py"):
                shutil.copy(p, tmp)
            f = Path(tmp) / "ejecutor_aislado.py"
            texto = f.read_text(encoding="utf-8")
            if texto.count(viejo) != 1:
                raise SystemExit(f"{desc}: el original aparece {texto.count(viejo)} veces")
            f.write_text(texto.replace(viejo, nuevo), encoding="utf-8")
            r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q", "-rf", "--tb=no",
                                "integracion"], cwd=AQUI.parent, capture_output=True, text=True, timeout=1800,
                               env={**os.environ, "CODIGO_ACTUAL_DIR": tmp, "PYTHONDONTWRITEBYTECODE": "1"})
        fallidas = sorted({m.split("::")[-1].split(" ")[0] for m in re.findall(r"FAILED (\S+)", r.stdout)})
        muertas += bool(fallidas)
        lineas.append(f"{'MUERTA' if fallidas else 'SOBREVIVE'}\t{desc}\t{len(fallidas)} pruebas fallan: "
                      f"{', '.join(fallidas[:5])}{' …' if len(fallidas) > 5 else ''}")
    lineas.append(f"{muertas} de {len(MUTACIONES)} mutaciones del ejecutor detectadas")
    salida.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print(lineas[-1])
    return 0 if muertas == len(MUTACIONES) else 1


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()))
