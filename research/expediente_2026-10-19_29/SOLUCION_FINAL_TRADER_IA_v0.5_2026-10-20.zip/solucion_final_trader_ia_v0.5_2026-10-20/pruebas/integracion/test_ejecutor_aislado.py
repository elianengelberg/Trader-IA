"""Ejecutor aislado (v0.5): pruebas de CONTRATO y de EXTREMO A EXTREMO de P4 → P1 → P2 con el registro de decisiones.
Todo con datos, código y claves SINTÉTICOS; el ancla externa es el doble de prueba (no existe un servicio real). Cada
registro se comprueba con un verificador INDEPENDIENTE (``revisar_registro``, escrito aquí sin usar el ejecutor)."""
from __future__ import annotations

import ast
import contextlib
import hashlib
import io
import json
import os
import select
import subprocess
import sys
import time
from pathlib import Path

import fabricas_t as F
import pytest
import version
from ancla_de_prueba import ServidorAnclaDePrueba
from version import desde_v05

pytestmark = desde_v05
E, V, PA, U = version.ejecutor(), version.p1(), version.p2(), version.p4()
AQUI = Path(__file__).resolve().parent
CODIGO = AQUI.parent / "cruzada" / "codigo_oos_sintetico.py"
NODET = AQUI.parent / "cruzada" / "codigo_oos_nodet.py"
RESP = {"p_conj": 0.97, "p_btc": 0.95, "x2": 0.02, "exceso": 0.12, "decision": "RESPALDADA FUERA DE MUESTRA"}
T = F.T_REAL


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def montar(tmp: Path, codigo: Path = CODIGO, **cambios: object) -> dict:
    raiz = F.arbol_t(tmp / "T")
    (tmp / "parametros.json").write_text(json.dumps(RESP), encoding="utf-8")
    (tmp / "contador.txt").write_text(str(tmp / "llamadas.txt"), encoding="utf-8")
    archivos = {"codigo": codigo, "parametros": tmp / "parametros.json", "contador": tmp / "contador.txt",
                "prerregistro": raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                "script": raiz / "experimentos" / "fuera_de_muestra_T.py",
                **{f"src/{p.name}": p for p in sorted((raiz / "src" / "tendencia").glob("*.py"))},
                **{f"manifiesto_{s}": raiz / "datos" / s / "MANIFIESTO.json" for s in ("BTCUSDT", "ETHUSDT")}}
    encargo = {"experimento": "EJECUTOR-1", "archivos": {k: str(v) for k, v in archivos.items()}, "semilla": 7,
               "limite_segundos": 60, "raiz_t": str(raiz)} | cambios
    return {"encargo": encargo, "dir": tmp / "trabajo", "ancla_ruta": tmp / "ancla" / "A.jsonl", "tmp": tmp}


def ancla(m: dict):  # type: ignore[no-untyped-def]
    servidor = ServidorAnclaDePrueba(m["ancla_ruta"], F.SEMILLA_ANCLA, "PRUEBA-ANCLA", modulo=U)
    return U.AnclaFirmada(servidor, servidor.publica, "PRUEBA-ANCLA")


def correr(m: dict, **kw) -> dict:  # type: ignore[no-untyped-def]
    return E.ejecutar_encargo(m["encargo"], m["dir"], kw.pop("ancla", None) or ancla(m), **kw)


def calculos(m: dict) -> int:
    p = m["tmp"] / "llamadas.txt"
    return len(p.read_text().splitlines()) if p.exists() else 0


def revisar_registro(ruta: Path) -> list[dict]:
    """Verificador INDEPENDIENTE del registro: cadena, forma y coherencia entre P4, P1 y P2 en cada entrada."""
    if not ruta.exists():
        return []
    datos = ruta.read_bytes()
    assert datos.endswith(b"\n"), "el registro no termina en una línea completa"
    entradas, anterior = [], None
    for i, b in enumerate(datos.split(b"\n")[:-1]):
        x = json.loads(b)
        assert json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode() == b, i
        assert x["n"] == i and x["anterior"] == anterior and x["accion_ejecutada"] == "NINGUNA", i
        assert x["contenido_sha256"] == sha(json.dumps(x["contenido"], ensure_ascii=False, sort_keys=True,
                                                       separators=(",", ":")).encode()), i
        c = x["contenido"]
        if x["tipo"] == "DECIDIDO":
            p4, p1, p2 = c["p4"], c["p1"], c["p2"]
            assert p4["estado"] == "REGISTRADO" and p1["estado"] == p2["validez"]
            assert p1["resultado_sha256"] == p4["resultado_sha256"]
            if "RECIBO_ANCLA" in p1["vias"]:
                assert p1["reserva_sha256"] == p4["reserva_sha256"]
            if p2["validez"] not in ("VERIFICADO", "REPRODUCIDO"):
                assert p2["etiqueta_estadistica"] is None and p2["avance"] == "NO_CANDIDATA"
            assert p2["autorizacion"] in ("NO_OTORGADA", "CONTRADICTORIA", "REGISTRADA_EXTERNAMENTE")
            if p2["validez"] == "REPRODUCIDO":
                assert c["reproduccion"]["estado"] == "REGISTRADO"
        entradas.append(x)
        anterior = sha(b)
    return entradas


def decididas(m: dict) -> list[dict]:
    return [x for x in revisar_registro(m["dir"] / E.REGISTRO) if x["tipo"] == "DECIDIDO"]


# ---------- cadena válida, reanudación idempotente ----------
def test_cadena_valida_y_reanudacion_idempotente(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)
    a = correr(m)
    assert a["estado"] == "DECIDIDO" and a["accion_ejecutada"] == "NINGUNA"
    c = a["contenido"]
    assert (c["p1"]["estado"], c["p1"]["vias"], c["p2"]["avance"], c["p2"]["autorizacion"]) == (
        "VERIFICADO", ["RECIBO_ANCLA"], "CANDIDATA_A_REVISION_HUMANA", "NO_OTORGADA")
    b = correr(m)
    assert b["estado"] == "DECIDIDO" and b["registro"]["nueva"] is False and b["registro"]["n"] == a["registro"]["n"]
    assert calculos(m) == 1 and len(decididas(m)) == 1


def test_con_reproduccion(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, reproducir=True)
    a = correr(m)
    assert a["contenido"]["p2"]["validez"] == "REPRODUCIDO" and calculos(m) == 2
    m2 = montar(tmp_path / "nodet", NODET, reproducir=True)
    b = correr(m2)
    assert (b["contenido"]["p2"]["validez"], b["contenido"]["p2"]["avance"]) == ("NO_REPRODUCIDO", "NO_CANDIDATA")
    revisar_registro(m2["dir"] / E.REGISTRO)


# ---------- la evidencia local nunca se vuelve auténtica sola ----------
def test_evidencia_local_no_es_autentica(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path / "local")
    a = correr(m, ancla=U.AnclaArchivo(tmp_path / "local" / "ANCLA.jsonl"))
    assert (a["contenido"]["p1"]["estado"], a["contenido"]["p2"]["avance"]) == ("INCONCLUSO", "NO_CANDIDATA")
    m = montar(tmp_path / "no_aprobada")  # recibo firmado, pero la raíz del ancla NO está aprobada en P1
    monkeypatch.setattr(V, "RAICES_CONFIANZA", {})
    b = correr(m)
    assert b["contenido"]["p1"]["motivos"] == ["SIN_REFERENCIA_INDEPENDIENTE"] and b["contenido"]["p2"]["validez"] == (
        "INCONCLUSO")


# ---------- archivos protegidos y encargos inválidos ----------
def test_archivos_protegidos_se_rechazan_sin_tocar_p4(tmp_path: Path, raices, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path / "nombre")
    corte = tmp_path / "corte.py"
    corte.write_text("def calcular(c, s):\n    return {}\n")
    m["encargo"]["archivos"]["codigo"] = str(corte)  # «corte.py» como código a ejecutar
    a = correr(m)
    assert a["estado"] == "RECHAZADO_PROTEGIDO" and not (m["dir"] / "p4").exists() and calculos(m) == 0
    assert correr(m | {"encargo": m["encargo"] | {"archivos": m["encargo"]["archivos"] | {
        "codigo": str(CODIGO), "datos_extra": str(corte)}}})["estado"] == "DECIDIDO"  # como DATO no se protege
    m = montar(tmp_path / "hash")
    monkeypatch.setitem(E.PROTEGIDOS_SHA256, sha(Path(m["encargo"]["archivos"]["codigo"]).read_bytes()), "prueba")
    assert correr(m)["estado"] == "RECHAZADO_PROTEGIDO" and calculos(m) == 0
    m = montar(tmp_path / "ruta")
    b = correr(m, rutas_protegidas=(m["encargo"]["raiz_t"],))
    assert b["estado"] == "RECHAZADO_PROTEGIDO" and not (m["dir"] / "p4").exists()
    assert len(revisar_registro(m["dir"] / E.REGISTRO)) == 1


@pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.py").is_file(), reason="T no disponible")
def test_el_script_real_de_t_esta_protegido() -> None:
    """Solo lectura: el hash protegido es el del script congelado de T (941b6e11…)."""
    assert sha((T / "experimentos" / "fuera_de_muestra_T.py").read_bytes()) in E.PROTEGIDOS_SHA256


@pytest.mark.parametrize("cambio", [{"limite_segundos": None}, {"limite_segundos": 0}, {"semilla": True},
                                    {"semilla": 1.5}, {"inventada": 1}, {"archivos": {"datos": "x"}},
                                    {"tolerancia": float("nan")}, {"reproducir": "si"}, {"etapa": 3}])
def test_encargo_invalido_no_crea_nada(tmp_path: Path, cambio: dict) -> None:
    m = montar(tmp_path)
    m["encargo"] = {k: v for k, v in (m["encargo"] | cambio).items() if v is not None}
    a = correr(m)
    assert a["estado"] == "ENCARGO_INVALIDO" and not m["dir"].exists()


# ---------- ligadura: lo que P4 produjo, alterado antes de evaluarlo ----------
@pytest.mark.parametrize("que", ["resultado", "entrada", "recibo"])
def test_alteracion_entre_p4_y_la_evaluacion_es_inconsistente(tmp_path: Path, raices, que: str) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)

    def fallo(p: str) -> None:
        if p != "tras_p4":
            return
        if que == "resultado":
            r = E.dir_calculo(m["dir"], E.validar_encargo(m["encargo"])) / "original" / U.RESULTADO
            r.write_text(r.read_text().replace("0.97", "0.98"), encoding="utf-8")
        elif que == "entrada":
            Path(m["encargo"]["archivos"]["parametros"]).write_text(json.dumps(RESP | {"x2": 0.03}))
        else:
            (E.dir_calculo(m["dir"], E.validar_encargo(m["encargo"])) / "original" / U.RECIBO).write_text("{}", encoding="utf-8")

    a = correr(m, fallo=fallo)
    assert a["estado"] == "INCONSISTENTE" and a["contenido"]["problemas"], a
    assert decididas(m) == []


# ---------- interrupciones y reanudación (procesos hijos, caída real) ----------
def _hijo(m: dict, limite: float = 300, **extra: object) -> dict:
    """Ejecutor en un proceso hijo, en su PROPIO grupo: si no termina en ``limite`` segundos se detiene el grupo entero
    (también el cálculo de P4) y la prueba lo ve como «SIN_TERMINAR»."""
    args = {"encargo": m["encargo"], "dir": str(m["dir"]), "ancla": str(m["ancla_ruta"])} | extra
    p = subprocess.Popen([sys.executable, "-B", str(AQUI / "_conductor_ejecutor.py"), json.dumps(args)],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True,
                         env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    try:
        out, err = p.communicate(timeout=limite)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, 9)
        p.communicate()
        return {"estado": "SIN_TERMINAR"}
    return json.loads(out) if p.returncode == 0 else {"estado": f"MURIO({p.returncode})", "stderr": err[-400:]}


def test_limite_de_tiempo_obligatorio(tmp_path: Path) -> None:
    m = montar(tmp_path, AQUI.parent / "p4" / "codigos_sinteticos" / "colgado.py", limite_segundos=2)
    a = _hijo(m, limite=60)
    assert (a["estado"], a.get("contenido", {}).get("p4", {}).get("estado")) == ("SIN_RESULTADO", "FALLO_CALCULO"), a
    b = _hijo(m, limite=60)
    assert b["contenido"]["p4"]["estado"] == "REVISION_HUMANA" and calculos(m) == 1


@pytest.mark.parametrize("punto", ["tras_p4", "tras_reproduccion", "tras_p2", "durante_registro", "tras_registro"])
def test_caida_en_cada_punto_y_reanudacion(tmp_path: Path, punto: str) -> None:
    referencia = montar(tmp_path / "ref", reproducir=True)
    limpio = _hijo(referencia)
    assert limpio["estado"] == "DECIDIDO"
    m = montar(tmp_path / "caida", reproducir=True)
    assert _hijo(m, punto=punto)["estado"] == "MURIO(137)"
    s = _hijo(m)
    assert s["estado"] == "DECIDIDO", s
    entradas = revisar_registro(m["dir"] / E.REGISTRO)
    d = [x for x in entradas if x["tipo"] == "DECIDIDO"]
    assert len(d) == 1 and calculos(m) == 2  # una decisión; un cálculo original y uno de reproducción
    def semantico(c: dict) -> dict:  # los hashes dependen de las rutas temporales de cada montaje: se quitan
        return {"p1": {k: v for k, v in c["p1"].items() if not k.endswith("sha256")}, "p2": c["p2"],
                "estados_p4": (c["p4"]["estado"], c["reproduccion"]["estado"])}
    assert semantico(d[0]["contenido"]) == semantico(limpio["contenido"])
    assert d[0]["contenido"]["p1"]["resultado_sha256"] == d[0]["contenido"]["p4"]["resultado_sha256"]
    if punto == "durante_registro":
        assert [x["tipo"] for x in entradas] == ["COLA_ROTA_DESCARTADA", "DECIDIDO"]
    assert _hijo(m)["registro"]["nueva"] is False


def test_registro_roto_no_ejecuta_nada(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)
    assert correr(m)["estado"] == "DECIDIDO"
    otro = montar(tmp_path / "otro", experimento="EJECUTOR-2")  # otro cálculo (otras entradas), mismo directorio
    m2 = otro | {"dir": m["dir"], "ancla_ruta": m["ancla_ruta"]}
    assert correr(m2)["estado"] == "DECIDIDO"
    mismas = correr(m | {"encargo": m["encargo"] | {"experimento": "OTRO-NOMBRE"}})  # mismas entradas, otro nombre
    assert (mismas["estado"], mismas["contenido"]["p4"]["estado"]) == ("SIN_RESULTADO", "RECHAZADO")
    otra_semilla = correr(m | {"encargo": m["encargo"] | {"semilla": 8}})  # mismo experimento, otra semilla: P4 lo
    assert (otra_semilla["estado"], otra_semilla["contenido"]["p4"]["estado"]) == ("SIN_RESULTADO", "RECHAZADO")
    r = m["dir"] / E.REGISTRO
    lineas = r.read_bytes().split(b"\n")
    lineas[0] = lineas[0].replace(b'"NINGUNA"', b'"OPERAR"')
    r.write_bytes(b"\n".join(lineas))
    m3 = m | {"encargo": m["encargo"] | {"experimento": "EJECUTOR-3"}}
    a = correr(m3)
    assert a["estado"] == "REGISTRO_INCONSISTENTE" and calculos(m) == 1 and calculos(m2) == 1
    assert r.read_bytes() == b"\n".join(lineas)  # nada se reescribe


def _anexar_falsa(ruta: Path, contenido: dict) -> None:
    """Inyección con la cadena de hashes CORRECTA (quien puede escribir el archivo puede recalcularla)."""
    lineas = ruta.read_bytes().split(b"\n")[:-1]
    canon = lambda o: json.dumps(o, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()  # noqa: E731
    x = {"n": len(lineas), "utc": "2026-10-20T00:00:00.000000Z", "anterior": sha(lineas[-1]), "tipo": "DECIDIDO",
         "encargo_sha256": "e" * 64, "contenido": contenido, "contenido_sha256": sha(canon(contenido)),
         "accion_ejecutada": "NINGUNA", "version": E.VERSION}
    ruta.write_bytes(ruta.read_bytes() + canon(x) + b"\n")


def test_inyeccion_en_el_registro(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path)
    real = correr(m)["contenido"]
    r = m["dir"] / E.REGISTRO
    original = r.read_bytes()
    incoherente = json.loads(json.dumps(real))
    incoherente["p2"]["validez"] = "VERIFICADO"
    incoherente["p1"]["estado"] = "INCONCLUSO"  # P1 y P2 se contradicen
    _anexar_falsa(r, incoherente)
    assert correr(m | {"encargo": m["encargo"] | {"etapa": None, "r1": "NO_DEFINIDO"}})["estado"] == "REGISTRO_INCONSISTENTE"
    r.write_bytes(original)
    coherente = json.loads(json.dumps(real))  # LÍMITE: una inyección coherente con la cadena recalculada no se detecta
    _anexar_falsa(r, coherente)
    assert correr(m)["estado"] == "DECIDIDO"  # documentado en GARANTIAS_Y_RIESGOS.md (registro local, sin firma)


# ---------- fallos de almacenamiento al escribir el registro ----------
@pytest.mark.parametrize("plan", [{"op": "write", "n": 1, "modo": "ENOSPC", "contiene": '"tipo":"DECIDIDO"'},
                                  {"op": "write", "n": 1, "modo": "CORTA_ENOSPC", "contiene": '"tipo":"DECIDIDO"'},
                                  {"op": "fsync", "n": 1, "modo": "EIO"}])
def test_fallo_al_escribir_el_registro_se_reintenta_sin_recalcular(tmp_path: Path, plan: dict) -> None:
    m = montar(tmp_path)
    a = _hijo(m, fallos_es=plan)
    assert a["estado"] == "FALLO_ALMACENAMIENTO_REGISTRO" and a.get("inyectado"), a
    b = _hijo(m)
    assert b["estado"] == "DECIDIDO" and calculos(m) == 1
    tipos = [x["tipo"] for x in revisar_registro(m["dir"] / E.REGISTRO)]
    assert tipos.count("DECIDIDO") == 1


# ---------- concurrencia: un solo ejecutor por registro ----------
def test_dos_ejecutores_a_la_vez(tmp_path: Path) -> None:
    m = montar(tmp_path)
    base = tmp_path / "fifo"
    os.mkfifo(f"{base}_listo")
    os.mkfifo(f"{base}_seguir")
    args = {"encargo": m["encargo"], "dir": str(m["dir"]), "ancla": str(m["ancla_ruta"]), "pausa": "tras_p4",
            "listo": f"{base}_listo", "seguir": f"{base}_seguir"}
    p = subprocess.Popen([sys.executable, "-B", str(AQUI / "_conductor_ejecutor.py"), json.dumps(args)],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    fd = os.open(args["listo"], os.O_RDONLY | os.O_NONBLOCK)  # sin bloquear si el hijo muere antes de la pausa
    try:
        fin = time.monotonic() + 120
        while not select.select([fd], [], [], 0.2)[0] or not os.read(fd, 64):
            assert p.poll() is None and time.monotonic() < fin, p.communicate()
    finally:
        os.close(fd)  # el primero ya calculó y espera
    assert _hijo(m)["estado"] == "OCUPADO"
    with open(args["seguir"], "w") as fh:
        fh.write("x")
    out, _ = p.communicate(timeout=120)
    assert json.loads(out)["estado"] == "DECIDIDO" and calculos(m) == 1


# ---------- P2: errores de la consulta y autorizaciones solo constatadas ----------
def test_error_de_politica_y_autorizacion_constatada(tmp_path: Path, raices, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    m = montar(tmp_path, etapa="NO_EXISTE")
    a = correr(m)
    assert a["estado"] == "ERROR_POLITICA" and "no definida" in a["contenido"]["error"]
    m = montar(tmp_path / "aut", etapa="E", autorizacion="A")
    monkeypatch.setattr(PA, "ETAPAS_DEFINIDAS", {"E": "sintética"})
    primera = correr(m | {"encargo": {k: v for k, v in m["encargo"].items() if k not in ("etapa", "autorizacion")}})
    monkeypatch.setattr(PA, "AUTORIZACIONES", {"A": {
        "id": "A", "etapa": "E", "resultado_sha256": primera["contenido"]["p4"]["resultado_sha256"],
        "otorgada_por": "PRUEBA SINTÉTICA", "otorgada_utc": "2030-01-01T00:00:00Z", "texto_sha256": "1" * 64}})
    b = correr(m)
    assert (b["contenido"]["p2"]["autorizacion"], b["accion_ejecutada"]) == ("REGISTRADA_EXTERNAMENTE", "NINGUNA")
    assert all(x["accion_ejecutada"] == "NINGUNA" for x in revisar_registro(m["dir"] / E.REGISTRO))


# ---------- estática: el ejecutor no ejecuta nada por su cuenta ni usa la red ----------
def test_el_ejecutor_no_lanza_procesos_ni_usa_la_red() -> None:
    arbol = ast.parse((version.CODIGO_ACTUAL / "ejecutor_aislado.py").read_bytes())
    mods = {a.name.split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        (n.module or "").split(".")[0] for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    assert not mods & {"subprocess", "socket", "urllib", "http", "ctypes", "runpy", "importlib", "shutil"}
    llamadas = {ast.unparse(n.func) for n in ast.walk(arbol) if isinstance(n, ast.Call)}
    assert not llamadas & {"exec", "eval", "compile", "__import__", "os.system", "os.popen"}
    textos = [n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and isinstance(n.value, str)
              and n is not arbol.body[0].value]  # sin el docstring
    assert E.ACCION == "NINGUNA" and not any("papel/corte" in t for t in textos)


# ---------- línea de órdenes ----------
def test_linea_de_ordenes(tmp_path: Path) -> None:
    m = montar(tmp_path)
    enc = tmp_path / "encargo.json"
    enc.write_text(json.dumps(m["encargo"]), encoding="utf-8")
    salida = io.StringIO()
    with contextlib.redirect_stdout(salida):
        codigo = E.main([str(enc), str(m["dir"]), "--ancla-local", str(tmp_path / "A.jsonl")])
    inf = json.loads(salida.getvalue())
    assert (codigo, inf["estado"], inf["contenido"]["p1"]["estado"]) == (0, "DECIDIDO", "INCONCLUSO")
    with contextlib.redirect_stdout(io.StringIO()):
        assert E.main([str(enc), str(m["dir"])]) == 2  # sin ancla
        assert E.main([str(enc), str(tmp_path / "otro"), "--ancla-local", str(tmp_path / "B.jsonl"), "--protegida",
                       m["encargo"]["raiz_t"]]) == 3
