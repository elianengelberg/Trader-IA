"""Matriz ANTES / DESPUÉS de cada defecto: ejecuta LAS MISMAS pruebas de defectos contra v0.2, v0.3, v0.4 y v0.5
(salida original de pytest y JUnit XML por versión) y agrupa los resultados por identificador de defecto.

Patrón exigido: un defecto S (corregido en v0.3) FALLA en v0.2 y PASA en v0.3, v0.4 y v0.5; un defecto N (corregido
en v0.4) FALLA en v0.3 y PASA en v0.4 y v0.5; un defecto F (corregido en v0.5) FALLA en v0.4 y PASA en v0.5 (en v0.2 y
v0.3 no se exige nada: «*»). Un control (P*_control) PASA en la versión que tiene la función. «FALLA» significa que el
defecto se manifiesta en al menos un caso. La matriz marca cada fila que no cumple el patrón; el código de salida es 1
si alguna no lo cumple.

Uso: python3 matriz_antes_despues.py <dir_evidencia>"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

AQUI = Path(__file__).resolve().parent
VERSIONES = ("v0_2", "v0_3", "v0_4", "v0_5")
ARCHIVOS = ("p1/test_p1_defectos.py", "p2/test_p2_defectos.py", "p4/test_p4_defectos.py", "p4/test_p4_fallos_es.py",
            "p1/test_p1_defectos_v05.py", "p2/test_p2_defectos_v05.py", "p4/test_p4_defectos_v05.py")


def correr(version: str, destino: Path) -> dict[str, tuple[str, str]]:
    xml = destino / f"junit_defectos_{version}.xml"
    r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q", "-rA", "--tb=line",
                        f"--junitxml={xml}", *ARCHIVOS], cwd=AQUI, capture_output=True, text=True, check=False,
                       env={**os.environ, "VERSION_BAJO_PRUEBA": version, "PYTHONDONTWRITEBYTECODE": "1"})
    (destino / f"pytest_defectos_{version}.txt").write_text(r.stdout + r.stderr, encoding="utf-8")
    out = {}
    for caso in ET.parse(xml).getroot().iter("testcase"):
        nombre = caso.get("name", "")
        fallo = caso.find("failure")
        error = caso.find("error")
        omitida = caso.find("skipped")
        if fallo is not None or error is not None:
            x = fallo if fallo is not None else error
            out[nombre] = ("FALLA", (x.get("message") or "").splitlines()[0][:140] if x is not None else "")
        elif omitida is not None:
            out[nombre] = ("OMITIDA", omitida.get("message", "")[:140])
        else:
            out[nombre] = ("PASA", "")
    return out


def defecto(nombre: str) -> str:
    m = re.match(r"test_(P\d)_(S\d+|N\d+|F\d+|control)", nombre)
    if m:
        return f"{m.group(1)}-{m.group(2)}"
    if nombre.startswith("test_fallos_de_escritura_sistematicos"):
        return "P4-N1/N2 (sistemática)"
    return "OTRO"


def esperado(ident: str, version: str) -> str:
    n = VERSIONES.index(version)
    if ident.endswith("control"):
        return "PASA" if version != "v0_2" else "*"
    if "-S" in ident:
        return "FALLA" if n == 0 else "PASA"
    if "-F" in ident:
        return {2: "FALLA", 3: "PASA"}.get(n, "*")
    return "PASA" if n >= 2 else "FALLA"  # N* y la sistemática de fallos de escritura


def main(destino: Path) -> int:
    destino.mkdir(parents=True, exist_ok=True)
    res = {v: correr(v, destino) for v in VERSIONES}
    por_defecto: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
    for v in VERSIONES:
        for nombre, (estado, _) in res[v].items():
            por_defecto[defecto(nombre)][v].append(estado)
    filas, malas = [], 0
    for ident in sorted(por_defecto):
        celdas, ok = [], True
        for v in VERSIONES:
            estados = por_defecto[ident][v]
            n_pasa, n = estados.count("PASA"), len(estados)
            exp = esperado(ident, v)
            agregado = "PASA" if n_pasa == n else ("FALLA" if n_pasa == 0 else "MIXTO")
            if exp == "FALLA":
                ok &= n_pasa < n  # el defecto se manifiesta en al menos un caso
            elif exp == "PASA":
                ok &= agregado == "PASA"
            celdas.append(f"{agregado} ({n_pasa}/{n} pasan)")
        malas += not ok
        filas.append(f"| {ident} | {' | '.join(celdas)} | {'sí' if ok else '**NO**'} |")
    tabla = ["# Matriz antes / después de los defectos (salida real de pytest)", "",
             "Patrón: S* falla en v0.2 y pasa en v0.3–v0.5 · N* falla en v0.3 y pasa en v0.4–v0.5 · F* falla en v0.4 y "
             "pasa en v0.5 (en v0.2–v0.3: «*», sin exigencia) · control pasa.", "",
             "| Defecto | v0.2 | v0.3 | v0.4 | v0.5 | Cumple el patrón |", "|---|---|---|---|---|---|", *filas, "",
             "## Detalle por prueba", "", "| Prueba | v0.2 | v0.3 | v0.4 | v0.5 |", "|---|---|---|---|---|"]
    for nombre in sorted(set().union(*res.values())):
        def c(v: str) -> str:
            e, msg = res[v].get(nombre, ("—", ""))
            return e + (f": {msg.replace('|', '/')}" if e == "FALLA" and msg else "")
        tabla.append(f"| `{nombre}` | {c('v0_2')} | {c('v0_3')} | {c('v0_4')} | {c('v0_5')} |")
    (destino / "MATRIZ_ANTES_DESPUES.md").write_text("\n".join(tabla) + "\n", encoding="utf-8")
    (destino / "matriz_antes_despues.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print("\n".join(tabla[:len(filas) + 6]))
    return 1 if malas else 0


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]).resolve()))
