"""Prueba de las pruebas de la cadena P4 → P1 → P2: cada mutación ELIMINA un control de una COPIA del código actual
(v0.5) y se ejecutan las pruebas cruzadas, las del ancla firmada y las de v0.5; la mutación debe hacer fallar al menos
una. Las pruebas que la detectan se registran. Las ocho primeras son las de v0.4; las demás, de los controles de v0.5.
Uso: python3 mutacion_cruzada.py <dir_codigo> <salida.txt>"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
MUTACIONES = [
    ("P1: VERIFICADO sin referencia independiente", "verificar_reproduccion_T.py",
     "    if not aut[\"cubren\"]:\n        detalle = (\"ninguna declaración firmada por una raíz",
     "    if False:\n        detalle = (\"ninguna declaración firmada por una raíz"),
    ("P1: ignora el hash presellado por P4", "verificar_reproduccion_T.py",
     "        if resultado_sha256 != resultado_sha256_esperado:", "        if False:"),
    ("confianza: toda firma es válida", "confianza.py",
     "    return _iguales(_multiplicar(s, _G), _sumar(r, _multiplicar(h, a)))", "    return True"),
    ("P2: INCONCLUSO cuenta como evidencia válida", "politica_avance_T.py",
     'VALIDA = ("VERIFICADO", "REPRODUCIDO")', 'VALIDA = ("VERIFICADO", "REPRODUCIDO", "INCONCLUSO")'),
    ("P4: no guarda el recibo del ancla", "uso_unico.py",
     "        if ancla.emite_recibos:  # v0.4", "        if False:  # v0.4"),
    ("P4: no rechaza una reserva cuyo cálculo ya inició en el ancla", "uso_unico.py",
     '                if st["reserva"] and (st["iniciados"] or st["presellado"]):', "                if False:"),
    ("P4/AnclaFirmada: no comprueba el desafío", "uso_unico.py",
     '"reserva_sha256": reserva_sha, "desafio": desafio,\n                    "emisor": self.emisor}',
     '"reserva_sha256": reserva_sha,\n                    "emisor": self.emisor}'),
    ("P4/AnclaFirmada: no verifica la firma de la respuesta", "uso_unico.py",
     "            c = C.verificar_documento(respuesta, self.clave)", "            c = respuesta[\"contenido\"]"),
    # ---- v0.5 ----
    ("P1: un recibo de ancla vale como declaración del propietario (sin ligarlo a la ejecución)",
     "verificar_reproduccion_T.py", '        if raiz["tipo"] == "ancla":\n            recibo = C.recibo_de_ancla(decl)\n            if recibo is None:',
     '        if False:\n            recibo = C.recibo_de_ancla(decl)\n            if recibo is None:'),
    ("P1: acepta el recibo de OTRA reserva", "verificar_reproduccion_T.py",
     "            elif recibo != reserva_sha256:", "            elif False:"),
    ("P1: no comprueba que la reserva nombre a esa ancla", "verificar_reproduccion_T.py",
     '            elif reserva.get("ancla") != C.identidad_ancla(raiz):', "            elif False:"),
    ("P1: acepta como original la reserva de una reproducción", "verificar_reproduccion_T.py",
     '            elif reserva.get("reproduccion_de") is not None:', "            elif False:"),
    ("P1: REPRODUCIDO sin reproducción autenticada", "verificar_reproduccion_T.py",
     '    if not aut["cubren"]:\n        detalle = ("ninguna declaración ni recibo válido',
     '    if False:\n        detalle = ("ninguna declaración ni recibo válido'),
    ("P1: la reproducción no tiene que repetir código y entradas del original", "verificar_reproduccion_T.py",
     "            difieren = [c for c in CAMPOS_EJECUCION if reserva is not None and reserva_reproduccion.get(c) != reserva.get(c)]",
     "            difieren = []"),
    ("P1: una declaración del propietario sin reproduccion_de autentica la reproducción", "verificar_reproduccion_T.py",
     '        if decl["contexto"].get("reproduccion_de") != original_sha256:\n            continue',
     '        if False:\n            continue'),
    ("confianza: acepta claves de orden pequeño o mixto", "confianza.py",
     "    if a is None or _orden_pequeno(a) or not _iguales(_multiplicar(_Q, a), _NEUTRO):", "    if a is None:"),
    ("P4: no valida el esquema de los eventos encadenados", "uso_unico.py",
     '        _validar_evento(ev, esquema, f"{ruta.name}: línea {i + 1}")', "        pass"),
    ("P4/AnclaFirmada: no valida la clave fijada", "uso_unico.py",
     '        C.validar_clave_publica(clave_publica_hex, "clave pública del ancla")',
     '        C._hex(clave_publica_hex, 64, "clave pública del ancla")'),
    ("P4: el límite de tiempo no forma parte de la reserva", "uso_unico.py",
     '"limite_segundos": limite, "reproduccion_de": reproduccion_de}', '"limite_segundos": None, "reproduccion_de": reproduccion_de}'),
    ("P4/ancla: una reproducción convive con cualquier reserva", "uso_unico.py",
     '                if repro is not None and (x["reproduccion_de"] == repro or (',
     '                if repro is not None or (x["reproduccion_de"] == repro and ('),
]
PRUEBAS = ["cruzada", "p4/test_ancla_firmada.py", "p4/test_contrato_ancla.py", "p4/test_p4_defectos_v05.py",
           "p4/test_p4_v05.py", "p1/test_p1_v05.py", "p1/test_p1_defectos_v05.py", "p1/test_confianza.py",
           "p1/test_confianza_diferencial.py", "p2/test_p2_defectos_v05.py"]


def main(codigo: Path, salida: Path) -> int:
    lineas, sobreviven = [], 0
    for nombre, archivo, viejo, nuevo in MUTACIONES:
        with tempfile.TemporaryDirectory() as tmp:
            for f in codigo.glob("*.py"):
                shutil.copy(f, Path(tmp) / f.name)
            p = Path(tmp) / archivo
            texto = p.read_text(encoding="utf-8")
            if texto.count(viejo) != 1:
                raise SystemExit(f"{nombre}: el texto original aparece {texto.count(viejo)} veces")
            p.write_text(texto.replace(viejo, nuevo), encoding="utf-8")
            r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q", "-rf", "--tb=no",
                                *PRUEBAS], cwd=AQUI,
                               capture_output=True, text=True, env={**os.environ, "CODIGO_ACTUAL_DIR": tmp,
                                                                    "PYTHONDONTWRITEBYTECODE": "1"}, check=False)
        fallidas = sorted({m.split("::")[-1].split(" ")[0] for m in re.findall(r"FAILED (\S+)", r.stdout)})
        sobreviven += not fallidas
        lineas.append(f"{'MUERTA' if fallidas else 'SOBREVIVE'}\t{nombre}\t{len(fallidas)} pruebas fallan: "
                      f"{', '.join(fallidas[:6])}{' …' if len(fallidas) > 6 else ''}")
    salida.write_text("\n".join(lineas) + f"\n{len(MUTACIONES) - sobreviven} de {len(MUTACIONES)} mutaciones detectadas\n",
                      encoding="utf-8")
    print(salida.read_text(encoding="utf-8"))
    return 1 if sobreviven else 0


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()))
