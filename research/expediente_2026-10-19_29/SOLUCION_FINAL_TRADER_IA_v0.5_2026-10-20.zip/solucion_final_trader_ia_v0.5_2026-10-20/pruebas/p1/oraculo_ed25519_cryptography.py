"""Oráculo EXTERNO para la prueba diferencial de Ed25519: verifica cada caso con la biblioteca cryptography (OpenSSL).
Se ejecuta con OTRO intérprete (el que tenga cryptography). Uso: python3 oraculo_ed25519_cryptography.py casos.json
Escribe en la salida estándar una lista de true/false (o "CLAVE_RECHAZADA")."""
import json
import sys

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

salida = []
for c in json.load(open(sys.argv[1])):
    try:
        k = Ed25519PublicKey.from_public_bytes(bytes.fromhex(c["publica"]))
    except ValueError:
        salida.append("CLAVE_RECHAZADA")
        continue
    try:
        k.verify(bytes.fromhex(c["firma"]), bytes.fromhex(c["mensaje"]))
        salida.append(True)
    except InvalidSignature:
        salida.append(False)
print(json.dumps(salida))
