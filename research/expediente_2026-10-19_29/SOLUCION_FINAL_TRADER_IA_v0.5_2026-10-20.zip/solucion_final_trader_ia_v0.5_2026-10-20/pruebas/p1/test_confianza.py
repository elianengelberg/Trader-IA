"""confianza.py (v0.4): Ed25519 contra implementaciones INDEPENDIENTES (OpenSSL por línea de órdenes y la biblioteca
cryptography de otro intérprete), vector 1 de RFC 8032, maleabilidad, y esquema estricto de documentos y raíces.
Todas las claves son SINTÉTICAS."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import fabricas_t as F
import pytest
from version import desde_v04

C = F.C
pytestmark = desde_v04
OPENSSL = shutil.which("openssl")
PY_CRYPTO = next((p for p in ("/usr/bin/python3.12", "/usr/bin/python3.13") if os.path.exists(p)), None)


def test_vector_1_rfc8032() -> None:
    sk = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
    assert C.clave_publica(sk).hex() == "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
    firma = C.firmar(sk, b"")
    assert firma.hex() == ("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e3970"
                           "1cf9b46bd25bf5f0595bbe24655141438e7a100b")
    assert C.verificar_firma(C.clave_publica(sk), b"", firma)


def _openssl(*args: str, entrada: bytes | None = None) -> bytes:
    return subprocess.run([OPENSSL, *args], input=entrada, capture_output=True, check=True).stdout


@pytest.mark.skipif(OPENSSL is None, reason="openssl no disponible")
def test_interoperabilidad_con_openssl(tmp_path: Path) -> None:
    """Firma de OpenSSL → verificación propia; firma propia → verificación de OpenSSL (5 claves, mensajes variados)."""
    for i in range(5):
        k = tmp_path / f"k{i}.pem"
        _openssl("genpkey", "-algorithm", "ed25519", "-out", str(k))
        semilla = _openssl("pkey", "-in", str(k), "-outform", "DER")[-32:]
        publica = _openssl("pkey", "-in", str(k), "-pubout", "-outform", "DER")[-32:]
        assert C.clave_publica(semilla) == publica
        msg = tmp_path / f"m{i}"
        msg.write_bytes(C.canonico({"i": i, "texto": "ñ" * i, "lista": list(range(i))}))
        firma_openssl = _openssl("pkeyutl", "-sign", "-inkey", str(k), "-rawin", "-in", str(msg))
        assert C.verificar_firma(publica, msg.read_bytes(), firma_openssl)
        assert C.firmar(semilla, msg.read_bytes()) == firma_openssl  # Ed25519 es determinista
        (tmp_path / "pub.pem").write_bytes(_openssl("pkey", "-in", str(k), "-pubout"))
        (tmp_path / "f.bin").write_bytes(C.firmar(semilla, msg.read_bytes()))
        r = subprocess.run([OPENSSL, "pkeyutl", "-verify", "-pubin", "-inkey", str(tmp_path / "pub.pem"), "-rawin",
                            "-in", str(msg), "-sigfile", str(tmp_path / "f.bin")], capture_output=True, check=False)
        assert r.returncode == 0
        malo = bytearray(firma_openssl)
        malo[i] ^= 0x01
        assert not C.verificar_firma(publica, msg.read_bytes(), bytes(malo))


@pytest.mark.skipif(PY_CRYPTO is None, reason="no hay un intérprete con la biblioteca cryptography")
def test_interoperabilidad_con_cryptography(tmp_path: Path) -> None:
    casos = [(os.urandom(32), os.urandom(n)) for n in (0, 1, 31, 64, 1000)]
    entrada = json.dumps([[s.hex(), m.hex()] for s, m in casos])
    codigo = ("import json,sys\nfrom cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey as K\n"
              "from cryptography.hazmat.primitives import serialization as S\n"
              "out=[]\nfor s,m in json.loads(sys.stdin.read()):\n"
              " k=K.from_private_bytes(bytes.fromhex(s))\n"
              " out.append([k.public_key().public_bytes(S.Encoding.Raw,S.PublicFormat.Raw).hex(),"
              "k.sign(bytes.fromhex(m)).hex()])\nprint(json.dumps(out))")
    r = subprocess.run([PY_CRYPTO, "-I", "-c", codigo], input=entrada, capture_output=True, text=True, check=True)
    for (s, m), (pub, firma) in zip(casos, json.loads(r.stdout), strict=True):
        assert C.clave_publica(s).hex() == pub and C.firmar(s, m).hex() == firma
        assert C.verificar_firma(bytes.fromhex(pub), m, bytes.fromhex(firma))


def test_maleabilidad_y_entradas_mal_formadas() -> None:
    s, m = F.SEMILLA_PROPIETARIO, b"mensaje"
    pub, firma = C.clave_publica(s), C.firmar(s, m)
    s_int = int.from_bytes(firma[32:], "little")
    maleable = firma[:32] + int.to_bytes(s_int + C._Q, 32, "little")  # misma ecuación, S no canónico
    assert not C.verificar_firma(pub, m, maleable)
    r_no_canonico = int.to_bytes(C._P + 1, 32, "little")  # y ≥ p
    assert not C.verificar_firma(pub, m, r_no_canonico + firma[32:])
    for p, f in ((pub[:31], firma), (pub, firma[:63]), (pub, firma + b"\0")):
        assert not C.verificar_firma(p, m, f)
    assert not C.verificar_firma(pub, m + b"x", firma)
    assert not C.verificar_firma("no bytes", m, firma)  # type: ignore[arg-type]
    assert not C.verificar_firma(C.clave_publica(F.SEMILLA_INTRUSA), m, firma)


def _doc(**cambios) -> dict:  # type: ignore[no-untyped-def]
    contenido = {"formato": C.FORMATO_DECLARACION, "emisor": "PRUEBA-PROPIETARIO", "emitida_utc": "2026-10-20T00:00:00Z",
                 "artefactos": [{"ruta": "a/b.json", "sha256": "a" * 64}], "contexto": {}} | cambios
    return {"contenido": contenido, "firma_ed25519": C.firmar(F.SEMILLA_PROPIETARIO, json.dumps(
        contenido, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hex()}


@pytest.mark.parametrize("cambio,codigo", [
    ({"contexto": {"p": 0.5}}, "FORMATO"), ({"extra": 1}, "FORMATO"), ({"formato": "otro/v1"}, "FORMATO"),
    ({"emitida_utc": "2026-10-20T00:00:00"}, "FORMATO"), ({"artefactos": []}, "FORMATO"),
    ({"artefactos": [{"ruta": "../x", "sha256": "a" * 64}]}, "FORMATO"),
    ({"artefactos": [{"ruta": "/x", "sha256": "a" * 64}]}, "FORMATO"),
    ({"artefactos": [{"ruta": "a//b", "sha256": "a" * 64}]}, "FORMATO"),
    ({"artefactos": [{"ruta": "x", "sha256": "a" * 64}, {"ruta": "x", "sha256": "b" * 64}]}, "FORMATO"),
    ({"artefactos": [{"sha256": "A" * 64}]}, "FORMATO"), ({"artefactos": [{"sha256": "a" * 64, "otra": 1}]}, "FORMATO"),
    ({"emisor": "DESCONOCIDO"}, "EMISOR_NO_APROBADO")])
def test_declaracion_esquema_estricto(cambio: dict, codigo: str) -> None:
    with pytest.raises(C.ErrorConfianza) as e:
        C.verificar_declaracion(_doc(**cambio), F.RAICES_PRUEBA)
    assert e.value.codigo == codigo


def test_declaracion_valida_y_alteraciones() -> None:
    doc = _doc()
    contenido, raiz = C.verificar_declaracion(doc, F.RAICES_PRUEBA)
    assert raiz["id"] == "PRUEBA-PROPIETARIO" and contenido["artefactos"][0]["sha256"] == "a" * 64
    alterado = json.loads(json.dumps(doc))
    alterado["contenido"]["artefactos"][0]["sha256"] = "b" * 64
    with pytest.raises(C.ErrorConfianza, match="FIRMA_INVALIDA"):
        C.verificar_declaracion(alterado, F.RAICES_PRUEBA)
    with pytest.raises(C.ErrorConfianza, match="FORMATO"):
        C.verificar_declaracion(doc | {"otra": 1}, F.RAICES_PRUEBA)
    with pytest.raises(C.ErrorConfianza, match="FORMATO"):
        C.verificar_declaracion({**doc, "firma_ed25519": doc["firma_ed25519"].upper()}, F.RAICES_PRUEBA)


def test_claves_duplicadas_en_el_archivo(tmp_path: Path) -> None:
    p = tmp_path / "d.json"
    texto = json.dumps(_doc())
    p.write_text(texto.replace('"emisor": "PRUEBA-PROPIETARIO"', '"emisor": "X", "emisor": "PRUEBA-PROPIETARIO"'),
                 encoding="utf-8")
    with pytest.raises(C.ErrorConfianza, match="repetida"):
        C.cargar_json_estricto(p)


def _no_es_punto() -> str:
    y = 2
    while C._descomprimir(int.to_bytes(y, 32, "little")) is not None:
        y += 1
    return int.to_bytes(y, 32, "little").hex()


@pytest.mark.parametrize("cambio", [{"id": "OTRO"}, {"tipo": "auditor"}, {"clave_publica_ed25519": "z" * 64},
                                    {"aprobada_utc": "ayer"}, {"descripcion": ""}, {"extra": 1}, "no_es_punto"])
def test_raices_mal_formadas_se_rechazan(cambio) -> None:  # type: ignore[no-untyped-def]
    r = dict(F.RAICES_PRUEBA["PRUEBA-PROPIETARIO"])
    r.update({"clave_publica_ed25519": _no_es_punto()} if cambio == "no_es_punto" else cambio)
    with pytest.raises(C.ErrorConfianza, match="RAIZ_INVALIDA"):
        C.verificar_declaracion(_doc(), {"PRUEBA-PROPIETARIO": r})


@pytest.mark.skipif(OPENSSL is None, reason="openssl no disponible")
def test_procedimiento_de_firma_del_propietario_con_openssl(tmp_path: Path) -> None:
    """El procedimiento documentado: el propietario firma los bytes canónicos con OpenSSL FUERA de este equipo (aquí,
    con una clave sintética) y el verificador acepta el documento solo si la raíz está aprobada."""
    k = tmp_path / "propietario.pem"
    _openssl("genpkey", "-algorithm", "ed25519", "-out", str(k))
    publica = _openssl("pkey", "-in", str(k), "-pubout", "-outform", "DER")[-32:].hex()
    contenido = C.declaracion("PROPIETARIO-OPENSSL", "2026-10-20T12:00:00Z", [{"ruta": "x.json", "sha256": "c" * 64}])
    (tmp_path / "a_firmar.bin").write_bytes(C.canonico(contenido))
    firma = _openssl("pkeyutl", "-sign", "-inkey", str(k), "-rawin", "-in", str(tmp_path / "a_firmar.bin")).hex()
    doc = {"contenido": contenido, "firma_ed25519": firma}
    raices = {"PROPIETARIO-OPENSSL": F.RAICES_PRUEBA["PRUEBA-PROPIETARIO"] | {"id": "PROPIETARIO-OPENSSL",
                                                                              "clave_publica_ed25519": publica}}
    assert C.verificar_declaracion(doc, raices)[0] == contenido
    with pytest.raises(C.ErrorConfianza, match="EMISOR_NO_APROBADO"):
        C.verificar_declaracion(doc, {})
