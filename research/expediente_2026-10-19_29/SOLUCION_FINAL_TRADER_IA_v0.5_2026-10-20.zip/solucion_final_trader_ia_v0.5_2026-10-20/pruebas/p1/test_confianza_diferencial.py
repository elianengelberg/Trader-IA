"""v0.5: prueba DIFERENCIAL de Ed25519 contra una implementación independiente (cryptography/OpenSSL, en otro
intérprete). 600 casos con semilla fija: firmas válidas, bits alterados en firma, mensaje y clave, S no canónico
(S + q), R no canónico, claves y R de orden pequeño y claves de orden MIXTO (A + T, con T de torsión). Exigencias:
(1) nunca aceptamos algo que OpenSSL rechaza; (2) solo discrepamos en las clases documentadas como más estrictas
(clave de orden pequeño o mixto, R de orden pequeño) y en ellas siempre RECHAZAMOS."""
from __future__ import annotations

import hashlib
import json
import os
import random
import shutil
import subprocess
from pathlib import Path

import pytest
import version
from version import desde_v05

pytestmark = desde_v05
C = version.p1().C
AQUI = Path(__file__).resolve().parent
PY_EXTERNO = os.environ.get("PY_CRYPTOGRAPHY") or shutil.which("python3.12") or ""
ESTRICTAS = {"clave_orden_pequeno", "clave_orden_mixto", "r_orden_pequeno"}
NEUTRO = bytes([1] + [0] * 31)


def _hay_oraculo() -> bool:
    if not PY_EXTERNO:
        return False
    r = subprocess.run([PY_EXTERNO, "-I", "-c", "import cryptography"], capture_output=True)
    return r.returncode == 0


def _torsion() -> list[bytes]:
    """Los 8 puntos de orden que divide a 8, comprimidos: [q]·P de puntos válidos cualesquiera cae en la torsión."""
    pts = set()
    rng = random.Random(8)
    while len(pts) < 8:
        p = C._descomprimir(rng.randbytes(32))
        if p is not None:
            pts.add(C._comprimir(C._multiplicar(C._Q, p)))
    assert all(C._orden_pequeno(C._descomprimir(t)) for t in pts)
    return sorted(pts)


def _casos() -> list[dict]:
    rng = random.Random(20261020)
    torsion = _torsion()
    casos = []

    def caso(clase: str, publica: bytes, mensaje: bytes, firma: bytes) -> None:
        casos.append({"clase": clase, "publica": publica.hex(), "mensaje": mensaje.hex(), "firma": firma.hex()})

    for _ in range(120):
        semilla, m = rng.randbytes(32), rng.randbytes(rng.randrange(0, 80))
        pk, f = C.clave_publica(semilla), C.firmar(semilla, m)
        caso("valida", pk, m, f)
        i = rng.randrange(64 * 8)
        caso("firma_alterada", pk, m, bytes(b ^ ((1 << (i % 8)) if j == i // 8 else 0) for j, b in enumerate(f)))
        caso("mensaje_alterado", pk, m + b"x", f)
        i = rng.randrange(32 * 8)
        caso("clave_alterada", bytes(b ^ ((1 << (i % 8)) if j == i // 8 else 0) for j, b in enumerate(pk)), m, f)
        s = int.from_bytes(f[32:], "little") + C._Q
        if s < 2 ** 256:
            caso("s_no_canonico", pk, m, f[:32] + s.to_bytes(32, "little"))
    for t in torsion:  # claves de orden pequeño con la firma trivial (R = neutro, s = 0) y con R = t
        for k in range(8):
            m = f"torsion {k}".encode()
            caso("clave_orden_pequeno", t, m, NEUTRO + bytes(32))
            caso("clave_orden_pequeno", t, m, t + bytes(32))
    for _ in range(40):  # clave de orden MIXTO A' = A + T: se firma con el secreto de A, hasheando la clave A'
        semilla, m = rng.randbytes(32), rng.randbytes(16)
        a, prefijo = C._expandir(semilla)
        t = C._descomprimir(rng.choice([x for x in torsion if x != NEUTRO]))
        mixta = C._comprimir(C._sumar(C._multiplicar(a, C._G), t))
        r = C._h_mod_q(prefijo + m)
        rr = C._comprimir(C._multiplicar(r, C._G))
        s = (r + C._h_mod_q(rr + mixta + m) * a) % C._Q
        caso("clave_orden_mixto", mixta, m, rr + s.to_bytes(32, "little"))
    for _ in range(20):  # R de orden pequeño con una clave honesta
        semilla, m = rng.randbytes(32), rng.randbytes(8)
        caso("r_orden_pequeno", C.clave_publica(semilla), m, rng.choice(torsion) + bytes(32))
    for y in range(19):  # R no canónico: y + p con y pequeño (codificación > p)
        b = (y + C._P).to_bytes(32, "little")
        semilla = hashlib.sha256(bytes([y])).digest()
        caso("r_no_canonico", C.clave_publica(semilla), b"m", b + bytes(32))
    return casos


@pytest.mark.skipif(not _hay_oraculo(), reason="no hay un intérprete con cryptography (PY_CRYPTOGRAPHY o python3.12)")
def test_ed25519_contra_cryptography(tmp_path: Path) -> None:
    casos = _casos()
    archivo = tmp_path / "casos.json"
    archivo.write_text(json.dumps(casos), encoding="utf-8")
    r = subprocess.run([PY_EXTERNO, "-I", str(AQUI / "oraculo_ed25519_cryptography.py"), str(archivo)],
                       capture_output=True, text=True, check=True)
    externo = json.loads(r.stdout)
    propio = [C.verificar_firma(bytes.fromhex(c["publica"]), bytes.fromhex(c["mensaje"]), bytes.fromhex(c["firma"]))
              for c in casos]
    laxas, inesperadas, por_clase = [], [], {}
    for c, a, b in zip(casos, propio, externo, strict=True):
        b_ok = b is True
        por_clase.setdefault(c["clase"], [0, 0, 0])
        por_clase[c["clase"]][0] += 1
        por_clase[c["clase"]][1] += a
        por_clase[c["clase"]][2] += b_ok
        if a and not b_ok:
            laxas.append(c)
        elif a != b_ok and c["clase"] not in ESTRICTAS:
            inesperadas.append(c)
    print({k: f"{v[0]} casos; aceptados: propia {v[1]}, OpenSSL {v[2]}" for k, v in por_clase.items()})
    assert len(casos) >= 600 and not laxas and not inesperadas
    assert por_clase["valida"][1] == por_clase["valida"][2] == por_clase["valida"][0]
    assert all(por_clase[k][1] == 0 for k in ESTRICTAS)  # en las clases estrictas siempre rechazamos
    assert por_clase["clave_orden_pequeno"][2] > 0  # y OpenSSL acepta algunas: la diferencia es real, no supuesta
