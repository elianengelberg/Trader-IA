"""Defectos de P1. LAS MISMAS pruebas se ejecutan contra v0.2, v0.3 y v0.4 (VERSION_BAJO_PRUEBA):
- P1_S1…S8: encontrados en la auditoría anterior, corregidos en v0.3 (deben fallar en v0.2 y pasar en v0.3 y v0.4).
- P1_N1…N4: encontrados en esta ronda, corregidos en v0.4 (deben fallar en v0.3 y pasar en v0.4).
- P1_control_*: controles positivos (pasan en todas las versiones que tengan la función).
Cada prueba usa un caso por lo demás VÁLIDO (árbol completo y, para v0.4, declaración firmada por una raíz SINTÉTICA)
para que el único motivo de rechazo sea el defecto que prueba. Datos sintéticos; corte.py solo con fuente simulada."""
from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path

import adaptador as A
import fabricas_t as F
import pytest
import version

T = F.T_REAL
con_corte = pytest.mark.skipif(not (T / "papel" / "corte.py").is_file(), reason="corte.py no disponible")
SCRIPT = "experimentos/fuera_de_muestra_T.py"


def publicar(raiz: Path, obj: dict | None = None) -> Path:
    ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
    ruta.write_text(json.dumps(obj if obj is not None else F.oos(raiz=raiz), ensure_ascii=False), encoding="utf-8")
    return ruta


def firmado(ruta: Path, raiz: Path) -> list:
    return [F.declarar_archivo(ruta, raiz)]


def cli(*args: object) -> tuple[int, str]:
    r = subprocess.run([sys.executable, "-I", "-B", str(version.DIR_P1 / "verificar_reproduccion_T.py"),
                        *map(str, args)], capture_output=True, text=True, check=False)
    return r.returncode, r.stdout


def estado_cli(salida: str) -> str | None:
    try:
        o = json.loads(salida)
    except ValueError:
        return None  # sin informe (p. ej. un rastro de excepción)
    return o.get("estado", o.get("resultado"))


# ---------- controles positivos ----------
def test_P1_control_resultado_valido_y_firmado_es_verificado(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    v = A.evaluar(ruta, raiz=raiz, manifiesto=F.cadena(raiz), declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("VERIFICADO", [])


# ---------- S1, S2: esquema estricto ----------
@pytest.mark.parametrize("cambio", [
    lambda o: o.update(decision="RESPALDADA FUERA DE MUESTRA"),
    lambda o: o["principal"].update(SOL={"exceso_anual": 0.1, "ic90_anual": [0, 0.2], "p": 0.9}),
    lambda o: o["principal"]["BTC"].update(p_alternativa=0.99),
    lambda o: o["manifiestos_sha256"].update(SOLUSDT="f" * 64),
    lambda o: o["secundarios"].update(otra_cosa=1),
    lambda o: o["secundarios"]["costes_x2"].update(SOL=0.1),
], ids=["decision_suelta", "simbolo_SOL", "p_alternativa", "manifiesto_SOL", "secundario_extra", "costes_SOL"])
def test_P1_S1_clave_inesperada(tmp_path: Path, raices, cambio) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    o = F.oos(raiz=raiz)
    cambio(o)
    ruta = publicar(raiz, o)
    v = A.evaluar(ruta, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("CORRUPTO", ["CLAVE_INESPERADA"])


@pytest.mark.parametrize("ruta_", ["principal.ETH", "manifiestos_sha256.ETHUSDT", "secundarios.costes_x2.ETH",
                                   "categoria", "principal.ETH.p"])
def test_P1_S2_simbolo_o_campo_faltante(tmp_path: Path, raices, ruta_: str) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz, F.quitar(F.oos(raiz=raiz), ruta_))
    v = A.evaluar(ruta, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("CORRUPTO", ["CLAVE_AUSENTE"])


@pytest.mark.parametrize("ruta_,valor,codigo", [("principal.ETH.p", 1.5, "RANGO"),
                                                ("principal.ETH.ic90_anual", [0.3, 0.1], "RANGO"),
                                                ("secundarios.costes_x2.BTC", "0.06", "TIPO")])
def test_P1_S2_simbolo_eth_validado(tmp_path: Path, raices, ruta_: str, valor, codigo: str) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz, F.poner(F.oos(raiz=raiz), ruta_, valor))
    v = A.evaluar(ruta, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("CORRUPTO", [codigo])


# ---------- S3: falsificación coherente frente a referencias ----------
def test_P1_S3_script_y_resultado_falsificados_frente_al_manifiesto(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    registro = F.cadena(raiz)
    script = raiz / SCRIPT
    script.write_text(script.read_text() + "# cambio\n", encoding="utf-8")
    o = json.loads(ruta.read_text())
    o["script_sha256"] = F.sha(script.read_bytes())  # el resultado se ajusta al script alterado
    ruta.write_text(json.dumps(o), encoding="utf-8")
    v = A.evaluar(ruta, raiz=raiz, manifiesto=registro, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("CORRUPTO", ["HASH_MANIFIESTO"])


def test_P1_S3_resultado_sustituido_frente_al_presellado(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    presellado = F.sha(ruta.read_bytes())
    publicar(raiz, F.oos(p_conj=0.999, raiz=raiz))  # sigue siendo EVIDENCIA INSUFICIENTE: coherente
    v = A.evaluar(ruta, raiz=raiz, resultado_sha256_esperado=presellado, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("CORRUPTO", ["HASH"])


# ---------- S4, S8: correspondencias ----------
def test_P1_S4_codigo_del_resultado_igual_al_fijado_en_el_script(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    script = raiz / SCRIPT
    texto = script.read_text()
    viejo = texto[texto.index('CODIGO = "') + 10:texto.index('"\nDESDE')]
    script.write_text(texto.replace(viejo, "1" * 64), encoding="utf-8")
    ruta = publicar(raiz)  # el resultado declara el hash del script nuevo y la huella real del código
    v = A.evaluar(ruta, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("CORRUPTO", ["CONTRADICCION"])


def _arbol_papel(raiz: Path) -> None:
    (raiz / "papel" / "prerregistro_papel.json").write_text(json.dumps({
        "estrategias": {"T_BTC": {"ventanas": [30, 90, 180]}},
        "ramas": {"A": {"primera_ejecucion": "2026-10-18"}, "B": {"primera_ejecucion": "primer día (2027-04-13)"}}}))
    (raiz / "src" / "tendencia" / "datos.py").write_text('RESERVADO_FIN = "2026-10-14"\n', encoding="utf-8")


@pytest.mark.parametrize("rama,inicio,esperado", [("B", "2027-04-13", "VERIFICADO"), ("B", "2027-01-01", "CORRUPTO"),
                                                  ("A", "2026-10-19", "CORRUPTO")])
def test_P1_S8_inicio_contra_el_prerregistro(tmp_path: Path, raices, rama: str, inicio: str, esperado: str) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    _arbol_papel(raiz)
    ev = F.evaluar(raiz=raiz) | {"rama": rama, "inicio": inicio}
    ruta = raiz / "evaluacion.json"
    ruta.write_text(json.dumps(ev), encoding="utf-8")
    v = A.evaluar(ruta, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert v.estado == esperado and (esperado == "VERIFICADO" or v.codigos == ["CONTRADICCION"])


# ---------- S5, S6: comparación completa y REPRODUCIDO ----------
def test_P1_S5_comparar_mira_todas_las_hojas() -> None:
    V = version.p1()
    a = F.oos()
    assert any("principal.ETH.p" in d for d in V.comparar(a, F.poner(a, "principal.ETH.p", 0.01)))
    assert any("secundarios.costes_x2.BTC" in d for d in V.comparar(a, F.poner(a, "secundarios.costes_x2.BTC", 0.5)))


def recalculo(raiz: Path, sesgo: float = 0.0) -> dict:
    """Recálculo SINTÉTICO (no es el de T)."""
    o = F.oos(raiz=raiz)
    o["principal"]["conjunto"]["exceso_anual"] = 0.02 + sesgo
    return o


def test_P1_S6_reproducido_solo_tras_verificado_y_comparacion_completa(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz, recalculo(raiz))
    d = firmado(ruta, raiz)
    assert A.reproducir(ruta, recalculo(raiz), raiz=raiz, declaraciones=d).estado == "REPRODUCIDO"
    v = A.reproducir(ruta, recalculo(raiz, 1e-6), raiz=raiz, declaraciones=d)
    assert v.estado == "NO_REPRODUCIDO" and v.informe["discrepancias"][0].startswith("principal.conjunto.exceso_anual")
    assert A.reproducir(ruta, recalculo(raiz, 1e-6), 1e-5, raiz=raiz, declaraciones=d).estado == "REPRODUCIDO"
    assert A.reproducir(ruta, recalculo(raiz), declaraciones=d).estado == "INCONCLUSO"  # sin --raiz
    assert A.reproducir(ruta, recalculo(raiz) | {"extra": 1}, raiz=raiz, declaraciones=d).estado not in (
        "REPRODUCIDO", "NO_REPRODUCIDO", "VERIFICADO", "EXCEPCION")
    for tol in (-1.0, float("nan"), True, "0"):
        assert (lambda v: (v.estado, v.codigos))(A.reproducir(ruta, recalculo(raiz), tol, raiz=raiz, declaraciones=d)) == (
            "INCONCLUSO", ["USO"])


# ---------- S7: tablas y datos del corte (productor real con fuente SIMULADA) ----------
def _alterar(d: Path, alteracion: str) -> None:
    p = d / "decisiones_BTCUSDT.csv"
    if alteracion == "manifiesto_de_datos":
        m = d / "datos" / "ETHUSDT" / "MANIFIESTO.json"
        x = json.loads(m.read_text())
        x["archivos"] = x["archivos"][1:]
        m.write_text(json.dumps(x), encoding="utf-8")
    elif alteracion == "tabla_ausente":
        p.unlink()
    elif alteracion == "csv_no_utf8":
        p.write_bytes(p.read_bytes().replace(b"dia,", b"d\xffa,", 1))
    else:
        filas = list(csv.reader(p.open(encoding="utf-8")))
        if alteracion == "fila_borrada":
            del filas[-1]
        elif alteracion == "valor_cambiado":
            filas[11][8] = str(float(filas[11][8]) * 1.5)
        elif alteracion == "columna_cambiada":
            filas[0][8] = "equity"
        else:
            filas[5][0] = filas[6][0]
        with p.open("w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows(filas)


def _decl_corte(d: Path) -> list:
    return [("declaracion_corte", F.declarar([{"sha256": F.sha((d / "resultado.json").read_bytes())}]))]


@con_corte
def test_P1_S7_control_corte_real_simulado_verificado(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    cortes = F.corte_real_simulado(tmp_path)
    d = cortes / "2027-10-19"
    v = A.evaluar(d / "resultado.json", raiz=T, registro=cortes / "REGISTRO.jsonl", declaraciones=_decl_corte(d))
    assert v.estado == "VERIFICADO"


@con_corte
@pytest.mark.parametrize("alteracion,estado,codigo", [
    ("fila_borrada", "CORRUPTO", "CONTRADICCION"), ("valor_cambiado", "CORRUPTO", "HASH"),
    ("manifiesto_de_datos", "CORRUPTO", "HASH"), ("columna_cambiada", "CORRUPTO", "ESQUEMA"),
    ("tabla_ausente", "INCONCLUSO", "ARCHIVO_AUSENTE"), ("dia_saltado", "CORRUPTO", "CONTRADICCION")])
def test_P1_S7_tablas_y_datos_del_corte(tmp_path: Path, raices, alteracion: str, estado: str, codigo: str) -> None:  # type: ignore[no-untyped-def]
    cortes = F.corte_real_simulado(tmp_path)
    d = cortes / "2027-10-19"
    decl = _decl_corte(d)
    _alterar(d, alteracion)
    v = A.evaluar(d / "resultado.json", raiz=T, registro=cortes / "REGISTRO.jsonl", declaraciones=decl)
    assert v.estado == estado and v.codigos[0] == codigo


# ---------- N1: autenticidad (v0.3 declaraba VERIFICADO sin raíz de confianza independiente) ----------
def _falsificacion_conjunta(raiz: Path) -> Path:
    """Quien controla el árbol cambia el script, rehace el resultado y REGENERA el manifiesto local."""
    script = raiz / SCRIPT
    script.write_text(script.read_text() + "# cambio\n", encoding="utf-8")
    return publicar(raiz, F.oos(p_conj=0.999, raiz=raiz))


def test_P1_N1_alteracion_conjunta_de_archivos_y_manifiesto_no_es_verificado(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    publicar(raiz)
    ruta = _falsificacion_conjunta(raiz)
    v = A.evaluar(ruta, raiz=raiz, manifiesto=F.cadena(raiz))  # manifiesto regenerado: coherente con la falsificación
    assert (v.estado, v.codigos) == ("INCONCLUSO", ["SIN_REFERENCIA_INDEPENDIENTE"])


def test_P1_N1_declaracion_firmada_del_original_detecta_la_sustitucion(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    original = [("firmada_antes", F.declarar({"experimentos/fuera_de_muestra_T.json": ruta.read_bytes(),
                                              SCRIPT: (raiz / SCRIPT).read_bytes()}))]
    _falsificacion_conjunta(raiz)
    v = A.evaluar(ruta, raiz=raiz, manifiesto=F.cadena(raiz), declaraciones=original)
    assert (v.estado, v.codigos) == ("CORRUPTO", ["HASH_REFERENCIA"])


@pytest.mark.parametrize("caso", ["clave_intrusa", "emisor_no_aprobado", "sin_raices_aprobadas"])
def test_P1_N1_sin_firma_de_una_raiz_aprobada_no_hay_verificado(tmp_path: Path, monkeypatch, caso: str) -> None:  # type: ignore[no-untyped-def]
    V = version.p1()
    if hasattr(V, "RAICES_CONFIANZA") and caso != "sin_raices_aprobadas":
        monkeypatch.setattr(V, "RAICES_CONFIANZA", dict(F.RAICES_PRUEBA))
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    rel = {"experimentos/fuera_de_muestra_T.json": ruta.read_bytes()}
    doc = {"clave_intrusa": F.declarar(rel, semilla=F.SEMILLA_INTRUSA),
           "emisor_no_aprobado": F.declarar(rel, emisor="INTRUSO", semilla=F.SEMILLA_INTRUSA),
           "sin_raices_aprobadas": F.declarar(rel)}[caso]
    v = A.evaluar(ruta, raiz=raiz, declaraciones=[("d", doc)])
    assert (v.estado, v.codigos) == ("INCONCLUSO", ["SIN_REFERENCIA_INDEPENDIENTE"])


# ---------- N2: estados precisos (v0.3 mezclaba «inválido» y «no verificable» en RECHAZADO) ----------
def test_P1_N2_cli_distingue_corrupto_de_inconcluso(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    (raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md").rename(tmp_path / "apartado.md")  # falta un archivo: no verificable
    codigo, salida = cli(ruta, "--raiz", raiz)
    assert (codigo, estado_cli(salida)) == (3, "INCONCLUSO")
    (tmp_path / "apartado.md").rename(raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md")
    (raiz / SCRIPT).write_text((raiz / SCRIPT).read_text() + "# x\n", encoding="utf-8")  # hash distinto: inválido
    codigo, salida = cli(ruta, "--raiz", raiz)
    assert (codigo, estado_cli(salida)) == (1, "CORRUPTO")


def test_P1_N2_una_falta_no_oculta_una_corrupcion(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    (raiz / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md").unlink()          # falta (se comprueba antes en v0.3)
    (raiz / SCRIPT).write_text((raiz / SCRIPT).read_text() + "# x\n", encoding="utf-8")  # y una corrupción
    v = A.evaluar(ruta, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("CORRUPTO", ["HASH"])


def test_P1_N2_reproduccion_invalida_no_marca_corrupto_al_original(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    v = A.reproducir(ruta, F.oos(raiz=raiz) | {"extra": 1}, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert (v.estado, v.codigos) == ("INCONCLUSO", ["REPRODUCCION_NO_VALIDA"])


def test_P1_N2_manifiesto_ilegible_es_inconcluso_no_corrupto(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    (tmp_path / "roto.txt").write_text("no es un manifiesto\n", encoding="utf-8")
    codigo, salida = cli(ruta, "--raiz", raiz, "--manifiesto", tmp_path / "roto.txt")
    assert (codigo, estado_cli(salida)) == (3, "INCONCLUSO")


# ---------- N3: excepciones no controladas (v0.3 terminaba con un rastro y código 1, como un rechazo) ----------
def test_P1_N3_script_con_codigo_no_literal(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    script = raiz / SCRIPT
    script.write_text("def huella():\n    return 'x'\n\n\nCODIGO = huella()\n"
                      'DESDE, HASTA, DIAS = "2022-01-01", "2026-06-01", 1612\n', encoding="utf-8")
    ruta = publicar(raiz)  # el resultado declara el hash de ESTE script: coherente
    codigo, salida = cli(ruta, "--raiz", raiz)
    assert (codigo, estado_cli(salida)) == (3, "INCONCLUSO")
    assert "NO_DERIVABLE" in salida


@con_corte
def test_P1_N3_tabla_del_corte_no_utf8(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    cortes = F.corte_real_simulado(tmp_path)
    d = cortes / "2027-10-19"
    decl = _decl_corte(d)
    _alterar(d, "csv_no_utf8")
    v = A.evaluar(d / "resultado.json", raiz=T, registro=cortes / "REGISTRO.jsonl", declaraciones=decl)
    assert (v.estado, v.codigos) == ("CORRUPTO", ["TIPO"])


def test_P1_N3_rama_b_sin_reservado_fin(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    _arbol_papel(raiz)
    (raiz / "src" / "tendencia" / "datos.py").write_text("OTRA = 1\n", encoding="utf-8")
    ev = F.evaluar(raiz=raiz) | {"rama": "B", "inicio": "2027-04-13"}
    ruta = raiz / "evaluacion.json"
    ruta.write_text(json.dumps(ev), encoding="utf-8")
    v = A.evaluar(ruta, raiz=raiz, declaraciones=firmado(ruta, raiz))
    assert v.estado == "INCONCLUSO" and "NO_DERIVABLE" in v.codigos


# ---------- N4: el resultado se compara con los MISMOS bytes evaluados (v0.3 releía el archivo) ----------
def test_P1_N4_reproduccion_compara_los_bytes_evaluados(tmp_path: Path, raices, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    V = version.p1()
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    decl = firmado(ruta, raiz)
    original = V.cargar
    otro = json.dumps(F.oos(p_conj=0.999, raiz=raiz))  # coherente, distinto

    def cargar_y_sustituir(r):  # type: ignore[no-untyped-def]
        x = original(r)
        if Path(r) == ruta:  # tras la primera lectura, alguien sustituye el archivo
            ruta.write_text(otro, encoding="utf-8")
        return x

    monkeypatch.setattr(V, "cargar", cargar_y_sustituir)
    v = A.reproducir(ruta, F.oos(raiz=raiz), raiz=raiz, declaraciones=decl)
    assert v.estado == "REPRODUCIDO"
