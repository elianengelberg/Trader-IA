"""Defectos de P1 y de confianza encontrados en la revisión adversarial de v0.4 (F*), corregidos en v0.5. LAS MISMAS
pruebas contra v0.4 (deben FALLAR: el defecto existe) y v0.5 (deben PASAR); en v0.2 y v0.3 no se exige nada. El módulo
de firmas es el que importa el P1 bajo prueba (``V.C``). Árboles de T y claves SINTÉTICOS."""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
from pathlib import Path

import fabricas_t as F
import pytest
import version

V = version.p1()
RESULTADO = "experimentos/fuera_de_muestra_T.json"
NEUTRO = bytes([1] + [0] * 31)
CEROS = bytes(32)
FIRMA_TRIVIAL = (NEUTRO + bytes(32)).hex()  # R = neutro, s = 0: no requiere ninguna clave privada


def _arbol(tmp: Path, **kw) -> tuple[Path, Path]:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp / "T")
    ruta = raiz / RESULTADO
    ruta.write_text(json.dumps(F.oos(raiz=raiz, **kw)), encoding="utf-8")
    return raiz, ruta


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


# ---------- F1: raíces con clave de orden pequeño ----------
@pytest.mark.parametrize("clave", [NEUTRO, CEROS], ids=["neutro", "ceros"])
def test_P1_F1_raiz_de_orden_pequeno_no_autentica_una_falsificacion(tmp_path: Path, monkeypatch, clave: bytes) -> None:  # type: ignore[no-untyped-def]
    raiz, ruta = _arbol(tmp_path, p_conj=0.5)  # un resultado cualquiera, sin firma de nadie
    r = {"id": "R", "tipo": "propietario", "clave_publica_ed25519": clave.hex(), "aprobada_por": "PRUEBA",
         "aprobada_utc": "2026-01-01T00:00:00Z", "descripcion": "raíz con una clave degenerada"}
    monkeypatch.setattr(V, "RAICES_CONFIANZA", {"R": r})
    falsas = [(f"falsa_{i}", {"contenido": {"formato": "trader-ia/declaracion/v1", "emisor": "R",
                                            "emitida_utc": "2026-10-20T00:00:00Z",
                                            "artefactos": [{"sha256": _sha(ruta)}], "contexto": {"intento": i}},
                              "firma_ed25519": FIRMA_TRIVIAL}) for i in range(128)]
    inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=falsas)
    assert inf["estado"] != "VERIFICADO", inf["autenticidad"]["cubren"][:3]
    with pytest.raises(ValueError):
        V.C.validar_raiz("R", r)


# ---------- F2: un recibo del ancla de OTRA ejecución ----------
def test_P1_F2_recibo_de_una_reserva_cualquiera_no_autentica(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz, ruta = _arbol(tmp_path, p_conj=0.5)  # resultado inventado
    recibo = F.declarar([{"sha256": _sha(ruta), "descripcion": "presellado"}], emisor="PRUEBA-ANCLA",
                        semilla=F.SEMILLA_ANCLA, contexto={"reserva_sha256": "f" * 64})  # una reserva cualquiera
    inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=[("recibo", recibo)])
    assert inf["estado"] == "INCONCLUSO"
    assert [m["codigo"] for m in inf["motivos"]] == ["SIN_REFERENCIA_INDEPENDIENTE"]


# ---------- F3: reproducción desde un objeto en memoria (no autenticado) ----------
@pytest.mark.parametrize("caso", ["copia_del_original", "inventada_igual", "inventada_distinta"])
def test_P1_F3_reproduccion_no_autenticada_no_da_reproducido(tmp_path: Path, raices, caso: str) -> None:  # type: ignore[no-untyped-def]
    raiz, ruta = _arbol(tmp_path)
    d = [F.declarar_archivo(ruta, raiz)]
    otra = {"copia_del_original": json.loads(ruta.read_text()), "inventada_igual": F.oos(raiz=raiz),
            "inventada_distinta": F.oos(p_conj=0.76, raiz=raiz)}[caso]
    inf = V.evaluar_reproduccion(ruta, otra, 0.0, raiz=raiz, declaraciones=d)
    assert inf["estado"] not in ("REPRODUCIDO", "NO_REPRODUCIDO"), inf["estado"]


# ---------- F4: una declaración mal formada no oculta un CORRUPTO ----------
def _anidado(n: int) -> dict:
    raiz = x = {}
    for _ in range(n):
        x["a"] = {}
        x = x["a"]
    return raiz


@pytest.mark.parametrize("forma", ["sustituto_suelto", "anidamiento_extremo"])
def test_P1_F4_declaracion_mal_formada_no_oculta_un_corrupto(tmp_path: Path, raices, forma: str) -> None:  # type: ignore[no-untyped-def]
    raiz, ruta = _arbol(tmp_path)
    legitima = F.declarar_archivo(ruta, raiz)  # el propietario firmó el ORIGINAL
    ruta.write_text(json.dumps(F.oos(raiz=raiz, p_conj=0.5)), encoding="utf-8")  # …y alguien lo sustituye
    contexto = json.loads('{"x": "\\ud800"}') if forma == "sustituto_suelto" else _anidado(20000)
    mala = {"contenido": {"formato": "trader-ia/declaracion/v1", "emisor": "PRUEBA-PROPIETARIO",
                          "emitida_utc": "2026-10-20T00:00:00Z", "artefactos": [{"sha256": "a" * 64}],
                          "contexto": contexto}, "firma_ed25519": "0" * 128}
    inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=[legitima, ("mala", mala)])
    assert (inf["estado"], inf["motivos"][0]["codigo"]) == ("CORRUPTO", "HASH_REFERENCIA")


# ---------- F5: JSON anidado en exceso ----------
def test_P1_F5_resultado_anidado_en_exceso_es_un_estado(tmp_path: Path) -> None:
    p = tmp_path / "x.json"
    p.write_bytes(b"[" * 200000 + b"]" * 200000)
    inf = V.evaluar_archivo(p)
    assert (inf["estado"], inf["motivos"][0]["codigo"]) == ("CORRUPTO", "JSON_INVALIDO")


def test_P1_F5_linea_de_ordenes_no_termina_con_la_salida_de_corrupto_por_un_error(tmp_path: Path) -> None:
    raiz, ruta = _arbol(tmp_path)
    decl = tmp_path / "declaracion_anidada.json"
    decl.write_bytes(b"[" * 200000 + b"]" * 200000)
    salida = io.StringIO()
    with contextlib.redirect_stdout(salida):
        codigo = V.main([str(ruta), "--raiz", str(raiz), "--declaracion", str(decl)])
    assert codigo == 3 and json.loads(salida.getvalue())["estado"] == "INCONCLUSO"


# ---------- F11: fechas UTC en una sola forma ----------
@pytest.mark.parametrize("valor", ["2026-10-20Z", "20261020T000000Z", "2026-10-20T00:00Z", "2026-W43-2T00:00:00Z"])
def test_P1_F11_fecha_utc_en_una_sola_forma(valor: str) -> None:
    with pytest.raises(ValueError):
        V.C.declaracion("E", valor, [{"sha256": "a" * 64}])


# ---------- F12: un error de uso no oculta un CORRUPTO del original ----------
def test_P1_F12_un_error_de_uso_no_oculta_un_corrupto(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz, ruta = _arbol(tmp_path)
    legitima = F.declarar_archivo(ruta, raiz)
    ruta.write_text(json.dumps(F.oos(raiz=raiz, p_conj=0.5)), encoding="utf-8")  # sustituido tras la firma
    inf = V.evaluar_reproduccion(ruta, ruta, "x", raiz=raiz, declaraciones=[legitima])  # tolerancia inválida
    assert inf["estado"] == "CORRUPTO", [m["codigo"] for m in inf["motivos"]]
