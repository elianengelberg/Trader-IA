"""P1 v0.5: (1) V5 con recibos del ancla LIGADOS a la ejecución esperada, contra un oráculo escrito aparte (80
combinaciones); (2) autenticación de la reproducción contra un oráculo (210 combinaciones); (3) línea de órdenes con
--reserva y --reserva-reproduccion; (4) mutaciones aleatorias del árbol, del resultado y de las declaraciones (fuzzing
con semilla fija): nunca una excepción y nunca VERIFICADO salvo con los bytes firmados y el árbol leído intacto.
Árboles, reservas y claves SINTÉTICOS. Los hashes y la identidad del ancla se calculan aquí sin usar el código bajo
prueba."""
from __future__ import annotations

import contextlib
import hashlib
import io
import itertools
import json
import random
import shutil
from pathlib import Path

import fabricas_t as F
import pytest
import version
from version import desde_v05

pytestmark = desde_v05
V = version.p1()
RESULTADO = "experimentos/fuera_de_muestra_T.json"
SCRIPT = "experimentos/fuera_de_muestra_T.py"


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def canon(x: object) -> bytes:  # misma regla que el formato de P4, escrita aquí
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def identidad(raiz: dict) -> str:
    return f"firmada:{raiz['id']}:ed25519:{sha(bytes.fromhex(raiz['clave_publica_ed25519']))[:32]}"


ANCLA = F.RAICES_PRUEBA["PRUEBA-ANCLA"]


def reserva(**cambios: object) -> dict:
    base = {"version": "uso_unico v0.5", "experimento": "SINTETICO", "semilla": 7, "punto_entrada": "calcular",
            "reintentos_tras_inicio": 0, "entorno": {"python": "3.x", "implementacion": "CPython"},
            "archivos_sha256": {"codigo": "c" * 64, "datos": "d" * 64}, "ejecutor_sha256": "e" * 64,
            "ancla": identidad(ANCLA), "verificar_determinismo": False, "limite_segundos": None,
            "reproduccion_de": None}
    return base | cambios


def recibo(reserva_sha: str, resultado_sha: str, semilla: bytes = F.SEMILLA_ANCLA) -> tuple[str, dict]:
    return ("recibo", F.declarar([{"sha256": resultado_sha, "descripcion": "presellado"}], emisor="PRUEBA-ANCLA",
                                 semilla=semilla, contexto={"reserva_sha256": reserva_sha}))


def arbol(tmp: Path) -> tuple[Path, Path]:
    raiz = F.arbol_t(tmp / "T")
    ruta = raiz / RESULTADO
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    return raiz, ruta


# ---------- (1) V5 contra el oráculo ----------
DECL = ("ninguna", "propietario_cubre", "propietario_contradice", "recibo_esperado_cubre", "recibo_esperado_otro_sha",
        "recibo_otra_reserva", "ancla_sin_reserva_en_contexto", "recibo_firma_intrusa")
RESERVA = ("ninguna", "correcta", "otra_ancla", "es_reproduccion", "no_es_objeto")
CORRUPCION = ("ninguna", "script")


def oraculo_v5(decl: str, res: str, corr: str) -> tuple[str, set[str]]:
    corrupto = set()
    if corr == "script":
        corrupto |= {"HASH", "HASH_MANIFIESTO", "HASH_REFERENCIA"}
    if decl == "propietario_contradice":
        corrupto.add("HASH_REFERENCIA")
    if decl == "recibo_esperado_otro_sha" and res == "correcta":
        corrupto.add("RECIBO_CONTRADICE")
    if corrupto:
        return "CORRUPTO", corrupto
    motivos = {"USO"} if res == "no_es_objeto" else set()
    if not (decl == "propietario_cubre" or (decl == "recibo_esperado_cubre" and res == "correcta")):
        motivos.add("SIN_REFERENCIA_INDEPENDIENTE")
    return ("INCONCLUSO", motivos) if motivos else ("VERIFICADO", set())


def test_v5_recibos_ligados_contra_el_oraculo(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    vistos = set()
    for i, (decl, res, corr) in enumerate(itertools.product(DECL, RESERVA, CORRUPCION)):
        raiz, ruta = arbol(tmp_path / str(i))
        b = ruta.read_bytes()
        doc = {"ninguna": None, "correcta": reserva(), "otra_ancla": reserva(ancla="firmada:OTRA:ed25519:" + "0" * 32),
               "es_reproduccion": reserva(reproduccion_de="a" * 64), "no_es_objeto": ["no", "es", "un", "objeto"]}[res]
        esperada = sha(canon(doc if isinstance(doc, dict) else reserva()))
        d = {"ninguna": [], "propietario_cubre": [F.declarar_archivo(ruta, raiz)],
             "propietario_contradice": [("d", F.declarar({RESULTADO: "1" * 64}))],
             "recibo_esperado_cubre": [recibo(esperada, sha(b))],
             "recibo_esperado_otro_sha": [recibo(esperada, "2" * 64)],
             "recibo_otra_reserva": [recibo(sha(canon(reserva(semilla=8))), sha(b))],
             "ancla_sin_reserva_en_contexto": [("a", F.declarar([{"sha256": sha(b)}], emisor="PRUEBA-ANCLA",
                                                                semilla=F.SEMILLA_ANCLA))],
             "recibo_firma_intrusa": [recibo(esperada, sha(b), F.SEMILLA_INTRUSA)]}[decl]
        if corr == "script":
            (raiz / SCRIPT).write_text((raiz / SCRIPT).read_text() + "# alterado\n", encoding="utf-8")
        inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=d, reserva=doc)
        estado, codigos = oraculo_v5(decl, res, corr)
        obtenidos = [m["codigo"] for m in inf["motivos"]]
        assert inf["estado"] == estado, (decl, res, corr, obtenidos)
        if estado == "CORRUPTO":
            assert len(obtenidos) == 1 and obtenidos[0] in codigos, (decl, res, corr, obtenidos)
        else:
            assert set(obtenidos) == codigos, (decl, res, corr, obtenidos)
        if estado == "VERIFICADO":
            vias = inf["autenticidad"]["vias"]
            assert vias == (["PROPIETARIO"] if decl == "propietario_cubre" else ["RECIBO_ANCLA"])
        if isinstance(doc, dict) and estado != "CORRUPTO":
            assert inf["ejecucion"]["reserva_sha256"] == sha(canon(doc))
        vistos.add(estado)
    assert vistos == {"VERIFICADO", "CORRUPTO", "INCONCLUSO"}


# ---------- (2) reproducción contra el oráculo ----------
VIA = ("propietario", "recibo")
REPRO_DECL = ("ninguna", "propietario_repro_ok", "propietario_repro_de_otro", "propietario_sin_contexto",
              "recibo_repro_ok", "recibo_repro_otro_sha", "recibo_original_reusado")
RESERVA_REPRO = ("ninguna", "correcta", "archivos_distintos", "sin_reproduccion_de", "otra_ancla")
CONTENIDO = ("igual", "distinto", "invalido")


def oraculo_repro(via: str, decl: str, rr: str, cont: str) -> tuple[str, set[str]]:
    # el ORIGINAL se evalúa primero: dos recibos del ancla para SU reserva con presellados distintos lo contradicen
    if via == "recibo" and decl == "recibo_original_reusado" and cont != "igual":
        return "CORRUPTO", {"RECIBO_CONTRADICE"}
    if cont == "invalido":
        return "INCONCLUSO", {"REPRODUCCION_NO_VALIDA"}
    ligado = via == "recibo" and rr == "correcta"  # recibo de la reproducción: hace falta la reserva original
    if decl == "recibo_repro_otro_sha" and ligado:
        return "INCONCLUSO", {"REPRODUCCION_CONTRADICHA"}
    if not (decl == "propietario_repro_ok" or (decl == "recibo_repro_ok" and ligado)):
        return "INCONCLUSO", {"REPRODUCCION_NO_AUTENTICADA"}
    return ("REPRODUCIDO" if cont == "igual" else "NO_REPRODUCIDO"), set()


def test_reproduccion_autenticada_contra_el_oraculo(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    vistos = set()
    for i, (via, decl, rr, cont) in enumerate(itertools.product(VIA, REPRO_DECL, RESERVA_REPRO, CONTENIDO)):
        raiz, ruta = arbol(tmp_path / str(i))
        original = sha(ruta.read_bytes())
        r_orig = reserva()
        base = ([F.declarar_archivo(ruta, raiz)] if via == "propietario"
                else [recibo(sha(canon(r_orig)), original)])
        rep = tmp_path / str(i) / "reproduccion.json"
        rep.write_text({"igual": json.dumps(F.oos(raiz=raiz)), "distinto": json.dumps(F.oos(p_conj=0.76, raiz=raiz)),
                        "invalido": "{roto"}[cont], encoding="utf-8")
        doc_rr = {"ninguna": None, "correcta": reserva(reproduccion_de=original, ejecutor_sha256="f" * 64),
                  "archivos_distintos": reserva(reproduccion_de=original, archivos_sha256={"codigo": "9" * 64}),
                  "sin_reproduccion_de": reserva(experimento="OTRO"),
                  "otra_ancla": reserva(reproduccion_de=original, ancla="firmada:OTRA:ed25519:" + "0" * 32)}[rr]
        sha_rr = sha(canon(doc_rr if doc_rr is not None else reserva(reproduccion_de=original, ejecutor_sha256="f" * 64)))
        sr = sha(rep.read_bytes())
        extra = {"ninguna": [], "propietario_repro_ok": [("r", F.declarar([{"sha256": sr}],
                                                                          contexto={"reproduccion_de": original}))],
                 "propietario_repro_de_otro": [("r", F.declarar([{"sha256": sr}], contexto={"reproduccion_de": "b" * 64}))],
                 "propietario_sin_contexto": [("r", F.declarar([{"sha256": sr}]))],
                 "recibo_repro_ok": [recibo(sha_rr, sr)], "recibo_repro_otro_sha": [recibo(sha_rr, "3" * 64)],
                 "recibo_original_reusado": [recibo(sha(canon(r_orig)), sr)]}[decl]
        inf = V.evaluar_reproduccion(ruta, rep, 0.0, raiz=raiz, declaraciones=base + extra,
                                     reserva=r_orig if via == "recibo" else None, reserva_reproduccion=doc_rr)
        estado, codigos = oraculo_repro(via, decl, rr, cont)
        assert (inf["estado"], {m["codigo"] for m in inf["motivos"]}) == (estado, codigos), (via, decl, rr, cont)
        vistos.add(estado)
    assert vistos == {"REPRODUCIDO", "NO_REPRODUCIDO", "INCONCLUSO", "CORRUPTO"}


def test_reproduccion_en_memoria_con_original_corrupto_es_corrupto(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz, ruta = arbol(tmp_path)
    d = F.declarar_archivo(ruta, raiz)
    ruta.write_text(json.dumps(F.oos(raiz=raiz, p_conj=0.5)), encoding="utf-8")
    assert V.evaluar_reproduccion(ruta, {"x": 1}, 0.0, raiz=raiz, declaraciones=[d])["estado"] == "CORRUPTO"
    with pytest.raises(ValueError):  # forma de fecha con dos zonas: rechazada (también en v0.4)
        V.C.declaracion("E", "2026-10-20T00:00:00+00:00Z", [{"sha256": "a" * 64}])


# ---------- (3) línea de órdenes ----------
def _main(*args: object) -> tuple[int, dict | None]:
    salida = io.StringIO()
    with contextlib.redirect_stdout(salida):
        codigo = V.main([str(a) for a in args])
    return codigo, (json.loads(salida.getvalue()) if codigo != 2 else None)  # 2: uso, imprime la ayuda


def test_linea_de_ordenes_con_reservas(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz, ruta = arbol(tmp_path)
    original = sha(ruta.read_bytes())
    r_orig, r_rep = reserva(), reserva(reproduccion_de=original, ejecutor_sha256="f" * 64)
    archivos = {}
    for nombre, x in (("reserva.json", r_orig), ("reserva_rep.json", r_rep),
                      ("recibo.json", recibo(sha(canon(r_orig)), original)[1])):
        archivos[nombre] = tmp_path / nombre
        archivos[nombre].write_text(json.dumps(x), encoding="utf-8")
    rep = tmp_path / "rep.json"
    rep.write_bytes(ruta.read_bytes())
    (tmp_path / "recibo_rep.json").write_text(json.dumps(recibo(sha(canon(r_rep)), sha(rep.read_bytes()))[1]))
    comun = (ruta, "--raiz", raiz, "--declaracion", archivos["recibo.json"])
    assert _main(*comun)[0] == 3  # recibo sin --reserva: no liga
    codigo, inf = _main(*comun, "--reserva", archivos["reserva.json"])
    assert (codigo, inf["estado"], inf["autenticidad"]["vias"]) == (0, "VERIFICADO", ["RECIBO_ANCLA"])
    codigo, inf = _main(*comun, "--reserva", archivos["reserva.json"], "--declaracion", tmp_path / "recibo_rep.json",
                        "--reproduccion", rep, "--reserva-reproduccion", archivos["reserva_rep.json"])
    assert (codigo, inf["estado"], inf["reproduccion"]["autenticidad"]["vias"]) == (0, "REPRODUCIDO", ["RECIBO_ANCLA"])
    assert _main(*comun, "--reserva", tmp_path / "no_existe.json")[0] == 3  # USO
    assert _main(*comun, "--reserva-reproduccion", archivos["reserva_rep.json"])[0] == 3  # sin --reproduccion: USO
    assert _main(*comun, "--reserva", archivos["reserva.json"], "--reserva", archivos["reserva.json"])[0] == 2


# ---------- (4) mutaciones aleatorias (fuzzing) ----------
def _mutar(rng: random.Random, raiz: Path, ruta: Path, declaraciones: list) -> str:
    archivos = sorted(p for p in raiz.rglob("*") if p.is_file())
    op = rng.choice(["byte", "truncar", "borrar", "clave_extra", "numero", "decl_firma", "decl_sha", "decl_basura",
                     "decl_emisor", "sustituir_resultado", "nada"])
    if op in ("byte", "truncar", "borrar"):
        p = rng.choice(archivos)
        b = p.read_bytes()
        if op == "byte" and b:
            i = rng.randrange(len(b))
            p.write_bytes(b[:i] + bytes([b[i] ^ (1 << rng.randrange(8))]) + b[i + 1:])
        elif op == "truncar":
            p.write_bytes(b[: rng.randrange(len(b) + 1)])
        else:
            p.unlink()
        return f"{op}:{p.relative_to(raiz)}"
    if op in ("clave_extra", "numero", "sustituir_resultado"):
        o = json.loads(ruta.read_text())
        if op == "clave_extra":
            o[f"extra_{rng.randrange(9)}"] = 1
        elif op == "numero":
            o["principal"]["conjunto"]["p"] = round(rng.random(), 4)
        else:
            o = F.oos(raiz=raiz, p_conj=0.5)
        ruta.write_text(json.dumps(o), encoding="utf-8")
        return op
    if op == "nada":
        return op
    nombre, doc = declaraciones[0]
    if not (isinstance(doc, dict) and isinstance(doc.get("contenido"), dict) and "firma_ed25519" in doc):
        return "nada"  # ya reemplazada por basura en una mutación anterior
    doc = json.loads(json.dumps(doc))
    if op == "decl_firma":
        f = doc["firma_ed25519"]
        i = rng.randrange(len(f))
        doc["firma_ed25519"] = f[:i] + ("0" if f[i] != "0" else "1") + f[i + 1:]
    elif op == "decl_sha":
        doc["contenido"]["artefactos"][0]["sha256"] = "%064x" % rng.getrandbits(256)
    elif op == "decl_emisor":
        doc["contenido"]["emisor"] = "PRUEBA-ANCLA"
    else:
        doc = rng.choice([None, 1, "x", [], {"contenido": {}}, {"contenido": {"x": "\ud800"}, "firma_ed25519": "0" * 128}])
    declaraciones[0] = (nombre, doc)
    return op


def test_fuzzing_nunca_excepcion_ni_verificado_indebido(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    rng = random.Random(20261020)
    molde, ruta0 = arbol(tmp_path / "molde")
    base = V.evaluar_archivo(ruta0, raiz=molde, declaraciones=[F.declarar_archivo(ruta0, molde)])
    assert base["estado"] == "VERIFICADO"
    firmado = sha(ruta0.read_bytes())
    relevantes = {k: v for k, v in base["archivos_leidos"].items()}
    contados = {"VERIFICADO": 0, "CORRUPTO": 0, "INCONCLUSO": 0}
    for i in range(300):
        raiz = tmp_path / f"c{i}" / "T"
        shutil.copytree(molde, raiz)
        ruta = raiz / RESULTADO
        decl = [F.declarar_archivo(ruta, raiz)]
        ops = [_mutar(rng, raiz, ruta, decl) for _ in range(rng.randint(1, 3))]
        inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=decl)  # nunca lanza
        contados[inf["estado"]] += 1
        intacto = ruta.is_file() and sha(ruta.read_bytes()) == firmado and all(
            (raiz / r).is_file() and sha((raiz / r).read_bytes()) == h for r, h in relevantes.items())
        if inf["estado"] == "VERIFICADO":
            assert intacto, (i, ops)
        if intacto and all(o in ("nada",) or o.startswith(("byte:", "truncar:", "borrar:")) for o in ops):
            assert inf["estado"] == "VERIFICADO", (i, ops, inf["motivos"])  # solo se tocaron archivos no leídos
    assert min(contados.values()) > 0, contados
