"""Tabla de decisión de P2 (regla de v0.4, igual en v0.5), para lectura humana: TODAS las combinaciones del espacio del oráculo (86.400), con la
salida de la IMPLEMENTACIÓN y la marca de si coincide con el oráculo; y un resumen. Registros sintéticos: solo recorren
ramas. «alcanzable_hoy» = con los registros reales (vacíos): sin definiciones, sin etapa y sin autorización.

Uso: python3 generar_tabla.py <dir_salida>"""
from __future__ import annotations

import csv
import io
import sys
from collections import Counter
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
sys.path.insert(1, str(AQUI.parent / "comun"))
import escenarios_p2 as E  # noqa: E402
import oraculo_p2 as O  # noqa: E402
import version  # noqa: E402

COLUMNAS = ("validez", "etiqueta", "registro_definiciones", "R1", "R3", "etapa", "autorizacion", "resultado",
            "error_en", "etiqueta_estadistica", "clase", "robustez", "avance", "etapa_salida", "autorizacion_estado",
            "post_hoc_R1", "post_hoc_R3", "coincide_con_oraculo", "alcanzable_hoy")


def filas() -> list[dict]:
    PA = version.p2()
    out = []
    for c in E.espacio():
        obtenido = E.ejecutar(PA, *c)
        validez, etiqueta, reg, r1, r3, etapa, aut = c
        fila = {"validez": validez, "etiqueta": etiqueta or "", "registro_definiciones": reg, "R1": r1, "R3": r3,
                "etapa": etapa or "", "autorizacion": aut or "", "resultado": obtenido[0],
                "coincide_con_oraculo": "sí" if obtenido == O.esperado(*c) else "NO",
                "alcanzable_hoy": "sí" if (reg == "VACIO" and etapa is None and aut is None) else "no"}
        if obtenido[0] == "ERROR":
            fila["error_en"] = obtenido[1]
        else:
            s = obtenido[1]
            fila |= {"etiqueta_estadistica": s["etiqueta_estadistica"] or "", "clase": s["clase"],  # type: ignore[index]
                     "robustez": s["robustez"], "avance": s["avance"], "etapa_salida": s["etapa_salida"],  # type: ignore[index]
                     "autorizacion_estado": s["autorizacion"], "post_hoc_R1": s["post_hoc_R1"],  # type: ignore[index]
                     "post_hoc_R3": s["post_hoc_R3"]}  # type: ignore[index]
        out.append(fila)
    return out


def main(salida: Path) -> None:
    f = filas()
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=COLUMNAS, lineterminator="\n", restval="")
    w.writeheader()
    w.writerows(f)
    salida.mkdir(parents=True, exist_ok=True)
    (salida / "TABLA_DECISION_P2_v0.5.csv").write_text(buf.getvalue(), encoding="utf-8")
    ok = [x for x in f if x["resultado"] == "OK"]
    hoy = [x for x in ok if x["alcanzable_hoy"] == "sí"]
    lineas = ["# Tabla de decisión de P2 v0.5 (resumen; la regla de decisión no cambió desde v0.4)", "",
              f"- Combinaciones: {len(f)}; con salida: {len(ok)}; con error de entrada (explícito): {len(f) - len(ok)}.",
              f"- Coinciden con el oráculo independiente: {sum(x['coincide_con_oraculo'] == 'sí' for x in f)} de {len(f)}.",
              f"- Alcanzables HOY (registros vacíos, sin etapa ni autorización): {len(hoy)}.", "",
              "| Estado de la autorización | Filas |", "|---|---|"]
    lineas += [f"| {k} | {v} |" for k, v in sorted(Counter(x["autorizacion_estado"] for x in ok).items())]
    lineas += ["", "| Avance (alcanzable hoy) | Validez | Filas |", "|---|---|---|"]
    lineas += [f"| {a} | {v} | {n} |" for (a, v), n in sorted(Counter((x["avance"], x["validez"]) for x in hoy).items())]
    lineas += ["", "| Error de entrada en | Filas |", "|---|---|"]
    lineas += [f"| {k} | {v} |" for k, v in sorted(Counter(x["error_en"] for x in f if x["resultado"] == "ERROR").items())]
    (salida / "TABLA_DECISION_P2_v0.5.md").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print("\n".join(lineas))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
