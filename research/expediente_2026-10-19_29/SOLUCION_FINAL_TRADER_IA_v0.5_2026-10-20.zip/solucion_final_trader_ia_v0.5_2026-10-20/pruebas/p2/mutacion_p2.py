"""Mutaciones de la política P2 (regla de v0.4, igual en v0.5) para comprobar que el oráculo independiente las detecta (prueba de la prueba).
Cada mutación se aplica a una COPIA temporal; se cuenta en cuántas combinaciones del espacio la implementación mutada
discrepa del oráculo. Una mutación «sobrevive» si no discrepa en ninguna.

Uso: python3 mutacion_p2.py <dir_codigo> <archivo_salida>"""
from __future__ import annotations

import importlib
import shutil
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
MUTACIONES = [
    ("autorización sin comprobar la etapa", '(a["etapa"] != etapa, f"es para la etapa {a[\'etapa\']!r}"),',
     '(False, f"es para la etapa {a[\'etapa\']!r}"),'),
    ("autorización sin comprobar el resultado", '(valida and a["resultado_sha256"] != ev.resultado_sha256, "es para otro resultado"),',
     '(False, "es para otro resultado"),'),
    ("candidata con cualquier clase", 'if clase == "RESPALDADA":\n            avance', 'if clase != "NO_RESPALDADA":\n            avance'),
    ("robustez con «alguna» en vez de «todas»", 'if e1 == e3 == "CUMPLE":', 'if "CUMPLE" in (e1, e3):'),
    ("post hoc con > en vez de ≥", "aprobada.astimezone(dt.UTC).date() >= _fecha(", "aprobada.astimezone(dt.UTC).date() > _fecha("),
    ("post hoc sin convertir la aprobación a UTC", "aprobada.astimezone(dt.UTC).date() >= _fecha(",
     "aprobada.date() >= _fecha("),
    ("evaluación sin ligar al resultado", '!= ev.resultado_sha256:\n        raise ErrorPolitica(f"{nombre}: la evaluación es de otro',
     '!= ev.resultado_sha256 and False:\n        raise ErrorPolitica(f"{nombre}: la evaluación es de otro'),
    ("registro sin comprobar id = clave", 'if d["id"] != clave:', 'if False:'),
    ("etiqueta aunque la evidencia no sea válida", '"etiqueta_estadistica": ev.etiqueta if valida else None,',
     '"etiqueta_estadistica": ev.etiqueta,'),
    ("REPRODUCIDO no cuenta como válida", 'VALIDA = ("VERIFICADO", "REPRODUCIDO")', 'VALIDA = ("VERIFICADO",)'),
    ("NO_EVALUADO sin definición", 'if not propias:\n            raise ErrorPolitica(f"{nombre}: NO_EVALUADO exige',
     'if False:\n            raise ErrorPolitica(f"{nombre}: NO_EVALUADO exige'),
]


def main(codigo: Path, salida: Path) -> int:
    sys.path.insert(0, str(AQUI))
    sys.path.insert(1, str(AQUI.parent / "comun"))
    lineas, sobreviven = [], 0
    for nombre, viejo, nuevo in MUTACIONES:
        with tempfile.TemporaryDirectory() as tmp:
            for f in ("confianza.py", "verificar_reproduccion_T.py", "politica_avance_T.py"):
                shutil.copy(codigo / f, Path(tmp) / f)
            p = Path(tmp) / "politica_avance_T.py"
            texto = p.read_text(encoding="utf-8")
            if texto.count(viejo) != 1:
                raise SystemExit(f"mutación {nombre!r}: el texto original aparece {texto.count(viejo)} veces")
            p.write_text(texto.replace(viejo, nuevo), encoding="utf-8")
            for m in ("politica_avance_T", "verificar_reproduccion_T", "confianza", "escenarios_p2", "oraculo_p2"):
                sys.modules.pop(m, None)
            sys.path.insert(0, tmp)
            PA = importlib.import_module("politica_avance_T")
            E = importlib.import_module("escenarios_p2")
            O = importlib.import_module("oraculo_p2")
            discrepan = sum(E.ejecutar(PA, *c) != O.esperado(*c) for c in E.espacio())
            sys.path.remove(tmp)
        sobreviven += discrepan == 0
        lineas.append(f"{'MUERTA' if discrepan else 'SOBREVIVE'}\t{discrepan} combinaciones discrepan\t{nombre}")
    salida.write_text("\n".join(lineas) + f"\n{len(MUTACIONES) - sobreviven} de {len(MUTACIONES)} mutaciones detectadas "
                      "por el oráculo\n", encoding="utf-8")
    print(salida.read_text(encoding="utf-8"))
    return 1 if sobreviven else 0


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]), Path(sys.argv[2])))
