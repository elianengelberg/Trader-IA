"""Oráculo INDEPENDIENTE de la política P2 (regla de v0.4, igual en v0.5): escrito desde la especificación (docstring de la política y
DECISIONES_METODOLOGICAS_SIN_DEFINIR.md), sin importar ni copiar su código. Trabaja con nombres de escenario, no con
estructuras de la implementación. Devuelve ("ERROR", etapa_del_error) o ("OK", salida_esperada).

Precedencia de errores especificada: evidencia → registros → etapa → R1 → R3 → autorización."""
from __future__ import annotations

# Clases de las etiquetas, leídas del TEXTO de los productores congelados (fuera_de_muestra_T.py:44-49 y
# tendencia.papel.decidir), no de la política.
CLASE = {"RESPALDADA FUERA DE MUESTRA": "RESPALDADA", "VENTAJA RESPALDADA": "RESPALDADA",
         "NO RESPALDADA": "NO_RESPALDADA", "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
         "EVIDENCIA INSUFICIENTE": "INSUFICIENTE", "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
         "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO"}
VALIDAS = {"VERIFICADO", "REPRODUCIDO"}

# Escenarios de entrada (los mismos nombres que usa la prueba para construirlos)
VALIDEZ = ("VERIFICADO", "REPRODUCIDO", "NO_REPRODUCIDO", "CORRUPTO", "INCONCLUSO")
ETIQUETAS = (*CLASE, None)
REGISTRO_DEF = ("VACIO", "SINTETICO", "SINTETICO_LIMITE", "ID_DISTINTO_DE_LA_CLAVE")
R = ("NO_DEFINIDO", "NO_EVALUADO", "CUMPLE", "NO_CUMPLE", "CUMPLE_OTRO_RESULTADO", "TUPLA_V03")
ETAPA = (None, "ETAPA_SINTETICA", "ETAPA_INVENTADA")
AUTORIZACION = (None, "COINCIDENTE", "OTRA_ETAPA", "OTRO_RESULTADO", "INEXISTENTE")
# SINTETICO: R1 aprobada ANTES del inicio de la ventana (2022-01-01) y R3 DESPUÉS (post hoc).
# SINTETICO_LIMITE: R1 aprobada a las 23:59:59 UTC del día anterior (escrita con zona +02:00) → no post hoc; R3 aprobada
# EXACTAMENTE el día de inicio a las 00:00 UTC → post hoc («en o después del inicio»).
POST_HOC = {"R1": False, "R3": True}


def esperado(validez: str, etiqueta: str | None, reg_def: str, r1: str, r3: str, etapa: str | None,
             aut: str | None) -> tuple[str, object]:
    valida = validez in VALIDAS
    # 1. evidencia: una evidencia válida exige una etiqueta literal conocida
    if valida and etiqueta not in CLASE:
        return "ERROR", "evidencia"
    # 2. registros: una definición registrada con otra clave invalida todo el registro
    if reg_def == "ID_DISTINTO_DE_LA_CLAVE":
        return "ERROR", "registros"
    # 3. etapa: solo etapas definidas
    if etapa == "ETAPA_INVENTADA":
        return "ERROR", "etapa"
    hay_def = reg_def in ("SINTETICO", "SINTETICO_LIMITE")

    def criterio(nombre: str, valor: str) -> tuple[str, object]:
        if valor == "NO_DEFINIDO":
            return ("ERROR", nombre) if hay_def else ("OK", ("NO_DEFINIDO", None))
        if valor == "NO_EVALUADO":
            return ("OK", ("NO_EVALUADO", None)) if hay_def else ("ERROR", nombre)
        if valor in ("TUPLA_V03", "CUMPLE_OTRO_RESULTADO") or not hay_def:
            return "ERROR", nombre
        return "OK", (valor, POST_HOC[nombre])

    c1, c3 = criterio("R1", r1), criterio("R3", r3)
    if c1[0] == "ERROR":
        return c1
    if c3[0] == "ERROR":
        return c3
    if aut == "INEXISTENTE":
        return "ERROR", "autorizacion"
    (e1, ph1), (e3, ph3) = c1[1], c3[1]  # type: ignore[misc]
    clase = CLASE[etiqueta] if valida else "SIN_EVIDENCIA_VALIDA"  # type: ignore[index]
    if not valida:
        rob = "NO_APLICA"
    elif "NO_CUMPLE" in (e1, e3):
        rob = "NO_ROBUSTA"
    elif e1 == "CUMPLE" and e3 == "CUMPLE":
        rob = "ROBUSTA"
    else:
        rob = "INDETERMINADA"
    avance = "CANDIDATA_A_REVISION_HUMANA" if clase == "RESPALDADA" else "NO_CANDIDATA"
    if aut is None:
        estado_aut = "NO_OTORGADA"
    else:
        etapa_aut = {"COINCIDENTE": "ETAPA_SINTETICA", "OTRA_ETAPA": "OTRA", "OTRO_RESULTADO": "ETAPA_SINTETICA"}[aut]
        coherente = (etapa is not None and etapa == etapa_aut and valida and aut != "OTRO_RESULTADO"
                     and clase == "RESPALDADA")
        estado_aut = "REGISTRADA_EXTERNAMENTE" if coherente else "CONTRADICTORIA"
    return "OK", {"etiqueta_estadistica": etiqueta if valida else None, "etiqueta_declarada": etiqueta,
                  "clase": clase, "robustez": rob, "avance": avance, "etapa_salida": etapa or "NO_DEFINIDA",
                  "autorizacion": estado_aut, "R1": e1, "R3": e3, "post_hoc_R1": ph1, "post_hoc_R3": ph3}
