"""Defectos de P2. LAS MISMAS pruebas contra v0.2, v0.3, v0.4 y v0.5 (VERSION_BAJO_PRUEBA):
- P2_S1…S5: corregidos en v0.3 (la API de v0.2 era otra: el adaptador no la soporta y la prueba falla; el defecto de
  v0.2 en sí lo muestran sus sondas, evidencia/40_sondas_v0_2.txt).
- P2_N1…N5: corregidos en v0.4 (fallan en v0.3 y pasan en v0.4 y v0.5)."""
from __future__ import annotations

import contextlib
import inspect
import json
from pathlib import Path

import fabricas_t as F
import pytest
import version

SHA_A, SHA_B = "a" * 64, "b" * 64
V03 = {"CORRUPTO": "RECHAZADO", "INCONCLUSO": "COHERENTE_SIN_INTEGRIDAD"}


def _def(ident: str, criterio: str, aprobada: str = "2000-01-01T00:00:00Z", **cambios) -> dict:  # type: ignore[no-untyped-def]
    return {"id": ident, "criterio": criterio, "aplica_a": "T", "texto_sha256": "0" * 64, "aprobada_utc": aprobada,
            "aprobada_por": "PRUEBA SINTÉTICA"} | cambios


DEFS = {"R1-S": _def("R1-S", "R1"), "R3-S": _def("R3-S", "R3")}
ETAPAS = {"ETAPA": "sintética", "OTRA": "sintética"}
AUTS = {n: {"id": n, "etapa": e, "resultado_sha256": s, "otorgada_por": "PRUEBA SINTÉTICA",
            "otorgada_utc": "2030-01-01T00:00:00Z", "texto_sha256": "1" * 64}
        for n, e, s in (("COINCIDENTE", "ETAPA", SHA_A), ("OTRA_ETAPA", "OTRA", SHA_A), ("OTRO_RESULTADO", "ETAPA", SHA_B))}


def r(estado: str, ident: str | None = None, sha: str = SHA_A) -> object:
    """Evaluación de R en el formato de la versión bajo prueba."""
    if estado in ("NO_DEFINIDO", "NO_EVALUADO"):
        return estado
    if version.NUMERO >= 2:  # v0.4 y v0.5
        return {"estado": estado, "definicion": ident, "resultado_sha256": sha}
    return (estado, ident)


@contextlib.contextmanager
def registros(PA, defs=None, etapas=None, auts=None):  # type: ignore[no-untyped-def]
    viejos = PA.DEFINICIONES_APROBADAS, PA.ETAPAS_DEFINIDAS, PA.AUTORIZACIONES
    PA.DEFINICIONES_APROBADAS, PA.ETAPAS_DEFINIDAS, PA.AUTORIZACIONES = defs or {}, etapas or {}, auts or {}
    try:
        yield
    finally:
        PA.DEFINICIONES_APROBADAS, PA.ETAPAS_DEFINIDAS, PA.AUTORIZACIONES = viejos


def decidir(validez: str, etiqueta: str | None, r1: object = "NO_DEFINIDO", r3: object = "NO_DEFINIDO", *,
            etapa: str | None = None, aut: str | None = None, defs=None, etapas=None, auts=None,  # type: ignore[no-untyped-def]
            inicio: str = "2022-01-01") -> dict:
    """Misma decisión con la API de cada versión, con los registros del MÓDULO (no inyectados por parámetro)."""
    PA = version.p2()
    if version.VERSION == "v0_2":
        raise NotImplementedError("la API de v0.2 (aplicar(etiqueta, ...)) no tiene validez de evidencia")
    with registros(PA, defs, etapas, auts):
        if version.VERSION == "v0_3":
            ev = PA.evidencia(V03.get(validez, validez), etiqueta, SHA_A, inicio)
            return PA.aplicar(ev, r1, r3, etapa=etapa, autorizacion=aut)
        ev = PA._evidencia_sintetica(validez, etiqueta, SHA_A, inicio)
        return PA._decidir(ev, r1, r3, etapa, aut)


# ---------- S1: sin evidencia válida no hay etiqueta ----------
@pytest.mark.parametrize("validez", ["CORRUPTO", "INCONCLUSO", "NO_REPRODUCIDO"])
def test_P2_S1_evidencia_no_valida_no_da_etiqueta(validez: str) -> None:
    s = decidir(validez, "RESPALDADA FUERA DE MUESTRA")
    assert (s["etiqueta_estadistica"], s["clase_estadistica"], s["decision_avance"]["resultado"]) == (
        None, "SIN_EVIDENCIA_VALIDA", "NO_CANDIDATA")


# ---------- S2: R1/R3 obligatorios y coherentes con el registro ----------
def test_P2_S2_r1_r3_obligatorios_y_coherentes() -> None:
    PA = version.p2()
    funcion = PA._decidir if hasattr(PA, "_decidir") else PA.aplicar
    with pytest.raises(TypeError):  # sin R1 ni R3: no hay valor por defecto
        funcion(None)  # type: ignore[call-arg]
    with pytest.raises(PA.ErrorPolitica, match="no puede ser NO_DEFINIDO"):
        decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", "NO_DEFINIDO", "NO_DEFINIDO", defs=DEFS)
    with pytest.raises(PA.ErrorPolitica, match="NO_EVALUADO exige"):
        decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", "NO_EVALUADO", "NO_DEFINIDO")
    s = decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", "NO_EVALUADO", "NO_EVALUADO", defs=DEFS)
    assert s["robustez"]["resumen"] == "INDETERMINADA"


# ---------- S3: la autorización nunca se otorga; las contradicciones son explícitas ----------
def test_P2_S3_autorizacion_constatada_nunca_otorgada() -> None:
    PA = version.p2()
    k = {"etapas": ETAPAS, "auts": AUTS, "etapa": "ETAPA"}
    assert decidir("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", **k)["autorizacion_ejecucion"]["estado"] == "NO_OTORGADA"
    s = decidir("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", aut="COINCIDENTE", **k)
    assert s["autorizacion_ejecucion"]["estado"] == "REGISTRADA_EXTERNAMENTE" and "no ejecuta" in s[
        "autorizacion_ejecucion"]["motivo"]
    for etiqueta, aut in (("EVIDENCIA INSUFICIENTE", "COINCIDENTE"), ("RESPALDADA FUERA DE MUESTRA", "OTRA_ETAPA"),
                          ("RESPALDADA FUERA DE MUESTRA", "OTRO_RESULTADO")):
        assert decidir("VERIFICADO", etiqueta, aut=aut, **k)["autorizacion_ejecucion"]["estado"] == "CONTRADICTORIA"
    assert decidir("CORRUPTO", "RESPALDADA FUERA DE MUESTRA", aut="COINCIDENTE", **k)[
        "autorizacion_ejecucion"]["estado"] == "CONTRADICTORIA"
    with pytest.raises(PA.ErrorPolitica, match="desconocida"):
        decidir("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", aut="INVENTADA", **k)
    with pytest.raises(PA.ErrorPolitica, match="no definida"):
        decidir("VERIFICADO", "VENTAJA RESPALDADA", etapa="DINERO_REAL")


# ---------- S4, S5: fechas estrictas, post hoc y hash del texto ----------
@pytest.mark.parametrize("aprobada", ["1", "ayer", "2021-12-31", "2021-12-31T23:00:00"])
def test_P2_S4_fecha_de_aprobacion_invalida(aprobada: str) -> None:
    PA = version.p2()
    with pytest.raises(PA.ErrorPolitica):
        decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", r("CUMPLE", "R1-S"), "NO_DEFINIDO",
                defs={"R1-S": _def("R1-S", "R1", aprobada)})


@pytest.mark.parametrize("aprobada,post_hoc", [("2021-12-31T23:59:59Z", False), ("2022-01-01T00:00:00Z", True),
                                               ("2022-01-01T01:00:00+02:00", False), ("2026-10-20T10:00:00+02:00", True)])
def test_P2_S4_post_hoc_con_fechas_reales(aprobada: str, post_hoc: bool) -> None:
    s = decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", r("CUMPLE", "R1-S"), "NO_DEFINIDO",
                defs={"R1-S": _def("R1-S", "R1", aprobada)})
    assert s["robustez"]["R1"]["post_hoc"] is post_hoc


def test_P2_S5_hash_del_texto_validado() -> None:
    PA = version.p2()
    with pytest.raises(PA.ErrorPolitica, match="SHA-256"):
        decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", r("CUMPLE", "R1-S"), "NO_DEFINIDO",
                defs={"R1-S": _def("R1-S", "R1", texto_sha256="cualquier cosa")})


# ---------- N1: ninguna función PÚBLICA acepta una evidencia armada a mano ----------
def test_P2_N1_no_hay_evidencia_publica_sin_pasar_por_P1() -> None:
    PA = version.p2()
    with pytest.raises((AttributeError, PA.ErrorPolitica)):  # el atajo de v0.3: evidencia «VERIFICADO» sin P1
        PA.aplicar(PA.evidencia("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", SHA_A, "2022-01-01"),
                   "NO_DEFINIDO", "NO_DEFINIDO")
    publicas = {n for n, x in vars(PA).items() if not n.startswith("_") and callable(x)
                and getattr(x, "__module__", None) == PA.__name__ and n != "ErrorPolitica"}
    assert publicas == {"desde_resultado", "robustez"}


# ---------- N2: la fecha de la ventana sale de los bytes VERIFICADOS (v0.3 releía el archivo) ----------
def test_P2_N2_inicio_de_ventana_de_los_bytes_verificados(tmp_path: Path, raices, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    PA = version.p2()
    raiz = F.arbol_t(tmp_path / "T")
    ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")  # ventana desde 2022-01-01
    sha = F.sha(ruta.read_bytes())
    otro = F.oos(raiz=raiz)
    otro["ventana"] = otro["principal"]["ventana"] = ["2025-01-01", "2026-06-01"]
    original = PA.V.cargar

    def cargar_y_sustituir(p):  # type: ignore[no-untyped-def]
        x = original(p)
        if Path(p) == ruta:
            ruta.write_text(json.dumps(otro), encoding="utf-8")  # alguien cambia el archivo tras verificarlo
        return x

    monkeypatch.setattr(PA.V, "cargar", cargar_y_sustituir)
    defs = {"R1-S": _def("R1-S", "R1", "2023-06-01T00:00:00Z")}  # posterior a 2022-01-01, anterior a 2025-01-01
    kw = {"declaraciones": [("d", F.declarar({"experimentos/fuera_de_muestra_T.json": sha}))]} if version.NUMERO >= 2 else {}
    with registros(PA, defs):
        s = PA.desde_resultado(ruta, raiz, r("CUMPLE", "R1-S", sha), "NO_DEFINIDO", **kw)
    assert s["robustez"]["R1"]["post_hoc"] is True  # medido contra la ventana VERIFICADA (2022-01-01)


# ---------- N3: los registros no se inyectan por parámetro ----------
def test_P2_N3_registros_no_inyectables(tmp_path: Path) -> None:
    PA = version.p2()
    params = inspect.signature(PA.desde_resultado).parameters
    assert not any(p.kind is p.VAR_KEYWORD for p in params.values())
    raiz = F.arbol_t(tmp_path / "T")
    ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    with pytest.raises(TypeError):
        PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", etapas=ETAPAS, autorizaciones=AUTS)


# ---------- N4: una evaluación de R1/R3 nombra el resultado evaluado y debe ser ESTE ----------
def test_P2_N4_evaluacion_ligada_al_resultado() -> None:
    PA = version.p2()
    with pytest.raises(PA.ErrorPolitica):  # sin resultado: no se sabe sobre qué se evaluó
        decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", ("CUMPLE", "R1-S"), "NO_DEFINIDO", defs={"R1-S": DEFS["R1-S"]})
    with pytest.raises(PA.ErrorPolitica, match="otro resultado"):
        decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", r("CUMPLE", "R1-S", SHA_B), "NO_DEFINIDO",
                defs={"R1-S": DEFS["R1-S"]})
    s = decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", r("CUMPLE", "R1-S", SHA_A), "NO_DEFINIDO",
                defs={"R1-S": DEFS["R1-S"]})
    assert s["robustez"]["R1"]["estado"] == "CUMPLE"


# ---------- N5: registros coherentes (clave = id; autorización para una etapa definida) ----------
def test_P2_N5_definicion_registrada_con_otra_clave() -> None:
    PA = version.p2()
    with pytest.raises(PA.ErrorPolitica, match="registrado como"):
        decidir("VERIFICADO", "EVIDENCIA INSUFICIENTE", r("CUMPLE", "R1-S"), "NO_DEFINIDO",
                defs={"R1-S": _def("R1-OTRA", "R1")})


def test_P2_N5_autorizacion_para_una_etapa_no_definida() -> None:
    PA = version.p2()
    with pytest.raises(PA.ErrorPolitica, match="no está definida"):
        decidir("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", etapa="ETAPA", aut="COINCIDENTE",
                etapas={"ETAPA": "sintética"}, auts=AUTS)  # OTRA_ETAPA apunta a «OTRA», que no existe
