"""Defecto de P2 encontrado en la revisión adversarial de v0.4 (F3), corregido en v0.5: una reproducción que nadie
autenticó convertía la evidencia en VÁLIDA (REPRODUCIDO) para la política. LA MISMA prueba contra v0.4 (debe FALLAR) y
v0.5 (debe PASAR)."""
from __future__ import annotations

import json
from pathlib import Path

import fabricas_t as F
import version


def test_P2_F3_reproduccion_no_autenticada_no_es_evidencia_valida(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    PA = version.p2()
    raiz = F.arbol_t(tmp_path / "T")
    ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    copia = json.loads(ruta.read_text())  # «reproducción» = copia del propio original, en memoria
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", declaraciones=[F.declarar_archivo(ruta, raiz)],
                           reproduccion=copia)
    assert s["evidencia"]["validez"] not in ("VERIFICADO", "REPRODUCIDO", "NO_REPRODUCIDO")
    assert s["etiqueta_estadistica"] is None and s["decision_avance"]["resultado"] == "NO_CANDIDATA"
