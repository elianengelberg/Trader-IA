"""Conductor de las pruebas de P4: ejecuta ``ejecutar`` del módulo de uso único indicado (``modulo``: la versión bajo
prueba) en un proceso aparte. ``punto``: muere con os._exit(137) (caída real, sin finally). ``pausa``: se detiene de
forma DETERMINISTA (escribe en la FIFO ``listo`` y espera a leer de ``seguir``). ``ancla_firmada``: cliente
AnclaFirmada contra el DOBLE DE PRUEBA de un ancla externa. ``fallos_es``: fallo de escritura inyectado (o "CONTAR").
Si ``ejecutar`` lanza una excepción, el proceso termina con un rastro: eso es lo que la prueba observa."""
from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent / "comun"))


def cargar(ruta: Path):  # type: ignore[no-untyped-def]
    spec = importlib.util.spec_from_file_location("uso_unico_conducido", ruta)
    m = importlib.util.module_from_spec(spec)
    sys.modules["uso_unico_conducido"] = m
    spec.loader.exec_module(m)  # type: ignore[union-attr]
    return m


if __name__ == "__main__":
    a = json.loads(sys.argv[1])
    U = cargar(Path(a["modulo"]))
    punto, pausa = a.get("punto"), a.get("pausa")
    proxy = None
    if a.get("fallos_es"):
        from fallos_es import OSConFallos
        proxy = OSConFallos(os, None if a["fallos_es"] == "CONTAR" else a["fallos_es"])
        U.os = proxy
    elif a.get("corte"):  # v0.5: corte de energía simulado
        from fallos_es import OSConCorte
        proxy = OSConCorte(os, None if a["corte"] == "CONTAR" else a["corte"])
        U.os = proxy

    def fallo(p: str) -> None:
        if p == punto:
            os._exit(137)
        if p == pausa:
            with open(a["listo"], "w") as fh:  # bloquea hasta que la prueba abra la FIFO para leer
                fh.write(p)
            with open(a["seguir"]) as fh:  # bloquea hasta que la prueba lo libere
                fh.read()

    ancla = None
    if a.get("ancla"):
        ancla = U.AnclaArchivo(a["ancla"])
    elif a.get("ancla_firmada"):
        from ancla_de_prueba import ServidorAnclaDePrueba
        f = a["ancla_firmada"]
        servidor = ServidorAnclaDePrueba(f["ruta"], bytes.fromhex(f["semilla_hex"]), f["emisor"], modulo=U,
                                         manipulacion=f.get("manipulacion"))
        ancla = U.AnclaFirmada(servidor, f.get("clave_cliente") or servidor.publica, f["emisor"])
    kw = {"ancla": ancla, "reintentos_tras_inicio": a.get("reintentos", 0), "fallo": fallo}
    if a.get("verificar_determinismo") is not None:
        kw["verificar_determinismo"] = a["verificar_determinismo"]
    for clave in ("limite_segundos", "reproduccion_de"):  # v0.5 (en v0.4 no existen: la llamada falla)
        if clave in a:
            kw[clave] = a[clave]
    s = U.ejecutar(a["dir"], a["experimento"], a["archivos"], a["semilla"], **kw)
    salida = dict(s.__dict__)
    if proxy is not None:
        salida |= {"conteo_es": proxy.conteo, "inyectado": proxy.inyectado}
    print(json.dumps(salida, ensure_ascii=False), flush=True)
    if isinstance(a.get("corte"), dict) and a["corte"].get("op") == "fin":
        proxy._cortar()  # v0.5: corte de energía DESPUÉS de informar la salida (¿sobrevive lo informado?)
