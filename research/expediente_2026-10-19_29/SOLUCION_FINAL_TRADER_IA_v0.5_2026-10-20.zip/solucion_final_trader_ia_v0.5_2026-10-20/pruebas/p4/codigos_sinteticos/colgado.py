"""Código de cálculo SINTÉTICO que NO termina nunca (para el límite de tiempo de v0.5)."""
import time


def calcular(contenidos, semilla):
    with open(contenidos["contador"].decode().strip(), "a") as fh:
        fh.write("calculo\n")
    while True:
        time.sleep(0.2)
