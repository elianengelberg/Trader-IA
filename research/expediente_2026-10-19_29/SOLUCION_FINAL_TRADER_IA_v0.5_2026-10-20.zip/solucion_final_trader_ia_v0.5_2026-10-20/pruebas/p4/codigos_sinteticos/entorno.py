"""Código de cálculo SINTÉTICO que intenta leer el entorno del proceso que lo lanza (variables y directorio)."""
import os


def calcular(contenidos, semilla):
    with open(contenidos["contador"].decode().strip(), "a") as fh:
        fh.write("calculo\n")
    return {"secreto": os.environ.get("SECRETO_DE_PRUEBA"), "directorio": os.getcwd(),
            "variables": len(os.environ)}
