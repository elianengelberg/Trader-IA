"""Código de cálculo SINTÉTICO que falla después de empezar (podría haber visto un resultado)."""


def calcular(contenidos, semilla):
    with open(contenidos["contador"].decode().strip(), "a") as fh:
        fh.write("calculo\n")
    raise SystemExit(3)
