"""Código de cálculo SINTÉTICO que intenta mostrar su resultado por stdout y stderr antes del presellado."""
import sys


def calcular(contenidos, semilla):
    with open(contenidos["contador"].decode().strip(), "a") as fh:
        fh.write("calculo\n")
    print("FUGA-RESULTADO-0.123")
    print("FUGA-RESULTADO-0.123", file=sys.stderr)
    return {"valor": 0.123}
