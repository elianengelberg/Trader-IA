"""Código de cálculo SINTÉTICO y LENTO (1,5 s) (lo ejecuta el proceso hijo desde los bytes reservados)."""
import random
import time


def calcular(contenidos, semilla):
    with open(contenidos["contador"].decode().strip(), "a") as fh:
        fh.write("calculo\n")
    time.sleep(1.5)
    datos = [float(x) for x in contenidos["datos"].decode().split()]
    rng = random.Random(semilla)
    medias = [sum(rng.choice(datos) for _ in datos) / len(datos) for _ in range(200)]
    return {"media": sum(datos) / len(datos), "p_mayor_que_cero": sum(m > 0 for m in medias) / len(medias),
            "n": len(datos)}
