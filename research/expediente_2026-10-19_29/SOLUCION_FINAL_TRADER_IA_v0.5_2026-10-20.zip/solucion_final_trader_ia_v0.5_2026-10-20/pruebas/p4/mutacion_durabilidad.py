"""Prueba de la prueba de CORTE DE ENERGÍA: cada mutación QUITA un fsync de una COPIA de uso_unico.py y se comprueba
que test_p4_corte_energia lo detecta (alguna violación). Uso: python3 mutacion_durabilidad.py <dir_codigo> <salida.txt>"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
MUTACIONES = [  # (descripción, línea original exacta, línea mutada); cada original aparece una vez
    ("diario: el evento añadido no se sincroniza (_anotar sin fsync final)",
     "            _escribir_todo(fd, linea + b\"\\n\")\n        os.fsync(fd)\n",
     "            _escribir_todo(fd, linea + b\"\\n\")\n"),
    ("reserva: el enlace del diario nuevo no se sincroniza (_reservar sin fsync del directorio)",
     "        tmp.unlink()\n    _fsync_dir(d)\n", "        tmp.unlink()\n"),
    ("escritura atómica sin fsync del directorio tras replace", "    os.replace(tmp, ruta)\n    _fsync_dir(ruta.parent)\n",
     "    os.replace(tmp, ruta)\n"),
    ("archivo nuevo sin fsync antes de enlazarlo o renombrarlo (_escribir_nuevo)",
     "        else:\n            _escribir_todo(fd, datos)\n        os.fsync(fd)\n",
     "        else:\n            _escribir_todo(fd, datos)\n"),
]


def main(codigo: Path, salida: Path) -> int:
    lineas, muertas = [], 0
    for desc, viejo, nuevo in MUTACIONES:
        with tempfile.TemporaryDirectory() as tmp:
            for p in codigo.glob("*.py"):
                shutil.copy(p, tmp)
            u = Path(tmp) / "uso_unico.py"
            texto = u.read_text(encoding="utf-8")
            assert texto.count(viejo) == 1, desc
            u.write_text(texto.replace(viejo, nuevo), encoding="utf-8")
            r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q", "--tb=line", "-x",
                                "p4/test_p4_corte_energia.py"], cwd=AQUI.parent,
                               capture_output=True, text=True, env={**os.environ, "CODIGO_ACTUAL_DIR": tmp,
                                                                    "PYTHONDONTWRITEBYTECODE": "1"})
            muerta = r.returncode != 0
            muertas += muerta
            resumen = next((x for x in reversed(r.stdout.splitlines()) if "violan" in x or "passed" in x), "")[:300]
            lineas.append(f"{'MUERTA' if muerta else 'SOBREVIVE'}\t{desc}\t{resumen}")
    lineas.append(f"{muertas} de {len(MUTACIONES)} mutaciones de durabilidad detectadas por la prueba de corte de energía")
    salida.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print(lineas[-1])
    return 0 if muertas == len(MUTACIONES) else 1


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]), Path(sys.argv[2])))
