"""Cliente AnclaFirmada (v0.4) frente a un servicio comprometido o un intermediario (DOBLE DE PRUEBA con
manipulaciones) y de extremo a extremo con ``ejecutar``: recibo guardado antes que el resultado, restauración del
recibo, y ninguna respuesta no auténtica hace avanzar el estado. Claves sintéticas."""
from __future__ import annotations

import json
from pathlib import Path

import fabricas_t as F
import pytest
import version
from ancla_de_prueba import ServidorAnclaDePrueba
from sincro import correr, llamadas, preparar
from version import desde_v04

pytestmark = desde_v04
U = version.p4()
C = F.C
R1 = "1" * 64


def cliente(tmp: Path, **kw):  # type: ignore[no-untyped-def]
    s = ServidorAnclaDePrueba(tmp / "a.jsonl", F.SEMILLA_ANCLA, "PRUEBA-ANCLA", modulo=U, **kw)
    return U.AnclaFirmada(s, s.publica, "PRUEBA-ANCLA"), s


@pytest.mark.parametrize("manipulacion", ["otra_clave", "otra_operacion", "estado_falso_tras_firma"])
def test_respuestas_no_autenticas(tmp_path: Path, manipulacion: str) -> None:
    a, _ = cliente(tmp_path, manipulacion=manipulacion)
    with pytest.raises(U.AnclaNoAutentica):
        a.consultar(R1)


def test_respuesta_vieja_repetida_no_sirve(tmp_path: Path) -> None:
    """Un intermediario guarda una respuesta auténtica (0 inicios) y la repite después de un inicio: el desafío no
    coincide y el cliente no la acepta."""
    a, servidor = cliente(tmp_path)
    capturada: list = []
    a.transporte = lambda sol: capturada.append(servidor(sol)) or capturada[-1]  # type: ignore[assignment]
    a.consultar(R1)
    a.registrar_reserva(R1, {"experimento": "E", "semilla": 1, "archivos_sha256": {"x": "0" * 64}})
    a.registrar_inicio_calculo(R1, 1)
    a.transporte = lambda sol: capturada[0]  # type: ignore[assignment]
    with pytest.raises(U.AnclaNoAutentica, match="desafío"):
        a.consultar(R1)


def test_clave_fijada_distinta(tmp_path: Path) -> None:
    s = ServidorAnclaDePrueba(tmp_path / "a.jsonl", F.SEMILLA_ANCLA, "PRUEBA-ANCLA", modulo=U)
    a = U.AnclaFirmada(s, C.clave_publica(F.SEMILLA_INTRUSA).hex(), "PRUEBA-ANCLA")
    with pytest.raises(U.AnclaNoAutentica):
        a.consultar(R1)


def test_recibo_de_otra_reserva(tmp_path: Path) -> None:
    a, _ = cliente(tmp_path, manipulacion="recibo_de_otra_reserva")
    a.registrar_reserva(R1, {"experimento": "E", "semilla": 1, "archivos_sha256": {"x": "0" * 64}})
    a.registrar_inicio_calculo(R1, 1)
    with pytest.raises(U.AnclaNoAutentica, match="recibo"):
        a.registrar_presellado(R1, "a" * 64)


def test_identidad_incluye_la_huella_de_la_clave(tmp_path: Path) -> None:
    a, s = cliente(tmp_path)
    assert a.identidad == f"firmada:PRUEBA-ANCLA:{C.huella_clave(s.publica)}"


def test_extremo_a_extremo_con_recibo(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    s = correr(e, "firmada")
    assert s["estado"] == "REGISTRADO" and s["recibo_ancla"] is not None and llamadas(e) == 1
    recibo = json.loads((Path(e["dir"]) / U.RECIBO).read_text(encoding="utf-8"))
    assert recibo == s["recibo_ancla"]
    contenido, _ = C.verificar_declaracion(recibo, F.RAICES_PRUEBA)
    assert contenido["artefactos"][0]["sha256"] == s["resultado_sha256"]
    assert contenido["contexto"]["reserva_sha256"] == s["reserva_sha256"]
    (Path(e["dir"]) / U.RECIBO).unlink()  # recibo perdido: se recupera del ancla, sin recalcular
    s2 = correr(e, "firmada")
    assert (s2["estado"], s2["calculado"]) == ("REGISTRADO", False) and (Path(e["dir"]) / U.RECIBO).exists()
    assert llamadas(e) == 1


@pytest.mark.parametrize("manipulacion", ["repetir", "otra_clave", "caida"])
def test_extremo_a_extremo_sin_respuesta_autentica_nada_avanza(tmp_path: Path, manipulacion: str) -> None:
    e = preparar(tmp_path, "det")
    s = correr(e, "firmada", firmada_extra={"manipulacion": manipulacion})
    esperado = "ANCLA_NO_DISPONIBLE" if manipulacion == "caida" else "ANCLA_NO_AUTENTICA"
    assert s["estado"] == esperado and llamadas(e) == 0 and not (Path(e["dir"]) / U.DIARIO).exists()
