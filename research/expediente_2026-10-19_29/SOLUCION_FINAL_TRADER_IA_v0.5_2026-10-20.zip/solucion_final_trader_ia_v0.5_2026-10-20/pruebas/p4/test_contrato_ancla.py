"""CONTRATO de la interfaz de ancla (DISENO_ANCLA_EXTERNA.md §3). Toda implementación debe pasarlo: hoy, AnclaArchivo
(local) y el cliente AnclaFirmada contra el DOBLE DE PRUEBA del servicio. Un ancla externa real tendrá que pasar
exactamente estas pruebas (con su propia fábrica) antes de usarse. Claves y datos sintéticos."""
from __future__ import annotations

import multiprocessing as mp
from pathlib import Path

import fabricas_t as F
import pytest
import version
from ancla_de_prueba import ServidorAnclaDePrueba
from version import desde_v04

pytestmark = desde_v04
U = version.p4()
C = F.C
R1, R2 = "1" * 64, "2" * 64
RES_A, RES_B = "a" * 64, "b" * 64


def reserva(experimento: str = "EXP", entradas: str = "x") -> dict:
    return {"experimento": experimento, "semilla": 7, "archivos_sha256": {"datos": entradas * 64}}


def fabrica(tipo: str, ruta: Path, **kw):  # type: ignore[no-untyped-def]
    if tipo == "archivo":
        return U.AnclaArchivo(ruta)
    servidor = ServidorAnclaDePrueba(ruta, F.SEMILLA_ANCLA, "PRUEBA-ANCLA", modulo=U, **kw)
    return U.AnclaFirmada(servidor, servidor.publica, "PRUEBA-ANCLA")


@pytest.fixture(params=["archivo", "firmada"])
def tipo(request) -> str:  # type: ignore[no-untyped-def]
    return request.param


def test_C1_reserva_desconocida(tmp_path: Path, tipo: str) -> None:
    st = fabrica(tipo, tmp_path / "a.jsonl").consultar(R1)
    assert (st["reserva"], st["iniciados"], st["presellado"], st["recibo"]) == (False, 0, None, None)


def test_C2_reserva_idempotente_y_conflictos(tmp_path: Path, tipo: str) -> None:
    a = fabrica(tipo, tmp_path / "a.jsonl")
    a.registrar_reserva(R1, reserva())
    a.registrar_reserva(R1, reserva())  # idempotente
    assert a.consultar(R1)["reserva"] is True
    with pytest.raises(U.AnclaConflicto):
        a.registrar_reserva(R2, reserva(entradas="y"))  # mismo experimento, otra reserva
    with pytest.raises(U.AnclaConflicto):
        a.registrar_reserva(R2, reserva(experimento="OTRO"))  # mismas entradas, otra reserva


def test_C3_inicio_con_comparacion_y_escritura(tmp_path: Path, tipo: str) -> None:
    a = fabrica(tipo, tmp_path / "a.jsonl")
    with pytest.raises(U.AnclaConflicto):
        a.registrar_inicio_calculo(R1, 1)  # sin reserva
    a.registrar_reserva(R1, reserva())
    with pytest.raises(U.AnclaConflicto):
        a.registrar_inicio_calculo(R1, 2)  # salto
    a.registrar_inicio_calculo(R1, 1)
    with pytest.raises(U.AnclaConflicto):
        a.registrar_inicio_calculo(R1, 1)  # repetido: otro proceso ya lo inició
    a.registrar_inicio_calculo(R1, 2)
    assert a.consultar(R1)["iniciados"] == 2


def test_C4_presellado_de_escritura_unica(tmp_path: Path, tipo: str) -> None:
    a = fabrica(tipo, tmp_path / "a.jsonl")
    with pytest.raises(U.AnclaConflicto):
        a.registrar_presellado(R1, RES_A)  # sin reserva
    a.registrar_reserva(R1, reserva())
    a.registrar_inicio_calculo(R1, 1)
    recibo = a.registrar_presellado(R1, RES_A)
    assert a.registrar_presellado(R1, RES_A) == recibo or tipo == "firmada"  # idempotente
    with pytest.raises(U.AnclaConflicto):
        a.registrar_presellado(R1, RES_B)
    with pytest.raises(U.AnclaConflicto):
        a.registrar_inicio_calculo(R1, 2)  # no hay inicios después de un presellado
    assert a.consultar(R1)["presellado"] == RES_A


def test_C5_persistencia_entre_instancias(tmp_path: Path, tipo: str) -> None:
    fabrica(tipo, tmp_path / "a.jsonl").registrar_reserva(R1, reserva())
    b = fabrica(tipo, tmp_path / "a.jsonl")
    b.registrar_inicio_calculo(R1, 1)
    assert fabrica(tipo, tmp_path / "a.jsonl").consultar(R1)["iniciados"] == 1


def _carrera(tipo: str, ruta: str, barrera, cola) -> None:  # type: ignore[no-untyped-def]  # proceso aparte
    a = fabrica(tipo, Path(ruta))
    barrera.wait()
    try:
        a.registrar_inicio_calculo(R1, 1)
        cola.put("GANA")
    except U.AnclaConflicto:
        cola.put("PIERDE")


def test_C6_carrera_de_inicios_entre_procesos(tmp_path: Path, tipo: str) -> None:
    """8 procesos (fork) esperan en una barrera heredada y piden a la vez el inicio 1: gana exactamente uno."""
    ruta = tmp_path / "a.jsonl"
    fabrica(tipo, ruta).registrar_reserva(R1, reserva())
    ctx = mp.get_context("fork")
    barrera, cola = ctx.Barrier(8), ctx.Queue()
    procesos = [ctx.Process(target=_carrera, args=(tipo, str(ruta), barrera, cola)) for _ in range(8)]
    for p in procesos:
        p.start()
    resultados = sorted(cola.get(timeout=120) for _ in procesos)
    for p in procesos:
        p.join(120)
    assert resultados == ["GANA"] + ["PIERDE"] * 7
    assert fabrica(tipo, ruta).consultar(R1)["iniciados"] == 1


def test_C7_indisponibilidad(tmp_path: Path, tipo: str) -> None:
    if tipo == "archivo":
        (tmp_path / "no_dir").write_text("x", encoding="utf-8")
        a = fabrica(tipo, tmp_path / "no_dir" / "a.jsonl")
    else:
        a = fabrica(tipo, tmp_path / "a.jsonl", manipulacion="caida")
    for op in (lambda: a.consultar(R1), lambda: a.registrar_reserva(R1, reserva()),
               lambda: a.registrar_inicio_calculo(R1, 1), lambda: a.registrar_presellado(R1, RES_A)):
        with pytest.raises(U.AnclaNoDisponible):
            op()


def test_C8_recibos(tmp_path: Path, tipo: str) -> None:
    a = fabrica(tipo, tmp_path / "a.jsonl")
    a.registrar_reserva(R1, reserva())
    a.registrar_inicio_calculo(R1, 1)
    recibo = a.registrar_presellado(R1, RES_A)
    if tipo == "archivo":
        assert recibo is None and a.emite_recibos is False
        return
    contenido, raiz = C.verificar_declaracion(recibo, F.RAICES_PRUEBA)  # verificable con la raíz del ancla
    assert raiz["tipo"] == "ancla" and contenido["contexto"]["reserva_sha256"] == R1
    assert [x["sha256"] for x in contenido["artefactos"]] == [RES_A]
    assert a.consultar(R1)["recibo"] == recibo
