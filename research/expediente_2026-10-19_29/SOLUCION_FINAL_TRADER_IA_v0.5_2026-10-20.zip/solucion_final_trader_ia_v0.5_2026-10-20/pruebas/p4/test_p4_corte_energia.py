"""P4 v0.5: CORTE DE ENERGÍA simulado (comun/fallos_es.OSConCorte) justo después de CADA operación de E/S de una
ejecución limpia (write, fsync, link, replace, ftruncate), con tres modelos de pérdida:
  (perder, deshacer)   se pierde lo escrito sin fsync y se deshacen las entradas de directorio sin fsync del directorio;
  (mitad, deshacer)    escritura desgarrada: sobrevive la mitad de lo no sincronizado;
  (perder, conservar)  se pierde lo no sincronizado pero las entradas de directorio sobreviven.
Además, un corte DESPUÉS de que la ejecución haya informado su salida («fin»). Después, ejecuciones normales (como
máximo 4) hasta un estado final. Invariantes: los del comprobador INDEPENDIENTE (comun/invariantes_p4.py), un estado
final explícito (REGISTRADO o REVISION_HUMANA; con código no determinista, también CONFLICTO) y DURABILIDAD de lo
informado: si una ejecución informó REGISTRADO antes del corte, el estado final es REGISTRADO con el mismo hash. Ancla local (en el mismo disco: también pierde lo no sincronizado). Registra cada escenario en
$EVIDENCIA_P4_CORTE (JSON) si está definida."""
from __future__ import annotations

import json
import os
from pathlib import Path

import fallos_es
import invariantes_p4 as I
import pytest
import version
from sincro import correr, llamadas, preparar
from version import desde_v05

pytestmark = desde_v05
U = version.p4()
VARIANTES = [("perder", "deshacer"), ("mitad", "deshacer"), ("perder", "conservar")]
FINALES = {"det": {"REGISTRADO", "REVISION_HUMANA"}, "nodet": {"REGISTRADO", "REVISION_HUMANA", "CONFLICTO"}}


def _operaciones(tmp: Path, codigo: str) -> list[tuple[str, int]]:
    e = preparar(tmp / "conteo", codigo)
    s = correr(e, "archivo", corte="CONTAR")
    assert s["estado"] == "REGISTRADO", s
    return [(op, n) for op in fallos_es.OSConCorte.OPERACIONES for n in range(1, s["conteo_es"][op] + 1)] + [("fin", 0)]


@pytest.mark.parametrize("codigo", ["det", "nodet"])
def test_corte_de_energia_tras_cada_operacion(tmp_path: Path, codigo: str) -> None:
    operaciones = _operaciones(tmp_path, codigo)
    assert len(operaciones) >= 20
    registro, malos = [], []
    for i, (op, n) in enumerate(operaciones):
        for datos, directorio in VARIANTES:
            e = preparar(tmp_path / f"e{i}_{datos[0]}{directorio[0]}", codigo)
            plan = {"op": op, "n": n, "datos": datos, "directorio": directorio,
                    "directorios": [e["dir"], str(Path(e["ancla"]).parent)]}
            s0 = correr(e, "archivo", corte=plan)
            informado = None
            if op == "fin":  # el proceso informó su salida y después se cortó la energía
                informado = s0.get("salida_informada")
                s0 = {"estado": "MURIO(137)"} if informado is not None else s0
            salidas = [s0 | {"muerte_provocada": s0["estado"] == "MURIO(137)"}]
            while len(salidas) < 5 and salidas[-1]["estado"] not in ("REGISTRADO", *U.ERRORES_TERMINALES):
                salidas.append(correr(e, "archivo"))
            v = I.violaciones(Path(e["dir"]), Path(e["ancla"]), salidas, llamadas(e))
            if s0["estado"] != "MURIO(137)":
                v.append(f"el corte no ocurrió: {s0['estado']}")
            if salidas[-1]["estado"] not in FINALES[codigo]:
                v.append(f"estado final {salidas[-1]['estado']}")
            if op == "fin" and informado is None:
                v.append("la ejecución no informó su salida antes del corte")
            if informado and informado["estado"] == "REGISTRADO" and (
                    salidas[-1]["estado"], salidas[-1].get("resultado_sha256")) != ("REGISTRADO", informado["resultado_sha256"]):
                v.append(f"lo informado como REGISTRADO no sobrevivió al corte: {salidas[-1]['estado']}")
            registro.append({"op": op, "n": n, "datos": datos, "directorio": directorio,
                             "salidas": [s["estado"] for s in salidas], "calculos": llamadas(e), "violaciones": v})
            if v:
                malos.append(registro[-1])
    destino = os.environ.get("EVIDENCIA_P4_CORTE")
    if destino:
        Path(destino).with_name(f"{Path(destino).stem}_{version.VERSION}_{codigo}.json").write_text(
            json.dumps(registro, ensure_ascii=False, indent=1), encoding="utf-8")
    assert not malos, f"{len(malos)} de {len(registro)} escenarios violan invariantes: {malos[:4]}"
