"""Defectos de P4. LAS MISMAS pruebas contra v0.2, v0.3 y v0.4 (VERSION_BAJO_PRUEBA); todo corre en procesos hijo
(conductor) con el módulo de la versión bajo prueba:
- P4_S1…S5: corregidos en v0.3 (deben fallar en v0.2 y pasar en v0.3 y v0.4).
- P4_N1…N4: encontrados en esta ronda, corregidos en v0.4 (deben fallar en v0.3 y pasar en v0.4).
Sincronización DETERMINISTA (pausas por FIFO), caídas reales (os._exit), fallos de escritura inyectados en el módulo
bajo prueba. Datos y códigos sintéticos."""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

import version
from sincro import Hijo, correr, llamadas, preparar

U = version.p4()


def diario_primera_linea(e: dict) -> bytes:
    return (Path(e["dir"]) / U.DIARIO).read_bytes().split(b"\n")[0]


# ---------- S1: un solo cálculo por reserva, también entre directorios ----------
def test_P4_S1_dos_directorios_misma_reserva_intercalados(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    a = Hijo(e, "archivo", pausa="tras_reservar")
    a.esperar_pausa()  # A ya concilió con el ancla (0 inicios)
    b = Hijo(e | {"dir": str(tmp_path / "estado_b")}, "archivo", pausa="tras_iniciar_calculo")
    b.esperar_pausa()  # B registró el inicio 1 en el ancla
    a.seguir()
    sa = a.fin()
    b.seguir()
    sb = b.fin()
    assert sa["estado"] == "INCONSISTENTE" and "inicio 1 rechazado" in sa["detalle"]
    assert sb["estado"] == "REGISTRADO" and llamadas(e) == 1


def test_P4_S1_concurrencia_determinista_mismo_directorio(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    a = Hijo(e, "archivo", pausa="tras_iniciar_calculo")
    a.esperar_pausa()
    otros = [Hijo(e, "archivo") for _ in range(6)]
    assert {o.fin()["estado"] for o in otros} == {"OCUPADO"}
    a.seguir()
    assert a.fin()["estado"] == "REGISTRADO" and llamadas(e) == 1
    assert correr(e, "archivo")["calculado"] is False


# ---------- S2: el ancla no se repara en silencio ----------
def test_P4_S2_ancla_perdida_es_inconsistente(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    assert correr(e, "archivo")["estado"] == "REGISTRADO"
    shutil.rmtree(Path(e["ancla"]).parent)
    s = correr(e, "archivo")
    assert (s["estado"], s["resultado"]) == ("INCONSISTENTE", None) and "no se repara" in s["detalle"]


def test_P4_S2_ancla_antigua_con_menos_inicios(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    Hijo(e, "archivo", punto="tras_reservar", reintentos=1).fin()
    vieja = tmp_path / "ancla_vieja"
    shutil.copytree(Path(e["ancla"]).parent, vieja)
    Hijo(e, "archivo", punto="durante_calculo", reintentos=1).fin()
    shutil.rmtree(Path(e["ancla"]).parent)
    shutil.copytree(vieja, Path(e["ancla"]).parent)
    s = correr(e, "archivo", reintentos=1)
    assert s["estado"] == "INCONSISTENTE" and "perdió registros" in s["detalle"]


# ---------- S3: el ejecutor está ligado a la reserva ----------
def test_P4_S3_ejecutor_modificado_se_rechaza(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    Hijo(e, punto="tras_reservar").fin()
    copia = tmp_path / "ejecutor_modificado"
    copia.mkdir()
    for f in version.DIR_P4.glob("*.py"):
        shutil.copy(f, copia / f.name)
    m = copia / "uso_unico.py"
    m.write_text(m.read_text(encoding="utf-8").replace(
        'res = ns[e["punto_entrada"]](contenidos, e["semilla"])',
        'res = ns[e["punto_entrada"]](contenidos, e["semilla"]); res["inyectado"] = 1'), encoding="utf-8")
    s = correr(e, modulo=m)
    assert s["estado"] == "RECHAZADO" and llamadas(e) == 0


# ---------- S4: el cálculo no hereda entorno ni directorio ----------
def test_P4_S4_el_calculo_no_hereda_entorno_ni_directorio(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    e = preparar(tmp_path, "entorno")
    monkeypatch.setenv("SECRETO_DE_PRUEBA", "valor-secreto")
    s = correr(e)
    assert s["estado"] == "REGISTRADO" and s["resultado"]["secreto"] is None
    assert Path(s["resultado"]["directorio"]).name.startswith("calculo_") and s["resultado"]["variables"] <= 2


# ---------- S5: determinismo ----------
def test_P4_S5_no_determinista_se_detecta_antes_de_presellar(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    s = correr(e, "archivo", verificar_determinismo=True)
    assert (s["estado"], s["resultado"]) == ("NO_DETERMINISTA", None) and llamadas(e) == 2
    assert not (Path(e["dir"]) / U.RESULTADO).exists() and U.leer(e["dir"])["presellado"] is None


# ---------- N1: escritura corta (v0.3 ignoraba los bytes escritos y seguía con el diario partido) ----------
def test_P4_N1_escritura_corta_del_diario(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    s = correr(e, "archivo", fallos_es={"op": "write", "contiene": "CALCULO_INICIADO", "n": 1, "modo": "CORTA"})
    assert s["estado"] == "REGISTRADO" and s.get("inyectado") is True
    assert U.leer(e["dir"])["estado"] == "REGISTRADO"  # el diario quedó legible y completo
    s2 = correr(e, "archivo")
    assert (s2["estado"], s2["calculado"]) == ("REGISTRADO", False) and llamadas(e) == 1


# ---------- N2: disco lleno o error de E/S → salida explícita y recuperable (v0.3: excepción sin salida) ----------
def test_P4_N2_disco_lleno_antes_de_iniciar_el_calculo(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    s = correr(e, fallos_es={"op": "write", "contiene": "CALCULO_INICIADO", "n": 1, "modo": "ENOSPC"})
    assert s["estado"] == "FALLO_ALMACENAMIENTO" and s["reserva_sha256"] and llamadas(e) == 0
    s2 = correr(e)
    assert s2["estado"] == "REGISTRADO" and s2["reserva_sha256"] == s["reserva_sha256"] and llamadas(e) == 1


def test_P4_N2_disco_lleno_al_presellar_va_a_revision_humana(tmp_path: Path) -> None:
    e = preparar(tmp_path, "nodet")
    s = correr(e, "archivo", fallos_es={"op": "write", "contiene": "PRESELLADO", "n": 1, "modo": "CORTA_ENOSPC"})
    assert s["estado"] == "FALLO_ALMACENAMIENTO" and llamadas(e) == 1
    s2 = correr(e, "archivo")
    assert s2["estado"] == "REVISION_HUMANA" and llamadas(e) == 1  # pudo observarse: no se recalcula
    assert not (Path(e["dir"]) / U.RESULTADO).exists()


# ---------- N3: un error de E/S del ancla local no deja escapar una excepción ni crea estado ----------
def test_P4_N3_ancla_local_inaccesible(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    Path(e["ancla"]).parent.write_text("no es un directorio", encoding="utf-8")
    s = correr(e, "archivo")
    assert s["estado"] == "ANCLA_NO_DISPONIBLE" and llamadas(e) == 0
    assert not (Path(e["dir"]) / U.DIARIO).exists()


# ---------- N4: una entrada ilegible se rechaza sin tocar el estado ----------
def test_P4_N4_entrada_ilegible(tmp_path: Path) -> None:
    e = preparar(tmp_path, "det")
    os.remove(e["archivos"]["datos"])
    s = correr(e, "archivo")
    assert s["estado"] == "RECHAZADO" and "ilegible" in s["detalle"]
    assert not (Path(e["dir"]) / U.DIARIO).exists() and not Path(e["ancla"]).exists()


def test_P4_control_recuperacion_conserva_la_reserva(tmp_path: Path) -> None:
    for punto in ("tras_reservar", "tras_presellado", "tras_archivo"):
        e = preparar(tmp_path / punto, "det")
        Hijo(e, "archivo", punto=punto).fin()
        primera = diario_primera_linea(e)
        s = correr(e, "archivo")
        assert s["estado"] == "REGISTRADO" and diario_primera_linea(e) == primera
        assert s["reserva_sha256"] == U._sha(U._canon(json.loads(primera)["datos"]))
