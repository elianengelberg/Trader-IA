"""Defectos de P4 encontrados en la revisión adversarial de v0.4 (F*), corregidos en v0.5. LAS MISMAS pruebas contra
v0.4 (deben FALLAR: el defecto existe) y v0.5 (deben PASAR); en v0.2 y v0.3 no se exige nada (la matriz lo marca «*»).
Datos y códigos sintéticos; anclas de archivo locales o el cliente firmado contra transportes de prueba."""
from __future__ import annotations

import hashlib
import json
import shutil
import time
from pathlib import Path

import fabricas_t as F
import pytest
import version
from sincro import Hijo, correr, llamadas, preparar

U = version.p4()
C = version.confianza()
NEUTRO = "01" + "00" * 31          # punto neutro: con él, la firma (R = neutro, s = 0) vale para cualquier mensaje
CEROS = "00" * 32                  # y = 0: punto de orden 4 (la firma trivial vale para 1 de cada 8 mensajes)


def _respuesta_falsificada(sol: dict) -> dict:
    contenido = {"formato": "trader-ia/ancla/respuesta/v1", "emisor": "X", "op": sol["op"],
                 "reserva_sha256": sol["reserva_sha256"], "desafio": sol["desafio"], "resultado": "ACEPTADO",
                 "motivo": "", "estado": {"reserva": True, "iniciados": 0, "presellado": None}, "recibo": None}
    return {"contenido": contenido, "firma_ed25519": (bytes.fromhex(NEUTRO) + bytes(32)).hex()}


# ---------- F1: clave fijada de orden pequeño ----------
@pytest.mark.parametrize("clave", [NEUTRO, CEROS])
def test_P4_F1_ancla_firmada_no_acepta_clave_de_orden_pequeno(clave: str) -> None:
    """Un intermediario SIN ninguna clave privada no debe conseguir que el cliente acepte una respuesta."""
    try:
        a = U.AnclaFirmada(_respuesta_falsificada, clave, "X")
    except ValueError:
        return  # v0.5: la clave se rechaza al construir el cliente
    aceptadas = 0
    for i in range(128):  # con CEROS la falsificación vale 1 de cada 8 desafíos: P(0 de 128) ≈ 4e-8
        try:
            a.consultar(f"{i:064x}")
            aceptadas += 1
        except U.AnclaNoDisponible:
            pass
    assert aceptadas == 0, f"{aceptadas} respuestas falsificadas aceptadas"


# ---------- F6: una respuesta hostil del ancla no hace escapar una excepción ----------
def _anidado(n: int) -> dict:
    raiz = x = {}
    for _ in range(n):
        x["a"] = {}
        x = x["a"]
    return raiz


@pytest.mark.parametrize("forma", ["sustituto_suelto", "anidamiento_extremo"])
def test_P4_F6_respuesta_hostil_del_ancla_da_una_salida(tmp_path: Path, forma: str) -> None:
    def transporte(_sol: dict) -> object:
        if forma == "sustituto_suelto":
            return json.loads('{"contenido": {"x": "\\ud800"}, "firma_ed25519": "' + "0" * 128 + '"}')
        return {"contenido": _anidado(20000), "firma_ed25519": "0" * 128}

    e = preparar(tmp_path)
    a = U.AnclaFirmada(transporte, C.clave_publica(F.SEMILLA_ANCLA).hex(), "PRUEBA-ANCLA")
    s = U.ejecutar(e["dir"], e["experimento"], e["archivos"], e["semilla"], ancla=a)
    assert s.estado == "ANCLA_NO_AUTENTICA" and llamadas(e) == 0


# ---------- F7: eventos encadenados pero mal formados (diario local y ancla local) ----------
def _reencadenar(eventos: list[dict]) -> bytes:
    lineas, anterior = [], None
    for i, ev in enumerate(eventos):
        b = json.dumps(dict(ev, n=i, anterior=anterior), ensure_ascii=False, sort_keys=True,
                       separators=(",", ":")).encode()
        lineas.append(b)
        anterior = hashlib.sha256(b).hexdigest()
    return b"\n".join(lineas) + b"\n"


ALTERACIONES = {
    "diario_presellado_sin_hash": ("diario", lambda ev: [dict(e, datos={}) if e["evento"] == "PRESELLADO" else e
                                                         for e in ev]),
    "diario_datos_no_objeto": ("diario", lambda ev: ev[:1] + [dict(e, datos=[1]) for e in ev[1:]]),
    "diario_sin_evento": ("diario", lambda ev: ev[:1] + [{k: v for k, v in e.items() if k != "evento"} for e in ev[1:]]),
    "ancla_presellado_sin_hash": ("ancla", lambda ev: [
        dict(e, datos={"reserva_sha256": e["datos"]["reserva_sha256"]}) if e["evento"] == "PRESELLADO" else e
        for e in ev]),
    "ancla_datos_no_objeto": ("ancla", lambda ev: [dict(e, datos="x") for e in ev]),
}


@pytest.mark.parametrize("caso", sorted(ALTERACIONES))
def test_P4_F7_eventos_mal_formados_dan_un_estado_terminal(tmp_path: Path, caso: str) -> None:
    e = preparar(tmp_path)
    ancla = U.AnclaArchivo(e["ancla"])
    assert U.ejecutar(e["dir"], e["experimento"], e["archivos"], e["semilla"], ancla=ancla).estado == "REGISTRADO"
    donde, f = ALTERACIONES[caso]
    ruta = Path(e["dir"]) / U.DIARIO if donde == "diario" else Path(e["ancla"])
    ruta.write_bytes(_reencadenar(f([json.loads(x) for x in ruta.read_bytes().splitlines()])))
    s = U.ejecutar(e["dir"], e["experimento"], e["archivos"], e["semilla"], ancla=U.AnclaArchivo(e["ancla"]))
    assert s.estado in U.ERRORES_TERMINALES and s.resultado is None and llamadas(e) == 1


# ---------- F8: un cálculo colgado se puede acotar ----------
def test_P4_F8_limite_de_tiempo_del_calculo(tmp_path: Path) -> None:
    e = preparar(tmp_path, "colgado")
    t0 = time.monotonic()
    s = correr(e, "archivo", limite_segundos=2)
    assert s["estado"] == "FALLO_CALCULO" and "límite de tiempo" in s["detalle"], s
    assert time.monotonic() - t0 < 30 and llamadas(e) == 1
    assert correr(e, "archivo", limite_segundos=2)["estado"] == "REVISION_HUMANA"  # el inicio constaba: no se repite
    assert llamadas(e) == 1


# ---------- F10: el directorio de trabajo del cálculo no queda huérfano si el padre muere ----------
def test_P4_F10_sin_directorio_huerfano_si_el_padre_muere(tmp_path: Path) -> None:
    e = preparar(tmp_path, "lento")
    tmp = tmp_path / "tmp_calculo"
    tmp.mkdir()
    s = Hijo(e, "archivo", punto="durante_calculo", entorno={"TMPDIR": str(tmp)}).fin()
    assert s["estado"].startswith("MURIO")
    fin = time.monotonic() + 20
    while list(tmp.glob("calculo_*")) and time.monotonic() < fin:  # el hijo termina ~1,5 s después del padre
        time.sleep(0.2)
    assert list(tmp.glob("calculo_*")) == []


# ---------- F14: argumentos que darían una reserva inutilizable se rechazan antes de tocar nada ----------
@pytest.mark.parametrize("cambio", [{"semilla": True}, {"semilla": 1.5}, {"semilla": "7"}, {"experimento": ""},
                                    {"punto_entrada": "no-valido"}, {"archivos": {"codigo": 5}}])
def test_P4_F14_argumentos_invalidos(tmp_path: Path, cambio: dict) -> None:
    e = preparar(tmp_path)
    args = {"experimento": e["experimento"], "archivos": e["archivos"], "semilla": e["semilla"]} | cambio
    with pytest.raises(ValueError):
        U.ejecutar(e["dir"], **args)
    assert not Path(e["dir"]).exists() and llamadas(e) == 0
    shutil.rmtree(tmp_path / "entradas_e")
