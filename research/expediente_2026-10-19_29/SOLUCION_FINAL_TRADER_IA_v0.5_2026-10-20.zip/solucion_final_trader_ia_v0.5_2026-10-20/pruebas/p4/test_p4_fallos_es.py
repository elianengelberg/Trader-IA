"""Inyección SISTEMÁTICA de fallos de escritura en P4 (con el ancla local): se cuentan las llamadas write, fsync,
replace, link y ftruncate de una ejecución limpia y, para CADA una y cada modo (ENOSPC, EIO, escritura corta, escritura
corta seguida de ENOSPC), se ejecuta con esa llamada fallando y después se recupera con ejecuciones normales.
Invariantes comprobados en cada escenario (código determinista y no determinista, reintentos_tras_inicio = 0):
  I1 ninguna ejecución termina sin salida (sin rastro de excepción);
  I2 el estado final es explícito: REGISTRADO o REVISION_HUMANA (y CONFLICTO con código no determinista);
  I3 el ancla nunca registra más de un inicio de cálculo;
  I4 nunca hay dos presellados distintos (ancla y diario coinciden);
  I5 si hay resultado en disco, coincide con el presellado del ancla y del diario;
  I6 los cálculos ejecutados no superan 1 + los recálculos de verificación registrados;
  I7 REVISION_HUMANA solo si un cálculo se inició sin presellado.
Con VERSION_BAJO_PRUEBA = v0_3 la misma prueba muestra las violaciones de esa versión. Registra cada escenario en
$EVIDENCIA_P4_FALLOS (JSON) si la variable está definida."""
from __future__ import annotations

import json
import os
from pathlib import Path

import fallos_es
import pytest
import version
from sincro import correr, llamadas, preparar

U = version.p4()
FINALES = {"det": {"REGISTRADO", "REVISION_HUMANA"}, "nodet": {"REGISTRADO", "REVISION_HUMANA", "CONFLICTO"}}


def _escenarios(tmp: Path, codigo: str) -> list[dict]:
    e = preparar(tmp / "conteo", codigo)
    s = correr(e, "archivo", fallos_es="CONTAR")
    assert s["estado"] == "REGISTRADO", s
    return [{"op": op, "n": n, "modo": modo} for op in fallos_es.OPERACIONES for n in range(1, s["conteo_es"][op] + 1)
            for modo in fallos_es.MODOS[op]]


def _violaciones(e: dict, salidas: list[dict]) -> list[str]:
    v = []
    if any(s["estado"].startswith("MURIO") for s in salidas):
        v.append("I1: una ejecución terminó sin salida: " + next(s.get("stderr", "") for s in salidas
                                                                 if s["estado"].startswith("MURIO"))[-200:])
        return v
    final = salidas[-1]["estado"]
    codigo = "nodet" if "nodet" in Path(e["archivos"]["codigo"]).read_text() or "urandom" in Path(
        e["archivos"]["codigo"]).read_text() else "det"
    if final not in FINALES[codigo]:
        v.append(f"I2: estado final {final}")
    reserva = next((s["reserva_sha256"] for s in salidas if s.get("reserva_sha256")), None)
    st = U.AnclaArchivo(e["ancla"]).consultar(reserva) if reserva and Path(e["ancla"]).exists() else {
        "iniciados": 0, "presellado": None}
    if st["iniciados"] > 1:
        v.append(f"I3: el ancla registra {st['iniciados']} inicios")
    local = U.leer(e["dir"]) if (Path(e["dir"]) / U.DIARIO).exists() else {"presellado": None, "eventos": []}
    if local.get("estado") == "INCONSISTENTE":
        v.append(f"I2: diario local INCONSISTENTE: {local.get('detalle')}")
        return v
    if st["presellado"] and local["presellado"] and st["presellado"] != local["presellado"]:
        v.append("I4: presellados distintos en el ancla y el diario")
    archivo = Path(e["dir"]) / U.RESULTADO
    if archivo.exists():
        sha = U._sha(archivo.read_bytes())
        if sha != st["presellado"] or sha != local["presellado"]:
            v.append("I5: resultado en disco distinto del presellado")
    if llamadas(e) > 1 + local["eventos"].count("RECALCULO_DE_VERIFICACION"):
        v.append(f"I6: {llamadas(e)} cálculos")
    if final == "REVISION_HUMANA" and not (st["iniciados"] >= 1 and st["presellado"] is None):
        v.append("I7: REVISION_HUMANA sin un inicio de cálculo sin presellado")
    return v


@pytest.mark.parametrize("codigo", ["det", "nodet"])
def test_fallos_de_escritura_sistematicos(tmp_path: Path, codigo: str) -> None:
    escenarios = _escenarios(tmp_path, codigo)
    assert len(escenarios) >= 40
    registro, malos = [], []
    for i, plan in enumerate(escenarios):
        e = preparar(tmp_path / f"esc{i}", codigo)
        salidas = [correr(e, "archivo", fallos_es=plan)]
        while len(salidas) < 4 and salidas[-1]["estado"] not in ("REGISTRADO", *U.ERRORES_TERMINALES) and \
                not salidas[-1]["estado"].startswith("MURIO"):
            salidas.append(correr(e, "archivo"))
        violaciones = _violaciones(e, salidas)
        registro.append({"plan": plan, "inyectado": salidas[0].get("inyectado"), "salidas": [s["estado"] for s in salidas],
                         "calculos": llamadas(e), "violaciones": violaciones})
        if violaciones:
            malos.append((plan, [s["estado"] for s in salidas], violaciones))
    destino = os.environ.get("EVIDENCIA_P4_FALLOS")
    if destino:
        Path(destino).with_name(f"{Path(destino).stem}_{version.VERSION}_{codigo}.json").write_text(
            json.dumps(registro, ensure_ascii=False, indent=1), encoding="utf-8")
    assert all(r["inyectado"] for r in registro)  # cada escenario inyectó su fallo
    assert not malos, f"{len(malos)} de {len(escenarios)} escenarios violan invariantes: {malos[:5]}"
