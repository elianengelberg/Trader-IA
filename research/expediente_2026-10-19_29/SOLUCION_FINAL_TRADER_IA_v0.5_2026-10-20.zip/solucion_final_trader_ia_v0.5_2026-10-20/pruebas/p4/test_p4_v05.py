"""P4 v0.5: reservas de REPRODUCCIÓN en el ancla (local y firmada), ``leer`` con la reserva, límite de tiempo como
parte de la reserva y con la verificación de determinismo, y MUTACIONES ALEATORIAS del diario y del ancla (semilla fija)
comprobadas con un verificador de invariantes INDEPENDIENTE (comun/invariantes_p4.py). Datos y códigos sintéticos."""
from __future__ import annotations

import random
from pathlib import Path

import fabricas_t as F
import invariantes_p4 as I
import pytest
import version
from ancla_de_prueba import ServidorAnclaDePrueba
from sincro import correr, llamadas, preparar
from version import desde_v05

pytestmark = desde_v05
U = version.p4()


def _ejecutar(e: dict, ancla, **kw):  # type: ignore[no-untyped-def]
    return U.ejecutar(e["dir"], e["experimento"], e["archivos"], e["semilla"], ancla=ancla, **kw)


@pytest.fixture(params=["archivo", "firmada"])
def ancla(request, tmp_path: Path):  # type: ignore[no-untyped-def]
    if request.param == "archivo":
        return U.AnclaArchivo(tmp_path / "ancla" / "ANCLA.jsonl")
    servidor = ServidorAnclaDePrueba(tmp_path / "ancla_externa" / "A.jsonl", F.SEMILLA_ANCLA, "PRUEBA-ANCLA", modulo=U)
    return U.AnclaFirmada(servidor, servidor.publica, "PRUEBA-ANCLA")


def test_reproduccion_convive_con_su_original(tmp_path: Path, ancla) -> None:  # type: ignore[no-untyped-def]
    e = preparar(tmp_path)
    o = _ejecutar(e, ancla)
    assert o.estado == "REGISTRADO"
    r = _ejecutar(e | {"dir": str(tmp_path / "rep")}, ancla, reproduccion_de=o.resultado_sha256)
    assert (r.estado, r.resultado_sha256) == ("REGISTRADO", o.resultado_sha256) and r.reserva_sha256 != o.reserva_sha256
    assert llamadas(e) == 2  # la reproducción CALCULA de nuevo
    lo, lr = U.leer(e["dir"]), U.leer(tmp_path / "rep")
    assert (lo["reserva_sha256"], lr["reserva_sha256"]) == (o.reserva_sha256, r.reserva_sha256)
    assert lr["reserva"]["reproduccion_de"] == o.resultado_sha256 and lo["reserva"]["reproduccion_de"] is None
    assert {k: v for k, v in lr["reserva"].items() if k != "reproduccion_de"} == {
        k: v for k, v in lo["reserva"].items() if k != "reproduccion_de"}
    if ancla.emite_recibos:
        assert r.recibo_ancla["contenido"]["contexto"]["reserva_sha256"] == r.reserva_sha256
    # la reproducción no sustituye al original: el original sigue igual
    assert _ejecutar(e, ancla).resultado_sha256 == o.resultado_sha256 and llamadas(e) == 2


def test_reproduccion_rechazada_sin_original_presellado_o_de_otro_hash(tmp_path: Path, ancla) -> None:  # type: ignore[no-untyped-def]
    e = preparar(tmp_path)
    falso = "ab" * 32
    # reproducir un hash que el ancla no registró para estas entradas, ANTES del original: se admite (no hay con qué
    # contrastar), pero después el ORIGINAL con las mismas entradas queda rechazado (convive solo con SU original)
    r = _ejecutar(e | {"dir": str(tmp_path / "rep")}, ancla, reproduccion_de=falso)
    assert r.estado == "REGISTRADO"
    o = _ejecutar(e, ancla)
    assert o.estado == "RECHAZADO" and ("mismas entradas" in o.detalle or "ese nombre" in o.detalle)
    e2 = preparar(tmp_path / "b", nombre="b")
    e2 = e2 | {"experimento": "SINTETICO-2"}
    o2 = _ejecutar(e2, ancla)
    assert o2.estado == "REGISTRADO"
    otro = _ejecutar(e2 | {"dir": str(tmp_path / "b" / "rep")}, ancla, reproduccion_de=falso)
    assert otro.estado == "RECHAZADO" and "reproducción solo convive" in otro.detalle


def test_reproduccion_antes_de_que_el_original_preselle_se_rechaza(tmp_path: Path) -> None:
    e = preparar(tmp_path)
    ancla = U.AnclaArchivo(tmp_path / "ancla" / "ANCLA.jsonl")
    s = correr(e, "archivo", punto="tras_iniciar_calculo")  # el original muere con el cálculo iniciado
    assert s["estado"].startswith("MURIO")
    r = _ejecutar(e | {"dir": str(tmp_path / "rep")}, ancla, reproduccion_de="cd" * 32)
    assert r.estado == "RECHAZADO"


def test_limite_de_tiempo_forma_parte_de_la_reserva(tmp_path: Path) -> None:
    e = preparar(tmp_path)
    a = _ejecutar(e, None, limite_segundos=30)
    assert a.estado == "REGISTRADO" and U.leer(e["dir"])["reserva"]["limite_segundos"] == 30
    assert _ejecutar(e, None, limite_segundos=31).estado == "RECHAZADO"  # otra configuración: no se calcula
    assert llamadas(e) == 1


def test_limite_de_tiempo_con_verificacion_de_determinismo(tmp_path: Path) -> None:
    e = preparar(tmp_path, "colgado")
    s = _ejecutar(e, None, limite_segundos=1, verificar_determinismo=True)
    assert s.estado == "FALLO_CALCULO" and llamadas(e) == 1
    e = preparar(tmp_path / "det", "det")
    assert _ejecutar(e, None, limite_segundos=30, verificar_determinismo=True).estado == "REGISTRADO"
    assert llamadas(e) == 2


# ---------- mutaciones aleatorias del estado persistente ----------
def _mutar(rng: random.Random, ruta: Path) -> str:
    if not ruta.exists():
        return "ausente"
    b = ruta.read_bytes()
    lineas = b.split(b"\n")
    op = rng.choice(["truncar", "byte", "borrar_linea", "duplicar_linea", "intercambiar", "basura", "vaciar", "borrar"])
    if op == "truncar":
        ruta.write_bytes(b[: rng.randrange(len(b) + 1)])
    elif op == "byte" and b:
        i = rng.randrange(len(b))
        ruta.write_bytes(b[:i] + bytes([b[i] ^ (1 << rng.randrange(8))]) + b[i + 1:])
    elif op == "borrar_linea" and len(lineas) > 2:
        del lineas[rng.randrange(len(lineas) - 1)]
        ruta.write_bytes(b"\n".join(lineas))
    elif op == "duplicar_linea" and len(lineas) > 1:
        i = rng.randrange(len(lineas) - 1)
        lineas.insert(i, lineas[i])
        ruta.write_bytes(b"\n".join(lineas))
    elif op == "intercambiar" and len(lineas) > 2:
        i, j = rng.sample(range(len(lineas) - 1), 2)
        lineas[i], lineas[j] = lineas[j], lineas[i]
        ruta.write_bytes(b"\n".join(lineas))
    elif op == "basura":
        ruta.write_bytes(b + rng.randbytes(rng.randrange(1, 40)))
    elif op == "vaciar":
        ruta.write_bytes(b"")
    elif op == "borrar":
        ruta.unlink()
    return op


@pytest.mark.parametrize("codigo", ["det", "nodet"])
def test_mutaciones_aleatorias_del_diario_y_del_ancla(tmp_path: Path, codigo: str) -> None:
    rng = random.Random(f"p4-{codigo}")
    resumen: dict[str, int] = {}
    for i in range(60):  # cada caso: una ejecución real (el ancla local se identifica por su ruta) y luego mutaciones
        e = preparar(tmp_path / f"c{i}", codigo)
        assert correr(e, "archivo", punto=rng.choice([None, None, "tras_presellado", "tras_ancla"]))["estado"] in (
            "REGISTRADO", "MURIO(137)")
        ops = [f"{q}:{_mutar(rng, Path(e['dir']) / q if q != 'ANCLA' else Path(e['ancla']))}"
               for q in rng.sample(["DIARIO.jsonl", "ANCLA", "resultado.json"], rng.randint(1, 2))]
        salidas = [correr(e, "archivo") for _ in range(2)]
        v = I.violaciones(Path(e["dir"]), Path(e["ancla"]), salidas, llamadas(e))
        assert not v, (i, ops, [s["estado"] for s in salidas], v)
        for s in salidas:
            resumen[s["estado"]] = resumen.get(s["estado"], 0) + 1
    assert set(resumen) <= I.SALIDAS and "REGISTRADO" in resumen and len(resumen) >= 3, resumen
