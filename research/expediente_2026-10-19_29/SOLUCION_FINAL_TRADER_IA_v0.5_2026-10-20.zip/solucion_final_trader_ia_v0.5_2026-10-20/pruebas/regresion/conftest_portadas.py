"""conftest de las suites portadas: el módulo bajo prueba es el de v0.4 (codigo/verificacion)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "codigo" / "verificacion"))
