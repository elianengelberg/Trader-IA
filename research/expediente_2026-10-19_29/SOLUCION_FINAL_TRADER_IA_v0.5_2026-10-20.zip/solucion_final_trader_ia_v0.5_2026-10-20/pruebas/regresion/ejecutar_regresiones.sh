#!/usr/bin/env bash
# Regresiones contra el código ACTUAL (v0.5) con suites anteriores SIN MODIFICAR (copiadas a directorios temporales
# junto al código actual): las de v0.3 y la suite completa de v0.4. Además, las sondas de v0.2 sobre v0.2. Escribe la
# salida ORIGINAL de pytest en $EVID. No modifica nada fuera de los temporales.
# Variables: PAQ (este paquete), V03 y V04 (carpetas de los paquetes v0.3 y v0.4 preservados), PY, EVID.
set -u
PAQ=${PAQ:?}; V03=${V03:?}; V04=${V04:?}; PY=${PY:?}; EVID=${EVID:?}
mkdir -p "$EVID"
TMPB=$(mktemp -d)
trap 'rm -rf "$TMPB"' EXIT
export PYTHONDONTWRITEBYTECODE=1
COD="$PAQ/codigo/verificacion"

correr() {  # nombre, directorio, [rutas de pytest]
  local nombre=$1 dir=$2; shift 2
  (cd "$dir" && "$PY" -B -m pytest -p no:cacheprovider -q -rfEs "${@:-.}" > "$EVID/$nombre.txt" 2>&1; echo "código de salida de pytest: $?" >> "$EVID/$nombre.txt")
  grep -E "^[0-9]+ (passed|failed)|^=+ .*(passed|failed)" "$EVID/$nombre.txt" | tail -1 | sed "s/^/$nombre: /"
}

# ---- suites de v0.3 sin modificar ----
# P1 (se esperan fallos SOLO por la API renombrada en v0.4; ver 20_*.md) y las portadas a v0.4/v0.5
d="$TMPB/p1_sin_modificar"; mkdir -p "$d"
cp "$V03"/p1/test_verificar_reproduccion_T.py "$V03"/p1/test_v0_2.py "$V03"/p1/test_v0_3.py "$V03"/p1/fabricas.py "$d"/
cp "$COD"/verificar_reproduccion_T.py "$COD"/confianza.py "$d"/
correr 22_regresion_p1_v0_3_sin_modificar_contra_v0_5 "$d"
(cd "$PAQ/pruebas" && "$PY" -B -m pytest -p no:cacheprovider -q -rfEs regresion/p1_v0_3_portadas \
  > "$EVID/23_regresion_p1_v0_3_portadas_contra_v0_5.txt" 2>&1; echo "código de salida de pytest: $?" >> "$EVID/23_regresion_p1_v0_3_portadas_contra_v0_5.txt")
grep -E "^[0-9]+ (passed|failed)" "$EVID/23_regresion_p1_v0_3_portadas_contra_v0_5.txt" | tail -1 | sed "s/^/23_regresion_p1_portadas: /"

# P2 (se espera que falle: la API pública aplicar/evidencia se ELIMINÓ en v0.4, N1/N3)
d="$TMPB/p2_sin_modificar"; mkdir -p "$d/p1" "$d/p2"
cp "$V03"/p2/test_politica_avance_T.py "$V03"/p2/generar_tabla.py "$V03"/p2/TABLA_DECISION_P2_v0.3.csv "$V03"/p2/TABLA_DECISION_P2_v0.3.md "$d/p2/"
cp "$V03"/p1/fabricas.py "$d/p1/"
cp "$COD"/politica_avance_T.py "$COD"/verificar_reproduccion_T.py "$COD"/confianza.py "$d/p2/"
cp "$COD"/verificar_reproduccion_T.py "$COD"/confianza.py "$d/p1/"
correr 24_regresion_p2_v0_3_sin_modificar_contra_v0_5 "$d/p2"

# P4
d="$TMPB/p4_sin_modificar"; mkdir -p "$d"
cp -r "$V03"/p4/test_uso_unico.py "$V03"/p4/test_v0_3.py "$V03"/p4/_conductor.py "$V03"/p4/sincro.py "$V03"/p4/codigos_sinteticos "$d"/
cp "$COD"/uso_unico.py "$COD"/confianza.py "$d"/
correr 25_regresion_p4_v0_3_sin_modificar_contra_v0_5 "$d"

# Cruzada (se espera que falle por la API; sus X1–X9 están en test_cruzada_v04.py)
d="$TMPB/cruzada_sin_modificar"; mkdir -p "$d/p1" "$d/p2" "$d/p4" "$d/cruzada"
cp "$V03"/cruzada/*.py "$d/cruzada/"; cp "$V03"/p1/fabricas.py "$d/p1/"
for s in p1 p2 p4; do cp "$COD"/*.py "$d/$s/"; done
correr 26_regresion_cruzada_v0_3_sin_modificar_contra_v0_5 "$d/cruzada"

# ---- suite COMPLETA de v0.4 sin modificar contra v0.5 ----
# Copia del paquete v0.4 (pruebas y referencias) con el código de v0.5 en codigo/verificacion: su version.py toma
# ese código como «v0_4». Se esperan fallos SOLO donde v0.5 cambió una expectativa a propósito (F2, F3; ver
# 27_*_explicacion.md).
d="$TMPB/v0_4_sin_modificar"; mkdir -p "$d/codigo/verificacion"
cp -r "$V04/pruebas" "$V04/referencia" "$V04/trazabilidad_T" "$d/"
cp "$COD"/*.py "$d/codigo/verificacion/"
correr 27_regresion_suite_v0_4_sin_modificar_contra_v0_5 "$d/pruebas" p1 p2 p4 cruzada regresion/p1_v0_3_portadas
grep -E "^FAILED" "$EVID/27_regresion_suite_v0_4_sin_modificar_contra_v0_5.txt" | sed 's/ - .*//' | sort > "$EVID/27_regresion_suite_v0_4_fallidas.txt"
echo "27: pruebas de v0.4 que fallan contra v0.5: $(wc -l < "$EVID/27_regresion_suite_v0_4_fallidas.txt")"

# ---- sondas de v0.2 (paquete v0.3 preservado): PASAN si el defecto EXISTE en v0.2 ----
: > "$EVID/40_sondas_v0_2_sobre_v0_2.txt"
for c in p1 p2 p4; do
  (cd "$V03" && echo "===== $c/test_sondas_v0_2.py" && "$PY" -B -m pytest -p no:cacheprovider -q -rA "$c/test_sondas_v0_2.py"; \
   echo "código de salida de pytest: $?") >> "$EVID/40_sondas_v0_2_sobre_v0_2.txt" 2>&1
done
grep -E "^(=====|[0-9]+ (passed|failed))" "$EVID/40_sondas_v0_2_sobre_v0_2.txt" | sed "s/^/40_sondas_v0_2: /"
{ (cd "$V03" && sha256sum -c --quiet SHA256SUMS.txt && echo "paquete v0.3 intacto tras las sondas")
  (cd "$V04" && sha256sum -c --quiet SHA256SUMS.txt && echo "paquete v0.4 intacto tras la regresión"); } > "$EVID/41_paquetes_previos_intactos.txt" 2>&1
cat "$EVID/41_paquetes_previos_intactos.txt"
