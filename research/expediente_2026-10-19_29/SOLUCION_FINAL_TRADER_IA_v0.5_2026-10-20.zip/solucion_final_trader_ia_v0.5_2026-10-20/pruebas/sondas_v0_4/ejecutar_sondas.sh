#!/usr/bin/env bash
# Sondas DIRECTAS (fuera de pytest) de los defectos F* de v0.4, ejecutadas contra v0.4 (referencia/v0_4) y contra v0.5.
# Muestran el comportamiento observable de cada versión; las pruebas F* de la matriz son la evidencia formal.
# Variables: PAQ, PY, EVID. Escribe $EVID/71_sondas_v0_4_y_v0_5.txt. La sonda de cryptography usa PY_CRYPTOGRAPHY.
set -u
PAQ=${PAQ:?}; PY=${PY:?}; EVID=${EVID:?}
D="$PAQ/pruebas/sondas_v0_4"; SAL="$EVID/71_sondas_v0_4_y_v0_5.txt"; : > "$SAL"
PYC=${PY_CRYPTOGRAPHY:-$(command -v python3.12 || true)}
for v in v0_4 v0_5; do
  dir=$([ $v = v0_4 ] && echo "$PAQ/referencia/v0_4" || echo "$PAQ/codigo/verificacion")
  {
    echo "################ $v ($dir)"
    for s in sonda_claves.py sonda_diario.py sonda_anidado.py; do echo "=== $s"; (cd "$(mktemp -d)" && "$PY" -I -B "$D/$s" "$dir" 2>&1); done
    for s in sonda_p1.py sonda_p4.py; do echo "=== $s"; (cd "$(mktemp -d)" && VERSION_BAJO_PRUEBA=$v "$PY" -I -B "$D/$s" "$PAQ" 2>&1 | tail -8); done
  } >> "$SAL"
done
if [ -n "$PYC" ]; then echo "################ cryptography/OpenSSL (referencia externa)" >> "$SAL"; "$PYC" -I "$D/sonda_cryptography.py" >> "$SAL" 2>&1; fi
grep -E "^(####|===)|FALSIFICADA|EXCEPCIÓN|VERIFICADO|REPRODUCIDO|aceptada|sin respuesta|terminó|RAIZ_INVALIDA|INCONSISTENTE" "$SAL" | head -60
