"""Sonda: JSON anidado en exceso, entero enorme y sustituto suelto ante P1 y confianza; formas de fecha UTC aceptadas."""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, sys.argv[1])
import confianza as C  # noqa: E402
import verificar_reproduccion_T as V  # noqa: E402

t = Path(tempfile.mkdtemp())
for nombre, contenido in (("profundo", b"[" * 200000 + b"]" * 200000), ("entero_enorme", b'{"a": ' + b"9" * 5000 + b"}"),
                          ("sustituto", b'{"x": "\\ud800"}')):
    p = t / f"{nombre}.json"
    p.write_bytes(contenido)
    try:
        inf = V.evaluar_archivo(p)
        print("P1", nombre, "->", inf["estado"], [m["codigo"] for m in inf["motivos"]])
    except BaseException as e:  # noqa: BLE001
        print("P1", nombre, "-> EXCEPCIÓN", type(e).__name__)
    try:
        C.cargar_json_estricto(p)
        print("confianza", nombre, "-> cargado")
    except C.ErrorConfianza as e:
        print("confianza", nombre, "->", e.codigo)
    except BaseException as e:  # noqa: BLE001
        print("confianza", nombre, "-> EXCEPCIÓN", type(e).__name__)
for v in ("2026-10-20Z", "20261020T000000Z", "2026-10-20T00:00Z", "2026-10-20T00:00:00.123456Z", "2026-W43-2T00:00:00Z"):
    try:
        C._utc(v, "x")
        print("_utc acepta", v)
    except C.ErrorConfianza:
        print("_utc rechaza", v)
