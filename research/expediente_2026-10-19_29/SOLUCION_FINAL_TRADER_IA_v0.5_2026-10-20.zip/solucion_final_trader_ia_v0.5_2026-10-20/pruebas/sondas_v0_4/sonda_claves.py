"""Sonda: claves públicas de orden pequeño en confianza v0.4 (firma universal) y comportamiento de cryptography."""
import sys, json
sys.path.insert(0, sys.argv[1])
import confianza as C
identidad = bytes([1] + [0] * 31)          # punto neutro (orden 1)
ceros = bytes(32)                           # y = 0: punto de orden 4
firma_trivial = identidad + bytes(32)       # R = neutro, s = 0
for nombre, A in (("identidad", identidad), ("ceros", ceros)):
    print(nombre, "punto válido para _descomprimir:", C._descomprimir(A) is not None)
    raiz = {"id": "R", "tipo": "propietario", "clave_publica_ed25519": A.hex(), "aprobada_por": "x",
            "aprobada_utc": "2026-10-20T00:00:00Z", "descripcion": "x"}
    try:
        C.validar_raiz("R", raiz); print("  validar_raiz: ACEPTA")
    except C.ErrorConfianza as e:
        print("  validar_raiz:", e.codigo)
    # falsificación: probar contenidos hasta que la firma trivial verifique
    for i in range(64):
        contenido = C.declaracion("R", "2026-10-20T00:00:00Z", [{"sha256": "ab" * 32}], {"intento": i})
        doc = {"contenido": contenido, "firma_ed25519": firma_trivial.hex()}
        try:
            C.verificar_declaracion(doc, {"R": raiz}); print(f"  declaración FALSIFICADA aceptada sin clave privada (intento {i})"); break
        except C.ErrorConfianza as e:
            pass
    else:
        print("  ninguna falsificación en 64 intentos")
