"""Misma comprobación con la biblioteca cryptography (OpenSSL), como referencia independiente."""
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature
identidad = bytes([1] + [0] * 31)
for nombre, A in (("identidad", identidad), ("ceros", bytes(32))):
    try:
        k = Ed25519PublicKey.from_public_bytes(A)
    except Exception as e:
        print(nombre, "clave rechazada al cargar:", type(e).__name__); continue
    ok = 0
    for i in range(64):
        try:
            k.verify(identidad + bytes(32), b"mensaje %d" % i); ok += 1
        except InvalidSignature:
            pass
    print(nombre, f"firma trivial (R=neutro, s=0) aceptada en {ok} de 64 mensajes")
