"""Sonda: eventos ENCADENADOS correctamente pero mal formados en el diario local y en el ancla local de P4 v0.4."""
import hashlib, json, shutil, sys, tempfile
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import uso_unico as U
tmp = Path(tempfile.mkdtemp())
codigo = tmp / "c.py"; codigo.write_text("def calcular(c, s):\n    return {'x': s}\n")
base = tmp / "base"; ancla = tmp / "A.jsonl"
assert U.ejecutar(base, "e", {"codigo": codigo}, 1, ancla=U.AnclaArchivo(ancla)).estado == "REGISTRADO"
canon = U._canon
def reencadenar(eventos):
    lineas, ant = [], None
    for i, ev in enumerate(eventos):
        ev = dict(ev, n=i, anterior=ant); b = canon(ev); lineas.append(b); ant = hashlib.sha256(b).hexdigest()
    return b"\n".join(lineas) + b"\n"
def eventos(ruta):
    return [json.loads(x) for x in ruta.read_bytes().splitlines()]
casos = {
  "diario: PRESELLADO sin resultado_sha256": ("diario", lambda ev: [e if e["evento"] != "PRESELLADO" else dict(e, datos={}) for e in ev]),
  "diario: datos no es objeto": ("diario", lambda ev: [ev[0]] + [dict(e, datos=[1]) for e in ev[1:]]),
  "diario: sin 'evento'": ("diario", lambda ev: ev[:1] + [{k: v for k, v in e.items() if k != "evento"} for e in ev[1:]]),
  "ancla: PRESELLADO sin resultado_sha256": ("ancla", lambda ev: [e if e["evento"] != "PRESELLADO" else dict(e, datos={"reserva_sha256": e["datos"]["reserva_sha256"]}) for e in ev]),
  "ancla: datos no es objeto": ("ancla", lambda ev: [dict(e, datos="x") for e in ev]),
}
for nombre, (donde, f) in casos.items():
    d = tmp / nombre.replace(" ", "_").replace(":", "").replace("'", ""); shutil.copytree(base, d)
    guardada = ancla.read_bytes()
    objetivo = d / U.DIARIO if donde == "diario" else ancla
    objetivo.write_bytes(reencadenar(f(eventos(objetivo))))
    try:
        s = U.ejecutar(d, "e", {"codigo": codigo}, 1, ancla=U.AnclaArchivo(ancla))
        print(f"{nombre}: salida {s.estado}")
    except Exception as e:
        print(f"{nombre}: EXCEPCIÓN {type(e).__name__}: {e}")
    ancla.write_bytes(guardada)
