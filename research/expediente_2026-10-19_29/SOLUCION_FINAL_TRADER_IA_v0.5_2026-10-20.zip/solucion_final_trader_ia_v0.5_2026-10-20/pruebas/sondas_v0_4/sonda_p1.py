"""Sondas sobre P1 (versión: VERSION_BAJO_PRUEBA), solo datos sintéticos de las fábricas."""
import hashlib, json, sys, tempfile
from pathlib import Path
paq = Path(sys.argv[1])
sys.path.insert(0, str(paq / "pruebas" / "comun"))
import fabricas_t as F, version
V = version.p1()
V.RAICES_CONFIANZA = dict(F.RAICES_PRUEBA)
R = "experimentos/fuera_de_muestra_T.json"
tmp = Path(tempfile.mkdtemp())

def arbol(nombre, **kw):
    raiz = F.arbol_t(tmp / nombre)
    ruta = raiz / R
    ruta.write_text(json.dumps(F.oos(raiz=raiz, **kw)), encoding="utf-8")
    return raiz, ruta

# D3: una declaración con un sustituto suelto (\ud800) oculta un CORRUPTO
raiz, ruta = arbol("d3")
original = ruta.read_bytes()
legitima = F.declarar({R: original})
ruta.write_text(json.dumps(F.oos(raiz=raiz, p_conj=0.5)), encoding="utf-8")   # resultado sustituido
print("D3 sin la declaración maliciosa:", V.evaluar_archivo(ruta, raiz=raiz, declaraciones=[("leg", legitima)])["estado"])
mala = json.loads('{"contenido": {"formato": "trader-ia/declaracion/v1", "emisor": "PRUEBA-PROPIETARIO", '
                  '"emitida_utc": "2026-10-20T00:00:00Z", "artefactos": [{"sha256": "' + "a" * 64 + '"}], '
                  '"contexto": {"x": "\\ud800"}}, "firma_ed25519": "' + "0" * 128 + '"}')
inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=[("leg", legitima), ("mala", mala)])
print("D3 con la declaración maliciosa:", inf["estado"], [m["codigo"] for m in inf["motivos"]])

# D4: un recibo del ancla para una reserva CUALQUIERA autentica un resultado falsificado
raiz, ruta = arbol("d4", p_conj=0.5)
sha = hashlib.sha256(ruta.read_bytes()).hexdigest()
recibo = F.declarar([{"sha256": sha, "descripcion": "presellado"}], emisor="PRUEBA-ANCLA", semilla=F.SEMILLA_ANCLA,
                    contexto={"reserva_sha256": "f" * 64})
inf = V.evaluar_archivo(ruta, raiz=raiz, declaraciones=[("recibo", recibo)])
print("D4 recibo de una reserva arbitraria:", inf["estado"], inf["autenticidad"]["cubren"])

# D5: REPRODUCIDO desde un JSON no autenticado (copia del propio original)
raiz, ruta = arbol("d5")
d = F.declarar({R: ruta.read_bytes()})
copia = json.loads(ruta.read_text())
print("D5 reproducción = copia en memoria:", V.evaluar_reproduccion(ruta, copia, 0.0, raiz=raiz, declaraciones=[("d", d)])["estado"])
falsa = F.oos(raiz=raiz, p_conj=0.76)
print("D5 «reproducción» inventada:", V.evaluar_reproduccion(ruta, falsa, 0.0, raiz=raiz, declaraciones=[("d", d)])["estado"])
