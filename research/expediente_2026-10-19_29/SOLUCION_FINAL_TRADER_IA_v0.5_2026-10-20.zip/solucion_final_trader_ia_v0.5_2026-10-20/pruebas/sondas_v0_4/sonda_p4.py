"""Sondas sobre P4 (versión: VERSION_BAJO_PRUEBA); código sintético; directorios temporales."""
import json, subprocess, sys, tempfile, time
from pathlib import Path
paq = Path(sys.argv[1])
sys.path.insert(0, str(paq / "pruebas" / "comun"))
import fabricas_t as F, version
from ancla_de_prueba import ServidorAnclaDePrueba
U = version.p4()
C = version.confianza()
tmp = Path(tempfile.mkdtemp())
codigo = tmp / "codigo.py"
codigo.write_text("def calcular(c, s):\n    return {'x': s}\n")

# D3-P4: respuesta del ancla con un sustituto suelto → excepción no controlada (sin Salida)
def transporte_malo(sol):
    return json.loads('{"contenido": {"formato": "trader-ia/ancla/respuesta/v1", "x": "\\ud800"}, "firma_ed25519": "' + "0" * 128 + '"}')
a = U.AnclaFirmada(transporte_malo, C.clave_publica(F.SEMILLA_ANCLA).hex(), "PRUEBA-ANCLA")
try:
    s = U.ejecutar(tmp / "e1", "exp", {"codigo": codigo}, 1, ancla=a)
    print("D3-P4 salida:", s.estado)
except Exception as e:
    print("D3-P4 EXCEPCIÓN sin salida:", type(e).__name__)

# D2-P4: clave fijada de orden pequeño → un intermediario sin clave privada falsifica respuestas del ancla
identidad = bytes([1] + [0] * 31).hex()
def intermediario(sol):
    contenido = {"formato": C.FORMATO_RESPUESTA_ANCLA, "emisor": "X", "op": sol["op"], "reserva_sha256": sol["reserva_sha256"],
                 "desafio": sol["desafio"], "resultado": "ACEPTADO", "motivo": "", "estado": {"reserva": True, "iniciados": 0, "presellado": None},
                 "recibo": None}
    return {"contenido": contenido, "firma_ed25519": (bytes([1] + [0] * 31) + bytes(32)).hex()}
try:
    a = U.AnclaFirmada(intermediario, identidad, "X")
    st = a.consultar("a" * 64)
    print("D2-P4 clave neutra aceptada; respuesta FALSIFICADA aceptada:", st)
except Exception as e:
    print("D2-P4 rechazada:", type(e).__name__, e)

# D6: sin límite de tiempo, un cálculo colgado no termina nunca (se mide en un proceso aparte con 8 s)
colgado = tmp / "colgado.py"
colgado.write_text("def calcular(c, s):\n    while True:\n        pass\n")
import inspect
limite = ", limite_segundos=2" if "limite_segundos" in inspect.signature(U.ejecutar).parameters else ""
prog = f"import sys; sys.path.insert(0, {str(version.DIR_P4)!r}); import uso_unico as U; print(U.ejecutar({str(tmp / 'e2')!r}, 'exp', {{'codigo': {str(colgado)!r}}}, 1{limite}).estado)"
print("D6 límite de tiempo disponible:", bool(limite))
t0 = time.time()
import os, signal
p = subprocess.Popen([sys.executable, "-I", "-B", "-c", prog], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
try:
    out, err = p.communicate(timeout=8)
    print("D6 terminó:", out.strip(), err[-200:])
except subprocess.TimeoutExpired:
    print(f"D6 ejecutar() sin respuesta tras {time.time() - t0:.0f} s (cálculo colgado; ningún límite)")
    os.killpg(p.pid, signal.SIGKILL)
    p.wait()
