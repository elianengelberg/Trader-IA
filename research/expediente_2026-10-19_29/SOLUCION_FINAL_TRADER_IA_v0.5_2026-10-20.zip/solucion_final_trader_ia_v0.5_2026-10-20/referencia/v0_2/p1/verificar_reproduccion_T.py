"""Verificador de reproducción de T, v0.2 (P1). Aislado: solo biblioteca estándar y solo lectura. PROPUESTA: no aplicado
al repositorio. Cambios respecto de v0.1 (defectos D1–D9 confirmados por sondas, ver DICTAMEN_P1.md):

- Niveles separados. COHERENTE_SIN_INTEGRIDAD: solo la coherencia interna del JSON. VERIFICADO: además, CADA hash que
  el resultado declara se recalcula desde los archivos reales de ``--raiz`` (D1, D2). «Reproducido» no lo declara este
  verificador: exige ``comparar`` con una reproducción independiente.
- La huella del código se recalcula con el algoritmo de ``tendencia.papel.huella_codigo``; el hash canónico de las
  reglas, desde ``papel/prerregistro_papel.json``; los manifiestos, desde ``datos/<SIMBOLO>/MANIFIESTO.json`` (D2).
- Ventana y días del resultado fuera de muestra contra las constantes del script cuyo hash se acaba de verificar (D7).
- Cortes: estados conocidos y coherentes (EVALUADO sin problemas; NO EVALUABLE con problemas; SIN OBSERVACIONES con el
  corte ≤ inicio) (D3, D4) y, con ``--registro``, el SHA-256 del archivo contra REGISTRO.jsonl encadenado (D6).
- NO_EVALUABLE es un resultado propio, distinto de RECHAZADO (D5). Claves JSON duplicadas: rechazo (D8). El informe
  incluye el SHA-256 del archivo verificado (D9) y lo que NO se comprobó.
- ``resultado_sha256_esperado`` / ``--resultado-sha256``: el hash del propio archivo debe ser el presellado por el
  mecanismo de uso único (P4) o su ancla; sin él, un archivo alterado de forma coherente verifica (hallazgo X-1).

Esquemas (sin cambios): el papel usa ``decision`` y ``prerregistro_sha256`` = hash CANÓNICO de las reglas; fuera de
muestra usa ``decision_prerregistrada`` y ``prerregistro_sha256`` = SHA-256 del ARCHIVO .md. ``papel.evaluar``
(congelado, no se toca) decide con ``b.get("p_mayor_que_cero", 0.5)``; aquí una clave ausente siempre es un error.

No importa ni ejecuta ``fuera_de_muestra_T.py`` ni ``corte.py``: el script se lee como texto (``ast``) solo después de
comprobar su hash. No consume ningún cerrojo. No lee bytes de datos de mercado salvo con ``--datos`` (no usado sobre los
datos reales en esta fase).

Uso: python3 -I verificar_reproduccion_T.py <resultado.json> [--raiz DIR_T] [--registro REGISTRO.jsonl]
                                             [--esperados esperados.json] [--resultado-sha256 HEX] [--datos]
Salida: 0 VERIFICADO · 1 RECHAZADO · 2 uso · 3 COHERENTE_SIN_INTEGRIDAD · 4 NO_EVALUABLE
"""
from __future__ import annotations

import ast
import datetime as dt
import hashlib
import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

VERSION = "verificar_reproduccion_T v0.2"
DECISIONES_FUERA = ("RESPALDADA FUERA DE MUESTRA", "NO RESPALDADA", "EVIDENCIA INSUFICIENTE")
DECISIONES_PAPEL = ("INFORMATIVO (menos de 12 meses: ninguna decisión)", "HIPÓTESIS NO RESPALDADA: detener",
                    "VENTAJA RESPALDADA", "EVIDENCIA INSUFICIENTE: continuar")
SALIDAS = {"VERIFICADO": 0, "RECHAZADO": 1, "COHERENTE_SIN_INTEGRIDAD": 3, "NO_EVALUABLE": 4}
SIMBOLOS = ("BTCUSDT", "ETHUSDT")


class ErrorVerificacion(Exception):
    """Error de verificación con un código estable (para pruebas y para el informe)."""

    def __init__(self, codigo: str, detalle: str):
        super().__init__(f"{codigo}: {detalle}")
        self.codigo, self.detalle = codigo, detalle


@dataclass
class Registro:
    esquema: str
    decision: str
    exceso_anual: float
    ic90: tuple[float, float] | None  # None: bootstrap no aplicable (solo papel, menos de 12 meses)
    p_conjunto: float | None
    p_btc: float | None
    exceso_x2: float
    dias: int
    meses: float | None
    hashes: dict[str, str] = field(default_factory=dict)


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


# ---------- lectura ----------
def _sin_duplicados(pares: list[tuple[str, object]]) -> dict:
    d: dict = {}
    for k, v in pares:
        if k in d:
            raise ErrorVerificacion("CLAVE_DUPLICADA", f"clave repetida en el JSON: {k!r}")
        d[k] = v
    return d


def cargar(ruta: str | Path) -> tuple[dict, str]:
    """(objeto, SHA-256 de los bytes leídos). Rechaza JSON ilegible, truncado o con claves duplicadas."""
    try:
        datos = Path(ruta).read_bytes()
    except OSError as e:
        raise ErrorVerificacion("LECTURA", f"no se puede leer {ruta}: {e}") from e
    try:
        obj = json.loads(datos.decode("utf-8"), object_pairs_hook=_sin_duplicados)
    except ValueError as e:
        raise ErrorVerificacion("LECTURA", f"{ruta}: JSON inválido: {e}") from e
    return obj, _sha(datos)


# ---------- acceso estricto (sin valores por defecto) ----------
def _clave(obj: object, ruta: str):  # type: ignore[no-untyped-def]
    actual = obj
    for parte in ruta.split("."):
        if not isinstance(actual, dict):
            raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un objeto antes de '{parte}', hay {type(actual).__name__}")
        if parte not in actual:
            raise ErrorVerificacion("AUSENTE", f"falta la clave '{ruta}'")
        actual = actual[parte]
    return actual


def _num(obj: object, ruta: str) -> float:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un número finito, hay {v!r}")
    return float(v)


def _prob(obj: object, ruta: str) -> float:
    v = _num(obj, ruta)
    if not 0.0 <= v <= 1.0:
        raise ErrorVerificacion("RANGO", f"{ruta}: probabilidad fuera de [0, 1]: {v}")
    return v


def _entero(obj: object, ruta: str) -> int:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, int) or v <= 0:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un entero positivo, hay {v!r}")
    return v


def _texto(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not isinstance(v, str) or not v:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un texto no vacío, hay {v!r}")
    return v


def _fecha(obj: object, ruta: str) -> str:
    v = _texto(obj, ruta)
    try:
        if dt.date.fromisoformat(v).isoformat() != v:
            raise ValueError(v)
    except ValueError as e:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba una fecha AAAA-MM-DD, hay {v!r}") from e
    return v


def _sha_campo(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not (isinstance(v, str) and len(v) == 64 and all(c in "0123456789abcdef" for c in v)):
        raise ErrorVerificacion("HASH_FORMATO", f"{ruta}: no es un SHA-256 en hexadecimal: {v!r}")
    return v


def _ic(obj: object, ruta: str) -> tuple[float, float]:
    v = _clave(obj, ruta)
    if not (isinstance(v, list) and len(v) == 2):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba una lista de 2 números, hay {v!r}")
    lo, hi = (_num({"x": x}, "x") for x in v)
    if lo > hi:
        raise ErrorVerificacion("RANGO", f"{ruta}: extremo inferior > superior ({lo} > {hi})")
    return lo, hi


# ---------- esquemas ----------
def detectar_esquema(obj: object) -> str:
    if not isinstance(obj, dict):
        raise ErrorVerificacion("TIPO", f"el resultado debe ser un objeto JSON, es {type(obj).__name__}")
    marcas = {"fuera_de_muestra": "decision_prerregistrada" in obj and "principal" in obj,
              "papel_corte": "corte_exclusivo" in obj and "estado" in obj,
              "papel_evaluar": "rama" in obj and "corte" in obj and "inicio" in obj}
    hallados = [k for k, v in marcas.items() if v]
    if len(hallados) != 1:
        raise ErrorVerificacion("ESQUEMA", f"esquema desconocido o ambiguo (coincide con {hallados or 'ninguno'})")
    return hallados[0]


def _estado_corte(obj: dict) -> str:
    """Coherencia de un corte de corte.py antes de mirar su evaluación (D3, D4)."""
    estado = _texto(obj, "estado")
    problemas = _clave(obj, "problemas")
    if not isinstance(problemas, list) or not all(isinstance(p, str) and p for p in problemas):
        raise ErrorVerificacion("TIPO", f"problemas: se esperaba una lista de textos, hay {problemas!r}")
    corte, inicio = _fecha(obj, "corte_exclusivo"), _fecha(obj, "inicio")
    if estado == "EVALUADO":
        if problemas:
            raise ErrorVerificacion("CONTRADICCION", "corte EVALUADO con problemas registrados (corte.py no evalúa si "
                                                     "hay problemas)")
        return estado
    if "evaluacion" in obj:
        raise ErrorVerificacion("CONTRADICCION", f"estado {estado!r} pero hay una sección 'evaluacion'")
    if estado.startswith("NO EVALUABLE"):
        if not problemas:
            raise ErrorVerificacion("CONTRADICCION", "NO EVALUABLE sin ningún problema registrado")
    elif estado.startswith("SIN OBSERVACIONES PROSPECTIVAS"):
        if corte > inicio:
            raise ErrorVerificacion("CONTRADICCION", f"SIN OBSERVACIONES pero el corte ({corte}) es posterior al "
                                                     f"inicio ({inicio})")
    else:
        raise ErrorVerificacion("VALOR", f"estado de corte desconocido: {estado!r}")
    raise ErrorVerificacion("SIN_EVALUACION", f"corte provisional coherente ({estado!r}): no hay decisión que verificar")


def normalizar(obj: dict, esquema: str | None = None) -> Registro:
    esquema = esquema or detectar_esquema(obj)
    if esquema == "fuera_de_muestra":
        r = Registro("fuera_de_muestra", _texto(obj, "decision_prerregistrada"),
                     _num(obj, "principal.conjunto.exceso_anual"), _ic(obj, "principal.conjunto.ic90_anual"),
                     _prob(obj, "principal.conjunto.p"), _prob(obj, "principal.BTC.p"),
                     _num(obj, "secundarios.costes_x2.conjunto"), _entero(obj, "dias"), None,
                     {"prerregistro_archivo": _sha_campo(obj, "prerregistro_sha256"),
                      "script": _sha_campo(obj, "script_sha256"), "codigo": _sha_campo(obj, "codigo_sha256"),
                      **{f"manifiesto_{s}": _sha_campo(obj, f"manifiestos_sha256.{s}") for s in SIMBOLOS}})
        if r.decision not in DECISIONES_FUERA:
            raise ErrorVerificacion("VALOR", f"decision_prerregistrada desconocida: {r.decision!r}")
        ventana, principal = _clave(obj, "ventana"), _clave(obj, "principal.ventana")
        if ventana != principal:
            raise ErrorVerificacion("CONTRADICCION", f"ventana {ventana!r} ≠ principal.ventana {principal!r}")
        return r
    if esquema == "papel_evaluar":
        return _normalizar_papel(obj, "papel_evaluar")
    if esquema == "papel_corte":
        _estado_corte(obj)
        ev = _clave(obj, "evaluacion")
        if _texto(ev, "corte") != obj["corte_exclusivo"]:
            raise ErrorVerificacion("CONTRADICCION", "evaluacion.corte distinto de corte_exclusivo")
        for k in ("rama", "inicio"):
            if _texto(ev, k) != _texto(obj, k):
                raise ErrorVerificacion("CONTRADICCION", f"evaluacion.{k} distinto del {k} del corte")
        dias_cal = (dt.date.fromisoformat(obj["corte_exclusivo"]) - dt.date.fromisoformat(obj["inicio"])).days
        if _entero(obj, "dias_calendario") != dias_cal:
            raise ErrorVerificacion("CONTRADICCION", f"dias_calendario ≠ corte − inicio ({dias_cal})")
        r = _normalizar_papel(ev, "papel_corte")
        r.hashes["reglas_corte"] = _sha_campo(obj, "reglas_sha256")
        r.hashes["codigo_corte"] = _sha_campo(obj, "codigo_sha256")
        if r.hashes["reglas_corte"] != r.hashes["reglas_canonicas"] or r.hashes["codigo_corte"] != r.hashes["codigo"]:
            raise ErrorVerificacion("CONTRADICCION", "los hashes del corte y de su evaluación no coinciden")
        return r
    raise ErrorVerificacion("ESQUEMA", f"esquema no soportado: {esquema!r}")


def _bootstrap(obj: dict, ruta: str) -> tuple[float | None, tuple[float, float] | None]:
    aplicable = _clave(obj, f"{ruta}.aplicable")
    if not isinstance(aplicable, bool):
        raise ErrorVerificacion("TIPO", f"{ruta}.aplicable: se esperaba true/false, hay {aplicable!r}")
    if not aplicable:
        return None, None
    return _prob(obj, f"{ruta}.p_mayor_que_cero"), _ic(obj, f"{ruta}.intervalo_anual")


def _normalizar_papel(obj: dict, esquema: str) -> Registro:
    if _texto(obj, "rama") not in ("A", "B"):
        raise ErrorVerificacion("VALOR", f"rama desconocida: {obj['rama']!r}")
    if "decision" not in obj and "estado" in obj:  # evaluar devolvió antes de decidir (sin datos o datos no aptos)
        if esquema == "papel_corte":
            raise ErrorVerificacion("CONTRADICCION", f"corte EVALUADO pero la evaluación dice {obj['estado']!r}")
        raise ErrorVerificacion("SIN_EVALUACION", f"evaluación sin decisión: {obj['estado']!r}")
    p_conj, ic = _bootstrap(obj, "bootstrap_conjunto")
    p_btc, _ = _bootstrap(obj, "bootstrap_btc")
    r = Registro(esquema, _texto(obj, "decision"), _num(obj, "exceso_anual_conjunto"), ic, p_conj, p_btc,
                 _num(obj, "exceso_anual_conjunto_costes_x2"), _entero(obj, "dias"), _num(obj, "meses"),
                 {"reglas_canonicas": _sha_campo(obj, "prerregistro_sha256"), "codigo": _sha_campo(obj, "codigo_sha256")})
    if r.decision not in DECISIONES_PAPEL:
        raise ErrorVerificacion("VALOR", f"decision desconocida: {r.decision!r}")
    if abs(r.meses - r.dias / 30.44) > 1e-9:
        raise ErrorVerificacion("CONTRADICCION", f"meses ({r.meses}) ≠ dias/30,44 ({r.dias / 30.44})")
    return r


# ---------- reglas de decisión congeladas, replicadas (las pruebas las comparan con las originales) ----------
def decision_fuera_de_muestra(p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)."""
    if p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "RESPALDADA FUERA DE MUESTRA"
    if p_conj < 0.10:
        return "NO RESPALDADA"
    return "EVIDENCIA INSUFICIENTE"


def decision_papel(meses: float, p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de tendencia.papel.decidir (código 73b22f3e…)."""
    if meses < 12:
        return "INFORMATIVO (menos de 12 meses: ninguna decisión)"
    if p_conj < 0.10:
        return "HIPÓTESIS NO RESPALDADA: detener"
    if meses >= 24 and p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "VENTAJA RESPALDADA"
    return "EVIDENCIA INSUFICIENTE: continuar"


def recalcular_decision(r: Registro) -> str:
    if r.esquema == "fuera_de_muestra":
        return decision_fuera_de_muestra(r.p_conjunto, r.p_btc, r.exceso_x2)
    if r.p_conjunto is None or r.p_btc is None:
        if r.meses >= 12:  # aquí el código congelado habría decidido con P = 0,5 por defecto
            raise ErrorVerificacion("CONTRADICCION", f"bootstrap no aplicable con {r.meses:.2f} meses: la decisión "
                                                     "dependería del 0,5 por defecto")
        return DECISIONES_PAPEL[0]
    return decision_papel(r.meses, r.p_conjunto, r.p_btc, r.exceso_x2)


# ---------- integridad contra archivos reales ----------
ARCHIVOS = {"fuera_de_muestra": {"prerregistro_archivo": "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                                 "script": "experimentos/fuera_de_muestra_T.py",
                                 **{f"manifiesto_{s}": f"datos/{s}/MANIFIESTO.json" for s in SIMBOLOS}}}


def huella_codigo(src: Path) -> str:
    """Mismo algoritmo que tendencia.papel.huella_codigo (las pruebas lo comparan con el original)."""
    py = sorted(src.glob("*.py"))
    if not py:
        raise ErrorVerificacion("AUSENTE", f"no hay archivos .py en {src}")
    h = hashlib.sha256()
    for p in py:
        h.update(p.name.encode() + b"\0" + p.read_bytes())
    return h.hexdigest()


def hash_reglas(ruta: Path) -> str:
    """Mismo algoritmo que tendencia.papel.hash_prerregistro, aplicado al JSON congelado de las reglas."""
    obj, _ = cargar(ruta)
    return _sha(json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode())


def parametros_script(datos: bytes) -> dict:
    """DESDE, HASTA y DIAS del script, leídos con ast (sin ejecutarlo)."""
    for n in ast.parse(datos).body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Tuple):
            nombres = [getattr(t, "id", None) for t in n.targets[0].elts]
            if nombres == ["DESDE", "HASTA", "DIAS"]:
                return dict(zip(nombres, ast.literal_eval(n.value), strict=True))
    raise ErrorVerificacion("AUSENTE", "el script no define DESDE, HASTA, DIAS")


def _comprobar_manifiesto(ruta: Path) -> int:
    """Cada archivo listado en un MANIFIESTO.json contra su SHA-256 (lee bytes de datos: solo con --datos)."""
    man, _ = cargar(ruta)
    archivos = _clave(man, "archivos")
    if not isinstance(archivos, list) or not archivos:
        raise ErrorVerificacion("TIPO", f"{ruta}: 'archivos' debe ser una lista no vacía")
    for a in archivos:
        p = ruta.parent / _texto(a, "ruta")
        if not p.is_file():
            raise ErrorVerificacion("AUSENTE", f"{p}: listado en el manifiesto y ausente")
        if _sha(p.read_bytes()) != _sha_campo(a, "sha256"):
            raise ErrorVerificacion("HASH", f"{p}: no coincide con su manifiesto")
    return len(archivos)


def comprobar_integridad(r: Registro, obj: dict, raiz: Path, datos: bool = False) -> tuple[dict, list[str]]:
    """Recalcula desde ``raiz`` cada hash que declara el resultado. Devuelve ({nombre: origen}, no_comprobado)."""
    hechos: dict[str, str] = {}

    def igual(nombre: str, real: str, origen: str) -> None:
        if real != r.hashes[nombre]:
            raise ErrorVerificacion("HASH", f"{nombre}: {origen} da {real[:12]}…, el resultado declara "
                                            f"{r.hashes[nombre][:12]}…")
        hechos[nombre] = origen

    for nombre, rel in ARCHIVOS.get(r.esquema, {}).items():
        p = raiz / rel
        if not p.is_file():
            raise ErrorVerificacion("AUSENTE", f"{nombre}: falta {p}")
        igual(nombre, _sha(p.read_bytes()), rel)
    igual("codigo", huella_codigo(raiz / "src" / "tendencia"), "huella de src/tendencia/*.py")
    no_comprobado = []
    if r.esquema == "fuera_de_muestra":
        par = parametros_script((raiz / ARCHIVOS["fuera_de_muestra"]["script"]).read_bytes())
        if obj["ventana"] != [par["DESDE"], par["HASTA"]] or r.dias != par["DIAS"]:
            raise ErrorVerificacion("CONTRADICCION", f"ventana {obj['ventana']} / días {r.dias} ≠ los del script "
                                                     f"verificado ({par['DESDE']}–{par['HASTA']}, {par['DIAS']})")
        hechos["ventana_y_dias"] = "constantes del script verificado (ast)"
        if datos:
            for s in SIMBOLOS:
                hechos[f"datos_{s}"] = f"{_comprobar_manifiesto(raiz / ARCHIVOS['fuera_de_muestra'][f'manifiesto_{s}'])} archivos"
        else:
            no_comprobado.append("archivos de datos listados en los manifiestos (no se leen sin --datos)")
    else:
        igual("reglas_canonicas", hash_reglas(raiz / "papel" / "prerregistro_papel.json"),
              "papel/prerregistro_papel.json canonizado")
        if r.esquema == "papel_corte":
            igual("reglas_corte", r.hashes["reglas_canonicas"], "igual a reglas_canonicas")
            igual("codigo_corte", r.hashes["codigo"], "igual a codigo")
            no_comprobado.append("datos_sha256 y decisiones_sha256 del corte (archivos del directorio del corte)")
    return hechos, no_comprobado


def comprobar_registro(obj: dict, resultado_sha256: str, registro: Path) -> str:
    """REGISTRO.jsonl de corte.py: cadena linea_anterior_sha256 y entrada con el SHA-256 de ESTE archivo (D6)."""
    try:
        texto = registro.read_text(encoding="utf-8")
    except OSError as e:
        raise ErrorVerificacion("AUSENTE", f"no se puede leer {registro}: {e}") from e
    if not texto.endswith("\n"):
        raise ErrorVerificacion("REGISTRO", "la última línea del registro está incompleta")
    anterior, propias = None, []
    for n, linea in enumerate(texto.split("\n")[:-1], 1):
        try:
            x = json.loads(linea, object_pairs_hook=_sin_duplicados)
        except ValueError as e:
            raise ErrorVerificacion("REGISTRO", f"línea {n} ilegible") from e
        if not isinstance(x, dict) or x.get("linea_anterior_sha256") != anterior:
            raise ErrorVerificacion("REGISTRO", f"cadena rota en la línea {n}")
        anterior = _sha(linea.encode())
        if x.get("corte") == obj["corte_exclusivo"]:
            propias.append((n, x))
    evaluadas = [n for n, x in propias if x.get("estado") == "EVALUADO"]
    if len(evaluadas) > 1:
        raise ErrorVerificacion("REGISTRO", f"el corte figura EVALUADO más de una vez (líneas {evaluadas})")
    coinciden = [n for n, x in propias if x.get("resultado_sha256") == resultado_sha256 and x.get("estado") == obj["estado"]]
    if not coinciden:
        raise ErrorVerificacion("REGISTRO", f"ninguna línea del registro tiene este archivo ({resultado_sha256[:12]}…) "
                                            f"con estado {obj['estado']!r}")
    if obj["estado"] == "EVALUADO" and coinciden[-1] != propias[-1][0]:
        raise ErrorVerificacion("REGISTRO", "hay líneas del corte posteriores a su evaluación")
    return f"línea {coinciden[-1]} de {registro.name}"


# ---------- verificación ----------
SEMANTICA = {"fuera_de_muestra": {"prerregistro_archivo", "script", "codigo", "manifiesto_BTCUSDT", "manifiesto_ETHUSDT"},
             "papel_evaluar": {"reglas_canonicas", "codigo"},
             "papel_corte": {"reglas_canonicas", "codigo", "reglas_corte", "codigo_corte"}}


def verificar(obj: object, raiz: str | Path | None = None, resultado_sha256: str | None = None,
              registro: str | Path | None = None, esperados: dict[str, str] | None = None,
              datos: bool = False, resultado_sha256_esperado: str | None = None) -> dict:
    """Informe si todo es coherente; si no, ErrorVerificacion. ``nivel`` = VERIFICADO solo si cada hash declarado se
    recalculó desde ``raiz`` (y, para un corte, si su archivo figura en ``registro``)."""
    if resultado_sha256_esperado is not None and resultado_sha256 != resultado_sha256_esperado:
        raise ErrorVerificacion("HASH", f"el archivo ({(resultado_sha256 or 'sin hash')[:12]}…) no es el presellado "
                                        f"({resultado_sha256_esperado[:12]}…)")
    r = normalizar(obj)  # type: ignore[arg-type]
    esperados = esperados or {}
    for nombre, valor in esperados.items():
        if nombre not in SEMANTICA[r.esquema]:
            otros = [e for e, s in SEMANTICA.items() if nombre in s]
            raise ErrorVerificacion("HASH_SEMANTICA", f"'{nombre}' no se aplica al esquema {r.esquema} (se aplica a {otros})")
        if r.hashes[nombre] != valor:
            raise ErrorVerificacion("HASH", f"{nombre}: el resultado dice {r.hashes[nombre][:12]}…, la referencia "
                                            f"declarada es {valor[:12]}…")
    recalculada = recalcular_decision(r)
    if recalculada != r.decision:
        raise ErrorVerificacion("CONTRADICCION", f"decisión registrada {r.decision!r} ≠ la que dan sus propias cifras "
                                                 f"con la regla congelada ({recalculada!r})")
    integridad, no_comprobado = ({}, ["ningún hash recalculado desde archivos (falta --raiz)"])
    if raiz is not None:
        integridad, no_comprobado = comprobar_integridad(r, obj, Path(raiz), datos)  # type: ignore[arg-type]
    completo = raiz is not None
    if r.esquema == "papel_corte":
        if registro is not None:
            if resultado_sha256 is None:
                raise ErrorVerificacion("AUSENTE", "para comprobar el registro hace falta el SHA-256 del archivo")
            integridad["archivo_en_registro"] = comprobar_registro(obj, resultado_sha256, Path(registro))  # type: ignore[arg-type]
        else:
            completo = False
            no_comprobado.append("REGISTRO.jsonl del corte (falta --registro)")
    elif registro is not None:
        raise ErrorVerificacion("HASH_SEMANTICA", f"--registro solo se aplica a cortes, no a {r.esquema}")
    return {"version": VERSION, "nivel": "VERIFICADO" if completo else "COHERENTE_SIN_INTEGRIDAD",
            "esquema": r.esquema, "resultado_sha256": resultado_sha256,
            "naturaleza": "EVALUADO_SIN_DECISION" if r.decision == DECISIONES_PAPEL[0] else "EVALUADO_CON_DECISION",
            "decision": r.decision, "decision_recalculada": recalculada, "exceso_anual": r.exceso_anual,
            "ic90": list(r.ic90) if r.ic90 else None, "p_conjunto": r.p_conjunto, "p_btc": r.p_btc,
            "exceso_x2": r.exceso_x2, "dias": r.dias, "hashes_declarados": r.hashes,
            "integridad_desde_archivos": integridad, "referencias_declaradas_coinciden": sorted(esperados),
            "resultado_sha256_esperado_coincide": resultado_sha256_esperado is not None,
            "no_comprobado": no_comprobado}


def verificar_archivo(ruta: str | Path, **kw) -> dict:  # type: ignore[no-untyped-def]
    obj, sha = cargar(ruta)
    return verificar(obj, resultado_sha256=sha, **kw)


def comparar(a: object, b: object, tolerancia: float = 0.0) -> list[str]:
    """Evidencia contradictoria entre dos registros del MISMO experimento (p. ej. el resultado y una reproducción
    independiente). Devuelve la lista de discrepancias; vacía = coherentes. Con tolerancia 0 exige igualdad exacta."""
    ra, rb = normalizar(a), normalizar(b)  # type: ignore[arg-type]
    dif = []
    if ra.esquema != rb.esquema:
        dif.append(f"esquemas distintos ({ra.esquema} / {rb.esquema})")
    for campo in ("decision", "dias"):
        if getattr(ra, campo) != getattr(rb, campo):
            dif.append(f"{campo}: {getattr(ra, campo)!r} ≠ {getattr(rb, campo)!r}")
    for campo in ("exceso_anual", "p_conjunto", "p_btc", "exceso_x2"):
        x, y = getattr(ra, campo), getattr(rb, campo)
        if (x is None) != (y is None) or (x is not None and abs(x - y) > tolerancia):
            dif.append(f"{campo}: {x!r} ≠ {y!r}")
    if (ra.ic90 is None) != (rb.ic90 is None) or (
            ra.ic90 and any(abs(x - y) > tolerancia for x, y in zip(ra.ic90, rb.ic90))):
        dif.append(f"ic90: {ra.ic90} ≠ {rb.ic90}")
    for k in sorted(set(ra.hashes) | set(rb.hashes)):
        if ra.hashes.get(k) != rb.hashes.get(k):
            dif.append(f"hash {k}: {ra.hashes.get(k)} ≠ {rb.hashes.get(k)}")
    return dif


def main(argv: list[str]) -> int:
    if not argv or argv[0].startswith("--"):
        print(__doc__)
        return 2
    ruta, kw, i = argv[0], {}, 1
    try:
        while i < len(argv):
            if argv[i] == "--datos":
                kw["datos"], i = True, i + 1
            elif argv[i] in ("--raiz", "--registro", "--esperados") and i + 1 < len(argv):
                kw[argv[i][2:]], i = argv[i + 1], i + 2
            elif argv[i] == "--resultado-sha256" and i + 1 < len(argv):
                kw["resultado_sha256_esperado"], i = argv[i + 1], i + 2
            else:
                print(__doc__)
                return 2
        if "esperados" in kw:
            kw["esperados"], _ = cargar(kw["esperados"])
        informe = verificar_archivo(ruta, **kw)
    except ErrorVerificacion as e:
        resultado = "NO_EVALUABLE" if e.codigo == "SIN_EVALUACION" else "RECHAZADO"
        print(json.dumps({"version": VERSION, "resultado": resultado, "codigo": e.codigo, "detalle": e.detalle},
                         ensure_ascii=False))
        return SALIDAS[resultado]
    print(json.dumps({"resultado": informe["nivel"], **informe}, ensure_ascii=False, indent=1))
    return SALIDAS[informe["nivel"]]


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
