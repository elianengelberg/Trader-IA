"""Genera TABLA_DECISION_P2_v0.2.md a partir de la política v0.2 (las pruebas comprueban que el archivo coincide).
Las filas con CUMPLE/NO_CUMPLE usan definiciones SINTÉTICAS solo para recorrer las ramas: hoy no existe ninguna
definición aprobada de R1/R3 para T, así que en la práctica solo son alcanzables las filas con NO_DEFINIDO."""
from __future__ import annotations

import itertools
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import politica_avance_T as PA  # noqa: E402

DEF_SINTETICAS = {
    f"{c}-SINTETICA": {"id": f"{c}-SINTETICA", "criterio": c, "aplica_a": "T", "texto_sha256": "0" * 64,
                       "aprobada_utc": "2000-01-01T00:00:00Z", "aprobada_por": "PRUEBA SINTÉTICA (no es una propuesta)"}
    for c in ("R1", "R3")}


def valor(criterio: str, estado: str) -> object:
    return "NO_DEFINIDO" if estado == "NO_DEFINIDO" else (estado, f"{criterio}-SINTETICA")


def filas() -> list[tuple]:
    out = []
    for etiqueta, e1, e3 in itertools.product(PA.ETIQUETAS, PA.ESTADOS_R, PA.ESTADOS_R):
        s = PA.aplicar(etiqueta, valor("R1", e1), valor("R3", e3), fecha_inicio_ventana="2022-01-01",
                       definiciones=DEF_SINTETICAS)
        alcanzable = "sí" if (e1, e3) == ("NO_DEFINIDO", "NO_DEFINIDO") else "no (requiere definición aprobada)"
        out.append((etiqueta, s["clase_estadistica"], e1, e3, s["robustez"]["resumen"],
                    s["decision_avance"]["resultado"], s["decision_avance"]["etapa"],
                    s["autorizacion_fase_posterior"]["estado"], alcanzable))
    return out


def markdown() -> str:
    cab = ("Etiqueta estadística (literal)", "Clase", "R1", "R3", "Robustez", "Decisión de avance", "Etapa",
           "Autorización", "¿Alcanzable hoy?")
    lineas = [f"# Tabla de decisión: {PA.VERSION} ({PA.ESTADO_VERSION})", "",
              "Generada por `generar_tabla.py`. Las 63 combinaciones de 7 etiquetas × 3 estados de R1 × 3 de R3. Las",
              "filas con CUMPLE o NO_CUMPLE usan definiciones **sintéticas**, solo para recorrer las ramas: hoy no hay",
              "ninguna definición aprobada para T, así que solo son alcanzables las 7 filas con R1 = R3 = NO_DEFINIDO.",
              "La etiqueta nunca cambia, la autorización es siempre NO_OTORGADA y R1/R3 nunca cambian la decisión de avance.",
              "", "| " + " | ".join(cab) + " |", "|" + "---|" * len(cab)]
    lineas += ["| " + " | ".join(f"`{c}`" if i == 0 else str(c) for i, c in enumerate(f)) + " |" for f in filas()]
    return "\n".join(lineas) + "\n"


if __name__ == "__main__":
    (AQUI / "TABLA_DECISION_P2_v0.2.md").write_text(markdown(), encoding="utf-8")
    print(f"{len(filas())} filas")
