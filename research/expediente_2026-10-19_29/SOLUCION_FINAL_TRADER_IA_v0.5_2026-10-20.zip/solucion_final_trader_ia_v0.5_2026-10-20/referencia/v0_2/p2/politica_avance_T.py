"""Política de avance de T, v0.2 — PROPUESTA, NO APROBADA. Solo biblioteca estándar; no lee datos ni escribe nada.

Cuatro salidas separadas (v0.1 mezclaba avance y autorización):
  1. etiqueta_estadistica: texto LITERAL del productor congelado; nunca se reescribe ni se reinterpreta.
  2. robustez: diagnóstico INFORMATIVO de R1 y R3. Un estado distinto de NO_DEFINIDO exige una definición APROBADA
     PARA T (registro ``DEFINICIONES_APROBADAS``, hoy VACÍO): sin ella, R1 y R3 solo pueden ser NO_DEFINIDO (v0.1
     aceptaba «CUMPLE» de cualquier origen, p. ej. una métrica de E3).
  3. decision_avance: depende SOLO de la clase de la etiqueta y NOMBRA la etapa a la que se refiere. Hoy no hay etapa
     siguiente definida (A5): «NO_CANDIDATA» no es una decisión universal.
  4. autorizacion_fase_posterior: siempre NO_OTORGADA. Esta función no autoriza nada; solo una decisión humana expresa,
     registrada fuera de ella, puede hacerlo.

Una definición aprobada en o después del INICIO de la ventana evaluada se marca como post hoc: nunca se presenta como
prerregistrada. Es la lectura conservadora (los datos de la ventana son observables desde su inicio); usar otra fecha,
p. ej. la de ejecución, es la ambigüedad A7. Para el fuera de muestra de T (ventana desde 2022-01-01) toda definición
actual es post hoc.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "p1"))
import verificar_reproduccion_T as V  # noqa: E402  (verificador de P1, v0.2)

VERSION = "POLITICA_AVANCE_T v0.2"
ESTADO_VERSION = "PROPUESTA: no aprobada"

ETIQUETAS = {
    # experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)
    "RESPALDADA FUERA DE MUESTRA": "RESPALDADA",
    "NO RESPALDADA": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE": "INSUFICIENTE",
    # tendencia.papel.decidir (código 73b22f3e…), citada; no se importa ni se altera
    "VENTAJA RESPALDADA": "RESPALDADA",
    "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
    "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO",
}
ESTADOS_R = ("CUMPLE", "NO_CUMPLE", "NO_DEFINIDO")
CAMPOS_DEFINICION = ("id", "criterio", "aplica_a", "texto_sha256", "aprobada_utc", "aprobada_por")

# Registros que solo una decisión humana puede llenar. VACÍOS: no hay definición de R1/R3 para T (A1, A2) ni etapa
# siguiente definida (A5). Las pruebas usan registros SINTÉTICOS para recorrer las ramas; no son propuestas.
DEFINICIONES_APROBADAS: dict[str, dict] = {}
ETAPAS_DEFINIDAS: dict[str, str] = {}


class ErrorPolitica(ValueError):
    pass


def _evaluacion_r(nombre: str, valor: object, definiciones: dict[str, dict], fecha_inicio_ventana: str | None) -> dict:
    """``valor`` = "NO_DEFINIDO" o (estado, id_de_definición_aprobada)."""
    if valor == "NO_DEFINIDO":
        return {"estado": "NO_DEFINIDO", "definicion": None, "post_hoc": None}
    if not (isinstance(valor, tuple) and len(valor) == 2 and valor[0] in ("CUMPLE", "NO_CUMPLE")
            and isinstance(valor[1], str)):
        raise ErrorPolitica(f"{nombre}: se espera 'NO_DEFINIDO' o (CUMPLE|NO_CUMPLE, id de definición), hay {valor!r}")
    estado, ident = valor
    d = definiciones.get(ident)
    if d is None:
        raise ErrorPolitica(f"{nombre}: la definición {ident!r} no está aprobada para T; sin ella {nombre} es NO_DEFINIDO")
    if any(not isinstance(d.get(c), str) or not d.get(c) for c in CAMPOS_DEFINICION):
        raise ErrorPolitica(f"{nombre}: la definición {ident!r} no tiene todos los campos {CAMPOS_DEFINICION}")
    if d["criterio"] != nombre or d["aplica_a"] != "T":
        raise ErrorPolitica(f"{nombre}: la definición {ident!r} es de {d['criterio']} para {d['aplica_a']}, no de "
                            f"{nombre} para T (no se trasladan métricas de otro experimento)")
    post_hoc = fecha_inicio_ventana is None or d["aprobada_utc"][:10] >= fecha_inicio_ventana
    return {"estado": estado, "definicion": ident, "post_hoc": post_hoc}


def robustez(e1: str, e3: str) -> str:
    """ROBUSTA solo si ambas se cumplen; NO_ROBUSTA si alguna falla; si no, INDETERMINADA. La regla de combinación
    («todas») viene de E3 v3 §6.3 y es la ambigüedad A6: hoy no tiene efecto porque R1 y R3 son NO_DEFINIDO."""
    if "NO_CUMPLE" in (e1, e3):
        return "NO_ROBUSTA"
    if "NO_DEFINIDO" in (e1, e3):
        return "INDETERMINADA"
    return "ROBUSTA"


def aplicar(etiqueta: str, r1: object = "NO_DEFINIDO", r3: object = "NO_DEFINIDO", *,
            fecha_inicio_ventana: str | None = None, exceso_no_positivo: bool | None = None, etapa: str | None = None,
            definiciones: dict[str, dict] | None = None, etapas: dict[str, str] | None = None) -> dict:
    if not isinstance(etiqueta, str) or etiqueta not in ETIQUETAS:
        raise ErrorPolitica(f"etiqueta estadística desconocida (se exige el texto literal del productor): {etiqueta!r}")
    if exceso_no_positivo is not None and not isinstance(exceso_no_positivo, bool):
        raise ErrorPolitica(f"exceso_no_positivo debe ser true, false o null, es {exceso_no_positivo!r}")
    definiciones = DEFINICIONES_APROBADAS if definiciones is None else definiciones
    etapas = ETAPAS_DEFINIDAS if etapas is None else etapas
    if etapa is not None and etapa not in etapas:
        raise ErrorPolitica(f"etapa {etapa!r} no definida (A5); no se inventan etapas")
    ev1, ev3 = (_evaluacion_r(n, v, definiciones, fecha_inicio_ventana) for n, v in (("R1", r1), ("R3", r3)))
    clase = ETIQUETAS[etiqueta]
    nombre_etapa = etapa or "NO_DEFINIDA"
    if clase == "RESPALDADA":
        avance = {"resultado": "CANDIDATA_A_REVISION_HUMANA", "etapa": nombre_etapa,
                  "texto": f"T es candidata a que una persona decida si pasa a la etapa {nombre_etapa}"}
    else:
        avance = {"resultado": "NO_CANDIDATA", "etapa": nombre_etapa,
                  "texto": (f"T no es candidata a la etapa {etapa}" if etapa else
                            "T no es candidata a una etapa posterior; esa etapa no está definida (A5), así que esto "
                            "no es una decisión universal: la acción vigente es la de la propia etiqueta")}
    advertencias = []
    if "NO_DEFINIDO" in (ev1["estado"], ev3["estado"]):
        advertencias.append("R1/R3 sin definición aprobada para T (A1, A2): robustez no evaluable")
    if any(e["post_hoc"] for e in (ev1, ev3)):
        advertencias.append("R1/R3 evaluados con una definición posterior al resultado: diagnóstico POST HOC, no "
                            "prerregistrado")
    rob = robustez(ev1["estado"], ev3["estado"])
    if clase == "RESPALDADA" and rob != "ROBUSTA":
        advertencias.append(f"robustez {rob}: dato para la decisión humana; no veta la candidatura (A3)")
    notas = []
    if exceso_no_positivo is not None:
        notas.append(f"exceso anual {'≤' if exceso_no_positivo else '>'} 0: informativo, no cambia nada")
    return {"version": VERSION, "estado_version": ESTADO_VERSION,
            "etiqueta_estadistica": etiqueta, "clase_estadistica": clase,
            "robustez": {"R1": ev1, "R3": ev3, "resumen": rob, "naturaleza": "diagnóstico informativo"},
            "decision_avance": avance,
            "autorizacion_fase_posterior": {"estado": "NO_OTORGADA",
                                            "motivo": "la política no autoriza; requiere una decisión humana expresa"},
            "advertencias": advertencias, "notas_informativas": notas}


def desde_resultado(ruta: str | Path, raiz: str | Path, r1: object = "NO_DEFINIDO", r3: object = "NO_DEFINIDO",
                    fecha_inicio_ventana: str | None = None, registro: str | Path | None = None,
                    resultado_sha256_esperado: str | None = None, **kw) -> dict:  # type: ignore[no-untyped-def]
    """Solo se clasifica un resultado que el verificador de P1 da por VERIFICADO (integridad desde archivos). Uno solo
    coherente, no evaluable, alterado o contradictorio no recibe etiqueta: se lanza ErrorPolitica o ErrorVerificacion."""
    inf = V.verificar_archivo(ruta, raiz=raiz, registro=registro, resultado_sha256_esperado=resultado_sha256_esperado)
    obj, _ = V.cargar(ruta)
    if fecha_inicio_ventana is None:  # la más conservadora que da el propio resultado
        fecha_inicio_ventana = obj["ventana"][0] if inf["esquema"] == "fuera_de_muestra" else obj["inicio"]
    if inf["nivel"] != "VERIFICADO":
        raise ErrorPolitica(f"resultado no verificado ({inf['nivel']}; no comprobado: {inf['no_comprobado']}): no se "
                            "le asigna etiqueta")
    salida = aplicar(inf["decision"], r1, r3, fecha_inicio_ventana=fecha_inicio_ventana,
                     exceso_no_positivo=inf["exceso_anual"] <= 0, **kw)
    return {**salida, "resultado_verificado": {k: inf[k] for k in ("esquema", "resultado_sha256", "nivel",
                                                                    "decision_recalculada", "no_comprobado")}}
