"""Conductor de las pruebas de P4 v0.2: ejecuta ``uso_unico.ejecutar`` en un proceso aparte y, si se pide, lo mata con
``os._exit(137)`` en un punto (sin finally ni vaciado de búferes, como una caída real). Datos sintéticos."""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import uso_unico as U  # noqa: E402

if __name__ == "__main__":
    a = json.loads(sys.argv[1])
    punto = a.get("punto")
    if a.get("esperar_hasta"):
        while time.time() < a["esperar_hasta"]:
            time.sleep(0.0005)
    s = U.ejecutar(a["dir"], a["experimento"], a["archivos"], a["semilla"],
                   ancla=U.AnclaArchivo(a["ancla"]) if a.get("ancla") else None,
                   reintentos_tras_inicio=a.get("reintentos", 0),
                   fallo=lambda p: os._exit(137) if p == punto else None)
    print(json.dumps(s.__dict__, ensure_ascii=False))
