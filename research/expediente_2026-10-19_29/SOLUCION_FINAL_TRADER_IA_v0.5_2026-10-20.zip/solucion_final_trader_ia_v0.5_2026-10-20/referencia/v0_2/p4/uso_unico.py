"""Prototipo AISLADO de ejecución de uso único, v0.2 (P4). Solo biblioteca estándar. PROPUESTA: no está integrado en
``papel/corte.py`` ni en ``fuera_de_muestra_T.py`` y no debe integrarse sin autorización.

Garantía buscada: un experimento se calcula con entradas, código y entorno fijados de antemano, y un resultado que pudo
observarse no puede sustituirse por otro repitiendo, borrando, truncando, restaurando o alterando el estado LOCAL,
siempre que exista un ancla que el atacante no controle. Sin ancla, o con el ancla local de este archivo frente a quien
puede escribirla, esa garantía NO existe (ver DICTAMEN_P4.md y ESTADO_Y_INVARIANTES_v0.2.md).

Cambios respecto de v0.1 (defectos D1–D6 confirmados por sondas):
- El código ejecutado es el de los bytes reservados (``archivos["codigo"]``), en un proceso hijo aislado (``-I -S``,
  sin stdout ni stderr; el resultado vuelve por un descriptor propio). El entorno (versión del intérprete) y el punto de
  entrada forman parte de la reserva. Ya no se acepta una función del llamador (D1).
- Interfaz de ancla: la reserva y el PRESELLADO se anotan en el ancla ANTES de que el resultado se escriba en disco; en
  cada llamada se concilia el diario local con el ancla: un presellado del ancla ausente en el diario es un retroceso
  (restauración o truncamiento) → INCONSISTENTE, sin calcular (D2, D3, D6).
- CALCULO_INICIADO separa un fallo previo al cálculo (se reintenta) de uno posterior a su inicio, que pudo observar el
  resultado: solo se reintenta hasta ``reintentos_tras_inicio`` (fijado en la reserva; por defecto 0 → REVISION_HUMANA) (D4).
- fsync del directorio padre al crear el directorio de estado y el ancla (D5).
"""
from __future__ import annotations

import base64
import datetime as dt
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

VERSION = "uso_unico v0.2"
DIARIO, RESULTADO, CERROJO = "DIARIO.jsonl", "resultado.json", ".cerrojo"
ERRORES_TERMINALES = ("CONFLICTO", "CORRUPTO", "INCONSISTENTE", "REVISION_HUMANA")
PUNTOS_DE_FALLO = ("antes_del_cerrojo", "antes_de_reservar", "durante_reserva", "tras_reservar", "tras_iniciar_calculo",
                   "durante_calculo", "tras_calculo", "durante_presellado", "tras_presellado", "tras_ancla",
                   "durante_escritura", "tras_archivo", "durante_registro")
SIN_ANCLA = "NINGUNA: no protege contra borrado, truncamiento ni restauración del estado local"


@dataclass
class Salida:
    # REGISTRADO | OCUPADO | RECHAZADO | FALLO_CALCULO | ANCLA_NO_DISPONIBLE | CONFLICTO | CORRUPTO | INCONSISTENTE |
    # REVISION_HUMANA. Solo REGISTRADO trae resultado.
    estado: str
    resultado: dict | None = None
    resultado_sha256: str | None = None
    calculado: bool = False
    detalle: str = ""
    ancla: str = SIN_ANCLA


class _CadenaRota(Exception):
    pass


class AnclaNoDisponible(Exception):
    """El ancla no respondió (p. ej., pérdida de conexión). Nunca se escribe el resultado sin su confirmación."""


class AnclaConflicto(Exception):
    """El ancla ya tiene otra reserva del mismo experimento o de las mismas entradas, u otro presellado."""


def _nada(_punto: str) -> None:
    return None


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _canon(x: object) -> bytes:
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def _ahora() -> str:
    return dt.datetime.now(dt.UTC).isoformat(timespec="microseconds")


def _fsync_dir(d: Path) -> None:
    fd = os.open(d, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _crear_dir(d: Path) -> None:
    """mkdir con fsync del padre, para que la entrada del directorio sobreviva a un corte de energía (D5)."""
    if not d.is_dir():
        d.mkdir(parents=True, exist_ok=True)
        _fsync_dir(d.parent)


def _entorno() -> dict:
    return {"python": sys.version, "implementacion": platform.python_implementation()}


# ---------- diario encadenado (local y del ancla) ----------
def _leer_cadena(ruta: Path) -> tuple[list[dict], list[bytes], bytes]:
    if not ruta.exists():
        return [], [], b""
    *completas, cola = ruta.read_bytes().split(b"\n")
    eventos: list[dict] = []
    anterior = None
    for i, crudo in enumerate(completas):
        try:
            ev = json.loads(crudo)
        except ValueError as e:
            raise _CadenaRota(f"{ruta.name}: línea {i + 1} ilegible") from e
        if not isinstance(ev, dict) or ev.get("n") != i or ev.get("anterior") != anterior or _canon(ev) != crudo:
            raise _CadenaRota(f"{ruta.name}: cadena rota en la línea {i + 1}")
        eventos.append(ev)
        anterior = _sha(crudo)
    return eventos, completas, cola


def _anotar(ruta: Path, lineas: list[bytes], eventos: list[dict], evento: str, datos: dict,
            fallo: Callable[[str], None] = _nada, punto: str | None = None, crear: bool = False) -> None:
    ev = {"n": len(lineas), "evento": evento, "utc": _ahora(), "datos": datos,
          "anterior": _sha(lineas[-1]) if lineas else None}
    linea = _canon(ev)
    nuevo = crear and not ruta.exists()
    fd = os.open(ruta, os.O_WRONLY | os.O_APPEND | (os.O_CREAT if crear else 0), 0o644)
    try:
        if punto:
            os.write(fd, linea[: len(linea) // 2])
            os.fsync(fd)
            fallo(punto)
            os.write(fd, linea[len(linea) // 2:] + b"\n")
        else:
            os.write(fd, linea + b"\n")
        os.fsync(fd)
    finally:
        os.close(fd)
    if nuevo:
        _fsync_dir(ruta.parent)
    lineas.append(linea)
    eventos.append(ev)


def _descartar_cola(ruta: Path, lineas: list[bytes], eventos: list[dict], cola: bytes) -> None:
    with open(ruta, "r+b") as fh:
        fh.truncate(sum(len(x) + 1 for x in lineas))
        fh.flush()
        os.fsync(fh.fileno())
    _anotar(ruta, lineas, eventos, "COLA_ROTA_DESCARTADA",
            {"bytes": len(cola), "sha256": _sha(cola), "contenido": cola.decode("utf-8", "replace")})


# ---------- ancla ----------
class AnclaArchivo:
    """Implementación LOCAL de la interfaz de ancla (consultar / registrar_reserva / registrar_inicio_calculo /
    registrar_presellado): un diario
    encadenado en otro archivo, con su propio cerrojo. NO es un ancla externa: detecta el borrado, el truncamiento o la
    restauración del directorio de estado, pero no a quien puede reescribir también este archivo. Un ancla externa
    (servicio de solo añadidos fuera del control del operador) implementaría la misma interfaz."""

    def __init__(self, ruta: str | Path):
        self.ruta = Path(ruta)
        self.descripcion = f"AnclaArchivo LOCAL ({self.ruta.name}): no es un ancla externa"

    def _con_cerrojo(self, f: Callable[[list[dict], list[bytes]], object]) -> object:
        _crear_dir(self.ruta.parent)
        fd = os.open(f"{self.ruta}.cerrojo", os.O_CREAT | os.O_RDWR, 0o644)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            eventos, lineas, cola = _leer_cadena(self.ruta)
            if cola:
                _descartar_cola(self.ruta, lineas, eventos, cola)
            return f(eventos, lineas)
        except _CadenaRota as e:
            raise AnclaConflicto(f"ancla ilegible o alterada: {e}") from e
        finally:
            os.close(fd)

    @staticmethod
    def _estado(eventos: list[dict], reserva_sha: str) -> dict:
        propios = [e for e in eventos if e["datos"].get("reserva_sha256") == reserva_sha]
        pres = [e["datos"]["resultado_sha256"] for e in propios if e["evento"] == "PRESELLADO"]
        return {"reserva": any(e["evento"] == "RESERVA" for e in propios),
                "iniciados": max((e["datos"]["n"] for e in propios if e["evento"] == "INICIO_CALCULO"), default=0),
                "presellado": pres[0] if pres else None}

    def consultar(self, reserva_sha: str) -> dict:
        return self._con_cerrojo(lambda ev, _l: self._estado(ev, reserva_sha))  # type: ignore[return-value]

    def registrar_reserva(self, reserva_sha: str, reserva: dict) -> None:
        def f(eventos: list[dict], lineas: list[bytes]) -> None:
            for e in eventos:
                x = e["datos"]
                if e["evento"] == "RESERVA" and x["reserva_sha256"] != reserva_sha and (
                        x["experimento"] == reserva["experimento"] or x["archivos_sha256"] == reserva["archivos_sha256"]):
                    raise AnclaConflicto(f"el ancla ya tiene {x['experimento']} con "
                                         f"{'ese nombre' if x['experimento'] == reserva['experimento'] else 'las mismas entradas'}"
                                         f" (semilla {x['semilla']})")
            if not self._estado(eventos, reserva_sha)["reserva"]:
                _anotar(self.ruta, lineas, eventos, "RESERVA",
                        {"reserva_sha256": reserva_sha, "experimento": reserva["experimento"],
                         "semilla": reserva["semilla"], "archivos_sha256": reserva["archivos_sha256"]}, crear=True)
        self._con_cerrojo(f)

    def registrar_inicio_calculo(self, reserva_sha: str, n: int) -> None:
        def f(eventos: list[dict], lineas: list[bytes]) -> None:
            st = self._estado(eventos, reserva_sha)
            if not st["reserva"]:
                raise AnclaConflicto("inicio de cálculo sin reserva en el ancla")
            if st["presellado"] is not None:
                raise AnclaConflicto("inicio de cálculo después de un presellado")
            if n > st["iniciados"]:
                _anotar(self.ruta, lineas, eventos, "INICIO_CALCULO", {"reserva_sha256": reserva_sha, "n": n})
        self._con_cerrojo(f)

    def registrar_presellado(self, reserva_sha: str, resultado_sha: str) -> None:
        def f(eventos: list[dict], lineas: list[bytes]) -> None:
            st = self._estado(eventos, reserva_sha)
            if not st["reserva"]:
                raise AnclaConflicto("presellado sin reserva en el ancla")
            if st["presellado"] not in (None, resultado_sha):
                raise AnclaConflicto("el ancla ya tiene otro presellado para esta reserva")
            if st["presellado"] is None:
                _anotar(self.ruta, lineas, eventos, "PRESELLADO",
                        {"reserva_sha256": reserva_sha, "resultado_sha256": resultado_sha})
        self._con_cerrojo(f)


# ---------- cálculo aislado ----------
_HIJO = r"""
import base64, json, os, sys
fd = int(sys.argv[1])
e = json.loads(sys.stdin.buffer.read())
contenidos = {k: base64.b64decode(v) for k, v in e["contenidos"].items()}
ns = {"__name__": "calculo_reservado"}
exec(compile(contenidos.pop("codigo"), "codigo_reservado", "exec"), ns)
res = ns[e["punto_entrada"]](contenidos, e["semilla"])
datos = json.dumps(res, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
with os.fdopen(fd, "wb") as fh:
    fh.write(datos)
"""


def _calcular_aislado(contenidos: dict[str, bytes], semilla: int, punto_entrada: str,
                      fallo: Callable[[str], None]) -> tuple[bytes | None, str]:
    """Ejecuta los bytes RESERVADOS de ``codigo`` en un proceso hijo sin salida visible. (bytes canónicos, motivo)."""
    r, w = os.pipe()
    try:
        p = subprocess.Popen([sys.executable, "-I", "-S", "-B", "-c", _HIJO, str(w)], stdin=subprocess.PIPE,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, pass_fds=(w,), close_fds=True)
    finally:
        os.close(w)
    entrada = json.dumps({"contenidos": {k: base64.b64encode(v).decode() for k, v in contenidos.items()},
                          "semilla": semilla, "punto_entrada": punto_entrada}).encode()
    try:
        p.stdin.write(entrada)  # type: ignore[union-attr]
        p.stdin.close()  # type: ignore[union-attr]
    except BrokenPipeError:
        pass
    fallo("durante_calculo")  # el padre muere con el hijo ya calculando
    with os.fdopen(r, "rb") as fh:
        datos = fh.read()
    codigo = p.wait()
    if codigo != 0:
        return None, f"el proceso de cálculo terminó con código {codigo}"
    try:
        obj = json.loads(datos)
    except ValueError:
        return None, "el cálculo no devolvió JSON"
    if not isinstance(obj, dict):
        return None, "el cálculo no devolvió un objeto JSON"
    return _canon(obj), ""


# ---------- escrituras atómicas ----------
def _reservar(d: Path, reserva: dict, fallo: Callable[[str], None]) -> None:
    tmp = d / f".{DIARIO}.{os.getpid()}.tmp"
    with open(tmp, "wb") as fh:
        fh.write(_canon({"n": 0, "evento": "RESERVADO", "utc": _ahora(), "datos": reserva, "anterior": None}) + b"\n")
        fh.flush()
        os.fsync(fh.fileno())
    fallo("durante_reserva")
    try:
        os.link(tmp, d / DIARIO)
    finally:
        tmp.unlink()
    _fsync_dir(d)


def _escribir_atomico(ruta: Path, datos: bytes, fallo: Callable[[str], None]) -> None:
    tmp = ruta.with_name(f".{ruta.name}.{os.getpid()}.tmp")
    with open(tmp, "wb") as fh:
        fh.write(datos[: len(datos) // 2])
        fh.flush()
        os.fsync(fh.fileno())
        fallo("durante_escritura")
        fh.write(datos[len(datos) // 2:])
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, ruta)
    _fsync_dir(ruta.parent)


# ---------- estados ----------
def _validar_secuencia(eventos: list[dict]) -> None:
    if not eventos:
        return
    tipos = [e["evento"] for e in eventos]
    if tipos[0] != "RESERVADO" or tipos.count("RESERVADO") != 1:
        raise _CadenaRota("el diario no empieza por una única reserva")
    pres = [e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"]
    if len(pres) > 1:
        raise _CadenaRota("más de un presellado")
    for i, e in enumerate(eventos):
        t = e["evento"]
        if t == "PRESELLADO" and "CALCULO_INICIADO" not in tipos[:i]:
            raise _CadenaRota(f"PRESELLADO sin CALCULO_INICIADO previo (línea {i + 1})")
        if t in ("SELLADO", "RESTAURADO", "REGISTRADO") and (
                not pres or e["datos"]["resultado_sha256"] != pres[0] or "PRESELLADO" not in tipos[:i]):
            raise _CadenaRota(f"{t} sin presellado coherente (línea {i + 1})")
        if t == "REGISTRADO" and "SELLADO" not in tipos[:i]:
            raise _CadenaRota(f"REGISTRADO sin SELLADO previo (línea {i + 1})")
    terminal = next((i for i, t in enumerate(tipos) if t in ERRORES_TERMINALES), None)
    if terminal is not None and any(t != "INTENTO" for t in tipos[terminal + 1:]):
        raise _CadenaRota("hay eventos después de un estado terminal")


def estado_actual(eventos: list[dict]) -> str:
    if not eventos:
        return "NUEVO"
    tipos = {e["evento"] for e in eventos}
    for t in (*ERRORES_TERMINALES, "REGISTRADO", "SELLADO", "PRESELLADO"):
        if t in tipos:
            return t
    return "CALCULO_INTERRUMPIDO" if "CALCULO_INICIADO" in tipos else "RESERVADO"


# ---------- ejecución ----------
def ejecutar(dir_estado: str | Path, experimento: str, archivos: dict[str, str | Path], semilla: int,
             punto_entrada: str = "calcular", ancla: AnclaArchivo | None = None, reintentos_tras_inicio: int = 0,
             fallo: Callable[[str], None] = _nada) -> Salida:
    """``archivos["codigo"]`` es el código que se ejecuta (``punto_entrada(contenidos, semilla)`` en un proceso hijo).
    El cálculo debe ser determinista. ``ancla``: objeto con consultar / registrar_reserva / registrar_presellado."""
    if "codigo" not in archivos:
        raise ValueError("archivos debe incluir 'codigo': el código que se ejecuta forma parte de la reserva")
    if isinstance(reintentos_tras_inicio, bool) or not isinstance(reintentos_tras_inicio, int) or reintentos_tras_inicio < 0:
        raise ValueError("reintentos_tras_inicio debe ser un entero ≥ 0")
    d = Path(dir_estado)
    _crear_dir(d)
    fallo("antes_del_cerrojo")
    fd = os.open(d / CERROJO, os.O_CREAT | os.O_RDWR, 0o644)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return Salida("OCUPADO", detalle="otra ejecución tiene el cerrojo; no se calcula",
                          ancla=ancla.descripcion if ancla else SIN_ANCLA)
        return _bajo_cerrojo(d, experimento, archivos, semilla, punto_entrada, ancla, reintentos_tras_inicio, fallo)
    finally:
        os.close(fd)


def _bajo_cerrojo(d: Path, experimento: str, archivos: dict[str, str | Path], semilla: int, punto_entrada: str,
                  ancla: AnclaArchivo | None, reintentos: int, fallo: Callable[[str], None]) -> Salida:
    desc = ancla.descripcion if ancla else SIN_ANCLA
    ruta = d / DIARIO
    try:
        eventos, lineas, cola = _leer_cadena(ruta)
        if cola:
            _descartar_cola(ruta, lineas, eventos, cola)
        _validar_secuencia(eventos)
    except _CadenaRota as e:
        return Salida("INCONSISTENTE", detalle=str(e), ancla=desc)
    for t in d.glob(".*.tmp"):
        t.unlink()
    contenidos = {k: Path(p).read_bytes() for k, p in sorted(archivos.items())}
    reserva = {"version": VERSION, "experimento": experimento, "semilla": semilla, "punto_entrada": punto_entrada,
               "reintentos_tras_inicio": reintentos, "entorno": _entorno(),
               "archivos_sha256": {k: _sha(v) for k, v in contenidos.items()}}
    reserva_sha = _sha(_canon(reserva))

    def terminal(evento: str, motivo: str, **datos: object) -> Salida:
        _anotar(ruta, lineas, eventos, evento, {"motivo": motivo, **datos})
        return Salida(evento, detalle=motivo, ancla=desc)

    if not eventos:
        if (d / RESULTADO).exists():
            return Salida("INCONSISTENTE", detalle="hay un resultado sin diario", ancla=desc)
        if ancla is not None:  # el ancla primero: una reserva en conflicto se rechaza sin dejar estado local
            try:
                st = ancla.consultar(reserva_sha)
                if st["reserva"] and (st["iniciados"] or st["presellado"]):
                    return Salida("RECHAZADO", ancla=desc, detalle="el ancla registra un cálculo iniciado para esta "
                                  "reserva y falta el estado local (¿borrado o restaurado?): no se calcula")
                ancla.registrar_reserva(reserva_sha, reserva)
            except AnclaNoDisponible as e:
                return Salida("ANCLA_NO_DISPONIBLE", detalle=str(e), ancla=desc)
            except AnclaConflicto as e:
                return Salida("RECHAZADO", detalle=str(e), ancla=desc)
        fallo("antes_de_reservar")
        _reservar(d, reserva, fallo)
        eventos, lineas, _ = _leer_cadena(ruta)

    estado = estado_actual(eventos)
    if estado in ERRORES_TERMINALES:
        _anotar(ruta, lineas, eventos, "INTENTO", {"pid": os.getpid(), "estado_previo": estado})
        return Salida(estado, detalle=next(e["datos"].get("motivo", "") for e in eventos if e["evento"] == estado),
                      ancla=desc)
    if eventos[0]["datos"] != reserva:
        _anotar(ruta, lineas, eventos, "RECHAZADO_ENTRADAS_DISTINTAS", {"ofrecidas": reserva})
        return Salida("RECHAZADO", detalle="entradas, código, semilla, entorno o configuración distintos de los "
                                           "reservados; no se calcula", ancla=desc)
    pre = next((e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"), None)
    iniciados_ancla = 0
    if ancla is not None:  # conciliación con el ancla ANTES de calcular o de escribir nada
        try:
            if not ancla.consultar(reserva_sha)["reserva"]:
                ancla.registrar_reserva(reserva_sha, reserva)
            st = ancla.consultar(reserva_sha)
            pre_ancla, iniciados_ancla = st["presellado"], st["iniciados"]
        except AnclaNoDisponible as e:
            return Salida("ANCLA_NO_DISPONIBLE", detalle=str(e), ancla=desc)
        except AnclaConflicto as e:
            return terminal("INCONSISTENTE", str(e))
        if pre_ancla is not None and pre is None:
            return terminal("INCONSISTENTE", "el ancla tiene un presellado que el diario local no tiene: retroceso, "
                                             "truncamiento o restauración del estado local; no se calcula",
                            presellado_ancla=pre_ancla)
        if pre_ancla is not None and pre_ancla != pre:
            return terminal("INCONSISTENTE", "el presellado del ancla y el del diario local difieren",
                            presellado_ancla=pre_ancla)
    fallo("tras_reservar")
    _anotar(ruta, lineas, eventos, "INTENTO", {"pid": os.getpid(), "estado_previo": estado})

    calculado, crudo = False, None
    if pre is None:
        # el mayor de los dos recuentos: un diario local restaurado no «olvida» cálculos que el ancla registró
        iniciados = max(sum(e["evento"] == "CALCULO_INICIADO" for e in eventos), iniciados_ancla)
        if iniciados > reintentos:
            return terminal("REVISION_HUMANA", f"{iniciados} cálculo(s) iniciado(s) sin presellado: pudieron observar un "
                                               "resultado; otro intento permitiría elegir entre resultados")
        if ancla is not None:
            try:
                ancla.registrar_inicio_calculo(reserva_sha, iniciados + 1)
            except AnclaNoDisponible as e:
                return Salida("ANCLA_NO_DISPONIBLE", detalle=f"{e}; no se inicia el cálculo", ancla=desc)
            except AnclaConflicto as e:
                return terminal("INCONSISTENTE", str(e))
        _anotar(ruta, lineas, eventos, "CALCULO_INICIADO", {"n": iniciados + 1})
        fallo("tras_iniciar_calculo")
        crudo, motivo = _calcular_aislado(contenidos, semilla, punto_entrada, fallo)
        if crudo is None:
            _anotar(ruta, lineas, eventos, "CALCULO_FALLIDO", {"motivo": motivo})
            return Salida("FALLO_CALCULO", detalle=motivo, ancla=desc)
        calculado = True
        fallo("tras_calculo")
        pre = _sha(crudo)
        _anotar(ruta, lineas, eventos, "PRESELLADO", {"resultado_sha256": pre}, fallo, "durante_presellado")
        fallo("tras_presellado")
    if ancla is not None:  # el ancla conoce el hash ANTES de que el resultado exista en disco
        try:
            ancla.registrar_presellado(reserva_sha, pre)
        except AnclaNoDisponible as e:
            return Salida("ANCLA_NO_DISPONIBLE", ancla=desc, detalle=f"{e}; el resultado no se escribe hasta que el "
                          "ancla confirme el presellado")
        except AnclaConflicto as e:
            return terminal("INCONSISTENTE", str(e))
        fallo("tras_ancla")
    archivo = d / RESULTADO
    if archivo.exists():
        en_disco = archivo.read_bytes()
        if _sha(en_disco) != pre:
            return terminal("CORRUPTO", f"resultado.json ({_sha(en_disco)[:12]}…) no coincide con el presellado "
                                        f"({pre[:12]}…)", encontrado_sha256=_sha(en_disco))
        crudo = en_disco
    else:
        if crudo is None:  # resultado perdido tras el presellado: solo vale el MISMO resultado
            _anotar(ruta, lineas, eventos, "RECALCULO_DE_VERIFICACION", {"resultado_sha256_exigido": pre})
            crudo, motivo = _calcular_aislado(contenidos, semilla, punto_entrada, fallo)
            calculado = True
            if crudo is None or _sha(crudo) != pre:
                return terminal("CONFLICTO", motivo or f"el recálculo ({_sha(crudo)[:12]}…) no reproduce el presellado "
                                                       f"({pre[:12]}…)")
        _escribir_atomico(archivo, crudo, fallo)
        fallo("tras_archivo")
        if any(e["evento"] == "SELLADO" for e in eventos):
            _anotar(ruta, lineas, eventos, "RESTAURADO", {"resultado_sha256": pre})
    if not any(e["evento"] == "SELLADO" for e in eventos):
        _anotar(ruta, lineas, eventos, "SELLADO", {"resultado_sha256": pre})
    if estado != "REGISTRADO":
        _anotar(ruta, lineas, eventos, "REGISTRADO", {"resultado_sha256": pre}, fallo, "durante_registro")
    return Salida("REGISTRADO", json.loads(crudo), pre, calculado, ancla=desc)


def leer(dir_estado: str | Path) -> dict:
    """Solo lectura: estado del diario, eventos y si resultado.json coincide con el presellado."""
    d = Path(dir_estado)
    try:
        eventos, _, cola = _leer_cadena(d / DIARIO)
        _validar_secuencia(eventos)
    except _CadenaRota as e:
        return {"estado": "INCONSISTENTE", "detalle": str(e)}
    pre = next((e["datos"]["resultado_sha256"] for e in eventos if e["evento"] == "PRESELLADO"), None)
    archivo = d / RESULTADO
    return {"estado": estado_actual(eventos), "eventos": [e["evento"] for e in eventos], "cola_rota": bool(cola),
            "presellado": pre, "archivo_coincide": archivo.exists() and _sha(archivo.read_bytes()) == pre}
