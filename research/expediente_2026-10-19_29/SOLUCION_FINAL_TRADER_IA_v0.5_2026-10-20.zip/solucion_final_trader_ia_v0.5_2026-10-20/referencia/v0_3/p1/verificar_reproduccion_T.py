"""Verificador de reproducción de T, v0.3 (P1). Aislado: solo biblioteca estándar y solo lectura. PROPUESTA: no aplicado
al repositorio. Cambios de v0.3 respecto de v0.2 (defectos S1–S8 confirmados por sondas, ver DICTAMEN_P1_FINAL.md):

- Esquema estricto: claves obligatorias y admitidas por esquema, tomadas de los productores reales; una clave inesperada
  (p. ej. un «decision» suelto en el fuera de muestra) o un símbolo faltante o sobrante se rechaza (S1, S2).
- Correspondencias: el ``codigo_sha256`` del resultado debe ser el CODIGO fijado en el script verificado (S4); el
  ``inicio`` de un resultado de papel, el del prerregistro para su rama (S8).
- Manifiestos del repositorio (``--manifiesto``, repetible: ``ARTEFACTOS_SHA256.txt`` o un JSON ruta → sha256, p. ej.
  ``EVIDENCIA_T_MULTI.json#cadena_historica_T_fuera_de_muestra``): cada archivo que se hashea y el propio resultado, si
  figuran, deben coincidir; el resultado DEBE figurar (S3). Los manifiestos no están autenticados: el informe nunca
  declara autenticidad («autenticidad: NO_VERIFICADA»).
- Cortes: ``datos_sha256`` desde los MANIFIESTO.json del corte y ``decisiones_sha256`` desde las tablas CSV (columnas,
  número de filas, días consecutivos y hash reconstruido); sin eso, el corte no llega a VERIFICADO (S7).
- REPRODUCIDO: solo con ``reproducir`` / ``--reproduccion``, solo si el original es VERIFICADO, la reproducción es
  estructuralmente válida y ``comparar_completo`` (todas las hojas del JSON; tolerancia absoluta explícita, 0 por
  defecto, solo para números) no encuentra diferencias (S5, S6). Si no: NO_REPRODUCIDO.

Cambios de v0.2 respecto de v0.1 (defectos D1–D9 confirmados por sondas, ver DICTAMEN_P1.md):

- Niveles separados. COHERENTE_SIN_INTEGRIDAD: solo la coherencia interna del JSON. VERIFICADO: además, CADA hash que
  el resultado declara se recalcula desde los archivos reales de ``--raiz`` (D1, D2). «Reproducido» no lo declara este
  verificador: exige ``comparar`` con una reproducción independiente.
- La huella del código se recalcula con el algoritmo de ``tendencia.papel.huella_codigo``; el hash canónico de las
  reglas, desde ``papel/prerregistro_papel.json``; los manifiestos, desde ``datos/<SIMBOLO>/MANIFIESTO.json`` (D2).
- Ventana y días del resultado fuera de muestra contra las constantes del script cuyo hash se acaba de verificar (D7).
- Cortes: estados conocidos y coherentes (EVALUADO sin problemas; NO EVALUABLE con problemas; SIN OBSERVACIONES con el
  corte ≤ inicio) (D3, D4) y, con ``--registro``, el SHA-256 del archivo contra REGISTRO.jsonl encadenado (D6).
- NO_EVALUABLE es un resultado propio, distinto de RECHAZADO (D5). Claves JSON duplicadas: rechazo (D8). El informe
  incluye el SHA-256 del archivo verificado (D9) y lo que NO se comprobó.
- ``resultado_sha256_esperado`` / ``--resultado-sha256``: el hash del propio archivo debe ser el presellado por el
  mecanismo de uso único (P4) o su ancla; sin él, un archivo alterado de forma coherente verifica (hallazgo X-1).

Esquemas (sin cambios): el papel usa ``decision`` y ``prerregistro_sha256`` = hash CANÓNICO de las reglas; fuera de
muestra usa ``decision_prerregistrada`` y ``prerregistro_sha256`` = SHA-256 del ARCHIVO .md. ``papel.evaluar``
(congelado, no se toca) decide con ``b.get("p_mayor_que_cero", 0.5)``; aquí una clave ausente siempre es un error.

No importa ni ejecuta ``fuera_de_muestra_T.py`` ni ``corte.py``: el script se lee como texto (``ast``) solo después de
comprobar su hash. No consume ningún cerrojo. No lee bytes de datos de mercado salvo con ``--datos`` (no usado sobre los
datos reales en esta fase).

Uso: python3 -I verificar_reproduccion_T.py <resultado.json> [--raiz DIR_T] [--registro REGISTRO.jsonl]
        [--esperados esperados.json] [--resultado-sha256 HEX] [--manifiesto RUTA[#CLAVE]]... [--datos]
        [--reproduccion otra.json [--tolerancia X]]
Salida: 0 VERIFICADO o REPRODUCIDO · 1 RECHAZADO · 2 uso · 3 COHERENTE_SIN_INTEGRIDAD · 4 NO_EVALUABLE · 5 NO_REPRODUCIDO
"""
from __future__ import annotations

import ast
import csv
import datetime as dt
import hashlib
import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

VERSION = "verificar_reproduccion_T v0.3"
DECISIONES_FUERA = ("RESPALDADA FUERA DE MUESTRA", "NO RESPALDADA", "EVIDENCIA INSUFICIENTE")
DECISIONES_PAPEL = ("INFORMATIVO (menos de 12 meses: ninguna decisión)", "HIPÓTESIS NO RESPALDADA: detener",
                    "VENTAJA RESPALDADA", "EVIDENCIA INSUFICIENTE: continuar")
SALIDAS = {"VERIFICADO": 0, "REPRODUCIDO": 0, "RECHAZADO": 1, "COHERENTE_SIN_INTEGRIDAD": 3, "NO_EVALUABLE": 4,
           "NO_REPRODUCIDO": 5}
AUTENTICIDAD = "NO_VERIFICADA: no hay raíz de confianza independiente (los manifiestos y el árbol son locales)"
SIMBOLOS = ("BTCUSDT", "ETHUSDT")


class ErrorVerificacion(Exception):
    """Error de verificación con un código estable (para pruebas y para el informe)."""

    def __init__(self, codigo: str, detalle: str):
        super().__init__(f"{codigo}: {detalle}")
        self.codigo, self.detalle = codigo, detalle


@dataclass
class Registro:
    esquema: str
    decision: str
    exceso_anual: float
    ic90: tuple[float, float] | None  # None: bootstrap no aplicable (solo papel, menos de 12 meses)
    p_conjunto: float | None
    p_btc: float | None
    exceso_x2: float
    dias: int
    meses: float | None
    hashes: dict[str, str] = field(default_factory=dict)


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


# ---------- lectura ----------
def _sin_duplicados(pares: list[tuple[str, object]]) -> dict:
    d: dict = {}
    for k, v in pares:
        if k in d:
            raise ErrorVerificacion("CLAVE_DUPLICADA", f"clave repetida en el JSON: {k!r}")
        d[k] = v
    return d


def cargar(ruta: str | Path) -> tuple[dict, str]:
    """(objeto, SHA-256 de los bytes leídos). Rechaza JSON ilegible, truncado o con claves duplicadas."""
    try:
        datos = Path(ruta).read_bytes()
    except OSError as e:
        raise ErrorVerificacion("LECTURA", f"no se puede leer {ruta}: {e}") from e
    try:
        obj = json.loads(datos.decode("utf-8"), object_pairs_hook=_sin_duplicados)
    except ValueError as e:
        raise ErrorVerificacion("LECTURA", f"{ruta}: JSON inválido: {e}") from e
    return obj, _sha(datos)


# ---------- acceso estricto (sin valores por defecto) ----------
def _clave(obj: object, ruta: str):  # type: ignore[no-untyped-def]
    actual = obj
    for parte in ruta.split("."):
        if not isinstance(actual, dict):
            raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un objeto antes de '{parte}', hay {type(actual).__name__}")
        if parte not in actual:
            raise ErrorVerificacion("AUSENTE", f"falta la clave '{ruta}'")
        actual = actual[parte]
    return actual


def _num(obj: object, ruta: str) -> float:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un número finito, hay {v!r}")
    return float(v)


def _prob(obj: object, ruta: str) -> float:
    v = _num(obj, ruta)
    if not 0.0 <= v <= 1.0:
        raise ErrorVerificacion("RANGO", f"{ruta}: probabilidad fuera de [0, 1]: {v}")
    return v


def _entero(obj: object, ruta: str) -> int:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, int) or v <= 0:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un entero positivo, hay {v!r}")
    return v


def _texto(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not isinstance(v, str) or not v:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un texto no vacío, hay {v!r}")
    return v


def _fecha(obj: object, ruta: str) -> str:
    v = _texto(obj, ruta)
    try:
        if dt.date.fromisoformat(v).isoformat() != v:
            raise ValueError(v)
    except ValueError as e:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba una fecha AAAA-MM-DD, hay {v!r}") from e
    return v


def _sha_campo(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not (isinstance(v, str) and len(v) == 64 and all(c in "0123456789abcdef" for c in v)):
        raise ErrorVerificacion("HASH_FORMATO", f"{ruta}: no es un SHA-256 en hexadecimal: {v!r}")
    return v


def _ic(obj: object, ruta: str) -> tuple[float, float]:
    v = _clave(obj, ruta)
    if not (isinstance(v, list) and len(v) == 2):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba una lista de 2 números, hay {v!r}")
    lo, hi = (_num({"x": x}, "x") for x in v)
    if lo > hi:
        raise ErrorVerificacion("RANGO", f"{ruta}: extremo inferior > superior ({lo} > {hi})")
    return lo, hi


def _claves(obj: object, ruta: str, obligatorias: set[str], admitidas: set[str] = frozenset()) -> dict:  # type: ignore[assignment]
    """Esquema estricto (v0.3): todas las obligatorias y ninguna fuera de obligatorias ∪ admitidas."""
    d = obj if ruta == "" else _clave(obj, ruta)
    if not isinstance(d, dict):
        raise ErrorVerificacion("TIPO", f"{ruta or 'raíz'}: se esperaba un objeto, hay {type(d).__name__}")
    faltan = sorted(obligatorias - set(d))
    if faltan:
        raise ErrorVerificacion("AUSENTE", f"{ruta or 'raíz'}: faltan {faltan}")
    sobran = sorted(set(d) - obligatorias - set(admitidas))
    if sobran:
        raise ErrorVerificacion("CLAVE_INESPERADA", f"{ruta or 'raíz'}: claves no admitidas {sobran}")
    return d


# Claves de los productores reales (fuera_de_muestra_T.json; resultado.json de corte.py con fuente simulada).
FUERA_RAIZ = {"categoria", "prerregistro_sha256", "script_sha256", "codigo_sha256", "manifiestos_sha256", "ventana", "dias",
              "decision_prerregistrada", "principal", "secundarios"}
FUERA_SIMBOLO = ({"exceso_anual", "ic90_anual", "p"}, {"exposicion_media", "T", "estatica", "buy_and_hold"})
FUERA_SECUNDARIOS = ({"costes_x2"}, {"subventanas", "costes_x3", "retraso_1_dia", "nulo_circular_BTC", "replicacion",
                                     "desarrollo_mas_fuera_de_muestra", "efectivo"})
PAPEL_EVALUACION = {"prerregistro_sha256", "codigo_sha256", "rama", "inicio", "corte", "dias", "meses",
                    "exceso_anual_conjunto", "bootstrap_conjunto", "bootstrap_btc", "exceso_anual_conjunto_costes_x2",
                    "decision"}
BOOTSTRAP_APLICABLE = {"aplicable", "dias", "media_diaria", "media_anual", "intervalo_anual", "p_mayor_que_cero",
                       "bloque", "remuestreos", "semilla", "nivel"}
CORTE_COMUN = {"corte_exclusivo", "rama", "inicio", "reglas_sha256", "codigo_sha256", "problemas", "datos_sha256", "estado",
               "monitor_carry"}
CORTE_EVALUADO = CORTE_COMUN | {"evaluacion", "dias_calendario", "decisiones_sha256"}
COLUMNAS_DECISIONES = ("dia", "decision_con_cierre_de", "cierre_usado", "disponible_desde_utc", "exposicion_objetivo",
                       "precio_referencia_apertura", "valor_operado", "coste", "equity_cierre", "exposicion_cierre",
                       "equity_buy_and_hold", "equity_estatica")
COLUMNAS_TEXTO = {"dia", "decision_con_cierre_de", "disponible_desde_utc"}


# ---------- esquemas ----------
def detectar_esquema(obj: object) -> str:
    if not isinstance(obj, dict):
        raise ErrorVerificacion("TIPO", f"el resultado debe ser un objeto JSON, es {type(obj).__name__}")
    marcas = {"fuera_de_muestra": "decision_prerregistrada" in obj and "principal" in obj,
              "papel_corte": "corte_exclusivo" in obj and "estado" in obj,
              "papel_evaluar": "rama" in obj and "corte" in obj and "inicio" in obj}
    hallados = [k for k, v in marcas.items() if v]
    if len(hallados) != 1:
        raise ErrorVerificacion("ESQUEMA", f"esquema desconocido o ambiguo (coincide con {hallados or 'ninguno'})")
    return hallados[0]


def _estado_corte(obj: dict) -> str:
    """Coherencia de un corte de corte.py antes de mirar su evaluación (D3, D4)."""
    estado = _texto(obj, "estado")
    if estado != "EVALUADO":
        presentes = sorted({"evaluacion", "dias_calendario", "decisiones_sha256"} & set(obj))
        if presentes:
            raise ErrorVerificacion("CONTRADICCION", f"estado {estado!r} pero hay campos de evaluación {presentes}")
    _claves(obj, "", CORTE_EVALUADO if estado == "EVALUADO" else CORTE_COMUN)
    for campo in ("datos_sha256",) + (("decisiones_sha256",) if estado == "EVALUADO" else ()):
        _claves(obj, campo, set(SIMBOLOS))
        for s in SIMBOLOS:
            _sha_campo(obj, f"{campo}.{s}")
    problemas = _clave(obj, "problemas")
    if not isinstance(problemas, list) or not all(isinstance(p, str) and p for p in problemas):
        raise ErrorVerificacion("TIPO", f"problemas: se esperaba una lista de textos, hay {problemas!r}")
    corte, inicio = _fecha(obj, "corte_exclusivo"), _fecha(obj, "inicio")
    if estado == "EVALUADO":
        if problemas:
            raise ErrorVerificacion("CONTRADICCION", "corte EVALUADO con problemas registrados (corte.py no evalúa si "
                                                     "hay problemas)")
        return estado
    if "evaluacion" in obj:
        raise ErrorVerificacion("CONTRADICCION", f"estado {estado!r} pero hay una sección 'evaluacion'")
    if estado.startswith("NO EVALUABLE"):
        if not problemas:
            raise ErrorVerificacion("CONTRADICCION", "NO EVALUABLE sin ningún problema registrado")
    elif estado.startswith("SIN OBSERVACIONES PROSPECTIVAS"):
        if corte > inicio:
            raise ErrorVerificacion("CONTRADICCION", f"SIN OBSERVACIONES pero el corte ({corte}) es posterior al "
                                                     f"inicio ({inicio})")
    else:
        raise ErrorVerificacion("VALOR", f"estado de corte desconocido: {estado!r}")
    raise ErrorVerificacion("SIN_EVALUACION", f"corte provisional coherente ({estado!r}): no hay decisión que verificar")


def normalizar(obj: dict, esquema: str | None = None) -> Registro:
    esquema = esquema or detectar_esquema(obj)
    if esquema == "fuera_de_muestra":
        r = Registro("fuera_de_muestra", _texto(obj, "decision_prerregistrada"),
                     _num(obj, "principal.conjunto.exceso_anual"), _ic(obj, "principal.conjunto.ic90_anual"),
                     _prob(obj, "principal.conjunto.p"), _prob(obj, "principal.BTC.p"),
                     _num(obj, "secundarios.costes_x2.conjunto"), _entero(obj, "dias"), None,
                     {"prerregistro_archivo": _sha_campo(obj, "prerregistro_sha256"),
                      "script": _sha_campo(obj, "script_sha256"), "codigo": _sha_campo(obj, "codigo_sha256"),
                      **{f"manifiesto_{s}": _sha_campo(obj, f"manifiestos_sha256.{s}") for s in SIMBOLOS}})
        if r.decision not in DECISIONES_FUERA:
            raise ErrorVerificacion("VALOR", f"decision_prerregistrada desconocida: {r.decision!r}")
        _claves(obj, "", FUERA_RAIZ)
        _claves(obj, "principal", {"ventana", "BTC", "ETH", "conjunto"})
        for k in ("BTC", "ETH"):
            _claves(obj, f"principal.{k}", *FUERA_SIMBOLO)
            _num(obj, f"principal.{k}.exceso_anual"), _ic(obj, f"principal.{k}.ic90_anual"), _prob(obj, f"principal.{k}.p")
        _claves(obj, "principal.conjunto", FUERA_SIMBOLO[0])
        _claves(obj, "manifiestos_sha256", set(SIMBOLOS))
        _claves(obj, "secundarios", *FUERA_SECUNDARIOS)
        _claves(obj, "secundarios.costes_x2", {"BTC", "ETH", "conjunto"})
        for k in ("BTC", "ETH"):
            _num(obj, f"secundarios.costes_x2.{k}")
        _texto(obj, "categoria")
        ventana, principal = _clave(obj, "ventana"), _clave(obj, "principal.ventana")
        if ventana != principal:
            raise ErrorVerificacion("CONTRADICCION", f"ventana {ventana!r} ≠ principal.ventana {principal!r}")
        return r
    if esquema == "papel_evaluar":
        return _normalizar_papel(obj, "papel_evaluar")
    if esquema == "papel_corte":
        _estado_corte(obj)
        ev = _clave(obj, "evaluacion")
        if _texto(ev, "corte") != obj["corte_exclusivo"]:
            raise ErrorVerificacion("CONTRADICCION", "evaluacion.corte distinto de corte_exclusivo")
        for k in ("rama", "inicio"):
            if _texto(ev, k) != _texto(obj, k):
                raise ErrorVerificacion("CONTRADICCION", f"evaluacion.{k} distinto del {k} del corte")
        dias_cal = (dt.date.fromisoformat(obj["corte_exclusivo"]) - dt.date.fromisoformat(obj["inicio"])).days
        if _entero(obj, "dias_calendario") != dias_cal:
            raise ErrorVerificacion("CONTRADICCION", f"dias_calendario ≠ corte − inicio ({dias_cal})")
        r = _normalizar_papel(ev, "papel_corte")
        r.hashes["reglas_corte"] = _sha_campo(obj, "reglas_sha256")
        r.hashes["codigo_corte"] = _sha_campo(obj, "codigo_sha256")
        if r.hashes["reglas_corte"] != r.hashes["reglas_canonicas"] or r.hashes["codigo_corte"] != r.hashes["codigo"]:
            raise ErrorVerificacion("CONTRADICCION", "los hashes del corte y de su evaluación no coinciden")
        return r
    raise ErrorVerificacion("ESQUEMA", f"esquema no soportado: {esquema!r}")


def _bootstrap(obj: dict, ruta: str) -> tuple[float | None, tuple[float, float] | None]:
    aplicable = _clave(obj, f"{ruta}.aplicable")
    if not isinstance(aplicable, bool):
        raise ErrorVerificacion("TIPO", f"{ruta}.aplicable: se esperaba true/false, hay {aplicable!r}")
    if not aplicable:
        _claves(obj, ruta, {"aplicable", "motivo"})
        return None, None
    _claves(obj, ruta, BOOTSTRAP_APLICABLE)
    return _prob(obj, f"{ruta}.p_mayor_que_cero"), _ic(obj, f"{ruta}.intervalo_anual")


def _normalizar_papel(obj: dict, esquema: str) -> Registro:
    if _texto(obj, "rama") not in ("A", "B"):
        raise ErrorVerificacion("VALOR", f"rama desconocida: {obj['rama']!r}")
    if "decision" not in obj and "estado" in obj:  # evaluar devolvió antes de decidir (sin datos o datos no aptos)
        if esquema == "papel_corte":
            raise ErrorVerificacion("CONTRADICCION", f"corte EVALUADO pero la evaluación dice {obj['estado']!r}")
        raise ErrorVerificacion("SIN_EVALUACION", f"evaluación sin decisión: {obj['estado']!r}")
    _claves(obj, "", PAPEL_EVALUACION, {"T_BTC", "T_ETH"} if esquema == "papel_evaluar" else {"metricas"})
    p_conj, ic = _bootstrap(obj, "bootstrap_conjunto")
    p_btc, _ = _bootstrap(obj, "bootstrap_btc")
    r = Registro(esquema, _texto(obj, "decision"), _num(obj, "exceso_anual_conjunto"), ic, p_conj, p_btc,
                 _num(obj, "exceso_anual_conjunto_costes_x2"), _entero(obj, "dias"), _num(obj, "meses"),
                 {"reglas_canonicas": _sha_campo(obj, "prerregistro_sha256"), "codigo": _sha_campo(obj, "codigo_sha256")})
    if r.decision not in DECISIONES_PAPEL:
        raise ErrorVerificacion("VALOR", f"decision desconocida: {r.decision!r}")
    if abs(r.meses - r.dias / 30.44) > 1e-9:
        raise ErrorVerificacion("CONTRADICCION", f"meses ({r.meses}) ≠ dias/30,44 ({r.dias / 30.44})")
    return r


# ---------- reglas de decisión congeladas, replicadas (las pruebas las comparan con las originales) ----------
def decision_fuera_de_muestra(p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)."""
    if p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "RESPALDADA FUERA DE MUESTRA"
    if p_conj < 0.10:
        return "NO RESPALDADA"
    return "EVIDENCIA INSUFICIENTE"


def decision_papel(meses: float, p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de tendencia.papel.decidir (código 73b22f3e…)."""
    if meses < 12:
        return "INFORMATIVO (menos de 12 meses: ninguna decisión)"
    if p_conj < 0.10:
        return "HIPÓTESIS NO RESPALDADA: detener"
    if meses >= 24 and p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "VENTAJA RESPALDADA"
    return "EVIDENCIA INSUFICIENTE: continuar"


def recalcular_decision(r: Registro) -> str:
    if r.esquema == "fuera_de_muestra":
        return decision_fuera_de_muestra(r.p_conjunto, r.p_btc, r.exceso_x2)
    if r.p_conjunto is None or r.p_btc is None:
        if r.meses >= 12:  # aquí el código congelado habría decidido con P = 0,5 por defecto
            raise ErrorVerificacion("CONTRADICCION", f"bootstrap no aplicable con {r.meses:.2f} meses: la decisión "
                                                     "dependería del 0,5 por defecto")
        return DECISIONES_PAPEL[0]
    return decision_papel(r.meses, r.p_conjunto, r.p_btc, r.exceso_x2)


# ---------- integridad contra archivos reales ----------
ARCHIVOS = {"fuera_de_muestra": {"prerregistro_archivo": "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                                 "script": "experimentos/fuera_de_muestra_T.py",
                                 **{f"manifiesto_{s}": f"datos/{s}/MANIFIESTO.json" for s in SIMBOLOS}}}


def huella_codigo(src: Path) -> str:
    """Mismo algoritmo que tendencia.papel.huella_codigo (las pruebas lo comparan con el original)."""
    py = sorted(src.glob("*.py"))
    if not py:
        raise ErrorVerificacion("AUSENTE", f"no hay archivos .py en {src}")
    h = hashlib.sha256()
    for p in py:
        h.update(p.name.encode() + b"\0" + p.read_bytes())
    return h.hexdigest()


def hash_reglas(ruta: Path) -> str:
    """Mismo algoritmo que tendencia.papel.hash_prerregistro, aplicado al JSON congelado de las reglas."""
    obj, _ = cargar(ruta)
    return _sha(json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode())


def parametros_script(datos: bytes) -> dict:
    """DESDE, HASTA, DIAS y CODIGO del script, leídos con ast (sin ejecutarlo)."""
    out: dict = {}
    for n in ast.parse(datos).body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Tuple):
            nombres = [getattr(t, "id", None) for t in n.targets[0].elts]
            if nombres == ["DESDE", "HASTA", "DIAS"]:
                out.update(zip(nombres, ast.literal_eval(n.value), strict=True))
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and getattr(n.targets[0], "id", None) == "CODIGO":
            out["CODIGO"] = ast.literal_eval(n.value)
    for k in ("DESDE", "HASTA", "DIAS", "CODIGO"):
        if k not in out:
            raise ErrorVerificacion("AUSENTE", f"el script no define {k}")
    return out


def inicio_prerregistrado(raiz: Path, rama: str) -> str:
    """Primera ejecución de la rama según el prerregistro: A, literal; B, RESERVADO_FIN (src/tendencia/datos.py, ast) +
    mayor ventana + 1 día, que además debe ser la fecha entre paréntesis del texto del prerregistro."""
    reglas, _ = cargar(raiz / "papel" / "prerregistro_papel.json")
    texto = _texto(reglas, f"ramas.{rama}.primera_ejecucion")
    if rama == "A":
        return texto
    fin = next(ast.literal_eval(n.value) for n in ast.parse((raiz / "src" / "tendencia" / "datos.py").read_bytes()).body
               if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", None) == "RESERVADO_FIN")
    mayor = max(max(e["ventanas"]) for e in _clave(reglas, "estrategias").values())
    calculada = (dt.date.fromisoformat(fin) + dt.timedelta(days=mayor + 1)).isoformat()
    if f"({calculada})" not in texto:
        raise ErrorVerificacion("CONTRADICCION", f"rama B: el código da {calculada}, el prerregistro dice {texto!r}")
    return calculada


def _datos_sha(man: dict) -> str:
    """Mismo algoritmo que papel/corte.py:_datos_sha (ruta y SHA-256 de cada archivo del manifiesto)."""
    return _sha(json.dumps(sorted((a["ruta"], a["sha256"]) for a in man["archivos"])).encode())


def comprobar_corte(obj: dict, r: Registro, dir_corte: Path) -> dict:
    """Archivos del directorio del corte (S7): manifiestos de datos y tablas de decisiones (filas, columnas, días)."""
    hechos: dict[str, str] = {}
    for s in SIMBOLOS:
        man, _ = cargar(dir_corte / "datos" / s / "MANIFIESTO.json")
        if _datos_sha(man) != obj["datos_sha256"][s]:
            raise ErrorVerificacion("HASH", f"datos_sha256.{s} no coincide con datos/{s}/MANIFIESTO.json del corte")
        hechos[f"datos_{s}"] = f"datos/{s}/MANIFIESTO.json"
        ruta = dir_corte / f"decisiones_{s}.csv"
        try:
            with ruta.open(encoding="utf-8", newline="") as fh:
                lector = csv.reader(fh)
                cabecera = next(lector, None)
                filas = list(lector)
        except OSError as e:
            raise ErrorVerificacion("AUSENTE", f"no se puede leer {ruta}: {e}") from e
        if tuple(cabecera or ()) != COLUMNAS_DECISIONES:
            raise ErrorVerificacion("ESQUEMA", f"{ruta.name}: columnas {cabecera} ≠ {list(COLUMNAS_DECISIONES)}")
        if len(filas) != r.dias:
            raise ErrorVerificacion("CONTRADICCION", f"{ruta.name}: {len(filas)} filas, la evaluación tiene {r.dias} días")
        esperado = [(dt.date.fromisoformat(obj["inicio"]) + dt.timedelta(days=i)).isoformat() for i in range(r.dias)]
        if [f[0] if f else None for f in filas] != esperado:
            raise ErrorVerificacion("CONTRADICCION", f"{ruta.name}: los días no son los consecutivos desde el inicio")
        try:
            dicts = [{c: (v if c in COLUMNAS_TEXTO else float(v)) for c, v in zip(COLUMNAS_DECISIONES, f, strict=True)}
                     for f in filas]
        except ValueError as e:
            raise ErrorVerificacion("TIPO", f"{ruta.name}: fila mal formada: {e}") from e
        if _sha(json.dumps(dicts, sort_keys=True).encode()) != obj["decisiones_sha256"][s]:
            raise ErrorVerificacion("HASH", f"decisiones_sha256.{s} no coincide con {ruta.name}")
        hechos[f"decisiones_{s}"] = f"{ruta.name}: {len(filas)} filas"
    return hechos


def cargar_manifiesto(especificacion: str | Path) -> dict[str, str]:
    """«RUTA» en formato sha256sum, o «RUTA#CLAVE» de un JSON {ruta: sha256 | {"sha256": …}}."""
    ruta, _, clave = str(especificacion).partition("#")
    if clave or ruta.endswith(".json"):
        obj, _ = cargar(ruta)
        d = _clave(obj, clave) if clave else obj
        if not isinstance(d, dict):
            raise ErrorVerificacion("TIPO", f"{especificacion}: se esperaba un objeto ruta → sha256")
        return {k: _sha_campo({"x": v.get("sha256") if isinstance(v, dict) else v}, "x") for k, v in d.items()}
    out: dict[str, str] = {}
    try:
        lineas = Path(ruta).read_text(encoding="utf-8").splitlines()
    except OSError as e:
        raise ErrorVerificacion("AUSENTE", f"no se puede leer el manifiesto {ruta}: {e}") from e
    for n, linea in enumerate(lineas, 1):
        if not linea.strip():
            continue
        h, sep, r_ = linea.partition("  ")
        if not sep or len(h) != 64:
            raise ErrorVerificacion("TIPO", f"{ruta}: línea {n} no tiene formato sha256sum")
        if r_ in out and out[r_] != h:
            raise ErrorVerificacion("CONTRADICCION", f"{ruta}: {r_} figura dos veces con hashes distintos")
        out[r_] = _sha_campo({"x": h}, "x")
    return out


def _comprobar_manifiesto(ruta: Path) -> int:
    """Cada archivo listado en un MANIFIESTO.json contra su SHA-256 (lee bytes de datos: solo con --datos)."""
    man, _ = cargar(ruta)
    archivos = _clave(man, "archivos")
    if not isinstance(archivos, list) or not archivos:
        raise ErrorVerificacion("TIPO", f"{ruta}: 'archivos' debe ser una lista no vacía")
    for a in archivos:
        p = ruta.parent / _texto(a, "ruta")
        if not p.is_file():
            raise ErrorVerificacion("AUSENTE", f"{p}: listado en el manifiesto y ausente")
        if _sha(p.read_bytes()) != _sha_campo(a, "sha256"):
            raise ErrorVerificacion("HASH", f"{p}: no coincide con su manifiesto")
    return len(archivos)


def comprobar_integridad(r: Registro, obj: dict, raiz: Path, datos: bool = False) -> tuple[dict, list[str]]:  # noqa: C901
    """Recalcula desde ``raiz`` cada hash que declara el resultado. Devuelve ({nombre: origen}, no_comprobado)."""
    hechos: dict[str, str] = {}

    def igual(nombre: str, real: str, origen: str) -> None:
        if real != r.hashes[nombre]:
            raise ErrorVerificacion("HASH", f"{nombre}: {origen} da {real[:12]}…, el resultado declara "
                                            f"{r.hashes[nombre][:12]}…")
        hechos[nombre] = origen

    rutas: dict[str, str] = {}  # ruta relativa → SHA-256 de cada archivo leído (para los manifiestos)
    for nombre, rel in ARCHIVOS.get(r.esquema, {}).items():
        p = raiz / rel
        if not p.is_file():
            raise ErrorVerificacion("AUSENTE", f"{nombre}: falta {p}")
        rutas[rel] = _sha(p.read_bytes())
        igual(nombre, rutas[rel], rel)
    igual("codigo", huella_codigo(raiz / "src" / "tendencia"), "huella de src/tendencia/*.py")
    for py in sorted((raiz / "src" / "tendencia").glob("*.py")):
        rutas[f"src/tendencia/{py.name}"] = _sha(py.read_bytes())
    no_comprobado = []
    if r.esquema == "fuera_de_muestra":
        par = parametros_script((raiz / ARCHIVOS["fuera_de_muestra"]["script"]).read_bytes())
        if par["CODIGO"] != r.hashes["codigo"]:
            raise ErrorVerificacion("CONTRADICCION", f"codigo_sha256 ({r.hashes['codigo'][:12]}…) ≠ CODIGO fijado en el "
                                                     f"script verificado ({par['CODIGO'][:12]}…)")
        hechos["codigo_igual_al_del_script"] = "CODIGO del script (ast)"
        if obj["ventana"] != [par["DESDE"], par["HASTA"]] or r.dias != par["DIAS"]:
            raise ErrorVerificacion("CONTRADICCION", f"ventana {obj['ventana']} / días {r.dias} ≠ los del script "
                                                     f"verificado ({par['DESDE']}–{par['HASTA']}, {par['DIAS']})")
        hechos["ventana_y_dias"] = "constantes del script verificado (ast)"
        if datos:
            for s in SIMBOLOS:
                hechos[f"datos_{s}"] = f"{_comprobar_manifiesto(raiz / ARCHIVOS['fuera_de_muestra'][f'manifiesto_{s}'])} archivos"
        else:
            no_comprobado.append("archivos de datos listados en los manifiestos (no se leen sin --datos)")
    else:
        igual("reglas_canonicas", hash_reglas(raiz / "papel" / "prerregistro_papel.json"),
              "papel/prerregistro_papel.json canonizado")
        rutas["papel/prerregistro_papel.json"] = _sha((raiz / "papel" / "prerregistro_papel.json").read_bytes())
        inicio = obj["inicio"]
        if inicio != inicio_prerregistrado(raiz, obj["rama"]):
            raise ErrorVerificacion("CONTRADICCION", f"inicio {inicio} ≠ primera ejecución prerregistrada de la rama "
                                                     f"{obj['rama']} ({inicio_prerregistrado(raiz, obj['rama'])})")
        hechos["inicio_prerregistrado"] = f"rama {obj['rama']}"
        if r.esquema == "papel_corte":
            igual("reglas_corte", r.hashes["reglas_canonicas"], "igual a reglas_canonicas")
            igual("codigo_corte", r.hashes["codigo"], "igual a codigo")
    hechos["_rutas"] = rutas  # type: ignore[assignment]
    return hechos, no_comprobado


def comprobar_registro(obj: dict, resultado_sha256: str, registro: Path) -> str:
    """REGISTRO.jsonl de corte.py: cadena linea_anterior_sha256 y entrada con el SHA-256 de ESTE archivo (D6)."""
    try:
        texto = registro.read_text(encoding="utf-8")
    except OSError as e:
        raise ErrorVerificacion("AUSENTE", f"no se puede leer {registro}: {e}") from e
    if not texto.endswith("\n"):
        raise ErrorVerificacion("REGISTRO", "la última línea del registro está incompleta")
    anterior, propias = None, []
    for n, linea in enumerate(texto.split("\n")[:-1], 1):
        try:
            x = json.loads(linea, object_pairs_hook=_sin_duplicados)
        except ValueError as e:
            raise ErrorVerificacion("REGISTRO", f"línea {n} ilegible") from e
        if not isinstance(x, dict) or x.get("linea_anterior_sha256") != anterior:
            raise ErrorVerificacion("REGISTRO", f"cadena rota en la línea {n}")
        anterior = _sha(linea.encode())
        if x.get("corte") == obj["corte_exclusivo"]:
            propias.append((n, x))
    evaluadas = [n for n, x in propias if x.get("estado") == "EVALUADO"]
    if len(evaluadas) > 1:
        raise ErrorVerificacion("REGISTRO", f"el corte figura EVALUADO más de una vez (líneas {evaluadas})")
    coinciden = [n for n, x in propias if x.get("resultado_sha256") == resultado_sha256 and x.get("estado") == obj["estado"]]
    if not coinciden:
        raise ErrorVerificacion("REGISTRO", f"ninguna línea del registro tiene este archivo ({resultado_sha256[:12]}…) "
                                            f"con estado {obj['estado']!r}")
    if obj["estado"] == "EVALUADO" and coinciden[-1] != propias[-1][0]:
        raise ErrorVerificacion("REGISTRO", "hay líneas del corte posteriores a su evaluación")
    return f"línea {coinciden[-1]} de {registro.name}"


# ---------- verificación ----------
SEMANTICA = {"fuera_de_muestra": {"prerregistro_archivo", "script", "codigo", "manifiesto_BTCUSDT", "manifiesto_ETHUSDT"},
             "papel_evaluar": {"reglas_canonicas", "codigo"},
             "papel_corte": {"reglas_canonicas", "codigo", "reglas_corte", "codigo_corte"}}


def verificar(obj: object, raiz: str | Path | None = None, resultado_sha256: str | None = None,  # noqa: C901
              registro: str | Path | None = None, esperados: dict[str, str] | None = None,
              datos: bool = False, resultado_sha256_esperado: str | None = None,
              manifiesto: dict[str, str] | None = None, dir_corte: str | Path | None = None,
              ruta_resultado: str | Path | None = None) -> dict:
    """Informe si todo es coherente; si no, ErrorVerificacion. ``nivel`` = VERIFICADO solo si cada hash declarado se
    recalculó desde ``raiz`` (y, para un corte, si su archivo figura en ``registro``)."""
    if resultado_sha256_esperado is not None and resultado_sha256 != resultado_sha256_esperado:
        raise ErrorVerificacion("HASH", f"el archivo ({(resultado_sha256 or 'sin hash')[:12]}…) no es el presellado "
                                        f"({resultado_sha256_esperado[:12]}…)")
    r = normalizar(obj)  # type: ignore[arg-type]
    esperados = esperados or {}
    for nombre, valor in esperados.items():
        if nombre not in SEMANTICA[r.esquema]:
            otros = [e for e, s in SEMANTICA.items() if nombre in s]
            raise ErrorVerificacion("HASH_SEMANTICA", f"'{nombre}' no se aplica al esquema {r.esquema} (se aplica a {otros})")
        if r.hashes[nombre] != valor:
            raise ErrorVerificacion("HASH", f"{nombre}: el resultado dice {r.hashes[nombre][:12]}…, la referencia "
                                            f"declarada es {valor[:12]}…")
    recalculada = recalcular_decision(r)
    if recalculada != r.decision:
        raise ErrorVerificacion("CONTRADICCION", f"decisión registrada {r.decision!r} ≠ la que dan sus propias cifras "
                                                 f"con la regla congelada ({recalculada!r})")
    integridad, no_comprobado = ({}, ["ningún hash recalculado desde archivos (falta --raiz)"])
    if raiz is not None:
        integridad, no_comprobado = comprobar_integridad(r, obj, Path(raiz), datos)  # type: ignore[arg-type]
    rutas = integridad.pop("_rutas", {})
    completo = raiz is not None
    contraste: dict = {"coinciden": [], "no_listados": []}
    if manifiesto is not None:  # admite {ruta: hex} o {ruta: {"sha256": hex}}; formato validado
        manifiesto = {k: _sha_campo({"x": v.get("sha256") if isinstance(v, dict) else v}, "x")
                      for k, v in manifiesto.items()}
        if raiz is None or ruta_resultado is None or resultado_sha256 is None:
            raise ErrorVerificacion("AUSENTE", "el contraste con un manifiesto exige --raiz y el archivo del resultado")
        try:
            rel = Path(ruta_resultado).resolve().relative_to(Path(raiz).resolve()).as_posix()
        except ValueError as e:
            raise ErrorVerificacion("CONTRADICCION", "el resultado no está dentro de --raiz: el manifiesto no lo describe") from e
        if rel not in manifiesto:
            raise ErrorVerificacion("AUSENTE", f"el manifiesto no describe este resultado ({rel})")
        for ruta_rel, sha in {**rutas, rel: resultado_sha256}.items():
            if ruta_rel in manifiesto:
                if manifiesto[ruta_rel] != sha:
                    raise ErrorVerificacion("HASH_MANIFIESTO", f"{ruta_rel}: {sha[:12]}… ≠ manifiesto {manifiesto[ruta_rel][:12]}…")
                contraste["coinciden"].append(ruta_rel)
            else:
                contraste["no_listados"].append(ruta_rel)
    if r.esquema == "papel_corte":
        if dir_corte is not None:
            integridad.update(comprobar_corte(obj, r, Path(dir_corte)))  # type: ignore[arg-type]
        else:
            completo = False
            no_comprobado.append("datos y tablas de decisiones del directorio del corte")
        if registro is not None:
            if resultado_sha256 is None:
                raise ErrorVerificacion("AUSENTE", "para comprobar el registro hace falta el SHA-256 del archivo")
            integridad["archivo_en_registro"] = comprobar_registro(obj, resultado_sha256, Path(registro))  # type: ignore[arg-type]
        else:
            completo = False
            no_comprobado.append("REGISTRO.jsonl del corte (falta --registro)")
    elif registro is not None:
        raise ErrorVerificacion("HASH_SEMANTICA", f"--registro solo se aplica a cortes, no a {r.esquema}")
    return {"version": VERSION, "nivel": "VERIFICADO" if completo else "COHERENTE_SIN_INTEGRIDAD",
            "esquema": r.esquema, "resultado_sha256": resultado_sha256,
            "naturaleza": "EVALUADO_SIN_DECISION" if r.decision == DECISIONES_PAPEL[0] else "EVALUADO_CON_DECISION",
            "decision": r.decision, "decision_recalculada": recalculada, "exceso_anual": r.exceso_anual,
            "ic90": list(r.ic90) if r.ic90 else None, "p_conjunto": r.p_conjunto, "p_btc": r.p_btc,
            "exceso_x2": r.exceso_x2, "dias": r.dias, "hashes_declarados": r.hashes,
            "integridad_desde_archivos": integridad, "referencias_declaradas_coinciden": sorted(esperados),
            "resultado_sha256_esperado_coincide": resultado_sha256_esperado is not None,
            "contraste_con_manifiestos": contraste if manifiesto is not None else None,
            "autenticidad": AUTENTICIDAD, "no_comprobado": no_comprobado}


def verificar_archivo(ruta: str | Path, **kw) -> dict:  # type: ignore[no-untyped-def]
    obj, sha = cargar(ruta)
    if isinstance(obj, dict) and "corte_exclusivo" in obj:
        kw.setdefault("dir_corte", Path(ruta).parent)
    return verificar(obj, resultado_sha256=sha, ruta_resultado=ruta, **kw)


def comparar_completo(a: object, b: object, tolerancia: float = 0.0, ruta: str = "") -> list[str]:
    """Todas las hojas: misma estructura, mismas claves, mismos textos y booleanos; números con |a − b| ≤ tolerancia."""
    if isinstance(a, bool) or isinstance(b, bool) or a is None or b is None or isinstance(a, str) or isinstance(b, str):
        return [] if (type(a) is type(b) and a == b) else [f"{ruta or 'raíz'}: {a!r} ≠ {b!r}"]
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        ok = math.isfinite(a) and math.isfinite(b) and abs(a - b) <= tolerancia
        return [] if ok else [f"{ruta}: {a!r} ≠ {b!r} (tolerancia {tolerancia})"]
    if isinstance(a, dict) and isinstance(b, dict):
        dif = [f"{ruta}.{k}: solo en {'el original' if k in a else 'la reproducción'}" for k in sorted(set(a) ^ set(b))]
        for k in sorted(set(a) & set(b)):
            dif += comparar_completo(a[k], b[k], tolerancia, f"{ruta}.{k}" if ruta else k)
        return dif
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [f"{ruta}: longitudes {len(a)} ≠ {len(b)}"]
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in comparar_completo(x, y, tolerancia, f"{ruta}[{i}]")]
    return [f"{ruta}: tipos distintos ({type(a).__name__} / {type(b).__name__})"]


def reproducir(ruta: str | Path, reproduccion: object, tolerancia: float = 0.0, **kw) -> dict:  # type: ignore[no-untyped-def]
    """REPRODUCIDO solo si: el original es VERIFICADO; la reproducción pasa la validación estructural del mismo
    esquema; y comparar_completo no encuentra diferencias con la tolerancia EXPLÍCITA. Si no, NO_REPRODUCIDO o error."""
    if isinstance(tolerancia, bool) or not isinstance(tolerancia, (int, float)) or not math.isfinite(tolerancia) \
            or tolerancia < 0:
        raise ErrorVerificacion("VALOR", f"tolerancia inválida: {tolerancia!r}")
    inf = verificar_archivo(ruta, **kw)
    if inf["nivel"] != "VERIFICADO":
        raise ErrorVerificacion("INTEGRIDAD", f"no se declara REPRODUCIDO sobre un original {inf['nivel']}")
    original, _ = cargar(ruta)
    rr = normalizar(reproduccion)  # type: ignore[arg-type]
    if rr.esquema != inf["esquema"]:
        raise ErrorVerificacion("ESQUEMA", f"la reproducción es {rr.esquema}, el original {inf['esquema']}")
    dif = comparar_completo(original, reproduccion, float(tolerancia))
    return {**inf, "nivel": "NO_REPRODUCIDO" if dif else "REPRODUCIDO", "tolerancia": float(tolerancia),
            "discrepancias": dif}


def comparar(a: object, b: object, tolerancia: float = 0.0) -> list[str]:
    """Evidencia contradictoria entre dos registros del MISMO experimento (p. ej. el resultado y una reproducción
    independiente). Devuelve la lista de discrepancias; vacía = coherentes. Con tolerancia 0 exige igualdad exacta."""
    ra, rb = normalizar(a), normalizar(b)  # type: ignore[arg-type]
    dif = []
    if ra.esquema != rb.esquema:
        dif.append(f"esquemas distintos ({ra.esquema} / {rb.esquema})")
    for campo in ("decision", "dias"):
        if getattr(ra, campo) != getattr(rb, campo):
            dif.append(f"{campo}: {getattr(ra, campo)!r} ≠ {getattr(rb, campo)!r}")
    for campo in ("exceso_anual", "p_conjunto", "p_btc", "exceso_x2"):
        x, y = getattr(ra, campo), getattr(rb, campo)
        if (x is None) != (y is None) or (x is not None and abs(x - y) > tolerancia):
            dif.append(f"{campo}: {x!r} ≠ {y!r}")
    if (ra.ic90 is None) != (rb.ic90 is None) or (
            ra.ic90 and any(abs(x - y) > tolerancia for x, y in zip(ra.ic90, rb.ic90))):
        dif.append(f"ic90: {ra.ic90} ≠ {rb.ic90}")
    for k in sorted(set(ra.hashes) | set(rb.hashes)):
        if ra.hashes.get(k) != rb.hashes.get(k):
            dif.append(f"hash {k}: {ra.hashes.get(k)} ≠ {rb.hashes.get(k)}")
    if dif and dif[0].startswith("esquemas distintos"):
        return dif
    return dif + comparar_completo(a, b, tolerancia)  # v0.3: también todas las demás hojas (S5)


def main(argv: list[str]) -> int:
    if not argv or argv[0].startswith("--"):
        print(__doc__)
        return 2
    ruta, kw, i = argv[0], {}, 1
    try:
        while i < len(argv):
            if argv[i] == "--datos":
                kw["datos"], i = True, i + 1
            elif argv[i] in ("--raiz", "--registro", "--esperados") and i + 1 < len(argv):
                kw[argv[i][2:]], i = argv[i + 1], i + 2
            elif argv[i] == "--resultado-sha256" and i + 1 < len(argv):
                kw["resultado_sha256_esperado"], i = argv[i + 1], i + 2
            elif argv[i] == "--manifiesto" and i + 1 < len(argv):
                kw.setdefault("manifiestos", []).append(argv[i + 1])
                i += 2
            elif argv[i] in ("--reproduccion", "--tolerancia") and i + 1 < len(argv):
                kw[argv[i][2:]], i = argv[i + 1], i + 2
            else:
                print(__doc__)
                return 2
        if "esperados" in kw:
            kw["esperados"], _ = cargar(kw["esperados"])
        if "manifiestos" in kw:
            unido: dict[str, str] = {}
            for m in kw.pop("manifiestos"):
                for k, v in cargar_manifiesto(m).items():
                    if unido.get(k, v) != v:
                        raise ErrorVerificacion("CONTRADICCION", f"los manifiestos discrepan sobre {k}")
                    unido[k] = v
            kw["manifiesto"] = unido
        if "tolerancia" in kw and "reproduccion" not in kw:
            raise ErrorVerificacion("VALOR", "--tolerancia solo se usa con --reproduccion")
        if "reproduccion" in kw:
            otra, _ = cargar(kw.pop("reproduccion"))
            try:
                tol = float(kw.pop("tolerancia", "0"))
            except ValueError as e:
                raise ErrorVerificacion("VALOR", "tolerancia no numérica") from e
            informe = reproducir(ruta, otra, tol, **kw)
        else:
            informe = verificar_archivo(ruta, **kw)
    except ErrorVerificacion as e:
        resultado = "NO_EVALUABLE" if e.codigo == "SIN_EVALUACION" else "RECHAZADO"
        print(json.dumps({"version": VERSION, "resultado": resultado, "codigo": e.codigo, "detalle": e.detalle},
                         ensure_ascii=False))
        return SALIDAS[resultado]
    print(json.dumps({"resultado": informe["nivel"], **informe}, ensure_ascii=False, indent=1))
    return SALIDAS[informe["nivel"]]


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
