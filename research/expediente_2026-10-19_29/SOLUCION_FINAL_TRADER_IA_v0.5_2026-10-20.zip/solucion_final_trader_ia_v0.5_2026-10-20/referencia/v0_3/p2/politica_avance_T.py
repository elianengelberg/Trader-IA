"""Política de avance de T, v0.3 — PROPUESTA, NO APROBADA. Solo biblioteca estándar; no lee datos ni escribe nada.

Cinco dimensiones que no se mezclan (v0.3 agrega la primera y la quinta; defectos S1–S5 de v0.2 en DICTAMEN_P2_FINAL.md):
  0. validez de la evidencia: lo que dice P1 (VERIFICADO, REPRODUCIDO, COHERENTE_SIN_INTEGRIDAD, NO_EVALUABLE,
     RECHAZADO, NO_REPRODUCIDO). Solo VERIFICADO o REPRODUCIDO cuentan como evidencia; ya no se puede clasificar una
     etiqueta suelta sin resultado verificado detrás (S1).
  1. etiqueta estadística: texto LITERAL del productor congelado, solo si la evidencia es válida; nunca se reescribe.
  2. robustez: diagnóstico INFORMATIVO de R1 y R3. R1/R3 son argumentos OBLIGATORIOS (sin valor por defecto, S2):
     NO_DEFINIDO solo si no hay definición aprobada para T de ese criterio; NO_EVALUADO si la hay pero no se evaluó;
     (CUMPLE|NO_CUMPLE, id) solo con una definición aprobada para T (registro hoy VACÍO).
  3. decisión de avance: depende solo de la clase de la etiqueta y nombra la etapa (hoy NO_DEFINIDA).
  4. autorización de ejecución: la política NUNCA la otorga. Solo registra si hay una autorización humana externa y si
     es coherente con la etapa, el resultado y la clase; si no lo es, CONTRADICTORIA (S3). Registro hoy VACÍO.

Fechas: ISO 8601 estrictas (S4). Una definición aprobada en o después del inicio de la ventana evaluada es post hoc.
"""
from __future__ import annotations

import datetime as dt
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "p1"))
import verificar_reproduccion_T as V  # noqa: E402  (verificador de P1, v0.3)

VERSION = "POLITICA_AVANCE_T v0.3"
ESTADO_VERSION = "PROPUESTA: no aprobada"

ETIQUETAS = {
    # experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)
    "RESPALDADA FUERA DE MUESTRA": "RESPALDADA",
    "NO RESPALDADA": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE": "INSUFICIENTE",
    # tendencia.papel.decidir (código 73b22f3e…), citada; no se importa ni se altera
    "VENTAJA RESPALDADA": "RESPALDADA",
    "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
    "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO",
}
VALIDEZ = ("VERIFICADO", "REPRODUCIDO", "COHERENTE_SIN_INTEGRIDAD", "NO_EVALUABLE", "RECHAZADO", "NO_REPRODUCIDO")
VALIDA = ("VERIFICADO", "REPRODUCIDO")
CAMPOS_DEFINICION = ("id", "criterio", "aplica_a", "texto_sha256", "aprobada_utc", "aprobada_por")
CAMPOS_AUTORIZACION = ("id", "etapa", "resultado_sha256", "otorgada_por", "otorgada_utc", "texto_sha256")

# Registros que solo una decisión humana puede llenar. VACÍOS: no hay definición de R1/R3 para T (A1, A2), ni etapa
# siguiente definida (A5), ni ninguna autorización. Las pruebas usan registros SINTÉTICOS para recorrer las ramas.
DEFINICIONES_APROBADAS: dict[str, dict] = {}
ETAPAS_DEFINIDAS: dict[str, str] = {}
AUTORIZACIONES: dict[str, dict] = {}


class ErrorPolitica(ValueError):
    pass


def _fecha_hora(valor: object, que: str) -> dt.datetime:
    if not isinstance(valor, str):
        raise ErrorPolitica(f"{que}: se esperaba una fecha y hora ISO 8601 con zona, hay {valor!r}")
    try:
        x = dt.datetime.fromisoformat(valor.replace("Z", "+00:00"))
    except ValueError as e:
        raise ErrorPolitica(f"{que}: fecha y hora inválida {valor!r}") from e
    if x.tzinfo is None:
        raise ErrorPolitica(f"{que}: falta la zona horaria en {valor!r}")
    return x


def _fecha(valor: object, que: str) -> dt.date:
    try:
        if not isinstance(valor, str) or dt.date.fromisoformat(valor).isoformat() != valor:
            raise ValueError
        return dt.date.fromisoformat(valor)
    except ValueError as e:
        raise ErrorPolitica(f"{que}: se esperaba una fecha AAAA-MM-DD, hay {valor!r}") from e


def _hex64(valor: object, que: str) -> str:
    if not (isinstance(valor, str) and len(valor) == 64 and all(c in "0123456789abcdef" for c in valor)):
        raise ErrorPolitica(f"{que}: se esperaba un SHA-256 hexadecimal, hay {valor!r}")
    return valor


def _registro_valido(d: dict, campos: tuple[str, ...], que: str) -> None:
    if any(not isinstance(d.get(c), str) or not d.get(c) for c in campos) or set(d) != set(campos):
        raise ErrorPolitica(f"{que}: debe tener exactamente los campos {campos}")
    _hex64(d["texto_sha256"], f"{que}.texto_sha256")


def evidencia(validez: str, etiqueta: str | None = None, resultado_sha256: str | None = None,
              fecha_inicio_ventana: str | None = None, motivo: str = "") -> dict:
    """Evidencia explícita. Con validez VERIFICADO o REPRODUCIDO exige etiqueta literal, hash del resultado y fecha de
    inicio de la ventana; con cualquier otra validez, la etiqueta (si la hay) queda solo como «declarada»."""
    if validez not in VALIDEZ:
        raise ErrorPolitica(f"validez desconocida: {validez!r}")
    if validez in VALIDA:
        if etiqueta not in ETIQUETAS:
            raise ErrorPolitica(f"etiqueta estadística desconocida (se exige el texto literal del productor): {etiqueta!r}")
        _hex64(resultado_sha256, "resultado_sha256")
        _fecha(fecha_inicio_ventana, "fecha_inicio_ventana")
    return {"validez": validez, "etiqueta": etiqueta, "resultado_sha256": resultado_sha256,
            "fecha_inicio_ventana": fecha_inicio_ventana, "motivo": motivo}


def _r(nombre: str, valor: object, definiciones: dict[str, dict], inicio: str | None) -> dict:
    propias = [k for k, d in definiciones.items() if d.get("criterio") == nombre and d.get("aplica_a") == "T"]
    if valor == "NO_DEFINIDO":
        if propias:
            raise ErrorPolitica(f"{nombre}: hay una definición aprobada para T ({propias}); no puede ser NO_DEFINIDO "
                                "(use NO_EVALUADO o una evaluación)")
        return {"estado": "NO_DEFINIDO", "definicion": None, "post_hoc": None}
    if valor == "NO_EVALUADO":
        if not propias:
            raise ErrorPolitica(f"{nombre}: NO_EVALUADO exige una definición aprobada para T; no la hay (NO_DEFINIDO)")
        return {"estado": "NO_EVALUADO", "definicion": None, "post_hoc": None}
    if not (isinstance(valor, tuple) and len(valor) == 2 and valor[0] in ("CUMPLE", "NO_CUMPLE")
            and isinstance(valor[1], str)):
        raise ErrorPolitica(f"{nombre}: se espera NO_DEFINIDO, NO_EVALUADO o (CUMPLE|NO_CUMPLE, id), hay {valor!r}")
    estado, ident = valor
    d = definiciones.get(ident)
    if d is None:
        raise ErrorPolitica(f"{nombre}: la definición {ident!r} no está aprobada para T")
    _registro_valido(d, CAMPOS_DEFINICION, f"{nombre}: definición {ident!r}")
    if d["criterio"] != nombre or d["aplica_a"] != "T":
        raise ErrorPolitica(f"{nombre}: la definición {ident!r} es de {d['criterio']} para {d['aplica_a']}, no de "
                            f"{nombre} para T (no se trasladan métricas de otro experimento)")
    aprobada = _fecha_hora(d["aprobada_utc"], f"{nombre}: aprobada_utc")
    post_hoc = inicio is None or aprobada.astimezone(dt.UTC).date() >= _fecha(inicio, "fecha_inicio_ventana")
    return {"estado": estado, "definicion": ident, "post_hoc": post_hoc}


def robustez(e1: str, e3: str) -> str:
    """ROBUSTA solo si ambas se cumplen; NO_ROBUSTA si alguna falla; INDETERMINADA en otro caso (NO_DEFINIDO o
    NO_EVALUADO). La regla «todas» viene de E3 v3 §6.3 y es la ambigüedad A6."""
    if "NO_CUMPLE" in (e1, e3):
        return "NO_ROBUSTA"
    if e1 == e3 == "CUMPLE":
        return "ROBUSTA"
    return "INDETERMINADA"


def aplicar(ev: dict, r1: object, r3: object, *, etapa: str | None = None, autorizacion: str | None = None,
            exceso_no_positivo: bool | None = None, definiciones: dict[str, dict] | None = None,
            etapas: dict[str, str] | None = None, autorizaciones: dict[str, dict] | None = None) -> dict:
    """``ev`` viene de ``evidencia()`` o de ``desde_resultado``. r1 y r3 son obligatorios. Determinista."""
    if not isinstance(ev, dict) or set(ev) != {"validez", "etiqueta", "resultado_sha256", "fecha_inicio_ventana",
                                               "motivo"}:
        raise ErrorPolitica("se requiere una evidencia construida con evidencia() o desde_resultado()")
    ev = evidencia(**ev)  # revalida
    if exceso_no_positivo is not None and not isinstance(exceso_no_positivo, bool):
        raise ErrorPolitica(f"exceso_no_positivo debe ser true, false o null, es {exceso_no_positivo!r}")
    definiciones = DEFINICIONES_APROBADAS if definiciones is None else definiciones
    etapas = ETAPAS_DEFINIDAS if etapas is None else etapas
    autorizaciones = AUTORIZACIONES if autorizaciones is None else autorizaciones
    if etapa is not None and etapa not in etapas:
        raise ErrorPolitica(f"etapa {etapa!r} no definida (A5); no se inventan etapas")
    ev1, ev3 = (_r(n, v, definiciones, ev["fecha_inicio_ventana"]) for n, v in (("R1", r1), ("R3", r3)))
    valida = ev["validez"] in VALIDA
    clase = ETIQUETAS[ev["etiqueta"]] if valida else "SIN_EVIDENCIA_VALIDA"
    nombre_etapa = etapa or "NO_DEFINIDA"
    advertencias: list[str] = []
    if not valida:
        avance = {"resultado": "NO_CANDIDATA", "etapa": nombre_etapa,
                  "texto": f"sin evidencia válida ({ev['validez']}): no hay etiqueta que evaluar"}
        rob = "NO_APLICA"
        if ev1["estado"] in ("CUMPLE", "NO_CUMPLE") or ev3["estado"] in ("CUMPLE", "NO_CUMPLE"):
            advertencias.append("R1/R3 evaluados sobre una evidencia no válida: se ignoran")
    else:
        rob = robustez(ev1["estado"], ev3["estado"])
        if clase == "RESPALDADA":
            avance = {"resultado": "CANDIDATA_A_REVISION_HUMANA", "etapa": nombre_etapa,
                      "texto": f"T es candidata a que una persona decida si pasa a la etapa {nombre_etapa}"}
        else:
            avance = {"resultado": "NO_CANDIDATA", "etapa": nombre_etapa,
                      "texto": (f"T no es candidata a la etapa {etapa}" if etapa else
                                "T no es candidata a una etapa posterior; esa etapa no está definida (A5): no es una "
                                "decisión universal; la acción vigente es la de la propia etiqueta")}
        if clase == "RESPALDADA" and rob != "ROBUSTA":
            advertencias.append(f"robustez {rob}: dato para la decisión humana; no veta la candidatura (A3)")
    if "NO_DEFINIDO" in (ev1["estado"], ev3["estado"]):
        advertencias.append("R1/R3 sin definición aprobada para T (A1, A2)")
    if any(e["post_hoc"] for e in (ev1, ev3)):
        advertencias.append("R1/R3 evaluados con una definición posterior al inicio de la ventana: POST HOC")
    # autorización: la política nunca la otorga; solo constata un registro humano externo y su coherencia
    if autorizacion is None:
        aut = {"estado": "NO_OTORGADA", "id": None, "motivo": "no hay autorización humana registrada"}
    else:
        a = autorizaciones.get(autorizacion)
        if a is None:
            raise ErrorPolitica(f"autorización {autorizacion!r} desconocida")
        _registro_valido(a, CAMPOS_AUTORIZACION, f"autorización {autorizacion!r}")
        _fecha_hora(a["otorgada_utc"], "otorgada_utc")
        problemas = [m for c, m in (
            (etapa is None, "la etapa no está definida"),
            (a["etapa"] != etapa, f"es para la etapa {a['etapa']!r}"),
            (not valida, "la evidencia no es válida"),
            (valida and a["resultado_sha256"] != ev["resultado_sha256"], "es para otro resultado"),
            (valida and clase != "RESPALDADA", f"la clase es {clase}, no RESPALDADA")) if c]
        aut = ({"estado": "CONTRADICTORIA", "id": autorizacion, "motivo": "; ".join(problemas) + ": requiere revisión"}
               if problemas else
               {"estado": "REGISTRADA_EXTERNAMENTE", "id": autorizacion,
                "motivo": "autorización humana registrada fuera de la política; esta función no ejecuta nada"})
    notas = []
    if exceso_no_positivo is not None:
        notas.append(f"exceso anual {'≤' if exceso_no_positivo else '>'} 0: informativo, no cambia nada")
    return {"version": VERSION, "estado_version": ESTADO_VERSION,
            "evidencia": {"validez": ev["validez"], "resultado_sha256": ev["resultado_sha256"], "motivo": ev["motivo"]},
            "etiqueta_estadistica": ev["etiqueta"] if valida else None,
            "etiqueta_declarada": ev["etiqueta"], "clase_estadistica": clase,
            "robustez": {"R1": ev1, "R3": ev3, "resumen": rob, "naturaleza": "diagnóstico informativo"},
            "decision_avance": avance, "autorizacion_ejecucion": aut,
            "advertencias": advertencias, "notas_informativas": notas}


def desde_resultado(ruta: str | Path, raiz: str | Path, r1: object, r3: object, *, registro: str | Path | None = None,
                    resultado_sha256_esperado: str | None = None, manifiesto: dict | None = None,
                    reproduccion: object = None, tolerancia: float = 0.0, **kw) -> dict:  # type: ignore[no-untyped-def]
    """Pasa por P1 v0.3. Un rechazo o una verificación incompleta NO lanzan: devuelven una salida con su validez
    explícita y sin etiqueta. Solo los errores de entrada de la política (R1/R3, etapa, autorización) lanzan."""
    vkw = {"raiz": raiz, "registro": registro, "resultado_sha256_esperado": resultado_sha256_esperado,
           "manifiesto": manifiesto}
    try:
        inf = (V.reproducir(ruta, reproduccion, tolerancia, **vkw) if reproduccion is not None
               else V.verificar_archivo(ruta, **vkw))
    except V.ErrorVerificacion as e:
        validez = "NO_EVALUABLE" if e.codigo == "SIN_EVALUACION" else "RECHAZADO"
        return aplicar(evidencia(validez, motivo=f"{e.codigo}: {e.detalle}"), r1, r3, **kw)
    obj, _ = V.cargar(ruta)
    inicio = obj["ventana"][0] if inf["esquema"] == "fuera_de_muestra" else obj["inicio"]
    ev = evidencia(inf["nivel"], inf["decision"], inf["resultado_sha256"], inicio,
                   motivo="; ".join(inf.get("discrepancias", []) or inf["no_comprobado"]))
    return {**aplicar(ev, r1, r3, exceso_no_positivo=inf["exceso_anual"] <= 0, **kw),
            "resultado_verificado": {k: inf.get(k) for k in ("esquema", "resultado_sha256", "nivel", "decision_recalculada",
                                                              "no_comprobado", "autenticidad")}}
