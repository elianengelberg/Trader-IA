"""Conductor de las pruebas de P4: ejecuta ``ejecutar`` de un módulo de uso único (por defecto el de esta carpeta; con
``modulo``, otro, p. ej. la v0.2 de referencia) en un proceso aparte. En el punto ``punto`` muere con os._exit(137)
(caída real, sin finally); en el punto ``pausa`` se detiene de forma DETERMINISTA: escribe en la FIFO ``listo`` y espera
a leer de la FIFO ``seguir`` (sin retardos ni relojes). Datos sintéticos."""
from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent


def cargar(ruta: Path):  # type: ignore[no-untyped-def]
    spec = importlib.util.spec_from_file_location("uso_unico_conducido", ruta)
    m = importlib.util.module_from_spec(spec)
    sys.modules["uso_unico_conducido"] = m
    spec.loader.exec_module(m)  # type: ignore[union-attr]
    return m


if __name__ == "__main__":
    a = json.loads(sys.argv[1])
    U = cargar(Path(a.get("modulo") or AQUI / "uso_unico.py"))
    punto, pausa = a.get("punto"), a.get("pausa")

    def fallo(p: str) -> None:
        if p == punto:
            os._exit(137)
        if p == pausa:
            with open(a["listo"], "w") as fh:  # bloquea hasta que la prueba abra la FIFO para leer
                fh.write(p)
            with open(a["seguir"]) as fh:  # bloquea hasta que la prueba lo libere
                fh.read()

    kw = {"ancla": U.AnclaArchivo(a["ancla"]) if a.get("ancla") else None,
          "reintentos_tras_inicio": a.get("reintentos", 0), "fallo": fallo}
    if a.get("verificar_determinismo") is not None:
        kw["verificar_determinismo"] = a["verificar_determinismo"]
    s = U.ejecutar(a["dir"], a["experimento"], a["archivos"], a["semilla"], **kw)
    print(json.dumps(s.__dict__, ensure_ascii=False))
