"""Raíz de confianza para P1, P2 y P4, v0.4: firmas Ed25519 y documentos firmados. Solo biblioteca estándar.

Por qué existe: un hash local (manifiesto, diario, ancla en el mismo equipo) no distingue un archivo auténtico de uno
alterado JUNTO con su manifiesto. Una firma sí: solo la produce quien tiene la clave privada. Si esa clave está fuera
del equipo donde están los archivos (la condición de independencia, que este módulo no puede comprobar y que el
propietario asume al aprobar una raíz), alterar los archivos y sus manifiestos no basta para obtener una referencia
válida.

- Ed25519 según RFC 8032 (variante pura, verificación sin cofactor, rechazo de S ≥ q y de codificaciones de punto no
  canónicas en y). Implementación de referencia, NO de tiempo constante: firmar con ella en este equipo sirve para las
  pruebas; una clave real se genera y se usa fuera (p. ej. ``openssl pkeyutl -sign -rawin``) y aquí solo se verifica.
- Documento firmado: ``{"contenido": {...}, "firma_ed25519": "<128 hex>"}``; la firma cubre ``canonico(contenido)``:
  JSON UTF-8 con claves ordenadas, sin espacios, sin NaN y SIN números de punto flotante (para que la serialización sea
  única en cualquier implementación).
- Declaración (``contenido.formato`` = FORMATO_DECLARACION): un emisor afirma que ciertos artefactos tienen ciertos
  SHA-256. Es lo que P1 acepta como referencia independiente y lo que firma un ancla externa como recibo.
- Raíz: ``{"id", "tipo", "clave_publica_ed25519", "aprobada_por", "aprobada_utc", "descripcion"}``. Los registros de
  raíces viven en el código que las usa (P1: ``RAICES_CONFIANZA``) y hoy están VACÍOS: ninguna raíz está aprobada.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path

VERSION = "confianza v0.4"
FORMATO_DECLARACION = "trader-ia/declaracion/v1"
FORMATO_RESPUESTA_ANCLA = "trader-ia/ancla/respuesta/v1"
TIPOS_RAIZ = ("propietario", "ancla")
CAMPOS_RAIZ = ("id", "tipo", "clave_publica_ed25519", "aprobada_por", "aprobada_utc", "descripcion")


class ErrorConfianza(ValueError):
    """Documento, firma o raíz no válidos, con un código estable."""

    def __init__(self, codigo: str, detalle: str):
        super().__init__(f"{codigo}: {detalle}")
        self.codigo, self.detalle = codigo, detalle


# ---------- Ed25519 (RFC 8032, §5.1 y código de referencia del §6) ----------
_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_RAIZ_M1 = pow(2, (_P - 1) // 4, _P)


def _inv(x: int) -> int:
    return pow(x, _P - 2, _P)


def _sumar(a: tuple, b: tuple) -> tuple:
    A, B = (a[1] - a[0]) * (b[1] - b[0]) % _P, (a[1] + a[0]) * (b[1] + b[0]) % _P
    C, D = 2 * a[3] * b[3] * _D % _P, 2 * a[2] * b[2] % _P
    E, F, G, H = B - A, D - C, D + C, B + A
    return E * F, G * H, F * G, E * H


def _multiplicar(s: int, p: tuple) -> tuple:
    q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            q = _sumar(q, p)
        p = _sumar(p, p)
        s >>= 1
    return q


def _iguales(a: tuple, b: tuple) -> bool:
    return (a[0] * b[2] - b[0] * a[2]) % _P == 0 and (a[1] * b[2] - b[1] * a[2]) % _P == 0


def _recuperar_x(y: int, signo: int) -> int | None:
    if y >= _P:
        return None
    x2 = (y * y - 1) * _inv(_D * y * y + 1)
    if x2 == 0:
        return None if signo else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _RAIZ_M1 % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != signo:
        x = _P - x
    return x


_GY = 4 * _inv(5) % _P
_GX = _recuperar_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _comprimir(p: tuple) -> bytes:
    zi = _inv(p[2])
    x, y = p[0] * zi % _P, p[1] * zi % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _descomprimir(b: bytes) -> tuple | None:
    if len(b) != 32:
        return None
    y = int.from_bytes(b, "little")
    signo, y = y >> 255, y & ((1 << 255) - 1)
    x = _recuperar_x(y, signo)
    return None if x is None else (x, y, 1, x * y % _P)


def _h_mod_q(b: bytes) -> int:
    return int.from_bytes(hashlib.sha512(b).digest(), "little") % _Q


def _expandir(semilla: bytes) -> tuple[int, bytes]:
    if not isinstance(semilla, bytes) or len(semilla) != 32:
        raise ErrorConfianza("CLAVE", "la semilla privada Ed25519 debe tener 32 bytes")
    h = hashlib.sha512(semilla).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def clave_publica(semilla: bytes) -> bytes:
    a, _ = _expandir(semilla)
    return _comprimir(_multiplicar(a, _G))


def firmar(semilla: bytes, mensaje: bytes) -> bytes:
    a, prefijo = _expandir(semilla)
    publica = _comprimir(_multiplicar(a, _G))
    r = _h_mod_q(prefijo + mensaje)
    rs = _comprimir(_multiplicar(r, _G))
    s = (r + _h_mod_q(rs + publica + mensaje) * a) % _Q
    return rs + int.to_bytes(s, 32, "little")


def verificar_firma(publica: bytes, mensaje: bytes, firma: bytes) -> bool:
    """True solo si la firma es válida. Nunca lanza por entradas mal formadas: devuelve False."""
    if not (isinstance(publica, bytes) and isinstance(mensaje, bytes) and isinstance(firma, bytes)):
        return False
    if len(publica) != 32 or len(firma) != 64:
        return False
    a = _descomprimir(publica)
    r = _descomprimir(firma[:32])
    if a is None or r is None:
        return False
    s = int.from_bytes(firma[32:], "little")
    if s >= _Q:
        return False
    h = _h_mod_q(firma[:32] + publica + mensaje)
    return _iguales(_multiplicar(s, _G), _sumar(r, _multiplicar(h, a)))


# ---------- JSON canónico y lectura estricta ----------
def _sin_flotantes(x: object, ruta: str = "contenido") -> None:
    if isinstance(x, float):
        raise ErrorConfianza("FORMATO", f"{ruta}: número de punto flotante (no admitido en un documento firmado)")
    if isinstance(x, dict):
        for k, v in x.items():
            if not isinstance(k, str):
                raise ErrorConfianza("FORMATO", f"{ruta}: clave no textual")
            _sin_flotantes(v, f"{ruta}.{k}")
    elif isinstance(x, list):
        for i, v in enumerate(x):
            _sin_flotantes(v, f"{ruta}[{i}]")
    elif not (x is None or isinstance(x, (str, int, bool))):
        raise ErrorConfianza("FORMATO", f"{ruta}: tipo no admitido {type(x).__name__}")


def canonico(x: object) -> bytes:
    _sin_flotantes(x)
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sin_duplicados(pares: list[tuple[str, object]]) -> dict:
    d: dict = {}
    for k, v in pares:
        if k in d:
            raise ErrorConfianza("FORMATO", f"clave repetida en el JSON: {k!r}")
        d[k] = v
    return d


def cargar_json_estricto(ruta: str | Path) -> object:
    try:
        datos = Path(ruta).read_bytes()
    except OSError as e:
        raise ErrorConfianza("LECTURA", f"no se puede leer {ruta}: {e}") from e
    try:
        return json.loads(datos.decode("utf-8"), object_pairs_hook=_sin_duplicados)
    except ValueError as e:  # incluye UnicodeDecodeError
        if isinstance(e, ErrorConfianza):
            raise
        raise ErrorConfianza("FORMATO", f"{ruta}: JSON inválido: {e}") from e


def _hex(valor: object, n: int, que: str) -> bytes:
    if not (isinstance(valor, str) and len(valor) == n and all(c in "0123456789abcdef" for c in valor)):
        raise ErrorConfianza("FORMATO", f"{que}: se esperaban {n} caracteres hexadecimales en minúscula")
    return bytes.fromhex(valor)


def _utc(valor: object, que: str) -> dt.datetime:
    if not isinstance(valor, str) or not valor.endswith("Z"):
        raise ErrorConfianza("FORMATO", f"{que}: se esperaba fecha y hora UTC terminada en Z, hay {valor!r}")
    try:
        x = dt.datetime.fromisoformat(valor[:-1] + "+00:00")
    except ValueError as e:
        raise ErrorConfianza("FORMATO", f"{que}: fecha y hora inválida {valor!r}") from e
    return x


def _ruta_relativa(valor: object, que: str) -> str:
    if not isinstance(valor, str) or not valor or valor.startswith("/") or "\\" in valor or any(
            p in ("", ".", "..") for p in valor.split("/")):
        raise ErrorConfianza("FORMATO", f"{que}: ruta relativa POSIX normalizada requerida, hay {valor!r}")
    return valor


# ---------- documentos firmados ----------
def huella_clave(publica_hex: str) -> str:
    return "ed25519:" + hashlib.sha256(_hex(publica_hex, 64, "clave pública")).hexdigest()[:32]


def firmar_documento(semilla: bytes, contenido: dict) -> dict:
    return {"contenido": contenido, "firma_ed25519": firmar(semilla, canonico(contenido)).hex()}


def verificar_documento(doc: object, publica_hex: str) -> dict:
    """Comprueba la forma del documento y su firma con ``publica_hex``. Devuelve el contenido."""
    if not isinstance(doc, dict) or set(doc) != {"contenido", "firma_ed25519"}:
        raise ErrorConfianza("FORMATO", "un documento firmado tiene exactamente 'contenido' y 'firma_ed25519'")
    contenido = doc["contenido"]
    if not isinstance(contenido, dict):
        raise ErrorConfianza("FORMATO", "'contenido' debe ser un objeto")
    firma = _hex(doc["firma_ed25519"], 128, "firma_ed25519")
    if not verificar_firma(_hex(publica_hex, 64, "clave pública"), canonico(contenido), firma):
        raise ErrorConfianza("FIRMA_INVALIDA", "la firma no corresponde al contenido con la clave de la raíz")
    return contenido


def validar_raiz(ident: str, raiz: object) -> dict:
    if not isinstance(raiz, dict) or set(raiz) != set(CAMPOS_RAIZ):
        raise ErrorConfianza("RAIZ_INVALIDA", f"raíz {ident!r}: debe tener exactamente {CAMPOS_RAIZ}")
    if raiz["id"] != ident:
        raise ErrorConfianza("RAIZ_INVALIDA", f"raíz {ident!r}: su id es {raiz['id']!r}")
    if raiz["tipo"] not in TIPOS_RAIZ:
        raise ErrorConfianza("RAIZ_INVALIDA", f"raíz {ident!r}: tipo {raiz['tipo']!r} ∉ {TIPOS_RAIZ}")
    for c in ("aprobada_por", "descripcion"):
        if not isinstance(raiz[c], str) or not raiz[c]:
            raise ErrorConfianza("RAIZ_INVALIDA", f"raíz {ident!r}: {c} vacío")
    try:
        publica = _hex(raiz["clave_publica_ed25519"], 64, f"raíz {ident!r}")
        _utc(raiz["aprobada_utc"], f"raíz {ident!r}: aprobada_utc")
    except ErrorConfianza as e:
        raise ErrorConfianza("RAIZ_INVALIDA", e.detalle) from e
    if _descomprimir(publica) is None:
        raise ErrorConfianza("RAIZ_INVALIDA", f"raíz {ident!r}: la clave pública no es un punto válido")
    return raiz


def validar_declaracion(contenido: object) -> dict:
    """Esquema estricto de una declaración (sin firma)."""
    if not isinstance(contenido, dict) or set(contenido) != {"formato", "emisor", "emitida_utc", "artefactos",
                                                             "contexto"}:
        raise ErrorConfianza("FORMATO", "una declaración tiene exactamente formato, emisor, emitida_utc, artefactos y "
                                        "contexto")
    if contenido["formato"] != FORMATO_DECLARACION:
        raise ErrorConfianza("FORMATO", f"formato {contenido['formato']!r} ≠ {FORMATO_DECLARACION!r}")
    if not isinstance(contenido["emisor"], str) or not contenido["emisor"]:
        raise ErrorConfianza("FORMATO", "emisor vacío")
    _utc(contenido["emitida_utc"], "emitida_utc")
    artefactos = contenido["artefactos"]
    if not isinstance(artefactos, list) or not artefactos:
        raise ErrorConfianza("FORMATO", "artefactos debe ser una lista no vacía")
    rutas: set[str] = set()
    for i, a in enumerate(artefactos):
        if not isinstance(a, dict) or "sha256" not in a or not set(a) <= {"sha256", "ruta", "descripcion"}:
            raise ErrorConfianza("FORMATO", f"artefactos[{i}]: claves admitidas sha256 (obligatoria), ruta, descripcion")
        _hex(a["sha256"], 64, f"artefactos[{i}].sha256")
        if "ruta" in a:
            ruta = _ruta_relativa(a["ruta"], f"artefactos[{i}].ruta")
            if ruta in rutas:
                raise ErrorConfianza("FORMATO", f"artefactos: la ruta {ruta!r} figura dos veces")
            rutas.add(ruta)
        if "descripcion" in a and not isinstance(a["descripcion"], str):
            raise ErrorConfianza("FORMATO", f"artefactos[{i}].descripcion debe ser texto")
    if not isinstance(contenido["contexto"], dict):
        raise ErrorConfianza("FORMATO", "contexto debe ser un objeto")
    canonico(contenido)  # sin flotantes en ninguna parte
    return contenido


def declaracion(emisor: str, emitida_utc: str, artefactos: list[dict], contexto: dict | None = None) -> dict:
    return validar_declaracion({"formato": FORMATO_DECLARACION, "emisor": emisor, "emitida_utc": emitida_utc,
                                "artefactos": artefactos, "contexto": contexto or {}})


def verificar_declaracion(doc: object, raices: dict[str, dict]) -> tuple[dict, dict]:
    """(declaración, raíz) si ``doc`` es una declaración bien formada firmada por una raíz APROBADA de ``raices``.
    Si no, ErrorConfianza: FORMATO, EMISOR_NO_APROBADO, RAIZ_INVALIDA o FIRMA_INVALIDA."""
    if not isinstance(doc, dict) or set(doc) != {"contenido", "firma_ed25519"}:
        raise ErrorConfianza("FORMATO", "un documento firmado tiene exactamente 'contenido' y 'firma_ed25519'")
    contenido = validar_declaracion(doc["contenido"])
    emisor = contenido["emisor"]
    if emisor not in raices:
        raise ErrorConfianza("EMISOR_NO_APROBADO", f"el emisor {emisor!r} no es una raíz de confianza aprobada")
    raiz = validar_raiz(emisor, raices[emisor])
    verificar_documento(doc, raiz["clave_publica_ed25519"])
    return contenido, raiz
