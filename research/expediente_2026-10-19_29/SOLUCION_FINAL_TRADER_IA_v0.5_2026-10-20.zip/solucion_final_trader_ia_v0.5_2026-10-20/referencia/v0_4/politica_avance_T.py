"""Política de avance de T, v0.4 — PROPUESTA, NO APROBADA. Solo biblioteca estándar; no lee datos ni escribe nada.

Cinco dimensiones que no se mezclan:
  0. validez de la evidencia: el ESTADO de P1 v0.4 (VERIFICADO, REPRODUCIDO, NO_REPRODUCIDO, CORRUPTO, INCONCLUSO).
     Solo VERIFICADO o REPRODUCIDO cuentan (A9: si debe exigirse REPRODUCIDO es una decisión del propietario).
  1. etiqueta estadística: texto LITERAL del productor congelado, solo si la evidencia es válida; nunca se reescribe.
  2. robustez: diagnóstico INFORMATIVO de R1 y R3; argumentos OBLIGATORIOS. NO_DEFINIDO solo si no hay definición
     aprobada para T; NO_EVALUADO si la hay y no se evaluó; una evaluación es un registro
     {"estado": CUMPLE|NO_CUMPLE, "definicion": id, "resultado_sha256": hash} LIGADO al resultado evaluado.
  3. decisión de avance: depende solo de la clase de la etiqueta y nombra la etapa (hoy NO_DEFINIDA).
  4. autorización de ejecución: la política NUNCA la otorga. Solo constata una autorización humana registrada y su
     coherencia (etapa definida, mismo resultado, evidencia válida, clase RESPALDADA); si no, CONTRADICTORIA.

Cambios de v0.4 respecto de v0.3 (INFORME_DEFECTOS_Y_CORRECCIONES.md):
- La evidencia solo nace de un informe de P1 producido DENTRO de ``desde_resultado`` (objeto sellado): ya no hay una
  función pública que acepte una evidencia «VERIFICADO» armada a mano (v0.3: ``aplicar(evidencia(...))``).
- Los registros (definiciones, etapas, autorizaciones) ya no se pueden inyectar por parámetro: solo valen los del
  módulo, hoy VACÍOS (v0.3 aceptaba ``autorizaciones=...`` de cualquier llamador).
- La fecha de inicio de la ventana sale del MISMO informe de P1 (v0.3 releía el archivo tras verificarlo).
- Dependencias validadas: cada registro coincide con su clave; una autorización solo puede ser para una etapa
  definida; una evaluación de R1/R3 nombra el resultado evaluado y debe ser ESTE.

Orden fijo de los errores de entrada (ErrorPolitica): evidencia → registros → etapa → R1 → R3 → autorización.
Fechas: ISO 8601 estrictas. Una definición aprobada en o después del inicio de la ventana evaluada es post hoc.
LÍMITE: Python no impide llamar funciones privadas (``_decidir``, ``_evidencia_sintetica``); la garantía es de
INTERFAZ, y toda salida declara su ``origen`` (``P1`` o ``SINTETICA``) y el SHA-256 del informe de P1.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import verificar_reproduccion_T as V  # noqa: E402  (verificador de P1, v0.4)

VERSION = "POLITICA_AVANCE_T v0.4"
ESTADO_VERSION = "PROPUESTA: no aprobada"

ETIQUETAS = {
    # experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)
    "RESPALDADA FUERA DE MUESTRA": "RESPALDADA",
    "NO RESPALDADA": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE": "INSUFICIENTE",
    # tendencia.papel.decidir (código 73b22f3e…), citada; no se importa ni se altera
    "VENTAJA RESPALDADA": "RESPALDADA",
    "HIPÓTESIS NO RESPALDADA: detener": "NO_RESPALDADA",
    "EVIDENCIA INSUFICIENTE: continuar": "INSUFICIENTE",
    "INFORMATIVO (menos de 12 meses: ninguna decisión)": "INFORMATIVO",
}
VALIDEZ = tuple(V.ESTADOS)
VALIDA = ("VERIFICADO", "REPRODUCIDO")
CRITERIOS = ("R1", "R3")
CAMPOS_DEFINICION = ("id", "criterio", "aplica_a", "texto_sha256", "aprobada_utc", "aprobada_por")
CAMPOS_AUTORIZACION = ("id", "etapa", "resultado_sha256", "otorgada_por", "otorgada_utc", "texto_sha256")
CAMPOS_EVALUACION = ("estado", "definicion", "resultado_sha256")

# Registros que solo una decisión humana puede llenar (cambio de código revisado). VACÍOS: no hay definición de R1/R3
# para T (A1, A2), ni etapa siguiente (A5), ni autorización. Las pruebas usan registros SINTÉTICOS con monkeypatch;
# ninguna función pública acepta registros como parámetro.
DEFINICIONES_APROBADAS: dict[str, dict] = {}
ETAPAS_DEFINIDAS: dict[str, str] = {}
AUTORIZACIONES: dict[str, dict] = {}


class ErrorPolitica(ValueError):
    pass


def _fecha_hora(valor: object, que: str) -> dt.datetime:
    if not isinstance(valor, str):
        raise ErrorPolitica(f"{que}: se esperaba una fecha y hora ISO 8601 con zona, hay {valor!r}")
    try:
        x = dt.datetime.fromisoformat(valor.replace("Z", "+00:00"))
    except ValueError as e:
        raise ErrorPolitica(f"{que}: fecha y hora inválida {valor!r}") from e
    if x.tzinfo is None:
        raise ErrorPolitica(f"{que}: falta la zona horaria en {valor!r}")
    return x


def _fecha(valor: object, que: str) -> dt.date:
    try:
        if not isinstance(valor, str) or dt.date.fromisoformat(valor).isoformat() != valor:
            raise ValueError
        return dt.date.fromisoformat(valor)
    except ValueError as e:
        raise ErrorPolitica(f"{que}: se esperaba una fecha AAAA-MM-DD, hay {valor!r}") from e


def _hex64(valor: object, que: str) -> str:
    if not (isinstance(valor, str) and len(valor) == 64 and all(c in "0123456789abcdef" for c in valor)):
        raise ErrorPolitica(f"{que}: se esperaba un SHA-256 hexadecimal, hay {valor!r}")
    return valor


def _registro_valido(clave: str, d: object, campos: tuple[str, ...], que: str) -> dict:
    if not isinstance(d, dict) or set(d) != set(campos) or any(not isinstance(d[c], str) or not d[c] for c in campos):
        raise ErrorPolitica(f"{que}: debe tener exactamente los campos {campos}, todos textos no vacíos")
    if d["id"] != clave:
        raise ErrorPolitica(f"{que}: registrado como {clave!r} pero su id es {d['id']!r}")
    _hex64(d["texto_sha256"], f"{que}.texto_sha256")
    return d


def _validar_registros() -> tuple[dict, dict, dict]:
    """Los tres registros del módulo, validados JUNTOS (dependencias incluidas)."""
    for k, d in DEFINICIONES_APROBADAS.items():
        _registro_valido(k, d, CAMPOS_DEFINICION, f"definición {k!r}")
        if d["criterio"] not in CRITERIOS:
            raise ErrorPolitica(f"definición {k!r}: criterio {d['criterio']!r} ∉ {CRITERIOS}")
        _fecha_hora(d["aprobada_utc"], f"definición {k!r}: aprobada_utc")
    for k, texto in ETAPAS_DEFINIDAS.items():
        if not (isinstance(k, str) and k and isinstance(texto, str) and texto):
            raise ErrorPolitica(f"etapa {k!r}: nombre y descripción deben ser textos no vacíos")
    for k, a in AUTORIZACIONES.items():
        _registro_valido(k, a, CAMPOS_AUTORIZACION, f"autorización {k!r}")
        if a["etapa"] not in ETAPAS_DEFINIDAS:
            raise ErrorPolitica(f"autorización {k!r}: es para la etapa {a['etapa']!r}, que no está definida")
        _hex64(a["resultado_sha256"], f"autorización {k!r}.resultado_sha256")
        _fecha_hora(a["otorgada_utc"], f"autorización {k!r}: otorgada_utc")
    return DEFINICIONES_APROBADAS, ETAPAS_DEFINIDAS, AUTORIZACIONES


# ---------- evidencia (sellada: solo la construye esta política) ----------
_SELLO = object()


@dataclass(frozen=True)
class _Evidencia:
    validez: str
    etiqueta: str | None
    resultado_sha256: str | None
    fecha_inicio_ventana: str | None
    motivo: str
    origen: str
    informe_p1_sha256: str | None
    sello: object = field(repr=False, compare=False, default=None)

    def __post_init__(self) -> None:
        if self.sello is not _SELLO:
            raise ErrorPolitica("la evidencia solo la construye la política a partir de un informe de P1")
        if self.validez not in VALIDEZ:
            raise ErrorPolitica(f"validez desconocida: {self.validez!r}")
        if self.validez in VALIDA:
            if self.etiqueta not in ETIQUETAS:
                raise ErrorPolitica(f"etiqueta estadística desconocida (se exige el texto literal del productor): "
                                    f"{self.etiqueta!r}")
            _hex64(self.resultado_sha256, "resultado_sha256")
            _fecha(self.fecha_inicio_ventana, "fecha_inicio_ventana")
        elif self.resultado_sha256 is not None:
            _hex64(self.resultado_sha256, "resultado_sha256")


def _evidencia_de_informe(inf: dict) -> _Evidencia:
    """Evidencia desde un informe de P1 v0.4: TODO sale del informe (los mismos bytes evaluados), nada del archivo."""
    motivos = "; ".join(f"{m['codigo']}: {m['detalle']}" for m in inf.get("motivos", []))
    if inf.get("discrepancias"):
        motivos = "; ".join(inf["discrepancias"])
    sha_inf = hashlib.sha256(json.dumps(inf, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()
    return _Evidencia(inf["estado"], inf.get("decision"), inf.get("resultado_sha256"), inf.get("inicio_ventana"),
                      motivos, f"P1 {inf.get('version')}", sha_inf, _SELLO)


def _evidencia_sintetica(validez: str, etiqueta: str | None = None, resultado_sha256: str | None = None,
                         fecha_inicio_ventana: str | None = None, motivo: str = "") -> _Evidencia:
    """SOLO para la tabla y las pruebas: la salida queda marcada con origen SINTETICA."""
    return _Evidencia(validez, etiqueta, resultado_sha256, fecha_inicio_ventana, motivo, "SINTETICA (solo pruebas)",
                      None, _SELLO)


# ---------- R1 / R3 ----------
def _r(nombre: str, valor: object, definiciones: dict[str, dict], ev: _Evidencia) -> dict:
    propias = [k for k, d in definiciones.items() if d["criterio"] == nombre and d["aplica_a"] == "T"]
    if valor == "NO_DEFINIDO":
        if propias:
            raise ErrorPolitica(f"{nombre}: hay una definición aprobada para T ({propias}); no puede ser NO_DEFINIDO "
                                "(use NO_EVALUADO o una evaluación)")
        return {"estado": "NO_DEFINIDO", "definicion": None, "post_hoc": None}
    if valor == "NO_EVALUADO":
        if not propias:
            raise ErrorPolitica(f"{nombre}: NO_EVALUADO exige una definición aprobada para T; no la hay (NO_DEFINIDO)")
        return {"estado": "NO_EVALUADO", "definicion": None, "post_hoc": None}
    if not (isinstance(valor, dict) and set(valor) == set(CAMPOS_EVALUACION) and valor["estado"] in ("CUMPLE", "NO_CUMPLE")):
        raise ErrorPolitica(f"{nombre}: se espera NO_DEFINIDO, NO_EVALUADO o una evaluación {{estado: CUMPLE|NO_CUMPLE, "
                            f"definicion, resultado_sha256}}, hay {valor!r}")
    ident = valor["definicion"]
    d = definiciones.get(ident) if isinstance(ident, str) else None
    if d is None:
        raise ErrorPolitica(f"{nombre}: la definición {ident!r} no está aprobada")
    if d["criterio"] != nombre or d["aplica_a"] != "T":
        raise ErrorPolitica(f"{nombre}: la definición {ident!r} es de {d['criterio']} para {d['aplica_a']}, no de "
                            f"{nombre} para T (no se trasladan métricas de otro experimento)")
    if _hex64(valor["resultado_sha256"], f"{nombre}.resultado_sha256") != ev.resultado_sha256:
        raise ErrorPolitica(f"{nombre}: la evaluación es de otro resultado ({valor['resultado_sha256'][:12]}…), no del "
                            f"evaluado ({str(ev.resultado_sha256)[:12]}…)")
    aprobada = _fecha_hora(d["aprobada_utc"], f"{nombre}: aprobada_utc")
    inicio = ev.fecha_inicio_ventana
    post_hoc = inicio is None or aprobada.astimezone(dt.UTC).date() >= _fecha(inicio, "fecha_inicio_ventana")
    return {"estado": valor["estado"], "definicion": ident, "post_hoc": post_hoc}


def robustez(e1: str, e3: str) -> str:
    """ROBUSTA solo si ambas se cumplen; NO_ROBUSTA si alguna falla; INDETERMINADA en otro caso (NO_DEFINIDO o
    NO_EVALUADO). La regla «todas» viene de E3 v3 §6.3 y es la ambigüedad A6."""
    if "NO_CUMPLE" in (e1, e3):
        return "NO_ROBUSTA"
    if e1 == e3 == "CUMPLE":
        return "ROBUSTA"
    return "INDETERMINADA"


# ---------- decisión (privada; recibe solo evidencia sellada) ----------
def _decidir(ev: _Evidencia, r1: object, r3: object, etapa: str | None, autorizacion: str | None,
             exceso_anual: float | None = None) -> dict:
    if not isinstance(ev, _Evidencia) or ev.sello is not _SELLO:
        raise ErrorPolitica("se requiere una evidencia construida por la política a partir de un informe de P1")
    definiciones, etapas, autorizaciones = _validar_registros()
    if etapa is not None and etapa not in etapas:
        raise ErrorPolitica(f"etapa {etapa!r} no definida (A5); no se inventan etapas")
    ev1 = _r("R1", r1, definiciones, ev)
    ev3 = _r("R3", r3, definiciones, ev)
    a = None
    if autorizacion is not None:
        a = autorizaciones.get(autorizacion)
        if a is None:
            raise ErrorPolitica(f"autorización {autorizacion!r} desconocida")
    valida = ev.validez in VALIDA
    clase = ETIQUETAS[ev.etiqueta] if valida else "SIN_EVIDENCIA_VALIDA"  # type: ignore[index]
    nombre_etapa = etapa or "NO_DEFINIDA"
    advertencias: list[str] = []
    if not valida:
        avance = {"resultado": "NO_CANDIDATA", "etapa": nombre_etapa,
                  "texto": f"sin evidencia válida ({ev.validez}): no hay etiqueta que evaluar"}
        rob = "NO_APLICA"
        if ev1["estado"] in ("CUMPLE", "NO_CUMPLE") or ev3["estado"] in ("CUMPLE", "NO_CUMPLE"):
            advertencias.append("R1/R3 evaluados sobre una evidencia no válida: se ignoran")
    else:
        rob = robustez(ev1["estado"], ev3["estado"])
        if clase == "RESPALDADA":
            avance = {"resultado": "CANDIDATA_A_REVISION_HUMANA", "etapa": nombre_etapa,
                      "texto": f"T es candidata a que una persona decida si pasa a la etapa {nombre_etapa}"}
        else:
            avance = {"resultado": "NO_CANDIDATA", "etapa": nombre_etapa,
                      "texto": (f"T no es candidata a la etapa {etapa}" if etapa else
                                "T no es candidata a una etapa posterior; esa etapa no está definida (A5): no es una "
                                "decisión universal; la acción vigente es la de la propia etiqueta")}
        if clase == "RESPALDADA" and rob != "ROBUSTA":
            advertencias.append(f"robustez {rob}: dato para la decisión humana; no veta la candidatura (A3)")
    if "NO_DEFINIDO" in (ev1["estado"], ev3["estado"]):
        advertencias.append("R1/R3 sin definición aprobada para T (A1, A2)")
    if any(e["post_hoc"] for e in (ev1, ev3)):
        advertencias.append("R1/R3 evaluados con una definición posterior al inicio de la ventana: POST HOC")
    if a is None:
        aut = {"estado": "NO_OTORGADA", "id": None, "motivo": "no hay autorización humana registrada"}
    else:
        problemas = [m for c, m in (
            (etapa is None, "la etapa no está definida en la consulta"),
            (a["etapa"] != etapa, f"es para la etapa {a['etapa']!r}"),
            (not valida, "la evidencia no es válida"),
            (valida and a["resultado_sha256"] != ev.resultado_sha256, "es para otro resultado"),
            (valida and clase != "RESPALDADA", f"la clase es {clase}, no RESPALDADA")) if c]
        aut = ({"estado": "CONTRADICTORIA", "id": autorizacion, "motivo": "; ".join(problemas) + ": requiere revisión"}
               if problemas else
               {"estado": "REGISTRADA_EXTERNAMENTE", "id": autorizacion,
                "motivo": "autorización humana registrada fuera de la política; esta función no ejecuta nada"})
    notas = []
    if exceso_anual is not None and valida:
        notas.append(f"exceso anual {'≤' if exceso_anual <= 0 else '>'} 0: informativo, no cambia nada")
    return {"version": VERSION, "estado_version": ESTADO_VERSION,
            "evidencia": {"validez": ev.validez, "resultado_sha256": ev.resultado_sha256, "motivo": ev.motivo,
                          "origen": ev.origen, "informe_p1_sha256": ev.informe_p1_sha256,
                          "fecha_inicio_ventana": ev.fecha_inicio_ventana},
            "etiqueta_estadistica": ev.etiqueta if valida else None,
            "etiqueta_declarada": ev.etiqueta, "clase_estadistica": clase,
            "robustez": {"R1": ev1, "R3": ev3, "resumen": rob, "naturaleza": "diagnóstico informativo"},
            "decision_avance": avance, "autorizacion_ejecucion": aut,
            "advertencias": advertencias, "notas_informativas": notas}


# ---------- única entrada pública ----------
def desde_resultado(ruta: str | Path, raiz: str | Path, r1: object, r3: object, *, registro: str | Path | None = None,
                    resultado_sha256_esperado: str | None = None, manifiesto: dict | None = None,
                    declaraciones: list[tuple[str, object]] = (), reproduccion: object = None,  # type: ignore[assignment]
                    tolerancia: float = 0.0, etapa: str | None = None, autorizacion: str | None = None) -> dict:
    """Pasa SIEMPRE por P1 v0.4 (lee el archivo una vez). Un resultado CORRUPTO o INCONCLUSO no lanza: devuelve una
    salida con su validez explícita y sin etiqueta. Solo los errores de entrada de la política lanzan ErrorPolitica."""
    vkw = {"raiz": raiz, "registro": registro, "resultado_sha256_esperado": resultado_sha256_esperado,
           "manifiesto": manifiesto, "declaraciones": list(declaraciones)}
    inf = (V.evaluar_reproduccion(ruta, reproduccion, tolerancia, **vkw) if reproduccion is not None
           else V.evaluar_archivo(ruta, **vkw))
    ev = _evidencia_de_informe(inf)
    salida = _decidir(ev, r1, r3, etapa, autorizacion, inf.get("exceso_anual"))
    return {**salida, "resultado_verificado": {k: inf.get(k) for k in (
        "esquema", "resultado_sha256", "estado", "decision_recalculada", "motivos", "autenticidad")}}
