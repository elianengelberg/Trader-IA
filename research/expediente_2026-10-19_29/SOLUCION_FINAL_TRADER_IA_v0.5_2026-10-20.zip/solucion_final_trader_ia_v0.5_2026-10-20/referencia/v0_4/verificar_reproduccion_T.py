"""Verificador de reproducción de T, v0.4 (P1). Aislado: solo biblioteca estándar y solo lectura. PROPUESTA: no
aplicado al repositorio.

ESTADOS (exactamente uno por evaluación; las condiciones no se solapan):

- VERIFICADO: (V1) el JSON es legible, sin claves duplicadas, y cumple de forma estricta exactamente un esquema de
  resultado de T; (V2) la decisión registrada es la que da la regla congelada con sus propias cifras; (V3) con
  ``--raiz``, cada hash que declara se recalcula desde los archivos y coincide, y también las correspondencias (CODIGO
  y ventana del script, inicio prerregistrado, tablas y datos del corte, registro del corte); (V4) toda referencia
  LOCAL suministrada (manifiestos, esperados, hash presellado por P4) es coherente; (V5) al menos una DECLARACIÓN
  FIRMADA por una raíz de confianza aprobada (``RAICES_CONFIANZA``) cubre el SHA-256 del resultado, y ninguna lo
  contradice; (V6) no es un corte provisional.
- CORRUPTO: hay una inconsistencia DEMOSTRADA: JSON ilegible o con claves duplicadas, violación del esquema de un
  resultado de T, decisión distinta de la regla congelada, hash o correspondencia que no coincide, contradicción
  interna, referencias suministradas que se contradicen entre sí o con los archivos, o una declaración firmada válida
  que asigna otro hash al resultado o a un archivo leído.
- INCONCLUSO: no se demostró ninguna inconsistencia, pero falta alguna condición de VERIFICADO: sin ``--raiz``,
  archivos ausentes, corte provisional, tipo de archivo no admitido (p. ej. ``calidad_datos.json``), dato no derivable
  del árbol, referencia que no cubre el resultado, ninguna declaración firmada válida (sin raíz aprobada no hay
  autenticidad), uso incorrecto o error interno. Nunca oculta un CORRUPTO: las faltas se acumulan y solo se informan
  después de completar las comprobaciones que no dependen de ellas.
- REPRODUCIDO / NO_REPRODUCIDO (solo con ``--reproduccion``): el original es VERIFICADO, la reproducción cumple V1 y
  V2, y ``comparar_completo`` (todas las hojas; tolerancia absoluta explícita, 0 por defecto) no encuentra / encuentra
  diferencias. Si el original no es VERIFICADO, el estado es el del original; si la reproducción no cumple V1 o V2,
  INCONCLUSO (REPRODUCCION_NO_VALIDA): un defecto de la reproducción no prueba nada sobre el original.

Cambios de v0.4 respecto de v0.3 (DEFECTOS en INFORME_DEFECTOS_Y_CORRECCIONES.md):
- Estados de arriba en lugar de VERIFICADO = «coherente con los archivos locales» (v0.3 lo emitía aunque el archivo y
  su manifiesto hubieran sido alterados juntos). La autenticidad ya no es una nota: es la condición V5.
- Errores no controlados (script con CODIGO no literal, CSV no UTF-8, prerregistro sin la clave esperada) → estados.
- El resultado se lee UNA vez: la reproducción se compara con los bytes evaluados (v0.3 releía el archivo).
- ``calidad_datos.json`` (``contraste_btc_diario_vs_horario``): INCONCLUSO, procedencia no verificada.
- Códigos separados: CLAVE_AUSENTE (CORRUPTO) / ARCHIVO_AUSENTE (INCONCLUSO); JSON_INVALIDO (CORRUPTO); USO.

Esquemas (sin cambios): el papel usa ``decision`` y ``prerregistro_sha256`` = hash CANÓNICO de las reglas; fuera de
muestra usa ``decision_prerregistrada`` y ``prerregistro_sha256`` = SHA-256 del ARCHIVO .md. No importa ni ejecuta
``fuera_de_muestra_T.py`` ni ``corte.py`` (el script se lee como texto con ``ast`` después de comprobar su hash). No
consume ningún cerrojo. No lee bytes de datos de mercado salvo con ``--datos``.

Uso: python3 -I verificar_reproduccion_T.py <resultado.json> [--raiz DIR_T] [--registro REGISTRO.jsonl]
        [--esperados esperados.json] [--resultado-sha256 HEX] [--manifiesto RUTA[#CLAVE]]... [--declaracion RUTA]...
        [--datos] [--reproduccion otra.json [--tolerancia X]]
Salida: 0 VERIFICADO (o REPRODUCIDO con --reproduccion) · 1 CORRUPTO · 2 uso de la línea de órdenes · 3 INCONCLUSO ·
        5 NO_REPRODUCIDO
"""
from __future__ import annotations

import ast
import csv
import datetime as dt
import hashlib
import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import confianza as C  # noqa: E402

VERSION = "verificar_reproduccion_T v0.4"
DECISIONES_FUERA = ("RESPALDADA FUERA DE MUESTRA", "NO RESPALDADA", "EVIDENCIA INSUFICIENTE")
DECISIONES_PAPEL = ("INFORMATIVO (menos de 12 meses: ninguna decisión)", "HIPÓTESIS NO RESPALDADA: detener",
                    "VENTAJA RESPALDADA", "EVIDENCIA INSUFICIENTE: continuar")
ESTADOS = ("VERIFICADO", "REPRODUCIDO", "NO_REPRODUCIDO", "CORRUPTO", "INCONCLUSO")
SALIDAS = {"VERIFICADO": 0, "REPRODUCIDO": 0, "CORRUPTO": 1, "INCONCLUSO": 3, "NO_REPRODUCIDO": 5}
SIMBOLOS = ("BTCUSDT", "ETHUSDT")
CODIGOS_CORRUPTO = frozenset({"JSON_INVALIDO", "CLAVE_DUPLICADA", "TIPO", "RANGO", "VALOR", "CLAVE_AUSENTE",
                              "CLAVE_INESPERADA", "HASH_FORMATO", "ESQUEMA", "CONTRADICCION", "HASH", "HASH_MANIFIESTO",
                              "HASH_REFERENCIA", "REGISTRO"})
CODIGOS_INCONCLUSO = frozenset({"ARCHIVO_AUSENTE", "SIN_EVALUACION", "TIPO_NO_ADMITIDO", "PROCEDENCIA_NO_VERIFICADA",
                                "NO_DERIVABLE", "MANIFIESTO_NO_CUBRE", "MANIFIESTO_NO_VALIDO", "INTEGRIDAD_INCOMPLETA",
                                "SIN_REFERENCIA_INDEPENDIENTE", "REPRODUCCION_NO_VALIDA", "USO", "ERROR_INTERNO"})

# Raíces de confianza aprobadas por el propietario (confianza.CAMPOS_RAIZ). VACÍO: no hay ninguna (B-2). Sin raíz
# aprobada, ningún resultado puede ser VERIFICADO. Las pruebas instalan raíces SINTÉTICAS con monkeypatch; ninguna
# función pública acepta raíces como parámetro.
RAICES_CONFIANZA: dict[str, dict] = {}

# Archivos que NO son resultados de T y cuya procedencia no está demostrada: se informan como INCONCLUSO.
EVIDENCIA_NO_ADMITIDA = {
    "contraste_btc_diario_vs_horario": (
        "experimentos/calidad_datos.json: su productor no está versionado (orden ad hoc del 2026-10-17T01:27Z, "
        "recuperada de la transcripción local de la sesión); compara solo apertura 00 h y cierre 23 h, solo de "
        "2019-10-01 a 2026-05-31 (2435 de 3210 días; los 775 anteriores no se cuentan ni como comparados ni como "
        "'sin_horaria'); no se puede reproducir sin leer datos de mercado. No es evidencia de T."),
}


class ErrorVerificacion(Exception):
    """Error con un código estable; ``motivos`` acumula faltas diferidas (INCONCLUSO)."""

    def __init__(self, codigo: str, detalle: str, motivos: list[tuple[str, str]] | None = None):
        super().__init__(f"{codigo}: {detalle}")
        self.codigo, self.detalle = codigo, detalle
        self.motivos = motivos or [(codigo, detalle)]


def clase(codigo: str) -> str:
    if codigo in CODIGOS_CORRUPTO:
        return "CORRUPTO"
    if codigo in CODIGOS_INCONCLUSO:
        return "INCONCLUSO"
    raise ValueError(f"código sin clase: {codigo!r}")  # defensa: la prueba estática garantiza que no ocurre


@dataclass
class Registro:
    esquema: str
    decision: str
    exceso_anual: float
    ic90: tuple[float, float] | None  # None: bootstrap no aplicable (solo papel, menos de 12 meses)
    p_conjunto: float | None
    p_btc: float | None
    exceso_x2: float
    dias: int
    meses: float | None
    hashes: dict[str, str] = field(default_factory=dict)


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


# ---------- lectura ----------
def _sin_duplicados(pares: list[tuple[str, object]]) -> dict:
    d: dict = {}
    for k, v in pares:
        if k in d:
            raise ErrorVerificacion("CLAVE_DUPLICADA", f"clave repetida en el JSON: {k!r}")
        d[k] = v
    return d


def cargar(ruta: str | Path) -> tuple[object, str]:
    """(objeto, SHA-256 de los bytes leídos). Ausente o ilegible: ARCHIVO_AUSENTE; JSON inválido o truncado:
    JSON_INVALIDO; claves duplicadas: CLAVE_DUPLICADA."""
    try:
        datos = Path(ruta).read_bytes()
    except OSError as e:
        raise ErrorVerificacion("ARCHIVO_AUSENTE", f"no se puede leer {ruta}: {e}") from e
    try:
        obj = json.loads(datos.decode("utf-8"), object_pairs_hook=_sin_duplicados)
    except ErrorVerificacion:
        raise
    except ValueError as e:  # incluye UnicodeDecodeError
        raise ErrorVerificacion("JSON_INVALIDO", f"{ruta}: JSON inválido: {e}") from e
    return obj, _sha(datos)


# ---------- acceso estricto (sin valores por defecto) ----------
def _clave(obj: object, ruta: str):  # type: ignore[no-untyped-def]
    actual = obj
    for parte in ruta.split("."):
        if not isinstance(actual, dict):
            raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un objeto antes de '{parte}', hay {type(actual).__name__}")
        if parte not in actual:
            raise ErrorVerificacion("CLAVE_AUSENTE", f"falta la clave '{ruta}'")
        actual = actual[parte]
    return actual


def _num(obj: object, ruta: str) -> float:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un número finito, hay {v!r}")
    return float(v)


def _prob(obj: object, ruta: str) -> float:
    v = _num(obj, ruta)
    if not 0.0 <= v <= 1.0:
        raise ErrorVerificacion("RANGO", f"{ruta}: probabilidad fuera de [0, 1]: {v}")
    return v


def _entero(obj: object, ruta: str) -> int:
    v = _clave(obj, ruta)
    if isinstance(v, bool) or not isinstance(v, int) or v <= 0:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un entero positivo, hay {v!r}")
    return v


def _texto(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not isinstance(v, str) or not v:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba un texto no vacío, hay {v!r}")
    return v


def _fecha(obj: object, ruta: str) -> str:
    v = _texto(obj, ruta)
    try:
        if dt.date.fromisoformat(v).isoformat() != v:
            raise ValueError(v)
    except ValueError as e:
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba una fecha AAAA-MM-DD, hay {v!r}") from e
    return v


def _es_sha(v: object) -> bool:
    return isinstance(v, str) and len(v) == 64 and all(c in "0123456789abcdef" for c in v)


def _sha_campo(obj: object, ruta: str) -> str:
    v = _clave(obj, ruta)
    if not _es_sha(v):
        raise ErrorVerificacion("HASH_FORMATO", f"{ruta}: no es un SHA-256 en hexadecimal: {v!r}")
    return v  # type: ignore[return-value]


def _ic(obj: object, ruta: str) -> tuple[float, float]:
    v = _clave(obj, ruta)
    if not (isinstance(v, list) and len(v) == 2):
        raise ErrorVerificacion("TIPO", f"{ruta}: se esperaba una lista de 2 números, hay {v!r}")
    lo, hi = (_num({"x": x}, "x") for x in v)
    if lo > hi:
        raise ErrorVerificacion("RANGO", f"{ruta}: extremo inferior > superior ({lo} > {hi})")
    return lo, hi


def _claves(obj: object, ruta: str, obligatorias: set[str], admitidas: set[str] = frozenset()) -> dict:  # type: ignore[assignment]
    """Esquema estricto: todas las obligatorias y ninguna fuera de obligatorias ∪ admitidas."""
    d = obj if ruta == "" else _clave(obj, ruta)
    if not isinstance(d, dict):
        raise ErrorVerificacion("TIPO", f"{ruta or 'raíz'}: se esperaba un objeto, hay {type(d).__name__}")
    faltan = sorted(obligatorias - set(d))
    if faltan:
        raise ErrorVerificacion("CLAVE_AUSENTE", f"{ruta or 'raíz'}: faltan {faltan}")
    sobran = sorted(set(d) - obligatorias - set(admitidas))
    if sobran:
        raise ErrorVerificacion("CLAVE_INESPERADA", f"{ruta or 'raíz'}: claves no admitidas {sobran}")
    return d


# Claves de los productores reales (fuera_de_muestra_T.json; resultado.json de corte.py con fuente simulada).
FUERA_RAIZ = {"categoria", "prerregistro_sha256", "script_sha256", "codigo_sha256", "manifiestos_sha256", "ventana", "dias",
              "decision_prerregistrada", "principal", "secundarios"}
FUERA_SIMBOLO = ({"exceso_anual", "ic90_anual", "p"}, {"exposicion_media", "T", "estatica", "buy_and_hold"})
FUERA_SECUNDARIOS = ({"costes_x2"}, {"subventanas", "costes_x3", "retraso_1_dia", "nulo_circular_BTC", "replicacion",
                                     "desarrollo_mas_fuera_de_muestra", "efectivo"})
PAPEL_EVALUACION = {"prerregistro_sha256", "codigo_sha256", "rama", "inicio", "corte", "dias", "meses",
                    "exceso_anual_conjunto", "bootstrap_conjunto", "bootstrap_btc", "exceso_anual_conjunto_costes_x2",
                    "decision"}
BOOTSTRAP_APLICABLE = {"aplicable", "dias", "media_diaria", "media_anual", "intervalo_anual", "p_mayor_que_cero",
                       "bloque", "remuestreos", "semilla", "nivel"}
CORTE_COMUN = {"corte_exclusivo", "rama", "inicio", "reglas_sha256", "codigo_sha256", "problemas", "datos_sha256", "estado",
               "monitor_carry"}
CORTE_EVALUADO = CORTE_COMUN | {"evaluacion", "dias_calendario", "decisiones_sha256"}
COLUMNAS_DECISIONES = ("dia", "decision_con_cierre_de", "cierre_usado", "disponible_desde_utc", "exposicion_objetivo",
                       "precio_referencia_apertura", "valor_operado", "coste", "equity_cierre", "exposicion_cierre",
                       "equity_buy_and_hold", "equity_estatica")
COLUMNAS_TEXTO = {"dia", "decision_con_cierre_de", "disponible_desde_utc"}

# Marcas completas de cada esquema y claves DISTINTIVAS de un resultado de T (si aparece alguna sin un esquema completo,
# el archivo pretende ser un resultado de T y no lo es: ESQUEMA → CORRUPTO).
MARCAS = {"fuera_de_muestra": ("decision_prerregistrada", "principal"),
          "papel_corte": ("corte_exclusivo", "estado"),
          "papel_evaluar": ("rama", "corte", "inicio")}
DISTINTIVAS = frozenset({"decision_prerregistrada", "principal", "manifiestos_sha256", "script_sha256", "corte_exclusivo",
                         "reglas_sha256", "decisiones_sha256", "datos_sha256", "bootstrap_conjunto", "bootstrap_btc",
                         "prerregistro_sha256", "codigo_sha256"})


# ---------- esquemas ----------
def detectar_esquema(obj: object) -> str:
    if not isinstance(obj, dict):
        raise ErrorVerificacion("TIPO_NO_ADMITIDO", f"un resultado de T es un objeto JSON; esto es {type(obj).__name__}")
    hallados = [k for k, m in MARCAS.items() if all(c in obj for c in m)]
    if len(hallados) == 1:
        return hallados[0]
    if len(hallados) > 1:
        raise ErrorVerificacion("ESQUEMA", f"esquema ambiguo (coincide con {hallados})")
    distintivas = sorted(DISTINTIVAS & set(obj))
    texto_de_t = obj.get("decision") in DECISIONES_PAPEL or obj.get("decision_prerregistrada") in DECISIONES_FUERA
    if not distintivas and texto_de_t:
        distintivas = ["decision"]  # un texto de decisión de T: pretende ser un resultado de T
    if distintivas:
        raise ErrorVerificacion("ESQUEMA", f"tiene claves de un resultado de T ({distintivas}) pero no las de ningún "
                                           "esquema completo")
    for clave_, motivo in EVIDENCIA_NO_ADMITIDA.items():
        if clave_ in obj:
            raise ErrorVerificacion("PROCEDENCIA_NO_VERIFICADA", motivo)
    raise ErrorVerificacion("TIPO_NO_ADMITIDO", "no es un resultado de T (ningún esquema conocido)")


def _estado_corte(obj: dict) -> str:
    """Coherencia de un corte de corte.py antes de mirar su evaluación."""
    estado = _texto(obj, "estado")
    if estado != "EVALUADO":
        presentes = sorted({"evaluacion", "dias_calendario", "decisiones_sha256"} & set(obj))
        if presentes:
            raise ErrorVerificacion("CONTRADICCION", f"estado {estado!r} pero hay campos de evaluación {presentes}")
    _claves(obj, "", CORTE_EVALUADO if estado == "EVALUADO" else CORTE_COMUN)
    for campo in ("datos_sha256",) + (("decisiones_sha256",) if estado == "EVALUADO" else ()):
        _claves(obj, campo, set(SIMBOLOS))
        for s in SIMBOLOS:
            _sha_campo(obj, f"{campo}.{s}")
    problemas = _clave(obj, "problemas")
    if not isinstance(problemas, list) or not all(isinstance(p, str) and p for p in problemas):
        raise ErrorVerificacion("TIPO", f"problemas: se esperaba una lista de textos, hay {problemas!r}")
    corte, inicio = _fecha(obj, "corte_exclusivo"), _fecha(obj, "inicio")
    if estado == "EVALUADO":
        if problemas:
            raise ErrorVerificacion("CONTRADICCION", "corte EVALUADO con problemas registrados (corte.py no evalúa si "
                                                     "hay problemas)")
        return estado
    if estado.startswith("NO EVALUABLE"):
        if not problemas:
            raise ErrorVerificacion("CONTRADICCION", "NO EVALUABLE sin ningún problema registrado")
    elif estado.startswith("SIN OBSERVACIONES PROSPECTIVAS"):
        if corte > inicio:
            raise ErrorVerificacion("CONTRADICCION", f"SIN OBSERVACIONES pero el corte ({corte}) es posterior al "
                                                     f"inicio ({inicio})")
    else:
        raise ErrorVerificacion("VALOR", f"estado de corte desconocido: {estado!r}")
    raise ErrorVerificacion("SIN_EVALUACION", f"corte provisional coherente ({estado!r}): no hay decisión que verificar")


def normalizar(obj: object, esquema: str | None = None) -> Registro:
    esquema = esquema or detectar_esquema(obj)
    if esquema == "fuera_de_muestra":
        r = Registro("fuera_de_muestra", _texto(obj, "decision_prerregistrada"),
                     _num(obj, "principal.conjunto.exceso_anual"), _ic(obj, "principal.conjunto.ic90_anual"),
                     _prob(obj, "principal.conjunto.p"), _prob(obj, "principal.BTC.p"),
                     _num(obj, "secundarios.costes_x2.conjunto"), _entero(obj, "dias"), None,
                     {"prerregistro_archivo": _sha_campo(obj, "prerregistro_sha256"),
                      "script": _sha_campo(obj, "script_sha256"), "codigo": _sha_campo(obj, "codigo_sha256"),
                      **{f"manifiesto_{s}": _sha_campo(obj, f"manifiestos_sha256.{s}") for s in SIMBOLOS}})
        if r.decision not in DECISIONES_FUERA:
            raise ErrorVerificacion("VALOR", f"decision_prerregistrada desconocida: {r.decision!r}")
        _claves(obj, "", FUERA_RAIZ)
        _claves(obj, "principal", {"ventana", "BTC", "ETH", "conjunto"})
        for k in ("BTC", "ETH"):
            _claves(obj, f"principal.{k}", *FUERA_SIMBOLO)
            _num(obj, f"principal.{k}.exceso_anual"), _ic(obj, f"principal.{k}.ic90_anual"), _prob(obj, f"principal.{k}.p")
        _claves(obj, "principal.conjunto", FUERA_SIMBOLO[0])
        _claves(obj, "manifiestos_sha256", set(SIMBOLOS))
        _claves(obj, "secundarios", *FUERA_SECUNDARIOS)
        _claves(obj, "secundarios.costes_x2", {"BTC", "ETH", "conjunto"})
        for k in ("BTC", "ETH"):
            _num(obj, f"secundarios.costes_x2.{k}")
        _texto(obj, "categoria")
        ventana, principal = _clave(obj, "ventana"), _clave(obj, "principal.ventana")
        if not (isinstance(ventana, list) and len(ventana) == 2):
            raise ErrorVerificacion("TIPO", f"ventana: se esperaba [desde, hasta], hay {ventana!r}")
        _fecha({"x": ventana[0]}, "x"), _fecha({"x": ventana[1]}, "x")
        if ventana != principal:
            raise ErrorVerificacion("CONTRADICCION", f"ventana {ventana!r} ≠ principal.ventana {principal!r}")
        return r
    if esquema == "papel_evaluar":
        return _normalizar_papel(obj, "papel_evaluar")  # type: ignore[arg-type]
    if esquema == "papel_corte":
        _estado_corte(obj)  # type: ignore[arg-type]
        ev = _clave(obj, "evaluacion")
        if _texto(ev, "corte") != obj["corte_exclusivo"]:  # type: ignore[index]
            raise ErrorVerificacion("CONTRADICCION", "evaluacion.corte distinto de corte_exclusivo")
        for k in ("rama", "inicio"):
            if _texto(ev, k) != _texto(obj, k):
                raise ErrorVerificacion("CONTRADICCION", f"evaluacion.{k} distinto del {k} del corte")
        dias_cal = (dt.date.fromisoformat(obj["corte_exclusivo"]) - dt.date.fromisoformat(obj["inicio"])).days  # type: ignore[index]
        if _entero(obj, "dias_calendario") != dias_cal:
            raise ErrorVerificacion("CONTRADICCION", f"dias_calendario ≠ corte − inicio ({dias_cal})")
        r = _normalizar_papel(ev, "papel_corte")
        r.hashes["reglas_corte"] = _sha_campo(obj, "reglas_sha256")
        r.hashes["codigo_corte"] = _sha_campo(obj, "codigo_sha256")
        if r.hashes["reglas_corte"] != r.hashes["reglas_canonicas"] or r.hashes["codigo_corte"] != r.hashes["codigo"]:
            raise ErrorVerificacion("CONTRADICCION", "los hashes del corte y de su evaluación no coinciden")
        return r
    raise ErrorVerificacion("USO", f"esquema no soportado: {esquema!r}")


def _bootstrap(obj: dict, ruta: str) -> tuple[float | None, tuple[float, float] | None]:
    aplicable = _clave(obj, f"{ruta}.aplicable")
    if not isinstance(aplicable, bool):
        raise ErrorVerificacion("TIPO", f"{ruta}.aplicable: se esperaba true/false, hay {aplicable!r}")
    if not aplicable:
        _claves(obj, ruta, {"aplicable", "motivo"})
        return None, None
    _claves(obj, ruta, BOOTSTRAP_APLICABLE)
    return _prob(obj, f"{ruta}.p_mayor_que_cero"), _ic(obj, f"{ruta}.intervalo_anual")


def _normalizar_papel(obj: dict, esquema: str) -> Registro:
    if _texto(obj, "rama") not in ("A", "B"):
        raise ErrorVerificacion("VALOR", f"rama desconocida: {obj['rama']!r}")
    if "decision" not in obj and "estado" in obj:  # evaluar devolvió antes de decidir (sin datos o datos no aptos)
        if esquema == "papel_corte":
            raise ErrorVerificacion("CONTRADICCION", f"corte EVALUADO pero la evaluación dice {obj['estado']!r}")
        raise ErrorVerificacion("SIN_EVALUACION", f"evaluación sin decisión: {obj['estado']!r}")
    _claves(obj, "", PAPEL_EVALUACION, {"T_BTC", "T_ETH"} if esquema == "papel_evaluar" else {"metricas"})
    _fecha(obj, "inicio"), _fecha(obj, "corte")
    p_conj, ic = _bootstrap(obj, "bootstrap_conjunto")
    p_btc, _ = _bootstrap(obj, "bootstrap_btc")
    r = Registro(esquema, _texto(obj, "decision"), _num(obj, "exceso_anual_conjunto"), ic, p_conj, p_btc,
                 _num(obj, "exceso_anual_conjunto_costes_x2"), _entero(obj, "dias"), _num(obj, "meses"),
                 {"reglas_canonicas": _sha_campo(obj, "prerregistro_sha256"), "codigo": _sha_campo(obj, "codigo_sha256")})
    if r.decision not in DECISIONES_PAPEL:
        raise ErrorVerificacion("VALOR", f"decision desconocida: {r.decision!r}")
    if abs(r.meses - r.dias / 30.44) > 1e-9:  # type: ignore[operator]
        raise ErrorVerificacion("CONTRADICCION", f"meses ({r.meses}) ≠ dias/30,44 ({r.dias / 30.44})")
    return r


# ---------- reglas de decisión congeladas, replicadas (las pruebas las comparan con las originales) ----------
def decision_fuera_de_muestra(p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de experimentos/fuera_de_muestra_T.py:44-49 (script 941b6e11…)."""
    if p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "RESPALDADA FUERA DE MUESTRA"
    if p_conj < 0.10:
        return "NO RESPALDADA"
    return "EVIDENCIA INSUFICIENTE"


def decision_papel(meses: float, p_conj: float, p_btc: float, x2: float) -> str:
    """Copia literal de tendencia.papel.decidir (código 73b22f3e…)."""
    if meses < 12:
        return "INFORMATIVO (menos de 12 meses: ninguna decisión)"
    if p_conj < 0.10:
        return "HIPÓTESIS NO RESPALDADA: detener"
    if meses >= 24 and p_conj >= 0.95 and p_btc >= 0.90 and x2 > 0:
        return "VENTAJA RESPALDADA"
    return "EVIDENCIA INSUFICIENTE: continuar"


def recalcular_decision(r: Registro) -> str:
    if r.esquema == "fuera_de_muestra":
        return decision_fuera_de_muestra(r.p_conjunto, r.p_btc, r.exceso_x2)  # type: ignore[arg-type]
    if r.p_conjunto is None or r.p_btc is None:
        if r.meses >= 12:  # type: ignore[operator]  # aquí el código congelado habría decidido con P = 0,5 por defecto
            raise ErrorVerificacion("CONTRADICCION", f"bootstrap no aplicable con {r.meses:.2f} meses: la decisión "
                                                     "dependería del 0,5 por defecto")
        return DECISIONES_PAPEL[0]
    return decision_papel(r.meses, r.p_conjunto, r.p_btc, r.exceso_x2)  # type: ignore[arg-type]


def validar_registro(obj: object) -> tuple[Registro, str]:
    """V1 y V2: esquema estricto y decisión recalculada con la regla congelada. (registro, decisión recalculada)."""
    r = normalizar(obj)
    recalculada = recalcular_decision(r)
    if recalculada != r.decision:
        raise ErrorVerificacion("CONTRADICCION", f"decisión registrada {r.decision!r} ≠ la que dan sus propias cifras "
                                                 f"con la regla congelada ({recalculada!r})")
    return r, recalculada


# ---------- integridad contra archivos reales ----------
ARCHIVOS = {"fuera_de_muestra": {"prerregistro_archivo": "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
                                 "script": "experimentos/fuera_de_muestra_T.py",
                                 **{f"manifiesto_{s}": f"datos/{s}/MANIFIESTO.json" for s in SIMBOLOS}}}


class _Arbol:
    """Lectura ÚNICA de cada archivo del árbol durante una verificación: el hash y el análisis salen de los mismos bytes."""

    def __init__(self, raiz: Path):
        self.raiz, self._bytes = raiz, {}

    def leer(self, rel: str) -> bytes | None:
        if rel not in self._bytes:
            p = self.raiz / rel
            try:
                self._bytes[rel] = p.read_bytes() if p.is_file() else None
            except OSError:
                self._bytes[rel] = None
        return self._bytes[rel]

    def py(self, rel_dir: str) -> list[str]:
        return sorted(f"{rel_dir}/{p.name}" for p in (self.raiz / rel_dir).glob("*.py"))


def _huella(pares: list[tuple[str, bytes]]) -> str:
    h = hashlib.sha256()
    for nombre, b in sorted(pares):
        h.update(nombre.encode() + b"\0" + b)
    return h.hexdigest()


def huella_codigo(src: Path) -> str:
    """Mismo algoritmo que tendencia.papel.huella_codigo (las pruebas lo comparan con el original)."""
    py = sorted(src.glob("*.py"))
    if not py:
        raise ErrorVerificacion("ARCHIVO_AUSENTE", f"no hay archivos .py en {src}")
    return _huella([(p.name, p.read_bytes()) for p in py])


def _json_bytes(b: bytes, que: str) -> object:
    try:
        return json.loads(b.decode("utf-8"), object_pairs_hook=_sin_duplicados)
    except ErrorVerificacion:
        raise
    except ValueError as e:
        raise ErrorVerificacion("JSON_INVALIDO", f"{que}: JSON inválido: {e}") from e


def _hash_canonico(obj: object) -> str:
    return _sha(json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode())


def hash_reglas(ruta: Path) -> str:
    """Mismo algoritmo que tendencia.papel.hash_prerregistro, aplicado al JSON congelado de las reglas."""
    obj, _ = cargar(ruta)
    return _hash_canonico(obj)


def parametros_script(datos: bytes) -> dict:
    """DESDE, HASTA, DIAS y CODIGO del script, leídos con ast (sin ejecutarlo). Si no son literales: NO_DERIVABLE."""
    out: dict = {}
    try:
        for n in ast.parse(datos).body:
            if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Tuple):
                nombres = [getattr(t, "id", None) for t in n.targets[0].elts]
                if nombres == ["DESDE", "HASTA", "DIAS"]:
                    out.update(zip(nombres, ast.literal_eval(n.value), strict=True))
            if isinstance(n, ast.Assign) and len(n.targets) == 1 and getattr(n.targets[0], "id", None) == "CODIGO":
                out["CODIGO"] = ast.literal_eval(n.value)
    except (SyntaxError, ValueError, TypeError) as e:
        raise ErrorVerificacion("NO_DERIVABLE", f"constantes del script no literales o ilegibles: {e}") from e
    for k in ("DESDE", "HASTA", "DIAS", "CODIGO"):
        if k not in out:
            raise ErrorVerificacion("NO_DERIVABLE", f"el script no define {k} como literal")
    return out


def inicio_prerregistrado(raiz: Path, rama: str) -> str:
    """Primera ejecución de la rama según el prerregistro: A, literal; B, RESERVADO_FIN (src/tendencia/datos.py, ast) +
    mayor ventana + 1 día, que además debe ser la fecha entre paréntesis del texto del prerregistro."""
    reglas, _ = cargar(raiz / "papel" / "prerregistro_papel.json")
    p = raiz / "src" / "tendencia" / "datos.py"
    return _inicio(reglas, p.read_bytes() if p.is_file() else None, rama)


def _inicio(reglas: object, datos_py: bytes | None, rama: str) -> str:
    try:
        texto = _texto(reglas, f"ramas.{rama}.primera_ejecucion")
        if rama == "A":
            return texto
        if datos_py is None:
            raise ErrorVerificacion("ARCHIVO_AUSENTE", "falta src/tendencia/datos.py")
        fin = next(ast.literal_eval(n.value) for n in ast.parse(datos_py).body
                   if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", None) == "RESERVADO_FIN")
        mayor = max(max(e["ventanas"]) for e in _clave(reglas, "estrategias").values())
        calculada = (dt.date.fromisoformat(fin) + dt.timedelta(days=mayor + 1)).isoformat()
    except ErrorVerificacion as e:
        raise ErrorVerificacion("NO_DERIVABLE", f"inicio prerregistrado no derivable: {e}") from e
    except (SyntaxError, ValueError, TypeError, KeyError, AttributeError, StopIteration) as e:
        raise ErrorVerificacion("NO_DERIVABLE", f"inicio prerregistrado no derivable: {type(e).__name__}: {e}") from e
    if f"({calculada})" not in texto:
        raise ErrorVerificacion("CONTRADICCION", f"rama B: el código da {calculada}, el prerregistro dice {texto!r}")
    return calculada


def _datos_sha(man: dict) -> str:
    """Mismo algoritmo que papel/corte.py:_datos_sha (ruta y SHA-256 de cada archivo del manifiesto)."""
    try:
        return _sha(json.dumps(sorted((a["ruta"], a["sha256"]) for a in man["archivos"])).encode())
    except (KeyError, TypeError) as e:
        raise ErrorVerificacion("TIPO", f"manifiesto de datos mal formado: {e}") from e


def comprobar_corte(obj: dict, r: Registro, dir_corte: Path, faltas: list) -> dict:
    """Archivos del directorio del corte: manifiestos de datos y tablas de decisiones (filas, columnas, días)."""
    hechos: dict[str, str] = {}
    for s in SIMBOLOS:
        try:
            man, _ = cargar(dir_corte / "datos" / s / "MANIFIESTO.json")
        except ErrorVerificacion as e:
            if clase(e.codigo) == "CORRUPTO":
                raise
            faltas.append((e.codigo, e.detalle))
        else:
            if _datos_sha(man) != obj["datos_sha256"][s]:  # type: ignore[arg-type]
                raise ErrorVerificacion("HASH", f"datos_sha256.{s} no coincide con datos/{s}/MANIFIESTO.json del corte")
            hechos[f"datos_{s}"] = f"datos/{s}/MANIFIESTO.json"
        ruta = dir_corte / f"decisiones_{s}.csv"
        try:
            with ruta.open(encoding="utf-8", newline="") as fh:
                lector = csv.reader(fh)
                cabecera = next(lector, None)
                filas = list(lector)
        except OSError as e:
            faltas.append(("ARCHIVO_AUSENTE", f"no se puede leer {ruta}: {e}"))
            continue
        except (UnicodeDecodeError, csv.Error) as e:
            raise ErrorVerificacion("TIPO", f"{ruta.name}: no es un CSV UTF-8 legible: {e}") from e
        if tuple(cabecera or ()) != COLUMNAS_DECISIONES:
            raise ErrorVerificacion("ESQUEMA", f"{ruta.name}: columnas {cabecera} ≠ {list(COLUMNAS_DECISIONES)}")
        if len(filas) != r.dias:
            raise ErrorVerificacion("CONTRADICCION", f"{ruta.name}: {len(filas)} filas, la evaluación tiene {r.dias} días")
        esperado = [(dt.date.fromisoformat(obj["inicio"]) + dt.timedelta(days=i)).isoformat() for i in range(r.dias)]
        if [f[0] if f else None for f in filas] != esperado:
            raise ErrorVerificacion("CONTRADICCION", f"{ruta.name}: los días no son los consecutivos desde el inicio")
        try:
            dicts = [{c: (v if c in COLUMNAS_TEXTO else float(v)) for c, v in zip(COLUMNAS_DECISIONES, f, strict=True)}
                     for f in filas]
        except ValueError as e:
            raise ErrorVerificacion("TIPO", f"{ruta.name}: fila mal formada: {e}") from e
        if _sha(json.dumps(dicts, sort_keys=True).encode()) != obj["decisiones_sha256"][s]:
            raise ErrorVerificacion("HASH", f"decisiones_sha256.{s} no coincide con {ruta.name}")
        hechos[f"decisiones_{s}"] = f"{ruta.name}: {len(filas)} filas"
    return hechos


def cargar_manifiesto(especificacion: str | Path) -> dict[str, str]:
    """«RUTA» en formato sha256sum, o «RUTA#CLAVE» de un JSON {ruta: sha256 | {"sha256": …}}. Un manifiesto ilegible o
    mal formado: MANIFIESTO_NO_VALIDO (es una referencia, no la evidencia)."""
    ruta, _, clave_ = str(especificacion).partition("#")
    try:
        if clave_ or ruta.endswith(".json"):
            obj, _ = cargar(ruta)
            d = _clave(obj, clave_) if clave_ else obj
            if not isinstance(d, dict):
                raise ErrorVerificacion("TIPO", f"{especificacion}: se esperaba un objeto ruta → sha256")
            return {k: _sha_campo({"x": v.get("sha256") if isinstance(v, dict) else v}, "x") for k, v in d.items()}
        out: dict[str, str] = {}
        try:
            lineas = Path(ruta).read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError) as e:
            raise ErrorVerificacion("ARCHIVO_AUSENTE", f"no se puede leer el manifiesto {ruta}: {e}") from e
        for n, linea in enumerate(lineas, 1):
            if not linea.strip():
                continue
            h, sep, r_ = linea.partition("  ")
            if not sep or len(h) != 64:
                raise ErrorVerificacion("TIPO", f"{ruta}: línea {n} no tiene formato sha256sum")
            if r_ in out and out[r_] != h:
                raise ErrorVerificacion("CONTRADICCION", f"{ruta}: {r_} figura dos veces con hashes distintos")
            out[r_] = _sha_campo({"x": h}, "x")
        return out
    except ErrorVerificacion as e:
        if e.codigo == "CONTRADICCION":  # referencias que se contradicen: CORRUPTO, como entre manifiestos
            raise
        raise ErrorVerificacion("MANIFIESTO_NO_VALIDO", f"{especificacion}: {e.codigo}: {e.detalle}") from e


def unir_manifiestos(especificaciones: list[str]) -> dict[str, str]:
    """Varios manifiestos; si discrepan sobre una ruta: CONTRADICCION (referencias contradictorias → CORRUPTO)."""
    unido: dict[str, str] = {}
    for m in especificaciones:
        for k, v in cargar_manifiesto(m).items():
            if unido.get(k, v) != v:
                raise ErrorVerificacion("CONTRADICCION", f"los manifiestos discrepan sobre {k}")
            unido[k] = v
    return unido


def _comprobar_manifiesto(ruta: Path) -> int:
    """Cada archivo listado en un MANIFIESTO.json contra su SHA-256 (lee bytes de datos: solo con --datos)."""
    man, _ = cargar(ruta)
    archivos = _clave(man, "archivos")
    if not isinstance(archivos, list) or not archivos:
        raise ErrorVerificacion("TIPO", f"{ruta}: 'archivos' debe ser una lista no vacía")
    for a in archivos:
        p = ruta.parent / _texto(a, "ruta")
        if not p.is_file():
            raise ErrorVerificacion("ARCHIVO_AUSENTE", f"{p}: listado en el manifiesto y ausente")
        if _sha(p.read_bytes()) != _sha_campo(a, "sha256"):
            raise ErrorVerificacion("HASH", f"{p}: no coincide con su manifiesto")
    return len(archivos)


def comprobar_integridad(r: Registro, obj: dict, raiz: Path, datos: bool, faltas: list) -> tuple[dict, list[str], dict]:  # noqa: C901
    """Recalcula desde ``raiz`` cada hash que declara el resultado, leyendo cada archivo UNA vez. Las faltas (archivos
    ausentes, datos no derivables) se acumulan en ``faltas`` y se sigue con lo que no depende de ellas; una discrepancia
    lanza en el acto. Devuelve ({nombre: origen}, no_comprobado, {ruta relativa: sha256 de cada archivo leído})."""
    arbol = _Arbol(raiz)
    hechos: dict[str, str] = {}
    rutas: dict[str, str] = {}

    def igual(nombre: str, real: str, origen: str) -> None:
        if real != r.hashes[nombre]:
            raise ErrorVerificacion("HASH", f"{nombre}: {origen} da {real[:12]}…, el resultado declara "
                                            f"{r.hashes[nombre][:12]}…")
        hechos[nombre] = origen

    def leer(rel: str, nombre: str) -> bytes | None:
        b = arbol.leer(rel)
        if b is None:
            faltas.append(("ARCHIVO_AUSENTE", f"{nombre}: falta {raiz / rel}"))
            return None
        rutas[rel] = _sha(b)
        return b

    def diferir(f):  # type: ignore[no-untyped-def]
        try:
            return f()
        except ErrorVerificacion as e:
            if clase(e.codigo) == "CORRUPTO":
                raise
            faltas.append((e.codigo, e.detalle))
            return None

    contenido: dict[str, bytes] = {}
    for nombre, rel in ARCHIVOS.get(r.esquema, {}).items():
        b = leer(rel, nombre)
        if b is not None:
            contenido[rel] = b
            igual(nombre, rutas[rel], rel)
    fuentes = arbol.py("src/tendencia")
    if not fuentes:
        faltas.append(("ARCHIVO_AUSENTE", f"no hay archivos .py en {raiz / 'src' / 'tendencia'}"))
    else:
        pares = [(rel.rsplit("/", 1)[1], leer(rel, rel)) for rel in fuentes]
        if all(b is not None for _, b in pares):
            igual("codigo", _huella(pares), "huella de src/tendencia/*.py")  # type: ignore[arg-type]
    no_comprobado: list[str] = []
    if r.esquema == "fuera_de_muestra":
        rel_script = ARCHIVOS["fuera_de_muestra"]["script"]
        par = diferir(lambda: parametros_script(contenido[rel_script])) if rel_script in contenido else None
        if par is not None:
            if par["CODIGO"] != r.hashes["codigo"]:
                raise ErrorVerificacion("CONTRADICCION", f"codigo_sha256 ({r.hashes['codigo'][:12]}…) ≠ CODIGO fijado en "
                                                         f"el script verificado ({str(par['CODIGO'])[:12]}…)")
            hechos["codigo_igual_al_del_script"] = "CODIGO del script (ast)"
            if obj["ventana"] != [par["DESDE"], par["HASTA"]] or r.dias != par["DIAS"]:
                raise ErrorVerificacion("CONTRADICCION", f"ventana {obj['ventana']} / días {r.dias} ≠ los del script "
                                                         f"verificado ({par['DESDE']}–{par['HASTA']}, {par['DIAS']})")
            hechos["ventana_y_dias"] = "constantes del script verificado (ast)"
        if datos:
            for s in SIMBOLOS:
                rel = ARCHIVOS["fuera_de_muestra"][f"manifiesto_{s}"]
                if rel in contenido:
                    n = diferir(lambda rel=rel: _comprobar_manifiesto(raiz / rel))
                    if n is not None:
                        hechos[f"datos_{s}"] = f"{n} archivos"
        else:
            no_comprobado.append("archivos de datos listados en los manifiestos (no se leen sin --datos)")
    else:
        rel_reglas = "papel/prerregistro_papel.json"
        b_reglas = leer(rel_reglas, "reglas")
        if b_reglas is not None:
            reglas = _json_bytes(b_reglas, rel_reglas)
            igual("reglas_canonicas", _hash_canonico(reglas), "papel/prerregistro_papel.json canonizado")
            datos_py = arbol.leer("src/tendencia/datos.py")
            esperado = diferir(lambda: _inicio(reglas, datos_py, obj["rama"]))
            if esperado is not None:
                if obj["inicio"] != esperado:
                    raise ErrorVerificacion("CONTRADICCION", f"inicio {obj['inicio']} ≠ primera ejecución prerregistrada "
                                                             f"de la rama {obj['rama']} ({esperado})")
                hechos["inicio_prerregistrado"] = f"rama {obj['rama']}"
        if r.esquema == "papel_corte":
            igual("reglas_corte", r.hashes["reglas_canonicas"], "igual a reglas_canonicas")
            igual("codigo_corte", r.hashes["codigo"], "igual a codigo")
    return hechos, no_comprobado, rutas


def comprobar_registro(obj: dict, resultado_sha256: str, registro: Path) -> str:
    """REGISTRO.jsonl de corte.py: cadena linea_anterior_sha256 y entrada con el SHA-256 de ESTE archivo."""
    try:
        texto = registro.read_text(encoding="utf-8")
    except OSError as e:
        raise ErrorVerificacion("ARCHIVO_AUSENTE", f"no se puede leer {registro}: {e}") from e
    except UnicodeDecodeError as e:
        raise ErrorVerificacion("REGISTRO", f"{registro.name} no es UTF-8") from e
    if not texto.endswith("\n"):
        raise ErrorVerificacion("REGISTRO", "la última línea del registro está incompleta")
    anterior, propias = None, []
    for n, linea in enumerate(texto.split("\n")[:-1], 1):
        try:
            x = json.loads(linea, object_pairs_hook=_sin_duplicados)
        except ValueError as e:
            raise ErrorVerificacion("REGISTRO", f"línea {n} ilegible") from e
        if not isinstance(x, dict) or x.get("linea_anterior_sha256") != anterior:
            raise ErrorVerificacion("REGISTRO", f"cadena rota en la línea {n}")
        anterior = _sha(linea.encode())
        if x.get("corte") == obj["corte_exclusivo"]:
            propias.append((n, x))
    evaluadas = [n for n, x in propias if x.get("estado") == "EVALUADO"]
    if len(evaluadas) > 1:
        raise ErrorVerificacion("REGISTRO", f"el corte figura EVALUADO más de una vez (líneas {evaluadas})")
    coinciden = [n for n, x in propias if x.get("resultado_sha256") == resultado_sha256 and x.get("estado") == obj["estado"]]
    if not coinciden:
        raise ErrorVerificacion("REGISTRO", f"ninguna línea del registro tiene este archivo ({resultado_sha256[:12]}…) "
                                            f"con estado {obj['estado']!r}")
    if obj["estado"] == "EVALUADO" and coinciden[-1] != propias[-1][0]:
        raise ErrorVerificacion("REGISTRO", "hay líneas del corte posteriores a su evaluación")
    return f"línea {coinciden[-1]} de {registro.name}"


# ---------- verificación local (lanza ErrorVerificacion; base de evaluar) ----------
SEMANTICA = {"fuera_de_muestra": {"prerregistro_archivo", "script", "codigo", "manifiesto_BTCUSDT", "manifiesto_ETHUSDT"},
             "papel_evaluar": {"reglas_canonicas", "codigo"},
             "papel_corte": {"reglas_canonicas", "codigo", "reglas_corte", "codigo_corte"}}


def verificar(obj: object, raiz: str | Path | None = None, resultado_sha256: str | None = None,  # noqa: C901
              registro: str | Path | None = None, esperados: dict[str, str] | None = None,
              datos: bool = False, resultado_sha256_esperado: str | None = None,
              manifiesto: dict | None = None, dir_corte: str | Path | None = None,
              ruta_resultado: str | Path | None = None) -> dict:
    """Comprobaciones V1–V4 y V6 (sin autenticidad). Devuelve el informe de integridad LOCAL (``integridad_local``
    COMPLETA o PARCIAL) o lanza ErrorVerificacion: en el acto si es CORRUPTO; al final, con todos los motivos, si solo
    hay faltas (INCONCLUSO)."""
    faltas: list[tuple[str, str]] = []
    if resultado_sha256_esperado is not None:
        if not _es_sha(resultado_sha256_esperado):
            raise ErrorVerificacion("USO", f"--resultado-sha256 no es un SHA-256 hexadecimal: {resultado_sha256_esperado!r}")
        if resultado_sha256 != resultado_sha256_esperado:
            raise ErrorVerificacion("HASH", f"el archivo ({(resultado_sha256 or 'sin hash')[:12]}…) no es el presellado "
                                            f"({resultado_sha256_esperado[:12]}…)")
    r, recalculada = validar_registro(obj)
    esperados = esperados or {}
    for nombre, valor in esperados.items():
        if nombre not in SEMANTICA[r.esquema]:
            otros = [e for e, s in SEMANTICA.items() if nombre in s]
            raise ErrorVerificacion("USO", f"'{nombre}' no se aplica al esquema {r.esquema} (se aplica a {otros})")
        if r.hashes[nombre] != valor:
            raise ErrorVerificacion("HASH", f"{nombre}: el resultado dice {r.hashes[nombre][:12]}…, la referencia "
                                            f"declarada es {str(valor)[:12]}…")
    if registro is not None and r.esquema != "papel_corte":
        raise ErrorVerificacion("USO", f"--registro solo se aplica a cortes, no a {r.esquema}")
    if manifiesto is not None and raiz is None:
        raise ErrorVerificacion("USO", "el contraste con un manifiesto exige --raiz")
    integridad: dict = {}
    no_comprobado = ["ningún hash recalculado desde archivos (falta --raiz)"] if raiz is None else []
    rutas: dict[str, str] = {}
    completo = raiz is not None
    if raiz is not None:
        integridad, nc, rutas = comprobar_integridad(r, obj, Path(raiz), datos, faltas)  # type: ignore[arg-type]
        no_comprobado += nc
    rel = None
    if raiz is not None and ruta_resultado is not None:
        try:
            rel = Path(ruta_resultado).resolve().relative_to(Path(raiz).resolve()).as_posix()
        except ValueError:
            rel = None
    contraste: dict | None = None
    if manifiesto is not None:
        try:
            manifiesto = {k: _sha_campo({"x": v.get("sha256") if isinstance(v, dict) else v}, "x")
                          for k, v in manifiesto.items()}
        except ErrorVerificacion as e:
            raise ErrorVerificacion("MANIFIESTO_NO_VALIDO", e.detalle) from e
        contraste = {"coinciden": [], "no_listados": []}
        leidos = dict(rutas)
        if rel is not None and resultado_sha256 is not None:
            leidos[rel] = resultado_sha256
        for ruta_rel, sha in leidos.items():
            if ruta_rel in manifiesto:
                if manifiesto[ruta_rel] != sha:
                    raise ErrorVerificacion("HASH_MANIFIESTO", f"{ruta_rel}: {sha[:12]}… ≠ manifiesto "
                                                               f"{manifiesto[ruta_rel][:12]}…")
                contraste["coinciden"].append(ruta_rel)
            else:
                contraste["no_listados"].append(ruta_rel)
        if rel is None:
            faltas.append(("MANIFIESTO_NO_CUBRE", "el resultado no está dentro de --raiz: el manifiesto no lo describe"))
        elif rel not in manifiesto:
            faltas.append(("MANIFIESTO_NO_CUBRE", f"el manifiesto no describe este resultado ({rel})"))
    if r.esquema == "papel_corte":
        if dir_corte is not None:
            integridad.update(comprobar_corte(obj, r, Path(dir_corte), faltas))  # type: ignore[arg-type]
        else:
            completo = False
            no_comprobado.append("datos y tablas de decisiones del directorio del corte")
        if registro is not None:
            if resultado_sha256 is None:
                raise ErrorVerificacion("USO", "para comprobar el registro hace falta el SHA-256 del archivo")
            try:
                integridad["archivo_en_registro"] = comprobar_registro(obj, resultado_sha256, Path(registro))  # type: ignore[arg-type]
            except ErrorVerificacion as e:
                if clase(e.codigo) == "CORRUPTO":
                    raise
                faltas.append((e.codigo, e.detalle))
        else:
            completo = False
            no_comprobado.append("REGISTRO.jsonl del corte (falta --registro)")
    if faltas:
        raise ErrorVerificacion(faltas[0][0], faltas[0][1], faltas)
    inicio_ventana = obj["ventana"][0] if r.esquema == "fuera_de_muestra" else obj["inicio"]  # type: ignore[index]
    return {"version": VERSION, "integridad_local": "COMPLETA" if completo else "PARCIAL",
            "esquema": r.esquema, "resultado_sha256": resultado_sha256, "ruta_relativa": rel,
            "inicio_ventana": inicio_ventana,
            "naturaleza": "EVALUADO_SIN_DECISION" if r.decision == DECISIONES_PAPEL[0] else "EVALUADO_CON_DECISION",
            "decision": r.decision, "decision_recalculada": recalculada, "exceso_anual": r.exceso_anual,
            "ic90": list(r.ic90) if r.ic90 else None, "p_conjunto": r.p_conjunto, "p_btc": r.p_btc,
            "exceso_x2": r.exceso_x2, "dias": r.dias, "hashes_declarados": r.hashes,
            "integridad_desde_archivos": integridad, "archivos_leidos": rutas,
            "referencias_declaradas_coinciden": sorted(esperados),
            "resultado_sha256_esperado_coincide": resultado_sha256_esperado is not None,
            "contraste_con_manifiestos": contraste, "no_comprobado": no_comprobado}


def verificar_archivo(ruta: str | Path, **kw) -> dict:  # type: ignore[no-untyped-def]
    obj, sha = cargar(ruta)
    if isinstance(obj, dict) and "corte_exclusivo" in obj:
        kw.setdefault("dir_corte", Path(ruta).parent)
    return verificar(obj, resultado_sha256=sha, ruta_resultado=ruta, **kw)


# ---------- autenticidad (V5) ----------
def contrastar_declaraciones(declaraciones: list[tuple[str, object]], resultado_sha256: str | None,
                             ruta_relativa: str | None, archivos_leidos: dict[str, str]) -> dict:
    """Cada declaración se verifica contra ``RAICES_CONFIANZA``. Devuelve las que cubren el resultado (por su SHA-256),
    las que lo contradicen (misma ruta o archivo leído con otro SHA-256) y las no válidas (con su motivo)."""
    cubren, contradicen, no_validas = [], [], []
    for nombre, doc in declaraciones:
        try:
            decl, raiz = C.verificar_declaracion(doc, RAICES_CONFIANZA)
        except C.ErrorConfianza as e:
            no_validas.append(f"{nombre}: {e.codigo}: {e.detalle}")
            continue
        quien = f"{nombre} (emisor {raiz['id']}, {raiz['tipo']}, {C.huella_clave(raiz['clave_publica_ed25519'])})"
        leidos = dict(archivos_leidos)
        if ruta_relativa is not None and resultado_sha256 is not None:
            leidos[ruta_relativa] = resultado_sha256
        for a in decl["artefactos"]:
            if "ruta" in a and a["ruta"] in leidos and a["sha256"] != leidos[a["ruta"]]:
                contradicen.append(f"{quien}: {a['ruta']} declarado {a['sha256'][:12]}…, archivo "
                                   f"{leidos[a['ruta']][:12]}…")
        if resultado_sha256 is not None and any(a["sha256"] == resultado_sha256 for a in decl["artefactos"]):
            cubren.append(quien)
    return {"cubren": cubren, "contradicen": contradicen, "no_validas": no_validas}


# ---------- evaluación (estados; nunca lanza) ----------
DEFINICIONES = {
    "VERIFICADO": "V1–V6: esquema estricto, regla congelada, integridad completa desde --raiz, referencias locales "
                  "coherentes y SHA-256 del resultado cubierto por una declaración firmada de una raíz aprobada",
    "CORRUPTO": "inconsistencia demostrada en el resultado o entre él, sus archivos y las referencias suministradas",
    "INCONCLUSO": "ninguna inconsistencia demostrada, pero falta al menos una condición de VERIFICADO (ver motivos)",
    "REPRODUCIDO": "original VERIFICADO y reproducción válida sin diferencias (tolerancia explícita)",
    "NO_REPRODUCIDO": "original VERIFICADO y reproducción válida con diferencias",
}


def _motivos(pares: list[tuple[str, str]]) -> list[dict]:
    return [{"codigo": c, "clase": clase(c), "detalle": d} for c, d in pares]


def _con_estado(estado: str, base: dict, motivos: list[tuple[str, str]], **extra: object) -> dict:
    return {"version": VERSION, "estado": estado, "definicion": DEFINICIONES[estado], **base,
            "motivos": _motivos(motivos), **extra}


def evaluar(obj: object, resultado_sha256: str | None, *, declaraciones: list[tuple[str, object]] = (),  # type: ignore[assignment]
            **kw) -> dict:  # type: ignore[no-untyped-def]
    """Estado de un resultado YA leído (``obj`` y el SHA-256 de esos mismos bytes). Nunca lanza."""
    base: dict = {"resultado_sha256": resultado_sha256}
    try:
        inf, error = verificar(obj, resultado_sha256=resultado_sha256, **kw), None
    except ErrorVerificacion as e:
        inf, error = None, e
    except Exception as e:  # noqa: BLE001  defensa: nunca un rastro sin estado
        return _con_estado("INCONCLUSO", base, [("ERROR_INTERNO", f"{type(e).__name__}: {e}")])
    if error is not None and clase(error.codigo) == "CORRUPTO":
        return _con_estado("CORRUPTO", base, [(error.codigo, error.detalle)])
    rel, leidos = (inf["ruta_relativa"], inf["archivos_leidos"]) if inf else (None, {})
    if inf is None and kw.get("raiz") is not None and kw.get("ruta_resultado") is not None:
        try:
            rel = Path(kw["ruta_resultado"]).resolve().relative_to(Path(kw["raiz"]).resolve()).as_posix()
        except ValueError:
            rel = None
    try:
        aut = contrastar_declaraciones(list(declaraciones), resultado_sha256, rel, leidos)
    except Exception as e:  # noqa: BLE001
        return _con_estado("INCONCLUSO", base, [("ERROR_INTERNO", f"declaraciones: {type(e).__name__}: {e}")])
    autenticidad = {"estado": "CONTRASTADA" if aut["cubren"] and not aut["contradicen"] else "NO_CONTRASTADA",
                    "raices_aprobadas": sorted(RAICES_CONFIANZA), **aut}
    if inf is not None:
        base.update({k: v for k, v in inf.items() if k != "version"})
    if aut["contradicen"]:
        return _con_estado("CORRUPTO", base, [("HASH_REFERENCIA", "; ".join(aut["contradicen"]))],
                           autenticidad=autenticidad)
    motivos = list(error.motivos) if error is not None else []
    if inf is not None and inf["integridad_local"] != "COMPLETA":
        motivos.append(("INTEGRIDAD_INCOMPLETA", "; ".join(inf["no_comprobado"])))
    if not aut["cubren"]:
        detalle = ("ninguna declaración firmada por una raíz de confianza aprobada cubre el SHA-256 del resultado "
                   f"(raíces aprobadas: {len(RAICES_CONFIANZA)})")
        if aut["no_validas"]:
            detalle += "; no válidas: " + "; ".join(aut["no_validas"])
        motivos.append(("SIN_REFERENCIA_INDEPENDIENTE", detalle))
    return _con_estado("INCONCLUSO" if motivos else "VERIFICADO", base, motivos, autenticidad=autenticidad)


def _cargar_para_evaluar(ruta: str | Path, kw: dict) -> tuple[object, str | None, dict | None]:
    try:
        obj, sha = cargar(ruta)
    except ErrorVerificacion as e:
        est = clase(e.codigo)
        return None, None, _con_estado(est, {"resultado_sha256": None}, [(e.codigo, e.detalle)])
    if isinstance(obj, dict) and "corte_exclusivo" in obj:
        kw.setdefault("dir_corte", Path(ruta).parent)
    kw["ruta_resultado"] = ruta
    return obj, sha, None


def evaluar_archivo(ruta: str | Path, *, declaraciones: list[tuple[str, object]] = (), **kw) -> dict:  # type: ignore[no-untyped-def,assignment]
    """Lee el archivo UNA vez y evalúa esos bytes."""
    obj, sha, fallo = _cargar_para_evaluar(ruta, kw)
    return fallo if fallo is not None else evaluar(obj, sha, declaraciones=declaraciones, **kw)


def comparar_completo(a: object, b: object, tolerancia: float = 0.0, ruta: str = "") -> list[str]:
    """Todas las hojas: misma estructura, mismas claves, mismos textos y booleanos; números con |a − b| ≤ tolerancia."""
    if isinstance(a, bool) or isinstance(b, bool) or a is None or b is None or isinstance(a, str) or isinstance(b, str):
        return [] if (type(a) is type(b) and a == b) else [f"{ruta or 'raíz'}: {a!r} ≠ {b!r}"]
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        ok = math.isfinite(a) and math.isfinite(b) and abs(a - b) <= tolerancia
        return [] if ok else [f"{ruta}: {a!r} ≠ {b!r} (tolerancia {tolerancia})"]
    if isinstance(a, dict) and isinstance(b, dict):
        dif = [f"{ruta}.{k}: solo en {'el original' if k in a else 'la reproducción'}" for k in sorted(set(a) ^ set(b))]
        for k in sorted(set(a) & set(b)):
            dif += comparar_completo(a[k], b[k], tolerancia, f"{ruta}.{k}" if ruta else k)
        return dif
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [f"{ruta}: longitudes {len(a)} ≠ {len(b)}"]
        return [d for i, (x, y) in enumerate(zip(a, b, strict=True))
                for d in comparar_completo(x, y, tolerancia, f"{ruta}[{i}]")]
    return [f"{ruta}: tipos distintos ({type(a).__name__} / {type(b).__name__})"]


def _tolerancia(t: object) -> float:
    if isinstance(t, bool) or not isinstance(t, (int, float)) or not math.isfinite(t) or t < 0:
        raise ErrorVerificacion("USO", f"tolerancia inválida: {t!r}")
    return float(t)


def _comparar_reproduccion(original: object, esquema: str, reproduccion: object, tolerancia: float) -> list[str]:
    try:
        rr, _ = validar_registro(reproduccion)
    except ErrorVerificacion as e:
        raise ErrorVerificacion("REPRODUCCION_NO_VALIDA", f"la reproducción no es válida: {e.codigo}: {e.detalle}") from e
    if rr.esquema != esquema:
        raise ErrorVerificacion("REPRODUCCION_NO_VALIDA", f"la reproducción es {rr.esquema}, el original {esquema}")
    return comparar_completo(original, reproduccion, tolerancia)


def reproducir(ruta: str | Path, reproduccion: object, tolerancia: float = 0.0, **kw) -> dict:  # type: ignore[no-untyped-def]
    """Nivel LOCAL (lanza ErrorVerificacion): exige integridad local COMPLETA y compara con los MISMOS bytes evaluados.
    ``comparacion`` = SIN_DIFERENCIAS | CON_DIFERENCIAS. No declara REPRODUCIDO: eso lo hace evaluar_reproduccion."""
    tol = _tolerancia(tolerancia)
    obj, sha = cargar(ruta)
    if isinstance(obj, dict) and "corte_exclusivo" in obj:
        kw.setdefault("dir_corte", Path(ruta).parent)
    inf = verificar(obj, resultado_sha256=sha, ruta_resultado=ruta, **kw)
    if inf["integridad_local"] != "COMPLETA":
        raise ErrorVerificacion("INTEGRIDAD_INCOMPLETA", "no se compara una reproducción con un original sin integridad "
                                                         "local completa")
    dif = _comparar_reproduccion(obj, inf["esquema"], reproduccion, tol)
    return {**inf, "comparacion": "CON_DIFERENCIAS" if dif else "SIN_DIFERENCIAS", "tolerancia": tol,
            "discrepancias": dif}


def evaluar_reproduccion(ruta: str | Path, reproduccion: object, tolerancia: object = 0.0, *,  # type: ignore[assignment]
                         declaraciones: list[tuple[str, object]] = (), **kw) -> dict:  # type: ignore[no-untyped-def]
    """REPRODUCIDO / NO_REPRODUCIDO solo sobre un original VERIFICADO; si no, el estado del original. Nunca lanza."""
    try:
        tol = _tolerancia(tolerancia)
    except ErrorVerificacion as e:
        return _con_estado("INCONCLUSO", {"resultado_sha256": None}, [(e.codigo, e.detalle)])
    obj, sha, fallo = _cargar_para_evaluar(ruta, kw)
    if fallo is not None:
        return fallo
    inf = evaluar(obj, sha, declaraciones=declaraciones, **kw)
    if inf["estado"] != "VERIFICADO":
        return {**inf, "reproduccion": "NO EVALUADA: el original no es VERIFICADO"}
    base = {k: v for k, v in inf.items() if k not in ("version", "estado", "definicion", "motivos")}
    try:
        dif = _comparar_reproduccion(obj, inf["esquema"], reproduccion, tol)
    except ErrorVerificacion as e:
        return _con_estado("INCONCLUSO", base, [(e.codigo, e.detalle)])
    return _con_estado("NO_REPRODUCIDO" if dif else "REPRODUCIDO", base, [], tolerancia=tol, discrepancias=dif)


def comparar(a: object, b: object, tolerancia: float = 0.0) -> list[str]:
    """Evidencia contradictoria entre dos registros del MISMO experimento. Lista de discrepancias; vacía = coherentes."""
    ra, rb = normalizar(a), normalizar(b)
    dif = []
    if ra.esquema != rb.esquema:
        dif.append(f"esquemas distintos ({ra.esquema} / {rb.esquema})")
    for campo in ("decision", "dias"):
        if getattr(ra, campo) != getattr(rb, campo):
            dif.append(f"{campo}: {getattr(ra, campo)!r} ≠ {getattr(rb, campo)!r}")
    for campo in ("exceso_anual", "p_conjunto", "p_btc", "exceso_x2"):
        x, y = getattr(ra, campo), getattr(rb, campo)
        if (x is None) != (y is None) or (x is not None and abs(x - y) > tolerancia):
            dif.append(f"{campo}: {x!r} ≠ {y!r}")
    if (ra.ic90 is None) != (rb.ic90 is None) or (
            ra.ic90 and any(abs(x - y) > tolerancia for x, y in zip(ra.ic90, rb.ic90, strict=True))):  # type: ignore[arg-type]
        dif.append(f"ic90: {ra.ic90} ≠ {rb.ic90}")
    for k in sorted(set(ra.hashes) | set(rb.hashes)):
        if ra.hashes.get(k) != rb.hashes.get(k):
            dif.append(f"hash {k}: {ra.hashes.get(k)} ≠ {rb.hashes.get(k)}")
    if dif and dif[0].startswith("esquemas distintos"):
        return dif
    return dif + comparar_completo(a, b, tolerancia)


def main(argv: list[str]) -> int:  # noqa: C901
    if not argv or argv[0].startswith("--"):
        print(__doc__)
        return 2
    ruta, kw, i = argv[0], {}, 1
    manifiestos: list[str] = []
    rutas_decl: list[str] = []
    while i < len(argv):
        if argv[i] == "--datos":
            kw["datos"], i = True, i + 1
        elif argv[i] in ("--raiz", "--registro", "--esperados", "--reproduccion", "--tolerancia") and i + 1 < len(argv):
            kw[argv[i][2:]], i = argv[i + 1], i + 2
        elif argv[i] == "--resultado-sha256" and i + 1 < len(argv):
            kw["resultado_sha256_esperado"], i = argv[i + 1], i + 2
        elif argv[i] == "--manifiesto" and i + 1 < len(argv):
            manifiestos.append(argv[i + 1])
            i += 2
        elif argv[i] == "--declaracion" and i + 1 < len(argv):
            rutas_decl.append(argv[i + 1])
            i += 2
        else:
            print(__doc__)
            return 2

    def salir(informe: dict) -> int:
        print(json.dumps(informe, ensure_ascii=False, indent=1))
        return SALIDAS[informe["estado"]]

    try:
        if "esperados" in kw:
            kw["esperados"], _ = cargar(kw["esperados"])
        if manifiestos:
            kw["manifiesto"] = unir_manifiestos(manifiestos)
        if "tolerancia" in kw and "reproduccion" not in kw:
            raise ErrorVerificacion("USO", "--tolerancia solo se usa con --reproduccion")
        declaraciones: list[tuple[str, object]] = []
        for r in rutas_decl:
            try:
                declaraciones.append((r, C.cargar_json_estricto(r)))
            except C.ErrorConfianza as e:
                declaraciones.append((r, {"no_legible": f"{e.codigo}: {e.detalle}"}))
        if "reproduccion" in kw:
            otra, _ = cargar(kw.pop("reproduccion"))
            try:
                tol: object = float(kw.pop("tolerancia", "0"))
            except ValueError:
                tol = "no numérica"
            return salir(evaluar_reproduccion(ruta, otra, tol, declaraciones=declaraciones, **kw))
        return salir(evaluar_archivo(ruta, declaraciones=declaraciones, **kw))
    except ErrorVerificacion as e:  # errores de las referencias de la línea de órdenes, antes de evaluar
        return salir(_con_estado(clase(e.codigo), {"resultado_sha256": None}, [(e.codigo, e.detalle)]))


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
