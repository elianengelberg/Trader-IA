"""Escribe REGISTRO_ACCIONES.jsonl: registro ENCADENADO (cada línea lleva el SHA-256 de la anterior) de las acciones de
esta ronda y de las que NO se ejecutaron por falta de autorización. Las fechas son las de los archivos de evidencia
correspondientes (mtime UTC). Uso: python3 registrar_acciones.py <paquete>"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

ACCIONES = [
    ("evidencia/00_fx0_reproduccion_limpia_v0_4.txt",
     "FX-0: ZIP v0.4 verificado (testzip, lista, hashes) y toda su evidencia reproducida desde una extracción limpia",
     "dentro del encargo"),
    ("evidencia/00_estado_git_inicial_v0_5.txt", "estado de git al empezar la ronda v0.5 (solo lectura)", "dentro del encargo"),
    ("evidencia/00_preservacion.txt", "cinco entregas anteriores preservadas en 00_preservado (copias idénticas)",
     "dentro del encargo"),
    ("codigo/verificacion/confianza.py", "confianza v0.5 (claves de orden pequeño, forma canónica, fechas) en la copia aislada",
     "dentro del encargo"),
    ("codigo/verificacion/verificar_reproduccion_T.py", "P1 v0.5 (recibos ligados, reproducción autenticada)",
     "dentro del encargo"),
    ("codigo/verificacion/politica_avance_T.py", "P2 v0.5 (reproducción por archivo)", "dentro del encargo"),
    ("codigo/verificacion/uso_unico.py", "P4 v0.5 (esquemas, límite de tiempo, reproducciones, clave del ancla)",
     "dentro del encargo"),
    ("codigo/verificacion/ejecutor_aislado.py", "ejecutor aislado P4 → P1 → P2 con registro de decisiones (no integrado)",
     "dentro del encargo"),
    ("evidencia/06_cobertura_contraste_btc_manifiestos.txt",
     "cobertura de contraste_btc explicada con metadatos de manifiestos (sin bytes de datos)", "dentro del encargo"),
    ("evidencia/80_estado_real_de_T.json", "estado real de T en seis dimensiones (solo lectura): INCONCLUSO",
     "dentro del encargo"),
    ("evidencia/11_suite_v0_5.txt", "suite completa de v0.5 (sintética)", "dentro del encargo"),
    ("evidencia/10_matriz_antes_despues/MATRIZ_ANTES_DESPUES.md", "defectos contra v0.2, v0.3, v0.4 y v0.5",
     "dentro del encargo"),
    ("evidencia/52_cruzada_mutaciones.txt", "mutaciones de la cadena", "dentro del encargo"),
    ("evidencia/53_durabilidad_mutaciones.txt", "mutaciones de durabilidad (corte de energía simulado)", "dentro del encargo"),
    ("evidencia/54_ejecutor_mutaciones.txt", "mutaciones del ejecutor aislado", "dentro del encargo"),
    ("evidencia/27_regresion_suite_v0_4_sin_modificar_contra_v0_5.txt", "suite de v0.4 sin modificar contra v0.5",
     "dentro del encargo"),
    ("evidencia/60_parches_comprobacion.txt",
     "parches v0.5 comprobados sobre exportaciones temporales de HEAD y origin (repositorio intacto)", "dentro del encargo"),
    ("EXPEDIENTE_DE_DECISIONES_PENDIENTES.md", "expediente de decisiones pendientes (recomendaciones, sin aplicar)",
     "dentro del encargo"),
    ("evidencia/99_estado_git_comparado.txt", "estado de git final comparado con el inicial", "dentro del encargo"),
    ("evidencia/94_reproduccion_limpia_zip_A.txt",
     "FX-4: primera reproducción limpia (ZIP A); halló __pycache__ dejado en el paquete; corregido (-B, etapa 13)",
     "dentro del encargo"),
    ("evidencia/95_reproduccion_limpia.txt",
     "FX-4: toda la evidencia regenerada desde una extracción limpia del ZIP de origen y comparada archivo por archivo",
     "dentro del encargo"),
]
NO_EJECUTADAS = [
    ("aplicar los parches, commit, push, versionar corte.py", "B-1: requiere autorización (la orden lo prohíbe)"),
    ("elegir o implementar el ancla externa, crear o aprobar claves o raíces, publicar hashes o commits",
     "B-2: requiere autorización y una clave fuera de este equipo"),
    ("integrar P4 o el ejecutor aislado en papel/corte.py u otro ejecutor", "B-3: requiere autorización"),
    ("leer bytes de datos reales o reproducir calidad_datos.json", "B-4: requiere autorización"),
    ("calibración estadística (A-S1)", "B-5: requiere autorización y las decisiones D-S1 a D-S3"),
    ("backtests, descargas, repetir T, invocar fuera_de_muestra_T.py, dinero real, despliegues", "B-6: prohibido"),
    ("elegir definiciones, etapas, umbrales, δ o autorizaciones (A1–A14)", "decisiones del propietario"),
]


def main(paq: Path) -> None:
    lineas, anterior = [], None
    for ruta, accion, aut in ACCIONES:
        p = paq / ruta
        utc = dt.datetime.fromtimestamp(p.stat().st_mtime, dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        reg = {"n": len(lineas), "utc": utc, "accion": accion, "autorizacion": aut, "evidencia": ruta,
               "evidencia_sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "anterior_sha256": anterior}
        linea = json.dumps(reg, ensure_ascii=False, sort_keys=True)
        lineas.append(linea)
        anterior = hashlib.sha256(linea.encode()).hexdigest()
    for accion, motivo in NO_EJECUTADAS:
        reg = {"n": len(lineas), "utc": None, "accion": f"NO EJECUTADA: {accion}", "autorizacion": motivo,
               "evidencia": None, "evidencia_sha256": None, "anterior_sha256": anterior}
        linea = json.dumps(reg, ensure_ascii=False, sort_keys=True)
        lineas.append(linea)
        anterior = hashlib.sha256(linea.encode()).hexdigest()
    (paq / "REGISTRO_ACCIONES.jsonl").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print(f"{len(lineas)} entradas; SHA-256 de la última: {anterior}")


if __name__ == "__main__":
    main(Path(sys.argv[1]))
