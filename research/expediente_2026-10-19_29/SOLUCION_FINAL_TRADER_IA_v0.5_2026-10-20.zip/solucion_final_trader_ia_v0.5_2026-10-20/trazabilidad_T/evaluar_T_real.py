"""Estado REAL de T en seis dimensiones SEPARADAS, en solo lectura: integridad de archivos, autenticidad del origen,
reproducción, suficiencia de datos, cumplimiento metodológico y autorización para ejecutar.

Lee el resultado fuera de muestra de T, su script, su prerregistro, el código fuente y los MANIFIESTOS (metadatos),
y evalúa con P1 v0.5 y P2 v0.5 del paquete. No ejecuta T, no importa su script, no lee bytes de datos de mercado (sin
``--datos``), no escribe en el repositorio y comprueba que los archivos leídos no cambian (hash y mtime).

Uso: python3 -I evaluar_T_real.py <raíz del repositorio> <paquete> <salida.json>"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def huellas(rutas: list[Path]) -> dict:
    return {str(p): [hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns] for p in rutas}


def main(repo: Path, paquete: Path, salida: Path) -> int:
    sys.path.insert(0, str(paquete / "codigo" / "verificacion"))
    import politica_avance_T as PA
    import verificar_reproduccion_T as V

    T = repo / "research" / "tendencia_btc"
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    leidos = [ruta, T / "experimentos" / "fuera_de_muestra_T.py", T / "PRERREGISTRO_FUERA_DE_MUESTRA_T.md",
              *sorted((T / "src" / "tendencia").glob("*.py")), T / "datos" / "BTCUSDT" / "MANIFIESTO.json",
              T / "datos" / "ETHUSDT" / "MANIFIESTO.json", T / "ARTEFACTOS_SHA256.txt", T / "EVIDENCIA_T_MULTI.json",
              T / "experimentos" / "calidad_datos.json"]
    antes = huellas(leidos)
    manifiesto = V.unir_manifiestos([str(T / "ARTEFACTOS_SHA256.txt"),
                                     f"{T / 'EVIDENCIA_T_MULTI.json'}#cadena_historica_T_fuera_de_muestra",
                                     str(paquete / "trazabilidad_T" / "ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt")])
    p1 = V.evaluar_archivo(ruta, raiz=T, manifiesto=manifiesto)
    p2 = PA.desde_resultado(ruta, T, "NO_DEFINIDO", "NO_DEFINIDO", manifiesto=manifiesto)
    calidad = V.evaluar_archivo(T / "experimentos" / "calidad_datos.json", raiz=T)
    despues = huellas(leidos)
    estados = {
        "1_integridad_de_archivos": {
            "estado": p1.get("integridad_local"),
            "detalle": "hashes recalculados desde los archivos y coherentes con los tres manifiestos LOCALES "
                       f"(coinciden {len((p1.get('contraste_con_manifiestos') or {}).get('coinciden', []))} archivos)"},
        "2_autenticidad_del_origen": {
            "estado": (p1.get("autenticidad") or {}).get("estado"),
            "detalle": "; ".join(f"{m['codigo']}" for m in p1["motivos"]) + " — no hay ninguna raíz aprobada "
                       f"(RAICES_CONFIANZA = {len(V.RAICES_CONFIANZA)}); los manifiestos locales no son autenticidad"},
        "3_reproduccion": {"estado": "NO_INTENTADA",
                           "detalle": "repetir T está prohibido; P1 solo declararía REPRODUCIDO con una reproducción "
                                      "autenticada"},
        "4_suficiencia_de_datos": {
            "estado": "NO_VERIFICADA",
            "detalle": f"calidad_datos.json: {calidad['estado']} ({calidad['motivos'][0]['codigo']}); los bytes de "
                       "datos no se leyeron (--datos requiere autorización, B-4); ver evidencia/06_*"},
        "5_cumplimiento_metodologico": {
            "estado": "DECISION_COHERENTE_CON_LA_REGLA_CONGELADA" if p1.get("decision") == p1.get("decision_recalculada")
            else "INCOHERENTE",
            "detalle": f"decisión registrada {p1.get('decision')!r} = regla congelada aplicada a sus cifras "
                       f"({p1.get('decision_recalculada')!r}); limitación documentada: P no es un valor p "
                       "(expediente, MEC §1); no cambia la decisión registrada"},
        "6_autorizacion_para_ejecutar": {"estado": p2["autorizacion_ejecucion"]["estado"],
                                         "detalle": p2["autorizacion_ejecucion"]["motivo"]},
    }
    informe = {"generado_por": "trazabilidad_T/evaluar_T_real.py", "p1_version": V.VERSION, "p2_version": PA.VERSION,
               "resultado_sha256": p1.get("resultado_sha256"), "estado_p1": p1["estado"],
               "motivos_p1": [m["codigo"] for m in p1["motivos"]], "estado_p2": {
                   "validez": p2["evidencia"]["validez"], "etiqueta_estadistica": p2["etiqueta_estadistica"],
                   "etiqueta_declarada": p2["etiqueta_declarada"], "avance": p2["decision_avance"]["resultado"]},
               "dimensiones": estados, "archivos_leidos_sin_cambios": antes == despues,
               "archivos_leidos": sorted(antes)}
    salida.write_text(json.dumps(informe, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({k: informe[k] for k in ("estado_p1", "motivos_p1", "estado_p2", "archivos_leidos_sin_cambios")},
                     ensure_ascii=False))
    return 0 if antes == despues else 1


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])))
