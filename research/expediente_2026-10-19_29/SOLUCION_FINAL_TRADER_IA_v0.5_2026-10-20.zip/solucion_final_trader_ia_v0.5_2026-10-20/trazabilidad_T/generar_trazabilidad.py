"""Trazabilidad de los tres artefactos fuera de muestra de T, SOLO LECTURA: no modifica los artefactos, no ejecuta T,
no consume el cerrojo (no invoca fuera_de_muestra_T.py) y no escribe en el repositorio.

Genera, en el directorio de salida:
- TRAZABILIDAD_FUERA_DE_MUESTRA_T.json: hash, tamaño, blob de git, commit que los introdujo, presencia en origin,
  correspondencia con EVIDENCIA_T_MULTI.json y con ARTEFACTOS_SHA256.txt, cronología (de la transcripción local, si
  se pasa ``--transcripcion``, con el SHA-256 de cada línea citada) y LÍMITES de esta trazabilidad.
- ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt: manifiesto sha256sum (rutas relativas a research/tendencia_btc) que P1
  acepta con ``--manifiesto``. Es una referencia LOCAL: no autentica.
- DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json y .bin: declaración SIN FIRMAR y sus bytes canónicos exactos, para que
  el propietario la firme FUERA de este equipo (ver INSTRUCCIONES_FIRMA.md). Firmada por una raíz aprobada, es la
  referencia independiente que permite a P1 dar VERIFICADO.

Uso: python3 -I generar_trazabilidad.py <repo> <salida> [--transcripcion RUTA.jsonl]"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import subprocess
import sys
from pathlib import Path

_PAQ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_PAQ / "codigo" / "verificacion" if (_PAQ / "codigo" / "verificacion").is_dir() else _PAQ))
import confianza as C  # noqa: E402

T = "research/tendencia_btc"
ARTEFACTOS = ("experimentos/fuera_de_muestra_T.json", "experimentos/fuera_de_muestra_T.py",
              "PRERREGISTRO_FUERA_DE_MUESTRA_T.md")
RAMA_REMOTA = "origin/claude/algo-trading-simulation-platform-ngf7xo"
# Líneas de la transcripción local citadas (ver evidencia/04_cronologia_fuera_de_muestra_transcripcion.txt).
CRONOLOGIA = ((4433, "se escribe PRERREGISTRO_FUERA_DE_MUESTRA_T.md"),
              (4455, "se escribe experimentos/fuera_de_muestra_T.py"),
              (4463, "prueba de humo con una COPIA del script apuntada a la ventana de desarrollo (salida en el scratchpad)"),
              (4468, "corrección de estilo del script (antes del congelado)"),
              (4470, "prueba de humo con una COPIA apuntada a la ventana de desarrollo"),
              (4480, "congelado: hashes del prerregistro y del script; el resultado no existía; ÚNICA ejecución"),
              (4481, "salida de la ejecución: EVIDENCIA INSUFICIENTE"),
              (4507, "segunda ejecución: el script se niega (el resultado ya existe); prerregistro y script sin cambios"),
              (4508, "salida de la comprobación"))


def git(repo: Path, *args: str) -> str:
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, check=True).stdout.strip()


def git_ok(repo: Path, *args: str) -> bool:
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, check=False).returncode == 0


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def manifiesto_sha256sum(ruta: Path) -> dict[str, str]:
    out = {}
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        h, _, r = linea.partition("  ")
        if r:
            out[r] = h
    return out


def generar(repo: Path, salida: Path, transcripcion: Path | None) -> dict:
    t = repo / T
    head = git(repo, "rev-parse", "HEAD")
    remota = git(repo, "rev-parse", RAMA_REMOTA)
    evidencia = json.loads((t / "EVIDENCIA_T_MULTI.json").read_text(encoding="utf-8"))["cadena_historica_T_fuera_de_muestra"]
    art_trabajo = manifiesto_sha256sum(t / "ARTEFACTOS_SHA256.txt")
    art_head = {r for r in (ln.partition("  ")[2] for ln in git(repo, "show", f"HEAD:{T}/ARTEFACTOS_SHA256.txt").splitlines()) if r}
    registros = []
    for rel in ARTEFACTOS:
        b = (t / rel).read_bytes()
        commits = git(repo, "log", "--format=%H %cI", "--diff-filter=A", "--", f"{T}/{rel}").splitlines()
        registros.append({
            "ruta": rel, "sha256": sha(b), "bytes": len(b),
            "blob_git_copia_de_trabajo": git(repo, "hash-object", f"{T}/{rel}"),
            "blob_git_HEAD": git(repo, "rev-parse", f"HEAD:{T}/{rel}"),
            "commit_que_lo_introdujo": commits[-1].split()[0] if commits else None,
            "fecha_commit": commits[-1].split()[1] if commits else None,
            "presente_en_origin": git_ok(repo, "cat-file", "-e", f"{remota}:{T}/{rel}"),
            "coincide_con_EVIDENCIA_T_MULTI": evidencia.get(rel, {}).get("sha256") == sha(b),
            "listado_en_ARTEFACTOS_SHA256_copia_de_trabajo": rel in art_trabajo,
            "listado_en_ARTEFACTOS_SHA256_HEAD": rel in art_head})
    cronologia = []
    if transcripcion is not None:
        lineas = transcripcion.read_text(encoding="utf-8").split("\n")
        for n, que in CRONOLOGIA:
            o = json.loads(lineas[n - 1])
            cronologia.append({"linea": n, "utc": o.get("timestamp"), "evento": que,
                               "sha256_linea": sha(lineas[n - 1].encode())})
    traza = {
        "formato": "trader-ia/trazabilidad-fuera-de-muestra-T/v1",
        "generado_utc": dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "repositorio": {"HEAD": head, "rama_remota": RAMA_REMOTA, "commit_remoto": remota,
                        "HEAD_publicado": git_ok(repo, "merge-base", "--is-ancestor", head, remota)},
        "artefactos": registros,
        "cronologia_transcripcion_local": cronologia,
        "limites": [
            "Los tres artefactos entraron en git en el MISMO commit local (sin publicar): git no prueba que el "
            "prerregistro precediera al resultado.",
            "El orden (prerregistro → script → única ejecución → negativa a repetir) consta solo en la transcripción "
            "LOCAL de la sesión: es trazabilidad, no una prueba independiente.",
            "ARTEFACTOS_SHA256.txt no los lista (ni en HEAD ni en la copia de trabajo); EVIDENCIA_T_MULTI.json sí, pero "
            "está en los mismos commits locales sin publicar.",
            "Ningún registro de este archivo es una raíz de confianza: la autenticidad requiere la declaración firmada "
            "por una raíz aprobada (DECLARACION_A_FIRMAR_*), cuya firma solo prueba lo que el firmante acepta en la "
            "fecha de la firma, no que nada cambiara antes."]}
    salida.mkdir(parents=True, exist_ok=True)
    (salida / "TRAZABILIDAD_FUERA_DE_MUESTRA_T.json").write_text(json.dumps(traza, ensure_ascii=False, indent=1) + "\n",
                                                                encoding="utf-8")
    (salida / "ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt").write_text(
        "".join(f"{r['sha256']}  {r['ruta']}\n" for r in registros), encoding="utf-8")
    contenido = C.declaracion(
        "PROPIETARIO-T", traza["generado_utc"],
        [{"ruta": r["ruta"], "sha256": r["sha256"], "descripcion": "artefacto fuera de muestra de T"} for r in registros],
        {"commit_local": head, "proposito": "referencia independiente de los artefactos fuera de muestra de T para P1"})
    (salida / "DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json").write_text(
        json.dumps(contenido, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    (salida / "DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.bin").write_bytes(C.canonico(contenido))
    return traza


if __name__ == "__main__":
    args = sys.argv[1:]
    trans = None
    if "--transcripcion" in args:
        i = args.index("--transcripcion")
        trans = Path(args[i + 1])
        del args[i:i + 2]
    if len(args) != 2:
        print(__doc__)
        sys.exit(2)
    print(json.dumps(generar(Path(args[0]), Path(args[1]), trans), ensure_ascii=False, indent=1))
