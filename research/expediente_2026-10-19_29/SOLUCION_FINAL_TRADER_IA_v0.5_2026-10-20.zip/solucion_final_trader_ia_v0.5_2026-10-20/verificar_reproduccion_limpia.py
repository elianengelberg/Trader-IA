"""Documenta la reproducción completa desde una extracción limpia del ZIP de origen (evidencia/95_*). Solo lee.
Uso: python3 -I verificar_reproduccion_limpia.py <zip_origen> <paquete_reproducido> [<paquete_final>]
1. SHA-256 del ZIP de origen y comprobación de su SHA256SUMS contra los bytes de cada miembro.
2. Todo lo que NO es evidencia es idéntico en el ZIP, en la extracción DESPUÉS de ejecutar ``ejecutar_todo.sh`` (la
   ejecución no modificó ni agregó nada) y, si se da, en el paquete final. La evidencia del paquete final es la
   reproducida, más este 95.
3. La evidencia del ZIP y la reproducida coinciden: semánticamente (``comparar_evidencias.py``) y, archivo por archivo,
   byte a byte o tras normalizar tiempos, rutas, fechas y direcciones; de cada archivo que difiere se muestra la
   primera línea distinta.
4. En la ejecución reproducida, la huella del repositorio antes (90) y después (91) es idéntica.
Salida 0 si todo coincide."""
from __future__ import annotations

import hashlib
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

REGENERADOS_AL_EMPAQUETAR = {"SHA256SUMS.txt", "REGISTRO_ACCIONES.jsonl"}
NUEVAS_EN_ESTA_CONSTRUCCION = {"97_paquete_intacto.txt": "etapa 13, agregada tras la primera reproducción (94_*)"}
CUBIERTOS = re.compile(r"^(05_|1[0-4]_|2[2-7]_|3[12]_|41_|5[2-4]_|6[01]_|70_|80_|9[89]_)")


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _norm(t: str) -> str:
    t = re.sub(r" in [0-9.]+s( \([0-9:]+\))?", "", t)
    t = re.sub(r"tras \d+ s", "tras N s", t)
    t = re.sub(r"/tmp/\S*|/home/\S*", "<ruta>", t)
    t = re.sub(r"\d{4}-\d{2}-\d{2}T[0-9:.]+Z?", "<fecha>", t)
    return re.sub(r"0x[0-9a-f]+", "0x…", t)


def _archivos(d: Path) -> set[str]:
    return {p.relative_to(d).as_posix() for p in d.rglob("*") if p.is_file()}


def main(zip_origen: Path, rep: Path, final: Path | None) -> int:
    malas = 0

    def informe(ok: bool, texto: str) -> None:
        nonlocal malas
        malas += not ok
        print(f"{'OK     ' if ok else 'FALLA  '} {texto}")

    print(f"== 1. ZIP de origen: {zip_origen.name}\nSHA-256 {_sha(zip_origen.read_bytes())}")
    with zipfile.ZipFile(zip_origen) as z:
        raiz = z.namelist()[0].split("/")[0]
        miembros = {n[len(raiz) + 1:]: z.read(n) for n in z.namelist() if not n.endswith("/")}
    sumas = dict(reversed(x.split("  ", 1)) for x in miembros["SHA256SUMS.txt"].decode().splitlines())
    informe(set(sumas) == set(miembros) - {"SHA256SUMS.txt"}
            and all(_sha(miembros[r]) == h for r, h in sumas.items()),
            f"SHA256SUMS del ZIP coincide con los bytes de sus {len(sumas)} archivos")

    print("\n== 2. lo que no es evidencia (código, pruebas, documentos, parches, referencias, preservados, tablas)")
    otros = sorted(r for r in sumas if not r.startswith("evidencia/") and r not in REGENERADOS_AL_EMPAQUETAR)
    for nombre, paq in (("extracción reproducida (después de ejecutar)", rep), ("paquete final", final)):
        if paq is None:
            continue
        distintos = [r for r in otros if not (paq / r).is_file() or _sha((paq / r).read_bytes()) != sumas[r]]
        nuevos = sorted(r for r in _archivos(paq) if not r.startswith("evidencia/") and r not in sumas
                        and r not in REGENERADOS_AL_EMPAQUETAR)
        informe(not distintos, f"{nombre}: {len(otros) - len(distintos)} de {len(otros)} idénticos al ZIP"
                + (f"; distintos: {distintos}" if distintos else ""))
        informe(not nuevos, f"{nombre}: archivos nuevos fuera de evidencia/ (p. ej. __pycache__): {nuevos or 'ninguno'}")
    if final is not None:
        ev_r, ev_f = rep / "evidencia", final / "evidencia"
        rel, relf = _archivos(ev_r), _archivos(ev_f) - {"95_reproduccion_limpia.txt"}
        iguales = rel == relf and all((ev_r / r).read_bytes() == (ev_f / r).read_bytes() for r in rel)
        informe(iguales, f"la evidencia del paquete final ES la reproducida ({len(rel)} archivos idénticos, más este 95)")

    print("\n== 3. evidencia del ZIP frente a la reproducida")
    with tempfile.TemporaryDirectory() as t:
        ev_a = Path(t) / "evidencia"
        for r, b in miembros.items():
            if r.startswith("evidencia/"):
                (Path(t) / r).parent.mkdir(parents=True, exist_ok=True)
                (Path(t) / r).write_bytes(b)
        ev_b = rep / "evidencia"
        comparador = Path(__file__).resolve().parent / "comparar_evidencias.py"
        s = subprocess.run([sys.executable, "-I", "-B", str(comparador), str(ev_a), str(ev_b)],
                           capture_output=True, text=True)
        print("-- comparar_evidencias.py (comparación semántica):")
        print(s.stdout.rstrip() + (("\n" + s.stderr.rstrip()) if s.stderr else ""))
        informe(s.returncode == 0, f"comparación semántica (salida {s.returncode})")
        print("-- todos los archivos, uno por uno:")
        for n in sorted(_archivos(ev_a) | _archivos(ev_b)):
            a, b = ev_a / n, ev_b / n
            if not a.is_file():
                informe(n in NUEVAS_EN_ESTA_CONSTRUCCION, f"{n}: solo en la reproducida — "
                        + NUEVAS_EN_ESTA_CONSTRUCCION.get(n, "NO prevista"))
                continue
            if not b.is_file():
                informe(False, f"{n}: falta en la reproducida")
                continue
            ba, bb = a.read_bytes(), b.read_bytes()
            ta, tb = ba.decode("utf-8", "replace"), bb.decode("utf-8", "replace")
            if ba == bb:
                print(f"IGUAL     {n}: idéntico byte a byte")
            elif _norm(ta) == _norm(tb):
                print(f"IGUAL     {n}: idéntico salvo tiempos, rutas, fechas y direcciones")
            elif n.startswith(("90_", "91_")) and ba.splitlines()[-1] == bb.splitlines()[-1]:
                print(f"FORMATO   {n}: huella del repositorio con otro formato; la línea final coincide; "
                      "se compara dentro de cada ejecución (punto 4)")
            elif CUBIERTOS.match(n):
                la, lb = _norm(ta).splitlines(), _norm(tb).splitlines()
                k = next((i for i, (x, y) in enumerate(zip(la, lb, strict=False)) if x != y), min(len(la), len(lb)))
                distintas = sum(x != y for x, y in zip(la, lb, strict=False)) + abs(len(la) - len(lb))
                print(f"CONTENIDO {n}: {distintas} de {max(len(la), len(lb))} líneas difieren tras normalizar; "
                      "su contenido semántico se comparó arriba. Primera diferencia:\n"
                      f"            A: {la[k][:150] if k < len(la) else '<fin>'}\n"
                      f"            R: {lb[k][:150] if k < len(lb) else '<fin>'}")
            else:
                informe(False, f"{n}: difiere y no lo cubre la comparación semántica")

    print("\n== 4. huella del repositorio en la ejecución reproducida")
    h90 = (rep / "evidencia" / "90_estado_git_antes.txt").read_bytes()
    h91 = (rep / "evidencia" / "91_estado_git_despues.txt").read_bytes()
    print(h91.decode().splitlines()[-1] + f"   ({len(h91.splitlines())} líneas)")
    informe(h90 == h91, "90 (antes) == 91 (después), byte a byte")
    print(f"\n{'TODO COINCIDE' if not malas else f'{malas} DIFERENCIAS'}")
    return 1 if malas else 0


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]) if len(sys.argv) > 3 else None))
