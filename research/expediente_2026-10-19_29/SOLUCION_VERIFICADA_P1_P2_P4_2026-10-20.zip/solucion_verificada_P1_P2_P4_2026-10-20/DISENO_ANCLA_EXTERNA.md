# Diseño del ancla externa de P4 (v0.4)

> **El ancla externa NO existe.** No se eligió, contrató, desplegó ni simuló ningún servicio. Elegirla y publicar
> en ella requiere tu autorización (B-2).
>
> Lo que sí está hecho y probado:
> - la interfaz;
> - el **cliente** `AnclaFirmada`, que verifica firmas, desafíos y recibos;
> - la **suite de contrato** que toda implementación debe pasar;
> - un **doble de prueba** con almacenamiento local y clave sintética, que solo sirve para ejecutar esas pruebas.

## 1. Para qué sirve
P4 impide recalcular o sustituir un resultado que pudo observarse. Para eso necesita un registro que quien opera la
máquina **no pueda reescribir**. `AnclaArchivo` está en la misma máquina, así que no cumple esa condición.

El ancla externa es ese registro. Además, al presellar, **firma un recibo** con el SHA-256 del resultado. P1 acepta
ese recibo como referencia independiente si la clave del ancla es una raíz aprobada. Así se cierra el hueco de
autenticidad de P1 para los resultados futuros.

## 2. Modelo de amenazas
| Actor | Capacidad | Qué debe impedir el ancla |
|---|---|---|
| A1 Operador local | Controla archivos, diario, ancla local, procesos y reloj de la máquina | Restaurar o borrar el estado para recalcular; sustituir un resultado presellado; falsificar recibos |
| A2 Intermediario de red | Lee, retiene, repite o altera mensajes | Aceptar una respuesta vieja (repetición), alterada o de otra operación |
| A3 Servicio de ancla comprometido | Controla el servicio y su clave | **Fuera del alcance de un ancla única.** Mitigación: custodia de la clave (§3, G10), registro auditable (G11) y, si se exige, dos anclas independientes |
| A4 Fallos | Disco lleno, error de E/S, caída, corte de red | Que un fallo se convierta en un segundo cálculo o en un resultado no presellado |

## 3. Garantías exigidas
Cada garantía tiene su prueba en `pruebas/p4/test_contrato_ancla.py` (C1–C8) o en `test_ancla_firmada.py`.

| ID | Garantía | Prueba |
|---|---|---|
| G1 | Historia por reserva de **solo añadidos**: nada se borra ni se reescribe | C5 (persistencia); el operador no tiene permiso de borrado (organizativo) |
| G2 | Estado por reserva **linealizable**: toda lectura ve la última escritura confirmada | C5, C6 |
| G3 | `registrar_inicio_calculo(r, n)` es una **comparación-y-escritura**: solo acepta n = inicios + 1 y nunca después de un presellado | C3, C4, C6 (8 procesos compiten: gana exactamente uno) |
| G4 | `registrar_presellado` es de **escritura única**; el mismo valor es idempotente y otro valor se rechaza | C4 |
| G5 | Conflicto si el mismo experimento o las mismas entradas ya tienen otra reserva | C2 |
| G6 | **Respuestas firmadas** (Ed25519, clave fijada en el cliente) que nombran la operación, la reserva, el **desafío** aleatorio de la solicitud, el estado y el emisor | `test_respuestas_no_autenticas`, `test_respuesta_vieja_repetida_no_sirve`, `test_clave_fijada_distinta` |
| G7 | **Recibo firmado** del presellado (declaración `trader-ia/declaracion/v1` con el SHA-256 del resultado y `contexto.reserva_sha256`) | C8, `test_recibo_de_otra_reserva`, `test_extremo_a_extremo_con_recibo` |
| G8 | Durabilidad **antes** de confirmar (fsync o replicación) | Organizativo / del proveedor (NO_VERIFICADO hasta elegirlo) |
| G9 | Sin confirmación no hay avance: P4 no calcula ni escribe | C7, `test_extremo_a_extremo_sin_respuesta_autentica_nada_avanza`, X5 |
| G10 | Clave privada **fuera del control del operador de T** (HSM, KMS o tercero), con un procedimiento de rotación con solapamiento y revocación | Organizativo (B-2) |
| G11 | Registro **auditable** por el propietario (recomendado: con pruebas de consistencia, al estilo de un registro de transparencia) | Organizativo |

## 4. Protocolo (implementado en el cliente; probado contra el doble de prueba)
**Solicitud** (no necesita firma: la seguridad está en la respuesta):
```
{"op", "reserva_sha256", "desafio": <16 bytes aleatorios en hexadecimal>, ...}
```
`op` es uno de `consultar`, `registrar_reserva` (con `reserva`), `registrar_inicio_calculo` (con `n`) o
`registrar_presellado` (con `resultado_sha256`).

**Respuesta:**
```
{"contenido": {...}, "firma_ed25519": <128 hex>}
```
La firma cubre `confianza.canonico(contenido)`: JSON UTF-8 con claves ordenadas, sin espacios y sin números de punto
flotante. `contenido` tiene:
```
{"formato": "trader-ia/ancla/respuesta/v1", "emisor", "op", "reserva_sha256", "desafio",
 "resultado": "ACEPTADO" | "CONFLICTO", "motivo",
 "estado": {"reserva", "iniciados", "presellado"},
 "recibo": <declaración firmada> | null}
```

**Cómo trata P4 cada respuesta:**

| Situación | Excepción | Salida de P4 | Terminal |
|---|---|---|---|
| El servicio no responde (red, caída, tiempo agotado) | `AnclaNoDisponible` | ANCLA_NO_DISPONIBLE | No |
| Firma inválida, desafío u operación distintos, o recibo que no corresponde | `AnclaNoAutentica` | ANCLA_NO_AUTENTICA | No |
| `CONFLICTO` firmado | `AnclaConflicto` | RECHAZADO (al reservar) o INCONSISTENTE (después) | — |

En ningún caso se calcula ni se escribe nada sin una respuesta auténtica `ACEPTADO`.

**Identidad del ancla en la reserva:** `firmada:<emisor>:ed25519:<huella de la clave>`. Cambiar de ancla o de clave
produce otra reserva, así que no se puede «cambiar de ancla» a mitad de un experimento.

## 5. Secuencia de una ejecución (P4 v0.4)
1. `consultar` → `registrar_reserva` (antes de crear el diario local).
2. `consultar` (conciliación: el ancla debe conocer la reserva y sus inicios deben ser ≥ los del diario).
3. `registrar_inicio_calculo(n)`, con comparación-y-escritura.
4. Cálculo aislado.
5. PRESELLADO en el diario.
6. `registrar_presellado` → recibo.
7. `RECIBO_ANCLA.json` (atómico) → `resultado.json` (atómico) → SELLADO → REGISTRADO.

En la recuperación se repite la conciliación. Si falta el recibo, se vuelve a pedir; si falta el resultado y el
cálculo es determinista, se recalcula exigiendo el mismo hash.

## 6. Opciones de implementación (elección tuya, B-2)
Las capacidades concretas de cada proveedor están **NO_VERIFICADAS**: hay que confirmarlas con su documentación
vigente antes de elegir.

| Opción | Cómo cumple G1–G7 | Dependencias | Límites |
|---|---|---|---|
| O1 Servicio mínimo propio | Una tabla por reserva con escritura condicional (versión esperada → nueva versión). Historial inmutable (almacenamiento WORM). Firma con una clave en KMS o HSM | Alojamiento, KMS o HSM, un operador **distinto** del de T, copias de seguridad | Hay que operarlo; la confianza recae en quien lo administra |
| O2 Repositorio git remoto con rama protegida | Cada operación es un commit en una rama sin reescritura. La comparación-y-escritura es «avanzar la rama solo si su punta es la esperada». Firma: una clave del servicio o del propietario | Cuenta en GitHub (u otra plataforma), un token de permisos mínimos, la protección de rama y la firma de commits | Un administrador puede quitar la protección: el administrador debe ser otra persona. Latencia alta |
| O3 Registro de transparencia público | Solo para los **recibos** (sellos públicos de presellados). No ofrece comparación-y-escritura por clave, así que no cubre G3 | Cliente del registro, conectividad | Debe combinarse con O1 u O2 |
| O4 Sello de tiempo (RFC 3161) | Fecha cierta de un hash. No hay comparación-y-escritura | Una autoridad de sellado | Solo complementa |

**Recomendación técnica:** O1 u O2 para G1–G7, más O3 u O4 para los recibos si se quiere una prueba pública de fecha.
Para el resultado HISTÓRICO de T, el ancla no aplica, porque ya se ejecutó sin P4. Su autenticidad requiere tu firma
de `DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json` (ver `trazabilidad_T/INSTRUCCIONES_FIRMA.md`).

## 7. Integración pendiente (cada paso requiere autorización)
1. Elegir la opción y el custodio de la clave (B-2).
2. Implementar el `transporte` del cliente para ese servicio. El cliente y la verificación ya existen.
3. Pasar `test_contrato_ancla.py` con una fábrica que construya el cliente contra el servicio real, en un entorno de
   prueba, con reservas sintéticas.
4. Registrar la clave pública del ancla como raíz `tipo: "ancla"` en `RAICES_CONFIANZA` de P1. Es un cambio de código
   revisado.
5. Hacer una ejecución sintética de extremo a extremo: P4 → recibo → P1 VERIFICADO → P2.
6. Recién entonces, decidir la integración en un ejecutor (B-3).

## 8. Qué cubre hoy el prototipo y qué falta
| Elemento | Estado |
|---|---|
| Interfaz y semántica de errores | Implementada y probada (contrato C1–C8 sobre AnclaArchivo y AnclaFirmada) |
| Cliente con firma, desafío y recibos | Implementado y probado contra el doble de prueba y sus manipulaciones |
| Recibo aceptado por P1 como referencia independiente | Probado (cadena X1–X18) con una raíz SINTÉTICA |
| Servicio externo, custodia de la clave, durabilidad | **No existe** (B-2) |
| Corte de energía, NFS, varias máquinas | No probado |
| Ejecución del código reservado por fuera de P4 | No protegido. Mitigación posible: datos cifrados con una clave que solo entrega el ancla |

## 9. Riesgos residuales con un ancla externa
- **Ancla comprometida (A3)** o connivencia de su operador con el operador de T: puede emitir recibos falsos. Se
  mitiga con dos anclas independientes, el registro auditable y la rotación de la clave.
- **Denegación de servicio:** si el ancla no está disponible, nada avanza. Es intencional (seguridad antes que
  disponibilidad).
- **Fechas:** `emitida_utc` las declara el firmante. Solo O3 u O4 dan una fecha cierta independiente.
- **Ejecución fuera del mecanismo:** el ancla no impide que alguien ejecute el código y los datos por su cuenta.
