# Garantías demostradas y riesgos residuales (v0.4)

**Clasificación de cada afirmación:**

| Etiqueta | Significado |
|---|---|
| [PRUEBA] | VERIFICADO_POR_PRUEBA (la prueba se nombra) |
| [INSP] | VERIFICADO_POR_INSPECCION |
| [INF] | INFERIDO |
| [NO_VER] | NO_VERIFICADO |
| [AUT] | REQUIERE_AUTORIZACION |

**Advertencias:**
- Las pruebas usan datos **sintéticos**: no son evidencia histórica.
- Las únicas lecturas de artefactos reales de T son de solo lectura y no leen bytes de datos de mercado.
- Todo lo hizo el mismo agente que escribió las versiones anteriores. **No hay revisión de un tercero** (B-7).

## P1 — Verificación de evidencia
**Garantías:**
- [PRUEBA] Cada evaluación da **exactamente un** estado. Las condiciones de VERIFICADO, CORRUPTO e INCONCLUSO coinciden con un oráculo independiente en las 720 combinaciones de raíz, falta, corrupción, manifiesto, declaración y presellado (`test_p1_v04::test_estados_contra_el_oraculo`).
- [PRUEBA] Todo código de error pertenece a una sola clase (prueba estática). Una falta (INCONCLUSO) **nunca oculta** una corrupción demostrable (`test_P1_N2_una_falta_no_oculta_una_corrupcion`).
- [PRUEBA] **Sin una declaración firmada por una raíz aprobada no hay VERIFICADO**, aunque archivos y manifiestos se alteren juntos de forma coherente (`test_P1_N1_*`). Con una declaración válida del original, la sustitución es CORRUPTO (`HASH_REFERENCIA`). Se rechazan: claves no aprobadas, firmas alteradas o maleables, raíces mal formadas y recibos falsificados (`test_confianza`, X12, X14).
- [PRUEBA] Ed25519 coincide con dos implementaciones independientes (OpenSSL por línea de órdenes y la biblioteca cryptography) y con el vector 1 de RFC 8032.
- [PRUEBA] Esquema estricto (S1, S2), hashes recalculados desde los archivos (S3, S4, N1), tablas y datos del corte reconstruidos con el productor real y una fuente simulada (S7), y el inicio contra el prerregistro (S8).
- [PRUEBA] REPRODUCIDO solo existe sobre un original VERIFICADO y compara los **mismos bytes** que se evaluaron (S6, N4).
- [PRUEBA] Las entradas mal formadas o no derivables dan un estado, nunca una excepción (N3).
- [PRUEBA] `calidad_datos.json` no es evidencia: INCONCLUSO, `PROCEDENCIA_NO_VERIFICADA`.
- [INSP] Cada archivo del árbol se lee **una vez** por verificación (`_Arbol`). No tiene una prueba propia porque no se puede intercalar una escritura de forma determinista dentro de una lectura.

**Riesgos residuales:**
- [INF] La independencia de una raíz depende de **dónde está la clave privada**: el código no puede comprobarlo. Quien pueda editar el verificador puede agregar su propia clave a `RAICES_CONFIANZA`. El verificador mismo debe obtenerse de una fuente confiable (commit publicado y revisado: B-1, B-2).
- [AUT] El resultado real de T es **INCONCLUSO** hasta que firmes su declaración (A12).
- [NO_VER] Los bytes de los datos reales frente a sus manifiestos (`--datos`) solo se probaron con datos sintéticos (B-4).
- [INSP] La huella del código cubre `src/tendencia/*.py`, no las dependencias ni el intérprete (así lo define el protocolo congelado).

## P2 — Política de decisiones
**Garantías:**
- [PRUEBA] La implementación coincide con un **oráculo escrito aparte** en el espacio completo de 86.400 combinaciones de entradas válidas e inválidas (`test_espacio_completo_contra_el_oraculo`). El oráculo detecta las **11 de 11** mutaciones probadas (`evidencia/31_*`).
- [PRUEBA] Las cinco dimensiones están separadas: validez, etiqueta, robustez, avance y autorización. Solo VERIFICADO o REPRODUCIDO dan una etiqueta.
- [PRUEBA] La política **nunca otorga** autorizaciones. Solo constata una autorización registrada y coherente; REGISTRADA_EXTERNAMENTE aparece únicamente con evidencia válida RESPALDADA, la etapa de la autorización y el mismo resultado (`test_registrada_externamente_solo_en_el_caso_coherente`, X4, X16).
- [PRUEBA] Ninguna función pública acepta una evidencia armada a mano ni registros inyectados (N1, N3, X16). La fecha de la ventana sale del informe de P1 (N2).
- [PRUEBA] Las evaluaciones de R1 y R3 están ligadas al resultado (N4). Los registros son coherentes (N5). Las fechas son estrictas, y el límite de post hoc se probó en el borde y con zona horaria (S4).
- [PRUEBA] Sin definiciones, etapas ni autorizaciones aprobadas (hoy), toda salida es NO_DEFINIDO, NO_DEFINIDA o NO_OTORGADA (`tablas/TABLA_DECISION_P2_v0.4.md`: 38 combinaciones alcanzables hoy).

**Riesgos residuales:**
- [INSP] Python no impide llamar a `_decidir` o `_evidencia_sintetica`. La garantía es de **interfaz**: toda salida declara su `origen` (`P1 …` o `SINTETICA`) y el SHA-256 del informe de P1.
- [AUT] La adecuación metodológica de las reglas para T (A1–A12) es tuya.

## P4 — Reserva, ancla e integridad
**Garantías** (bajo los supuestos S-a a S-e de abajo):
- [PRUEBA] **Un solo cálculo por reserva**, también entre directorios y procesos: comparación-y-escritura en el ancla, probada con sincronización determinista por FIFO y con una carrera de 8 procesos.
- [PRUEBA] Ningún resultado presellado se sustituye. La restauración, el truncamiento o la pérdida del ancla se detectan. El ejecutor, el entorno y la configuración están ligados a la reserva (S1–S5).
- [PRUEBA] **Fallos de escritura:** en 72 escenarios por código (cada `write`, `fsync`, `replace` y `link` de una ejecución, con ENOSPC, EIO, escritura corta y escritura corta seguida de ENOSPC) nunca hay:
  - una ejecución sin salida;
  - más de un inicio en el ancla;
  - dos presellados distintos;
  - un resultado en disco distinto del presellado;
  - cálculos de más.

  El estado final siempre es explícito: REGISTRADO o REVISION_HUMANA, y además CONFLICTO con código no determinista. La v0.3 viola los invariantes en 57 de 60 escenarios (`evidencia/10_matriz_antes_despues/fallos_es_*.json`).
- [PRUEBA] El cliente del ancla externa (`AnclaFirmada`) no acepta respuestas con una firma ajena o alterada, repetidas (desafío), de otra operación, ni recibos de otra reserva. Sin una respuesta auténtica nada avanza (`test_ancla_firmada`). El recibo se guarda **antes** que el resultado y P1 lo acepta (cadena X1–X18).
- [PRUEBA] La suite de contrato C1–C8 pasa con el ancla local y con el cliente firmado. Un ancla externa real debe pasarla antes de usarse.

**Supuestos:**
- S-a: un ancla fuera del control del operador. `AnclaArchivo` **no** lo cumple, y el ancla externa **no existe** (B-2).
- S-b: un sistema de archivos local con `flock` y `link`.
- S-c: el código reservado no se ejecuta por fuera del mecanismo.
- S-d: el núcleo libera el cerrojo cuando un proceso muere.
- S-e: fsync durable.

**Riesgos residuales:**
- [PRUEBA de límite] Quien controla el estado **y** el ancla local juntos no es detectado. Sin ancla, restaurar todo tampoco se detecta.
- [PRUEBA de límite] El código reservado puede ejecutarse por fuera de P4.
- [NO_VER] Corte de energía real, pérdida de páginas tras un fsync fallido, NFS y varias máquinas.
- [PRUEBA] Disponibilidad: con código **no determinista**, un fallo de disco entre el presellado y la escritura del resultado termina en CONFLICTO (revisión humana). Nunca termina en otro resultado. Un fallo en la confirmación de un inicio del ancla lleva a REVISION_HUMANA aunque el cálculo no haya empezado. Se prefiere la seguridad a la disponibilidad.
- [INSP] Sin límite de tiempo: un cálculo colgado deja la reserva OCUPADA (disponibilidad, no seguridad).

## Auditoría cruzada
- [PRUEBA] 20 pruebas (X1–X18): ninguna reserva inválida, hash inconsistente, evidencia corrupta, recibo ajeno o falso, ancla local ni archivo no admitido termina en una evidencia válida.
- [PRUEBA] Ninguna evidencia válida se convierte en autorización (X4, X16).
- [PRUEBA] Los artefactos congelados de T no cambian: hash y mtime antes y después (X8).
- [PRUEBA] P1, P2 y confianza no ejecutan ni escriben, y P4 solo lanza su hijo (X9, estática).
- [PRUEBA] Las 8 mutaciones que eliminan un control de la cadena son detectadas (`evidencia/52_*`).
- [NO_VER] **La integración real** (un ejecutor que pase por P4 con un ancla externa) no existe.
