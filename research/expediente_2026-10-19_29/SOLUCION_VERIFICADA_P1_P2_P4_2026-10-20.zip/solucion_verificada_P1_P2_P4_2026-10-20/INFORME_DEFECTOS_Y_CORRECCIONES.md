# Informe de defectos y correcciones — P1, P2 y P4 v0.4

## Cómo está demostrado cada defecto
- **Antes:** la MISMA prueba se ejecuta contra la versión anterior y FALLA (salida real de pytest en `evidencia/10_matriz_antes_despues/pytest_defectos_v0_*.txt`; matriz en `MATRIZ_ANTES_DESPUES.md`).
- **Corrección:** el cambio en `codigo/verificacion/`, versionado en `parches/v0.4/`.
- **Después:** la prueba PASA en v0.4.
- **Regresión:**
  - las suites de v0.3 se ejecutan sin modificar contra v0.4 (`evidencia/22`, `24`, `25`, `26`);
  - las de P1 también se portan con una tabla de cambios justificados (`evidencia/20`, `21`, `23`);
  - las sondas de v0.2 se ejecutan sobre v0.2 (`evidencia/40`).
- **Refutación:** casos adversariales y **mutaciones**, que eliminan el control para comprobar que alguna prueba lo detecta (`evidencia/31`, `52`).
- **Defectos S\*:** se encontraron en la auditoría anterior. Fallan en v0.2 y pasan en v0.3 y v0.4.
- **Defectos N\*:** se encontraron en esta ronda. Fallan en v0.3 y pasan en v0.4.

## P1 — Verificador de evidencia
| ID | Defecto | Prueba (antes → después) | Corrección | Refutación y límite |
|---|---|---|---|---|
| S1 | Aceptaba claves inesperadas | `test_P1_S1_*` (6): v0.2 falla → v0.3 y v0.4 pasan | Esquema estricto | — |
| S2 | Aceptaba símbolos o campos faltantes | `test_P1_S2_*` (8) | Ídem | v0.2 ya detectaba 1 de los 8 casos |
| S3 | Falsificación coherente de script y resultado | `test_P1_S3_*` (2) | Manifiestos y hash presellado | En v0.4 los manifiestos son referencias **locales**: ver N1 |
| S4 | No contrastaba `codigo_sha256` con el CODIGO del script | `test_P1_S4_*` | ast sobre el script verificado | — |
| S5 | `comparar` ignoraba campos | `test_P1_S5_*` | `comparar_completo` | — |
| S6 | REPRODUCIDO sin integridad previa | `test_P1_S6_*` | Exige VERIFICADO | — |
| S7 | No comprobaba las tablas ni los datos del corte | `test_P1_S7_*` (7, productor real con fuente simulada) | Reconstrucción de las tablas | — |
| S8 | No contrastaba el inicio con el prerregistro | `test_P1_S8_*` (3) | Rama A literal y rama B derivada | — |
| **N1** | **Autenticidad:** v0.3 daba VERIFICADO aunque el archivo, el script y el manifiesto se alteraran **juntos**, porque los manifiestos son locales | `test_P1_N1_*` (5): v0.3 da VERIFICADO → v0.4 da INCONCLUSO (`SIN_REFERENCIA_INDEPENDIENTE`) o, con una declaración firmada del original, CORRUPTO (`HASH_REFERENCIA`) | `confianza.py` (Ed25519, declaraciones firmadas). VERIFICADO exige una declaración de una **raíz aprobada** (`RAICES_CONFIANZA`, vacío); ninguna API pública acepta raíces | Clave intrusa, emisor no aprobado, firma alterada o maleable, raíz mal formada, recibo falso (X14) y recibo de otra reserva: todos rechazados. Interoperabilidad con OpenSSL y cryptography. **Límite:** el código no puede comprobar dónde está la clave privada |
| **N2** | **Estados imprecisos:** v0.3 daba RECHAZADO (salida 1) tanto a lo inválido como a lo no verificable; una falta podía ocultar una corrupción; una reproducción inválida marcaba CORRUPTO al original; un manifiesto ilegible rechazaba el resultado | `test_P1_N2_*` (4) | Cinco estados con condiciones disjuntas (docstring, `CODIGOS_CORRUPTO` / `CODIGOS_INCONCLUSO`). Las faltas se difieren hasta terminar las comprobaciones independientes | Oráculo de 720 combinaciones. Prueba estática: cada código tiene una sola clase |
| **N3** | **Excepciones no controladas:** un script con `CODIGO` no literal (ValueError), un CSV del corte no UTF-8 (UnicodeDecodeError) o una rama B sin `RESERVADO_FIN` (StopIteration) terminaban con un rastro y salida 1, igual que un rechazo | `test_P1_N3_*` (3) | NO_DERIVABLE (INCONCLUSO), TIPO (CORRUPTO), y defensa `ERROR_INTERNO` en `evaluar` | — |
| **N4** | **Doble lectura:** `reproducir` verificaba el archivo y lo **releía** para comparar; un cambio entre ambas lecturas comparaba otros bytes | `test_P1_N4_*` | Una sola lectura; se comparan los bytes evaluados | [INSP] Además, cada archivo del árbol se lee una vez (`_Arbol`) |
| M1 | *(requisito, no defecto)* `calidad_datos.json` y `contraste_btc_diario_vs_horario` | `test_p1_v04::test_calidad_datos_real_*`, X18 | INCONCLUSO `PROCEDENCIA_NO_VERIFICADA`; productor localizado (`contraste_btc/`) | La procedencia sigue NO_VERIFICADA (B-4) |

**Hallazgos internos de esta ronda, corregidos antes de entregar:**
- `confianza.validar_raiz` daba FORMATO en lugar de RAIZ_INVALIDA. Lo detectó `test_raices_mal_formadas_se_rechazan`; se corrigió el código.
- `{"decision": <texto de T>}` sin otras claves pasa a ser ESQUEMA (CORRUPTO), no TIPO_NO_ADMITIDO.

## P2 — Política de decisiones
| ID | Defecto | Prueba (antes → después) | Corrección | Refutación y límite |
|---|---|---|---|---|
| S1–S5 | Etiqueta sin evidencia; valor por defecto silencioso de R; autorización constante; fechas como texto; hash sin validar | `test_P2_S*` (14): v0.2 falla (su API era otra; las sondas, 7 de 7, muestran el defecto) → v0.3 y v0.4 pasan | v0.3 | — |
| **N1** | **Evidencia fabricada:** `aplicar(evidencia("VERIFICADO", …))` daba CANDIDATA **sin pasar por P1** | `test_P2_N1_*`: v0.3 da CANDIDATA → en v0.4 no hay atajo | Evidencia **sellada** (`_Evidencia`); la única entrada pública es `desde_resultado`, que pasa por P1 | X16 (dict, imitación de la clase, declaración que «autoriza»). **Límite:** las funciones privadas se pueden llamar; la salida declara su `origen` |
| **N2** | **Doble lectura:** la fecha de la ventana se leía de nuevo del archivo **después** de verificarlo | `test_P2_N2_*` (sustitución entre lecturas) | La fecha sale del informe de P1 | — |
| **N3** | **Registros inyectables:** `desde_resultado(..., autorizaciones=…, etapas=…)` aceptaba registros de cualquier llamador | `test_P2_N3_*` | Solo valen los registros del módulo (vacíos); no hay `**kw` | X16 |
| **N4** | Una evaluación de R1 o R3 **no decía sobre qué resultado** se hizo | `test_P2_N4_*` | Registro `{estado, definicion, resultado_sha256}`; debe coincidir con la evidencia | — |
| **N5** | **Registros incoherentes aceptados:** una definición registrada con otra clave; una autorización para una etapa no definida | `test_P2_N5_*` (2) | `_validar_registros` (dependencias) | — |

**Oráculo:**
- La implementación coincide con un oráculo independiente en 86.400 combinaciones.
- Mutaciones detectadas: 11 de 11.
- **Hallazgo:** en la primera corrida sobrevivía la mutación «post hoc con > en vez de ≥». El espacio no tenía el caso límite. Se agregaron aprobaciones exactamente en el día de inicio y con zona horaria, y la mutación pasó a detectarse.

## P4 — Reserva, ancla e integridad
| ID | Defecto | Prueba (antes → después) | Corrección | Refutación y límite |
|---|---|---|---|---|
| S1–S5 | Doble cálculo (inicio idempotente), reparación silenciosa del ancla, ejecutor no ligado, entorno heredado, no determinismo no detectado | `test_P4_S*` (8): v0.2 falla → v0.3 y v0.4 pasan | v0.3 | Pausas deterministas por FIFO |
| **N1** | **Escritura corta ignorada:** `os.write` puede escribir menos bytes; v0.3 seguía hasta REGISTRADO con el diario ilegible, y una escritura corta en el ancla **perdía el presellado** del ancla | `test_P4_N1_*` y la sistemática: v0.3 viola invariantes en 57 de 60 escenarios | `_escribir_todo`; toda escritura usa os.* | — |
| **N2** | **Disco lleno o error de E/S:** la excepción escapaba sin salida | `test_P4_N2_*` (2) y la sistemática (72 escenarios por código en v0.4, 0 violaciones) | FALLO_ALMACENAMIENTO (no terminal); la siguiente llamada concilia | Con código no determinista, un resultado presellado que no llegó a escribirse termina en CONFLICTO: es un costo de disponibilidad, no un riesgo de seguridad |
| **N3** | **E/S del ancla local:** la excepción escapaba | `test_P4_N3_*` | ANCLA_NO_DISPONIBLE, sin estado local | — |
| **N4** | **Entrada ilegible:** la excepción escapaba | `test_P4_N4_*` | RECHAZADO antes de tocar estado | — |
| N5 | *(documento)* El dictamen de v0.3 decía «toda salida lleva su reserva»; OCUPADO no la lleva | [INSP] | Documentado con precisión en `Salida` | — |
| — | *(capacidad nueva)* Cliente `AnclaFirmada`, recibos y contrato | `test_ancla_firmada`, `test_contrato_ancla` (C1–C8 en las dos anclas) | `uso_unico.py` | El servicio externo **no existe** (B-2) |

## Auditoría cruzada
- **Pruebas:** X1–X18 (20 pruebas). Ver `GARANTIAS_Y_RIESGOS.md`.
- **Hallazgo:** con la mutación «P4 no rechaza una reserva cuyo cálculo ya inició en el ancla» ninguna prueba fallaba. X6 borraba el estado con entradas **cambiadas**, y el rechazo venía de otro control (el conflicto de nombre). X6 se reforzó para borrar el estado con las **mismas** entradas; la mutación ahora se detecta.

## Correcciones de la infraestructura de pruebas
No son defectos del producto, pero quedan registradas porque cambian lo que se prueba.

| Cambio | Motivo |
|---|---|
| El doble de prueba `estado_falso_tras_firma` alteraba un valor que ya era 0 | La prueba no alteraba nada. Ahora invierte `reserva` |
| La carrera C6 usaba `multiprocessing.Manager` | El socket UNIX superaba el límite de longitud con el TMPDIR de la sesión. Ahora usa una barrera heredada por `fork` |
| Suites de P1 de v0.3 portadas | 46 reglas de reemplazo exacto (53 apariciones; cada regla exige su número de apariciones): 29 R (renombre) y 17 S (cambio deliberado, con el defecto que lo motiva), en `evidencia/20_*`. Diff completo en `evidencia/21_*`. Ninguna regla relaja un rechazo |
| Suite de P2 de v0.3 no portada | Prueba la API pública eliminada por N1 y N3. Su cobertura queda subsumida por el oráculo (86.400 ⊇ 3.360) y por `test_P2_S*`. Sin modificar falla por la API (`evidencia/24_*`) |
| Cruzada de v0.3 | Sin modificar, falla por la API (`evidencia/26_*`). Sus X1–X9 están reescritas en `test_cruzada_v04.py` |
