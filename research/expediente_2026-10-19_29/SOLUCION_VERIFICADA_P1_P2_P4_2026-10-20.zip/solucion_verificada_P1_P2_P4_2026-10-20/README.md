# Trader-IA — Solución verificada de P1, P2 y P4 (v0.4, 2026-10-20)

**Qué es:** la corrección completa de P1 (verificación de evidencia), P2 (política de decisiones) y P4 (reserva, ancla e
integridad), con la auditoría cruzada. Todo está hecho y probado en una copia aislada.

**Qué no es:**
- **No** está aplicado al repositorio, aprobado ni integrado en ningún ejecutor.
- El estado de git del repositorio no cambió: el SHA-256 de `git status --porcelain --ignored` es `87b9585d…` antes y después (`evidencia/90_*`, `91_*`, `99_*`).
- Los resultados congelados de T están intactos (`evidencia/98_*`, X8).

## Resultado en una línea por componente
| Componente | Estado técnico | Evidencia principal |
|---|---|---|
| **P1** v0.4 | 8 defectos de v0.3 corregidos (S1–S8, siguen corregidos) y 4 nuevos corregidos (N1 autenticidad, N2 estados, N3 excepciones, N4 doble lectura). VERIFICADO exige una raíz de confianza **aprobada** (hoy no hay ninguna) | Matriz antes/después; oráculo de 720 combinaciones; Ed25519 contra OpenSSL y cryptography; 187 pruebas de regresión portadas |
| **P2** v0.4 | 5 defectos de v0.3 (S1–S5) y 5 nuevos (N1 evidencia fabricada, N2 doble lectura, N3 registros inyectables, N4 evaluaciones no ligadas, N5 registros incoherentes) | Oráculo independiente en 86.400 combinaciones; 11 de 11 mutaciones detectadas |
| **P4** v0.4 | 5 defectos de v0.3 (S1–S5) y 4 nuevos (N1 escritura corta, N2 fallos de almacenamiento, N3 E/S del ancla, N4 entrada ilegible). Cliente de ancla externa con firmas, desafío y recibos. **El ancla externa no existe** | 72 escenarios de fallo de escritura por código, sin violaciones (v0.3: 57 de 60 con violaciones); contrato C1–C8; las 112 pruebas de v0.3 pasan sin modificar |
| **Cruzada** | P4 → P1 → P2: ningún camino convierte una reserva inválida, un hash inconsistente, una evidencia corrupta o un recibo ajeno en una decisión aceptada, ni una evidencia válida en una autorización | 20 pruebas X1–X18; 8 de 8 mutaciones detectadas |

**Estado real de T:** el resultado fuera de muestra es **INCONCLUSO**, con un único motivo: `SIN_REFERENCIA_INDEPENDIENTE`.
- Su integridad local es completa y coincide con los tres manifiestos locales.
- Pasa a VERIFICADO solo si firmas su declaración con una clave **fuera** de este equipo (`trazabilidad_T/INSTRUCCIONES_FIRMA.md`, A12, B-2).
- P2 da NO_CANDIDATA y NO_OTORGADA.

## Documentos
| Archivo | Contenido |
|---|---|
| `INFORME_DEFECTOS_Y_CORRECCIONES.md` | Cada defecto: prueba, antes y después, corrección, refutación y límite |
| `GARANTIAS_Y_RIESGOS.md` | Lo demostrado y lo que no, con la clase de cada afirmación |
| `DECISIONES_METODOLOGICAS_SIN_DEFINIR.md` | A1–A12 (tuyas) y las acciones bloqueadas B-1 a B-8 |
| `DISENO_ANCLA_EXTERNA.md` | Amenazas, garantías G1–G11, protocolo, opciones, integración pendiente |
| `TRAZABILIDAD_T_Y_CONTRASTE_BTC.md` | Trazabilidad de los tres artefactos fuera de muestra y procedencia de `contraste_btc_diario_vs_horario` |
| `REGISTRO_ACCIONES.jsonl` | Registro encadenado de las acciones de esta ronda y de las no ejecutadas por falta de autorización |

## Carpetas
| Carpeta | Contenido |
|---|---|
| `codigo/verificacion/` | `confianza.py`, `verificar_reproduccion_T.py` (P1), `politica_avance_T.py` (P2), `uso_unico.py` (P4) |
| `parches/v0.4/` | Serie versionada 0001–0006 y `TODO_v0.4.patch`, solo con archivos nuevos. Comprobada sobre HEAD y origin exportados (`evidencia/60_*`, `61_*`). **No aplicada** |
| `pruebas/` | p1, p2, p4 y cruzada (v0.4); defectos (se ejecutan contra v0.2, v0.3 y v0.4); mutaciones; regresión portada; `matriz_antes_despues.py` |
| `trazabilidad_T/` | Generador, trazabilidad, manifiesto, declaración a firmar e instrucciones |
| `contraste_btc/` | Procedencia de `calidad_datos.json` |
| `tablas/` | Tabla de decisión de P2 (86.400 filas, cada una coincide con el oráculo) |
| `referencia/` | Código exacto de v0.2 y v0.3, para las pruebas «antes» |
| `00_preservado/` | ZIP de las cuatro entregas anteriores, sin modificar |
| `evidencia/` | Salidas reales de todas las ejecuciones (índice abajo) |

## Reproducir
```
REPO=<raíz del repo> PY=<python con pytest> V03=<carpeta del paquete v0.3 descomprimido> bash ejecutar_todo.sh
sha256sum -c SHA256SUMS.txt
```
`V03` es la carpeta que contiene `00_preservado/CIERRE_FINAL_P1_P2_P4_2026-10-20.zip` descomprimido. `ejecutar_todo.sh`:
1. comprueba que el estado de git no cambia;
2. no ejecuta T;
3. no lee bytes de datos de mercado;
4. no usa la red.

## Índice de `evidencia/`
| Archivo | Contenido |
|---|---|
| `00_*` | Estado inicial, preservación, salida de `ejecutar_todo.sh` |
| `01_*` | Hashes del código de referencia |
| `02_*`, `03_*`, `04_*` | Investigación de `contraste_btc` y cronología de T (transcripción local, con el SHA-256 de cada línea) |
| `05_*` | Trazabilidad regenerada y comparada |
| `10_matriz_antes_despues/` | Matriz y salidas de pytest por versión; JUnit; fallos de escritura por escenario (JSON) |
| `11_*` | Suite completa de v0.4 |
| `12_*` | ruff |
| `13_*` | Estabilidad (3 corridas) |
| `20_*` a `26_*` | Regresiones (portadas y sin modificar) |
| `31_*`, `32_*` | Mutaciones y tabla de P2 |
| `40_*`, `41_*` | Sondas de v0.2 e integridad del paquete v0.3 |
| `52_*` | Mutaciones de la cadena |
| `60_*`, `61_*` | Parches |
| `90_*`, `91_*`, `98_*`, `99_*` | Integridad final y estado de git |

## Lo que NO se hizo
- No se hicieron commits, push, despliegues ni integraciones.
- No se usó dinero real, no se descargaron datos, no se leyeron bytes de datos de mercado y no se hicieron backtests.
- No se repitió T, no se invocó `fuera_de_muestra_T.py` ni se tocó su cerrojo, y no se ejecutó la calibración.
- No se publicaron hashes. No se creó, aprobó ni usó ninguna clave real: todas son sintéticas y están en las fábricas de prueba.
- No se eligió ninguna definición, etapa, umbral ni autorización.
- `papel/corte.py` solo se ejecutó en temporales con la fuente simulada de sus propias pruebas.
- **Revisión por un tercero: no realizada.**
