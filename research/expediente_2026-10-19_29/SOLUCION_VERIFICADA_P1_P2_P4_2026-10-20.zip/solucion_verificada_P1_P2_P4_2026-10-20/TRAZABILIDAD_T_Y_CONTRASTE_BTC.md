# Trazabilidad de los artefactos fuera de muestra de T y procedencia de `contraste_btc_diario_vs_horario`

Todo se hizo en **solo lectura**:
- git: `log`, `show`, `rev-parse`, `cat-file`, `grep`, `archive`;
- archivos de T sin modificar;
- la transcripción local de la sesión.

No se ejecutó T, no se invocó `fuera_de_muestra_T.py` ni se tocó su cerrojo, y no se leyeron datos de mercado.

## 1. Los tres artefactos fuera de muestra (`trazabilidad_T/`)
| Artefacto | SHA-256 | Blob de git | En `ARTEFACTOS_SHA256.txt` | En `EVIDENCIA_T_MULTI.json` | En origin |
|---|---|---|---|---|---|
| `experimentos/fuera_de_muestra_T.json` | `4f8fafde…633c45` | `68afab8d…` | **no** | sí, coincide | no |
| `experimentos/fuera_de_muestra_T.py` | `941b6e11…17fe0fa` | `fdc204c0…` | **no** | sí, coincide | no |
| `PRERREGISTRO_FUERA_DE_MUESTRA_T.md` | `94a16556…4db58f` | `6ce24de8…` | **no** | sí, coincide | no |

Los tres entraron en el **mismo** commit local, `692f2b2` (2026-10-18T05:05:02Z), que no está publicado.

**Cronología según la transcripción local** (`evidencia/04_*`; cada línea citada lleva su SHA-256):
1. 19:25:09Z: se escribe el prerregistro.
2. 19:26:12Z: se escribe el script, y a las 19:26:41Z se corrige su estilo.
3. Pruebas de humo con una **copia** del script apuntada a la ventana de desarrollo, que escribe en el scratchpad.
4. 19:27:04Z: congelado de los hashes `94a16556…` y `941b6e11…`. El resultado no existía. Hubo **una sola ejecución**, con resultado EVIDENCIA INSUFICIENTE.
5. 19:28:44Z: una segunda ejecución se niega a correr. El prerregistro y el script no cambiaron.

**Qué se corrigió en la trazabilidad, sin tocar los artefactos:**
- `ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt`: un manifiesto que P1 acepta con `--manifiesto`.
- `TRAZABILIDAD_FUERA_DE_MUESTRA_T.json`: hashes, blobs, commits, presencia en origin, cronología y límites.
- `DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json` y `.bin`: la declaración que, firmada por ti fuera de este equipo, daría la referencia independiente.
- El parche `0006` los agrega al repositorio como archivos **nuevos** (no se modifica `ARTEFACTOS_SHA256.txt`, que tiene cambios sin commit que no son de esta sesión).
- El generador se vuelve a ejecutar en cada `ejecutar_todo.sh` y se compara con lo guardado (`evidencia/05_*`).

**Límites:**
- git no prueba que el prerregistro precediera al resultado.
- La transcripción es local.
- Sin tu firma, P1 da **INCONCLUSO**, con el único motivo `SIN_REFERENCIA_INDEPENDIENTE`.

## 2. `contraste_btc_diario_vs_horario` (`contraste_btc/PROCEDENCIA_CALIDAD_DATOS.md`)
- **Productor localizado:** una orden ad hoc del 2026-10-17T01:27:24Z, en la transcripción local. Nunca se versionó. Las rondas anteriores dijeron «no está en el repositorio ni en el historial», lo cual era cierto pero incompleto.
- **Qué mide:** compara la apertura y el cierre diarios de BTC con las velas horarias de las 00:00 y las 23:00, ambas del mismo proveedor.
  - Solo del 2019-10-01 al 2026-05-31: 2.435 días, todos iguales.
  - **Los 775 días anteriores no se cuentan en ningún campo** (`sin_horaria = 0` no significa cobertura completa).
  - No mira máximos, mínimos ni volumen.
- **Estado:** procedencia **NO VERIFICADA**. Reproducirla exige leer datos de mercado (B-4).
  - P1 v0.4 → INCONCLUSO (`PROCEDENCIA_NO_VERIFICADA`), probado sobre el archivo real.
  - P2 → NO_CANDIDATA (X18).
  - Un resultado de T que contenga esa clave es CORRUPTO (`CLAVE_INESPERADA`).
