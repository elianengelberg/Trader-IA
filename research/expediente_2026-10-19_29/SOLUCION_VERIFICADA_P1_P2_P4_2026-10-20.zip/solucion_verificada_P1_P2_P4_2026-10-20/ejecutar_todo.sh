#!/usr/bin/env bash
# Reproduce TODA la evidencia de este paquete. Solo lectura sobre el repositorio (verifica que su estado de git no
# cambia); no ejecuta T, no lee bytes de datos de mercado, no usa red. Variables (con valores por defecto de esta sesión):
#   REPO  raíz del repositorio            PY   intérprete con pytest
#   V03   paquete v0.3 preservado (carpeta descomprimida de 00_preservado/CIERRE_FINAL_*.zip)
set -u
PAQ="$(cd "$(dirname "$0")" && pwd)"
REPO=${REPO:-/home/user/Trader-IA}
PY=${PY:-$REPO/research/hcarry_next/.venv/bin/python}
V03=${V03:-$(dirname "$PAQ")/cierre_final_P1_P2_P4_2026-10-20}
T="$REPO/research/tendencia_btc"
EVID="$PAQ/evidencia"
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$T/src:$REPO/research/hcarry_next/src"
export TMPDIR=${TMPDIR:-$(dirname "$PAQ")}
mkdir -p "$EVID"
cd "$PAQ"

estado_git() { (cd "$REPO" && echo "HEAD $(git rev-parse HEAD)" && git status --porcelain --ignored | sha256sum); }
estado_git > "$EVID/90_estado_git_antes.txt"
echo "== $(date -u +%FT%TZ) inicio; estado git: $(tail -1 "$EVID/90_estado_git_antes.txt")"

echo "== 1. estilo (ruff, mismas reglas que v0.3)"
"$REPO/research/hcarry_next/.venv/bin/ruff" check --no-cache --select E,F,W,B --line-length 125 codigo/verificacion \
  > "$EVID/12_ruff.txt" 2>&1; echo "código de salida: $?" >> "$EVID/12_ruff.txt"; tail -2 "$EVID/12_ruff.txt"

echo "== 2. suite completa de v0.4 (unitarias, adversariales, oráculos, concurrencia, fallos, contrato, cruzada, regresión portada)"
(cd pruebas && "$PY" -B -m pytest -p no:cacheprovider -q -rs p1 p2 p4 cruzada regresion/p1_v0_3_portadas \
  > "$EVID/11_suite_v0_4.txt" 2>&1; echo "código de salida de pytest: $?" >> "$EVID/11_suite_v0_4.txt")
grep -E "passed|failed" "$EVID/11_suite_v0_4.txt" | tail -1

echo "== 3. matriz antes/después (las mismas pruebas de defectos contra v0.2, v0.3 y v0.4)"
EVIDENCIA_P4_FALLOS="$EVID/10_matriz_antes_despues/fallos_es.json" "$PY" -B pruebas/matriz_antes_despues.py \
  "$EVID/10_matriz_antes_despues" > "$EVID/10_matriz_resumen.txt" 2>&1; echo "código de salida: $?" >> "$EVID/10_matriz_resumen.txt"
grep -c "| sí |" "$EVID/10_matriz_antes_despues/MATRIZ_ANTES_DESPUES.md" | sed 's/^/filas que cumplen el patrón: /'
grep -c "\*\*NO\*\*" "$EVID/10_matriz_antes_despues/MATRIZ_ANTES_DESPUES.md" | sed 's/^/filas que NO lo cumplen: /'

echo "== 4. estabilidad: concurrencia, fallos y ancla firmada repetidas 3 veces"
: > "$EVID/13_p4_repeticiones.txt"
for i in 1 2 3; do (cd pruebas && "$PY" -B -m pytest -p no:cacheprovider -q p4 cruzada 2>&1 | tail -1 | sed "s/^/corrida $i: /") >> "$EVID/13_p4_repeticiones.txt"; done
cat "$EVID/13_p4_repeticiones.txt"

echo "== 5. prueba de las pruebas (mutaciones)"
"$PY" -B pruebas/p2/mutacion_p2.py codigo/verificacion "$EVID/31_p2_mutaciones_oraculo.txt" | tail -1
"$PY" -B pruebas/mutacion_cruzada.py codigo/verificacion "$EVID/52_cruzada_mutaciones.txt" | tail -1

echo "== 6. regresiones con las suites de v0.3 sin modificar y sondas de v0.2"
PAQ="$PAQ" V03="$V03" PY="$PY" EVID="$EVID" bash pruebas/regresion/ejecutar_regresiones.sh

echo "== 7. tabla de decisión de P2"
"$PY" -B pruebas/p2/generar_tabla.py tablas > "$EVID/32_p2_tabla_resumen.txt"; sed -n 3,5p "$EVID/32_p2_tabla_resumen.txt"

echo "== 8. trazabilidad de T: regenerada en un temporal y comparada (salvo fechas de generación)"
TT=$(mktemp -d)
"$PY" -I -B trazabilidad_T/generar_trazabilidad.py "$REPO" "$TT" > /dev/null
"$PY" -I -B - "$TT" trazabilidad_T > "$EVID/05_trazabilidad_regenerada.txt" <<'EOF'
import json, sys
from pathlib import Path
nuevo, guardado = Path(sys.argv[1]), Path(sys.argv[2])
a = json.loads((nuevo / "TRAZABILIDAD_FUERA_DE_MUESTRA_T.json").read_text())
b = json.loads((guardado / "TRAZABILIDAD_FUERA_DE_MUESTRA_T.json").read_text())
for x in (a, b):
    x.pop("generado_utc"); x.pop("cronologia_transcripcion_local")
print("trazabilidad (artefactos, git, límites) idéntica a la guardada:", a == b)
print("manifiesto idéntico:", (nuevo / "ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt").read_bytes()
      == (guardado / "ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt").read_bytes())
EOF
rm -rf "$TT"; cat "$EVID/05_trazabilidad_regenerada.txt"

echo "== 9. parches versionados: construcción y comprobación sobre HEAD y origin exportados"
"$PY" -B parches/construir_y_comprobar.py "$PAQ" "$REPO" "$PY" "$EVID"

echo "== 10. integridad de las entregas anteriores y de los artefactos congelados de T"
{
  (cd 00_preservado && sha256sum -c ../evidencia/00_preservacion_relativa.txt)
  (cd "$V03" && sha256sum -c --quiet SHA256SUMS.txt && echo "paquete v0.3 (carpeta): intacto")
  (cd "$T" && sha256sum experimentos/fuera_de_muestra_T.json experimentos/fuera_de_muestra_T.py PRERREGISTRO_FUERA_DE_MUESTRA_T.md experimentos/calidad_datos.json)
} > "$EVID/98_integridad_final.txt" 2>&1; cat "$EVID/98_integridad_final.txt"

estado_git > "$EVID/91_estado_git_despues.txt"
if cmp -s "$EVID/90_estado_git_antes.txt" "$EVID/91_estado_git_despues.txt"; then
  echo "== estado git intacto: $(tail -1 "$EVID/91_estado_git_despues.txt")" | tee "$EVID/99_estado_git_comparado.txt"
else
  echo "== ¡EL ESTADO GIT CAMBIÓ!" | tee "$EVID/99_estado_git_comparado.txt"; exit 1
fi
echo "== $(date -u +%FT%TZ) fin"
