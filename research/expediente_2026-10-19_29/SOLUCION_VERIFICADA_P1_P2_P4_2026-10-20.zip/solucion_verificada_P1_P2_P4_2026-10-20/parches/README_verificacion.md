# verificacion/ — P1, P2 y P4 v0.4 (PROPUESTA: no aprobada ni integrada en ningún ejecutor)

| Módulo | Qué hace |
|---|---|
| `confianza.py` | Ed25519 (RFC 8032) y documentos firmados (declaraciones, respuestas del ancla) |
| `verificar_reproduccion_T.py` (P1) | Evalúa un resultado de T. Da exactamente un estado: VERIFICADO, REPRODUCIDO, NO_REPRODUCIDO, CORRUPTO o INCONCLUSO. VERIFICADO exige una declaración firmada por una raíz aprobada (`RAICES_CONFIANZA`, hoy vacío) |
| `politica_avance_T.py` (P2) | Separa validez, etiqueta, robustez, avance y autorización. Nunca otorga autorizaciones; sus registros están vacíos y no se inyectan |
| `uso_unico.py` (P4) | Ejecución de uso único con un ancla local o el cliente `AnclaFirmada` (el ancla externa no existe: ver `DISENO_ANCLA_EXTERNA.md`) |

**Pruebas:** desde `research/tendencia_btc`, ejecutar `python -m pytest verificacion/pruebas`. Son sintéticas; las
lecturas del árbol real de T son de solo lectura y no leen bytes de datos de mercado.

**Estado de T hoy:** el resultado fuera de muestra es INCONCLUSO, con un único motivo, `SIN_REFERENCIA_INDEPENDIENTE`.
Ver `../INSTRUCCIONES_FIRMA_FUERA_DE_MUESTRA_T.md`.
