"""Construye los parches VERSIONADOS v0.4 (solo archivos NUEVOS bajo research/tendencia_btc) y los comprueba SIN tocar
el repositorio: exporta HEAD y origin con ``git archive`` a directorios temporales, aplica la serie con
``git apply --check`` y ``git apply`` y ejecuta allí la suite (solo v0.4; las de regresión necesitan el paquete).
También comprueba que ninguna ruta de los parches existe en la copia de trabajo (sin leer bytes de datos).

Uso: python3 construir_y_comprobar.py <paquete> <repo> <python_con_pytest> <dir_evidencia>"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

R = "research/tendencia_btc"
V = f"{R}/verificacion"
SERIE = {
    "0001-confianza-firmas-y-base-de-pruebas": [
        ("codigo/verificacion/confianza.py", f"{V}/confianza.py"),
        ("pruebas/conftest.py", f"{V}/pruebas/conftest.py"),
        ("pruebas/comun/version.py", f"{V}/pruebas/comun/version.py"),
        ("pruebas/comun/fabricas_t.py", f"{V}/pruebas/comun/fabricas_t.py"),
        ("pruebas/p1/test_confianza.py", f"{V}/pruebas/p1/test_confianza.py")],
    "0002-P1-verificador-v0.4": [
        ("codigo/verificacion/verificar_reproduccion_T.py", f"{V}/verificar_reproduccion_T.py"),
        ("pruebas/comun/adaptador.py", f"{V}/pruebas/comun/adaptador.py"),
        ("pruebas/p1/test_p1_defectos.py", f"{V}/pruebas/p1/test_p1_defectos.py"),
        ("pruebas/p1/test_p1_v04.py", f"{V}/pruebas/p1/test_p1_v04.py")],
    "0003-P2-politica-v0.4": [
        ("codigo/verificacion/politica_avance_T.py", f"{V}/politica_avance_T.py"),
        *[(f"pruebas/p2/{f}", f"{V}/pruebas/p2/{f}") for f in (
            "oraculo_p2.py", "escenarios_p2.py", "test_p2_defectos.py", "test_p2_v04.py", "mutacion_p2.py",
            "generar_tabla.py")]],
    "0004-P4-uso-unico-v0.4": [
        ("codigo/verificacion/uso_unico.py", f"{V}/uso_unico.py"),
        ("pruebas/comun/ancla_de_prueba.py", f"{V}/pruebas/comun/ancla_de_prueba.py"),
        ("pruebas/comun/fallos_es.py", f"{V}/pruebas/comun/fallos_es.py"),
        *[(f"pruebas/p4/{f}", f"{V}/pruebas/p4/{f}") for f in (
            "_conductor.py", "sincro.py", "test_p4_defectos.py", "test_p4_fallos_es.py", "test_contrato_ancla.py",
            "test_ancla_firmada.py")],
        *[(f"pruebas/p4/codigos_sinteticos/{f}", f"{V}/pruebas/p4/codigos_sinteticos/{f}") for f in (
            "det.py", "entorno.py", "falla.py", "imprime.py", "lento.py", "nodet.py")]],
    "0005-cruzada-y-diseno-del-ancla": [
        *[(f"pruebas/cruzada/{f}", f"{V}/pruebas/cruzada/{f}") for f in (
            "codigo_oos_sintetico.py", "codigo_oos_nodet.py", "test_cruzada_v04.py")],
        ("pruebas/mutacion_cruzada.py", f"{V}/pruebas/mutacion_cruzada.py"),
        ("parches/README_verificacion.md", f"{V}/README.md"),
        ("DISENO_ANCLA_EXTERNA.md", f"{V}/DISENO_ANCLA_EXTERNA.md")],
    "0006-trazabilidad-T-y-procedencia-calidad-datos": [
        ("trazabilidad_T/generar_trazabilidad.py", f"{V}/trazabilidad/generar_trazabilidad.py"),
        ("trazabilidad_T/TRAZABILIDAD_FUERA_DE_MUESTRA_T.json", f"{R}/TRAZABILIDAD_FUERA_DE_MUESTRA_T.json"),
        ("trazabilidad_T/ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt", f"{R}/ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt"),
        ("trazabilidad_T/DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json", f"{R}/DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json"),
        ("trazabilidad_T/DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.bin", f"{R}/DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.bin"),
        ("trazabilidad_T/INSTRUCCIONES_FIRMA.md", f"{R}/INSTRUCCIONES_FIRMA_FUERA_DE_MUESTRA_T.md"),
        ("contraste_btc/PROCEDENCIA_CALIDAD_DATOS.md", f"{R}/PROCEDENCIA_CALIDAD_DATOS.md")],
}


def sh(*args: str, cwd: Path | None = None, ok: tuple[int, ...] = (0,)) -> subprocess.CompletedProcess:
    r = subprocess.run(list(args), cwd=cwd, capture_output=True, text=True, check=False)
    if r.returncode not in ok:
        raise SystemExit(f"falló {' '.join(args)}: {r.stderr[-800:]}")
    return r


def construir(paq: Path, salida: Path) -> list[Path]:
    salida.mkdir(parents=True, exist_ok=True)
    parches = []
    with tempfile.TemporaryDirectory() as tmp:
        for nombre, archivos in SERIE.items():
            cabecera = [f"# Parche {nombre} — Trader-IA, verificación v0.4 (PROPUESTA: NO APLICADA, NO APROBADA)",
                        "# Solo agrega archivos nuevos. SHA-256 de cada archivo agregado:"]
            cuerpo = []
            for origen, destino in archivos:
                datos = (paq / origen).read_bytes()
                (Path(tmp) / destino).parent.mkdir(parents=True, exist_ok=True)
                (Path(tmp) / destino).write_bytes(datos)
                cabecera.append(f"#   {hashlib.sha256(datos).hexdigest()}  {destino}")
                cuerpo.append(sh("git", "diff", "--no-index", "--binary", "--", "/dev/null", destino, cwd=Path(tmp),
                                 ok=(1,)).stdout)
            p = salida / f"{nombre}.patch"
            p.write_text("\n".join(cabecera) + "\n\n" + "".join(cuerpo), encoding="utf-8")
            parches.append(p)
    (salida / "TODO_v0.4.patch").write_text("".join(p.read_text(encoding="utf-8") for p in parches), encoding="utf-8")
    return parches


def comprobar(repo: Path, py: str, parches: list[Path], evid: Path) -> None:
    lineas = []
    rutas = [d for a in SERIE.values() for _, d in a]
    existentes = [d for d in rutas if (repo / d).exists()]
    lineas.append(f"rutas de los parches que ya existen en la copia de trabajo: {existentes or 'ninguna'} "
                  f"({len(rutas)} rutas; comprobado con os.path.exists, sin leer bytes)")
    remota = sh("git", "-C", str(repo), "rev-parse", "origin/claude/algo-trading-simulation-platform-ngf7xo").stdout.strip()
    for etiqueta, rev in (("HEAD", "HEAD"), ("origin", remota)):
        sha = sh("git", "-C", str(repo), "rev-parse", rev).stdout.strip()
        with tempfile.TemporaryDirectory() as tmp:
            arch = Path(tmp) / "a.tar"
            sh("git", "-C", str(repo), "archive", "--format=tar", "-o", str(arch), sha, "research")
            sh("tar", "-xf", str(arch), "-C", tmp)
            arch.unlink()
            for p in parches:
                sh("git", "apply", "--check", str(p), cwd=Path(tmp))
                sh("git", "apply", str(p), cwd=Path(tmp))
            lineas.append(f"{etiqueta} ({sha[:12]}): git apply --check y git apply de los 6 parches en orden: OK")
            t = Path(tmp) / R
            env = {**os.environ, "TRADER_IA_T": str(t), "PYTHONDONTWRITEBYTECODE": "1",
                   "PYTHONPATH": f"{t / 'src'}:{Path(tmp) / 'research' / 'hcarry_next' / 'src'}"}
            r = subprocess.run([py, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q", "-rs", "verificacion/pruebas"],
                               cwd=t, capture_output=True, text=True, env=env, check=False)
            (evid / f"61_parche_aplicado_en_{etiqueta}_pytest.txt").write_text(r.stdout + r.stderr, encoding="utf-8")
            resumen = [x for x in r.stdout.splitlines() if " passed" in x or " failed" in x][-1:]
            lineas.append(f"{etiqueta}: suite en la copia parcheada (código de salida {r.returncode}): {resumen}")
            shutil.rmtree(t / "verificacion" / "pruebas", ignore_errors=True)
    (evid / "60_parches_comprobacion.txt").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print("\n".join(lineas))


if __name__ == "__main__":
    paq, repo, py, evid = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4])
    comprobar(repo, py, construir(paq, paq / "parches" / "v0.4"), evid)
