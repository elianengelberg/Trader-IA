"""Inyección CONTROLADA de fallos de escritura: un sustituto del módulo ``os`` que se instala SOLO en el módulo bajo
prueba (``U.os = OSConFallos(os, plan)``) dentro de un proceso hijo. Cuenta las llamadas de cada operación y hace
fallar la n-ésima de la operación elegida (con ``contiene``, solo cuentan las escrituras cuyos bytes contienen ese
texto: así el plan no depende del número de escrituras de cada versión):
- ENOSPC / EIO: la llamada lanza OSError sin hacer nada (disco lleno, error de E/S);
- CORTA: os.write escribe la MITAD y devuelve ese número (escritura corta legítima, sin error);
- CORTA_ENOSPC: escritura corta y, en la siguiente escritura, ENOSPC (bytes a medias en disco).
No simula la pérdida de páginas sucias tras un fsync fallido ni un corte de energía (ver límites)."""
from __future__ import annotations

import errno

OPERACIONES = ("write", "fsync", "replace", "link", "ftruncate")
MODOS = {"write": ("ENOSPC", "EIO", "CORTA", "CORTA_ENOSPC"), "fsync": ("EIO",), "replace": ("EIO",),
         "link": ("ENOSPC",), "ftruncate": ("EIO",)}


class OSConFallos:
    def __init__(self, real, plan: dict | None = None):  # type: ignore[no-untyped-def]
        self._real, self._plan = real, plan
        self.conteo = dict.fromkeys(OPERACIONES, 0)
        self._enospc_pendiente = False
        self.inyectado = False

    def __getattr__(self, nombre: str):  # type: ignore[no-untyped-def]
        return getattr(self._real, nombre)

    def _toca(self, op: str, datos: bytes | None = None) -> str | None:
        self.conteo[op] += 1
        if not self._plan or self._plan["op"] != op:
            return None
        if "contiene" in self._plan:
            if datos is None or self._plan["contiene"].encode() not in bytes(datos):
                return None
            self._coincidencias = getattr(self, "_coincidencias", 0) + 1
            n = self._coincidencias
        else:
            n = self.conteo[op]
        if self._plan["n"] == n:
            self.inyectado = True
            return self._plan["modo"]
        return None

    @staticmethod
    def _error(modo: str) -> OSError:
        codigo = errno.ENOSPC if modo == "ENOSPC" else errno.EIO
        return OSError(codigo, f"{modo} inyectado")

    def write(self, fd: int, datos) -> int:  # type: ignore[no-untyped-def]
        if self._enospc_pendiente:
            self._enospc_pendiente = False
            raise self._error("ENOSPC")
        modo = self._toca("write", datos)
        if modo in ("ENOSPC", "EIO"):
            raise self._error(modo)
        if modo in ("CORTA", "CORTA_ENOSPC") and len(datos) > 1:
            self._enospc_pendiente = modo == "CORTA_ENOSPC"
            return self._real.write(fd, bytes(datos[: len(datos) // 2]))
        return self._real.write(fd, datos)

    def fsync(self, fd: int) -> None:
        if self._toca("fsync"):
            raise self._error("EIO")
        self._real.fsync(fd)

    def replace(self, a, b) -> None:  # type: ignore[no-untyped-def]
        if self._toca("replace"):
            raise self._error("EIO")
        self._real.replace(a, b)

    def link(self, a, b) -> None:  # type: ignore[no-untyped-def]
        if self._toca("link"):
            raise self._error("ENOSPC")
        self._real.link(a, b)

    def ftruncate(self, fd: int, n: int) -> None:
        if self._toca("ftruncate"):
            raise self._error("EIO")
        self._real.ftruncate(fd, n)
