"""Versión bajo prueba (VERSION_BAJO_PRUEBA = v0_2 | v0_3 | v0_4; por defecto v0_4) y rutas de sus módulos.

Las mismas pruebas de defectos se ejecutan contra cada versión para demostrar que FALLAN antes de la corrección y PASAN
después (matriz en evidencia/). Las pruebas propias de v0.4 se marcan ``solo_v04`` y se omiten en las otras."""
from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path

import pytest

PAQUETE = Path(__file__).resolve().parents[2]
VERSION = os.environ.get("VERSION_BAJO_PRUEBA", "v0_4")
if VERSION not in ("v0_2", "v0_3", "v0_4"):
    raise RuntimeError(f"VERSION_BAJO_PRUEBA desconocida: {VERSION!r}")
# Paquete de entrega: codigo/verificacion; repositorio (parche aplicado): la carpeta verificacion/ que contiene pruebas/.
# CODIGO_V04_DIR solo para la prueba de mutaciones (una COPIA mutada del código de v0.4).
_EN_PAQUETE = PAQUETE / "codigo" / "verificacion"
CODIGO_V04 = Path(os.environ.get("CODIGO_V04_DIR") or (_EN_PAQUETE if _EN_PAQUETE.is_dir() else PAQUETE))
if VERSION == "v0_4":
    DIR_P1 = DIR_P2 = DIR_P4 = CODIGO_V04
else:
    base = PAQUETE / "referencia" / VERSION
    if not base.is_dir():
        raise RuntimeError(f"{VERSION}: no hay código de referencia en {base} (solo en el paquete de entrega)")
    DIR_P1, DIR_P2, DIR_P4 = base / "p1", base / "p2", base / "p4"
MODULO_P4 = DIR_P4 / "uso_unico.py"
solo_v04 = pytest.mark.skipif(VERSION != "v0_4", reason=f"prueba propia de v0.4 (versión bajo prueba: {VERSION})")


def _importar(nombre: str, directorio: Path):  # type: ignore[no-untyped-def]
    if str(directorio) not in sys.path:
        sys.path.insert(0, str(directorio))
    return importlib.import_module(nombre)


def p1():  # type: ignore[no-untyped-def]
    return _importar("verificar_reproduccion_T", DIR_P1)


def p2():  # type: ignore[no-untyped-def]
    p1()  # P2 importa P1 de su propia versión; se carga primero para que coincidan
    return _importar("politica_avance_T", DIR_P2)


def p4():  # type: ignore[no-untyped-def]
    return _importar("uso_unico", DIR_P4)


def confianza():  # type: ignore[no-untyped-def]
    """Módulo de firmas de v0.4, cargado con otro nombre: las FÁBRICAS lo usan para firmar en cualquier versión."""
    nombre = "confianza_para_fabricas"
    if nombre not in sys.modules:
        spec = importlib.util.spec_from_file_location(nombre, CODIGO_V04 / "confianza.py")
        m = importlib.util.module_from_spec(spec)
        sys.modules[nombre] = m
        spec.loader.exec_module(m)  # type: ignore[union-attr]
    return sys.modules[nombre]
