"""Prueba de las pruebas de la cadena P4 → P1 → P2: cada mutación ELIMINA un control de una COPIA del código v0.4 y se
ejecutan las pruebas cruzadas y las del ancla firmada; la mutación debe hacer fallar al menos una. Las pruebas que la
detectan se registran. Uso: python3 mutacion_cruzada.py <dir_codigo_v0.4> <salida.txt>"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
MUTACIONES = [
    ("P1: VERIFICADO sin referencia independiente", "verificar_reproduccion_T.py",
     "    if not aut[\"cubren\"]:\n        detalle = (", "    if False:\n        detalle = ("),
    ("P1: ignora el hash presellado por P4", "verificar_reproduccion_T.py",
     "        if resultado_sha256 != resultado_sha256_esperado:", "        if False:"),
    ("confianza: toda firma es válida", "confianza.py",
     "    return _iguales(_multiplicar(s, _G), _sumar(r, _multiplicar(h, a)))", "    return True"),
    ("P2: INCONCLUSO cuenta como evidencia válida", "politica_avance_T.py",
     'VALIDA = ("VERIFICADO", "REPRODUCIDO")', 'VALIDA = ("VERIFICADO", "REPRODUCIDO", "INCONCLUSO")'),
    ("P4: no guarda el recibo del ancla", "uso_unico.py",
     "        if ancla.emite_recibos:  # v0.4", "        if False:  # v0.4"),
    ("P4: no rechaza una reserva cuyo cálculo ya inició en el ancla", "uso_unico.py",
     '                if st["reserva"] and (st["iniciados"] or st["presellado"]):', "                if False:"),
    ("P4/AnclaFirmada: no comprueba el desafío", "uso_unico.py",
     '"reserva_sha256": reserva_sha, "desafio": desafio,\n                    "emisor": self.emisor}',
     '"reserva_sha256": reserva_sha,\n                    "emisor": self.emisor}'),
    ("P4/AnclaFirmada: no verifica la firma de la respuesta", "uso_unico.py",
     "            c = C.verificar_documento(respuesta, self.clave)", "            c = respuesta[\"contenido\"]"),
]


def main(codigo: Path, salida: Path) -> int:
    lineas, sobreviven = [], 0
    for nombre, archivo, viejo, nuevo in MUTACIONES:
        with tempfile.TemporaryDirectory() as tmp:
            for f in codigo.glob("*.py"):
                shutil.copy(f, Path(tmp) / f.name)
            p = Path(tmp) / archivo
            texto = p.read_text(encoding="utf-8")
            if texto.count(viejo) != 1:
                raise SystemExit(f"{nombre}: el texto original aparece {texto.count(viejo)} veces")
            p.write_text(texto.replace(viejo, nuevo), encoding="utf-8")
            r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q", "-rf", "--tb=no",
                                "cruzada", "p4/test_ancla_firmada.py", "p4/test_contrato_ancla.py"], cwd=AQUI,
                               capture_output=True, text=True, env={**os.environ, "CODIGO_V04_DIR": tmp,
                                                                    "PYTHONDONTWRITEBYTECODE": "1"}, check=False)
        fallidas = sorted({m.split("::")[-1].split(" ")[0] for m in re.findall(r"FAILED (\S+)", r.stdout)})
        sobreviven += not fallidas
        lineas.append(f"{'MUERTA' if fallidas else 'SOBREVIVE'}\t{nombre}\t{len(fallidas)} pruebas fallan: "
                      f"{', '.join(fallidas[:6])}{' …' if len(fallidas) > 6 else ''}")
    salida.write_text("\n".join(lineas) + f"\n{len(MUTACIONES) - sobreviven} de {len(MUTACIONES)} mutaciones detectadas\n",
                      encoding="utf-8")
    print(salida.read_text(encoding="utf-8"))
    return 1 if sobreviven else 0


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()))
