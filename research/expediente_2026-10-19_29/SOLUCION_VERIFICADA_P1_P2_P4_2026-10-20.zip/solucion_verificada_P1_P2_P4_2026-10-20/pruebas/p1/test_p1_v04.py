"""P1 v0.4: los cinco estados contra un ORÁCULO escrito aparte (720 combinaciones de condiciones), clasificación
estática de cada código, línea de órdenes, artefacto real de T y calidad_datos.json en SOLO LECTURA."""
from __future__ import annotations

import ast
import contextlib
import hashlib
import io
import itertools
import json
import os
from pathlib import Path

import adaptador as A
import fabricas_t as F
import pytest
import version
from version import solo_v04

pytestmark = solo_v04
V = version.p1()
T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.json").is_file(), reason="T no disponible")
SCRIPT, RESULTADO, PRERREGISTRO = ("experimentos/fuera_de_muestra_T.py", "experimentos/fuera_de_muestra_T.json",
                                   "PRERREGISTRO_FUERA_DE_MUESTRA_T.md")
TRAZA = next((p for p in (version.PAQUETE / "trazabilidad_T" / "ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt",
                         T / "ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt") if p.is_file()), None)

FACTORES = {"raiz": (True, False), "falta": ("ninguna", "prerregistro"), "corrupcion": ("ninguna", "script", "decision"),
            "manifiesto": ("ninguno", "coherente", "discrepante", "no_cubre"),
            "declaracion": ("ninguna", "cubre", "contradice", "firma_invalida", "emisor_no_aprobado"),
            "presellado": ("ninguno", "coincide", "distinto")}


def oraculo(c: dict) -> tuple[str, set[str]]:
    """Especificación de los estados (docstring de P1 v0.4), escrita sin mirar la implementación. CORRUPTO: códigos
    admisibles (se informa uno); INCONCLUSO: conjunto EXACTO de motivos."""
    corrupto = set()
    if c["presellado"] == "distinto":
        corrupto.add("HASH")
    if c["corrupcion"] == "decision":
        corrupto.add("CONTRADICCION")
    if c["raiz"]:
        if c["corrupcion"] == "script":
            corrupto |= {"HASH", "HASH_MANIFIESTO", "HASH_REFERENCIA"}
        if c["manifiesto"] == "discrepante":
            corrupto.add("HASH_MANIFIESTO")
        if c["declaracion"] == "contradice":
            corrupto.add("HASH_REFERENCIA")
    if corrupto:
        return "CORRUPTO", corrupto
    motivos = set()
    if not c["raiz"]:
        motivos.add("USO" if c["manifiesto"] != "ninguno" else "INTEGRIDAD_INCOMPLETA")
    else:
        if c["falta"] == "prerregistro":
            motivos.add("ARCHIVO_AUSENTE")
        if c["manifiesto"] == "no_cubre":
            motivos.add("MANIFIESTO_NO_CUBRE")
    if c["declaracion"] != "cubre":
        motivos.add("SIN_REFERENCIA_INDEPENDIENTE")
    return ("INCONCLUSO", motivos) if motivos else ("VERIFICADO", set())


def construir(tmp: Path, c: dict) -> tuple[Path, dict]:
    raiz = F.arbol_t(tmp / "T")
    o = F.oos(raiz=raiz)
    if c["corrupcion"] == "decision":
        o["decision_prerregistrada"] = "RESPALDADA FUERA DE MUESTRA"  # sus cifras dan EVIDENCIA INSUFICIENTE
    ruta = raiz / RESULTADO
    ruta.write_text(json.dumps(o), encoding="utf-8")
    b = ruta.read_bytes()
    cadena = F.cadena(raiz)
    manifiesto = {"ninguno": None, "coherente": cadena,
                  "discrepante": cadena | {SCRIPT: {"sha256": "0" * 64}},
                  "no_cubre": {k: v for k, v in cadena.items() if k != RESULTADO}}[c["manifiesto"]]
    firmar = {RESULTADO: b, SCRIPT: (raiz / SCRIPT).read_bytes()}
    decl = {"ninguna": [], "cubre": [("d", F.declarar(firmar))],
            "contradice": [("d", F.declarar({RESULTADO: "1" * 64}))],
            "firma_invalida": [("d", F.declarar(firmar, semilla=F.SEMILLA_INTRUSA))],
            "emisor_no_aprobado": [("d", F.declarar(firmar, emisor="INTRUSO", semilla=F.SEMILLA_INTRUSA))]}[c["declaracion"]]
    kw: dict = {"declaraciones": decl}
    if manifiesto is not None:
        kw["manifiesto"] = manifiesto
    if c["presellado"] != "ninguno":
        kw["resultado_sha256_esperado"] = hashlib.sha256(b).hexdigest() if c["presellado"] == "coincide" else "0" * 64
    if c["corrupcion"] == "script":
        (raiz / SCRIPT).write_text((raiz / SCRIPT).read_text() + "# alterado tras la firma\n", encoding="utf-8")
    if c["falta"] == "prerregistro":
        (raiz / PRERREGISTRO).unlink()
    if c["raiz"]:
        kw["raiz"] = raiz
    return ruta, kw


def test_estados_contra_el_oraculo(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    combinaciones = [dict(zip(FACTORES, v, strict=True)) for v in itertools.product(*FACTORES.values())]
    assert len(combinaciones) == 2 * 2 * 3 * 4 * 5 * 3
    vistos = set()
    for i, c in enumerate(combinaciones):
        ruta, kw = construir(tmp_path / str(i), c)
        inf = V.evaluar_archivo(ruta, **kw)
        esperado, codigos = oraculo(c)
        obtenidos = [m["codigo"] for m in inf["motivos"]]
        assert inf["estado"] == esperado, (c, inf["motivos"])
        if esperado == "CORRUPTO":
            assert len(obtenidos) == 1 and obtenidos[0] in codigos, (c, obtenidos)
        else:
            assert set(obtenidos) == codigos, (c, obtenidos)
        assert all(m["clase"] == ("CORRUPTO" if esperado == "CORRUPTO" else "INCONCLUSO") for m in inf["motivos"])
        vistos.add(esperado)
    assert vistos == {"VERIFICADO", "CORRUPTO", "INCONCLUSO"}


def test_cada_codigo_tiene_exactamente_una_clase() -> None:
    """Todo código que el módulo puede emitir (primer argumento de ErrorVerificacion o primer elemento de un par
    (código, detalle)) pertenece a UNA sola clase; ningún estado queda sin definición ni código de salida."""
    import re
    arbol = ast.parse((version.DIR_P1 / "verificar_reproduccion_T.py").read_bytes())
    usados = set()
    for n in ast.walk(arbol):
        if isinstance(n, ast.Call) and getattr(n.func, "id", None) == "ErrorVerificacion" and n.args and \
                isinstance(n.args[0], ast.Constant):
            usados.add(n.args[0].value)
        if isinstance(n, ast.Tuple) and len(n.elts) == 2 and isinstance(n.elts[0], ast.Constant) and \
                isinstance(n.elts[0].value, str) and re.fullmatch(r"[A-Z][A-Z_]+", n.elts[0].value):
            usados.add(n.elts[0].value)
    usados -= {"BTC", "BTCUSDT"}  # ("BTC", "ETH") y SIMBOLOS: símbolos, no códigos
    assert not V.CODIGOS_CORRUPTO & V.CODIGOS_INCONCLUSO
    assert usados <= V.CODIGOS_CORRUPTO | V.CODIGOS_INCONCLUSO, usados - (V.CODIGOS_CORRUPTO | V.CODIGOS_INCONCLUSO)
    assert len(usados) >= 20
    assert set(V.SALIDAS) == set(V.ESTADOS) == set(V.DEFINICIONES)


def test_la_api_publica_no_acepta_raices() -> None:
    import inspect
    for nombre in ("evaluar", "evaluar_archivo", "evaluar_reproduccion", "verificar", "verificar_archivo"):
        assert not {"raices", "raices_confianza"} & set(inspect.signature(getattr(V, nombre)).parameters)
    assert V.RAICES_CONFIANZA == {}


def _main(*args: object) -> tuple[int, dict]:
    salida = io.StringIO()
    with contextlib.redirect_stdout(salida):
        codigo = V.main([str(a) for a in args])
    return codigo, json.loads(salida.getvalue())


def test_linea_de_ordenes_codigos_de_salida(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = raiz / RESULTADO
    ruta.write_text(json.dumps(F.oos(raiz=raiz)), encoding="utf-8")
    d = tmp_path / "decl.json"
    d.write_text(json.dumps(F.declarar({RESULTADO: ruta.read_bytes()})), encoding="utf-8")
    # sin raíces aprobadas (registro del módulo), una firma válida no basta: INCONCLUSO (3)
    codigo, inf = _main(ruta, "--raiz", raiz, "--declaracion", d)
    assert (codigo, inf["estado"], [m["codigo"] for m in inf["motivos"]]) == (3, "INCONCLUSO",
                                                                              ["SIN_REFERENCIA_INDEPENDIENTE"])
    monkeypatch.setattr(V, "RAICES_CONFIANZA", dict(F.RAICES_PRUEBA))
    assert _main(ruta, "--raiz", raiz, "--declaracion", d)[0] == 0
    otra = tmp_path / "otra.json"
    otra.write_text(json.dumps(F.oos(p_conj=0.76, raiz=raiz)), encoding="utf-8")
    assert _main(ruta, "--raiz", raiz, "--declaracion", d, "--reproduccion", otra)[1]["estado"] == "NO_REPRODUCIDO"
    assert _main(ruta, "--raiz", raiz, "--declaracion", d, "--reproduccion", otra)[0] == 5
    assert _main(ruta, "--raiz", raiz, "--declaracion", d, "--reproduccion", ruta)[0] == 0
    assert _main(ruta, "--raiz", raiz, "--declaracion", d, "--resultado-sha256", "0" * 64)[0] == 1
    assert _main(ruta, "--raiz", raiz, "--tolerancia", "0.1")[0] == 3
    (tmp_path / "ilegible.json").write_text('{"contenido": ', encoding="utf-8")
    codigo, inf = _main(ruta, "--raiz", raiz, "--declaracion", tmp_path / "ilegible.json")
    assert codigo == 3 and "no válidas" in inf["motivos"][0]["detalle"]
    salida = io.StringIO()
    with contextlib.redirect_stdout(salida):
        assert V.main([str(ruta), "--opcion-inventada"]) == 2  # uso incorrecto de la línea de órdenes


@pytest.mark.parametrize("contenido,estado,codigo", [
    ({"BTCUSDT": {}, "ETHUSDT": {}, "contraste_btc_diario_vs_horario": {"comparados": 1}}, "INCONCLUSO",
     "PROCEDENCIA_NO_VERIFICADA"),
    ({"cualquier": "cosa"}, "INCONCLUSO", "TIPO_NO_ADMITIDO"), ([1, 2], "INCONCLUSO", "TIPO_NO_ADMITIDO"),
    ({"principal": {}}, "CORRUPTO", "ESQUEMA")])
def test_archivos_que_no_son_resultados_de_t(tmp_path: Path, contenido, estado: str, codigo: str) -> None:  # type: ignore[no-untyped-def]
    p = tmp_path / "x.json"
    p.write_text(json.dumps(contenido), encoding="utf-8")
    inf = V.evaluar_archivo(p)
    assert (inf["estado"], inf["motivos"][0]["codigo"]) == (estado, codigo)


def test_un_resultado_de_t_con_la_clave_de_calidad_es_corrupto(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = raiz / RESULTADO
    ruta.write_text(json.dumps(F.oos(raiz=raiz) | {"contraste_btc_diario_vs_horario": {}}), encoding="utf-8")
    assert A.evaluar(ruta, raiz=raiz).codigos == ["CLAVE_INESPERADA"]


def _huellas(rutas: list[Path]) -> dict:
    return {str(p): (hashlib.sha256(p.read_bytes()).hexdigest(), os.stat(p).st_mtime_ns) for p in rutas}


@con_t
def test_calidad_datos_real_no_es_evidencia() -> None:
    ruta = T / "experimentos" / "calidad_datos.json"
    antes = _huellas([ruta])
    inf = V.evaluar_archivo(ruta, raiz=T)
    assert (inf["estado"], inf["motivos"][0]["codigo"]) == ("INCONCLUSO", "PROCEDENCIA_NO_VERIFICADA")
    assert "2435 de 3210" in inf["motivos"][0]["detalle"]
    assert _huellas([ruta]) == antes


@con_t
def test_artefacto_real_de_t_es_inconcluso_solo_por_falta_de_raiz_de_confianza() -> None:
    """Solo lectura. Integridad local completa y coherente con los TRES manifiestos locales (ARTEFACTOS_SHA256.txt,
    EVIDENCIA_T_MULTI.json y la trazabilidad generada); sin raíz aprobada el estado es INCONCLUSO, con ese único
    motivo. Los archivos reales no cambian (hash y mtime)."""
    ruta = T / RESULTADO
    leidos = [ruta, T / SCRIPT, T / PRERREGISTRO, *sorted((T / "src" / "tendencia").glob("*.py")),
              T / "datos" / "BTCUSDT" / "MANIFIESTO.json", T / "datos" / "ETHUSDT" / "MANIFIESTO.json"]
    antes = _huellas(leidos)
    if TRAZA is None:
        pytest.skip("falta ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt (trazabilidad no aplicada)")
    manifiesto = V.unir_manifiestos([str(T / "ARTEFACTOS_SHA256.txt"),
                                     f"{T / 'EVIDENCIA_T_MULTI.json'}#cadena_historica_T_fuera_de_muestra", str(TRAZA)])
    inf = V.evaluar_archivo(ruta, raiz=T, manifiesto=manifiesto)
    assert inf["estado"] == "INCONCLUSO" and [m["codigo"] for m in inf["motivos"]] == ["SIN_REFERENCIA_INDEPENDIENTE"]
    assert inf["integridad_local"] == "COMPLETA" and inf["decision_recalculada"] == "EVIDENCIA INSUFICIENTE"
    assert inf["resultado_sha256"].startswith("4f8fafde") and inf["contraste_con_manifiestos"]["no_listados"] == []
    assert {RESULTADO, SCRIPT, PRERREGISTRO} <= set(inf["contraste_con_manifiestos"]["coinciden"])
    assert _huellas(leidos) == antes


@con_t
def test_huella_igual_a_la_del_codigo_congelado() -> None:
    """La huella recalculada del árbol real es la del código congelado (73b22f3e…), sin importar ese código."""
    assert V.huella_codigo(T / "src" / "tendencia").startswith("73b22f3e")
