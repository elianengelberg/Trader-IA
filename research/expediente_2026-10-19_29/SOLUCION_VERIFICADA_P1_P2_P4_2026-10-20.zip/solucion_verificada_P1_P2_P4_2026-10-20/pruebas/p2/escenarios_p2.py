"""Construcción de los escenarios SINTÉTICOS de P2 v0.4 (registros, evaluaciones y evidencias) a partir de los nombres
del oráculo, y ejecución de la política sobre ellos. Compartido por la prueba exhaustiva y por generar_tabla.py.
Los registros sintéticos solo recorren ramas: no son propuestas ni definiciones aprobadas."""
from __future__ import annotations

import contextlib
import itertools

import oraculo_p2 as O

SHA_A, SHA_B = "a" * 64, "b" * 64
INICIO = "2022-01-01"


def _definicion(ident: str, criterio: str, aprobada: str) -> dict:
    return {"id": ident, "criterio": criterio, "aplica_a": "T", "texto_sha256": "0" * 64, "aprobada_utc": aprobada,
            "aprobada_por": "PRUEBA SINTÉTICA (no es una aprobación)"}


DEFINICIONES = {
    "VACIO": {},
    "SINTETICO": {"R1-SINT": _definicion("R1-SINT", "R1", "2000-01-01T00:00:00Z"),   # anterior a la ventana
                  "R3-SINT": _definicion("R3-SINT", "R3", "2027-01-01T00:00:00Z")},  # posterior: POST HOC
    "SINTETICO_LIMITE": {"R1-SINT": _definicion("R1-SINT", "R1", "2022-01-01T01:59:59+02:00"),  # = 2021-12-31 23:59:59 UTC
                         "R3-SINT": _definicion("R3-SINT", "R3", "2022-01-01T00:00:00Z")},     # el mismo día: POST HOC
    "ID_DISTINTO_DE_LA_CLAVE": {"R1-SINT": _definicion("OTRO-ID", "R1", "2000-01-01T00:00:00Z")},
}
ETAPAS = {"ETAPA_SINTETICA": "solo para recorrer ramas", "OTRA": "solo para recorrer ramas"}
AUTORIZACIONES = {n: {"id": n, "etapa": e, "resultado_sha256": s, "otorgada_por": "PRUEBA SINTÉTICA",
                      "otorgada_utc": "2030-01-01T00:00:00Z", "texto_sha256": "1" * 64}
                  for n, e, s in (("COINCIDENTE", "ETAPA_SINTETICA", SHA_A), ("OTRA_ETAPA", "OTRA", SHA_A),
                                  ("OTRO_RESULTADO", "ETAPA_SINTETICA", SHA_B))}


def valor_r(criterio: str, escenario: str) -> object:
    if escenario in ("NO_DEFINIDO", "NO_EVALUADO"):
        return escenario
    if escenario == "TUPLA_V03":
        return ("CUMPLE", f"{criterio}-SINT")
    estado = "CUMPLE" if escenario.startswith("CUMPLE") else "NO_CUMPLE"
    return {"estado": estado, "definicion": f"{criterio}-SINT",
            "resultado_sha256": SHA_B if escenario == "CUMPLE_OTRO_RESULTADO" else SHA_A}


@contextlib.contextmanager
def registros(PA, reg_def: str):  # type: ignore[no-untyped-def]
    viejos = PA.DEFINICIONES_APROBADAS, PA.ETAPAS_DEFINIDAS, PA.AUTORIZACIONES
    PA.DEFINICIONES_APROBADAS, PA.ETAPAS_DEFINIDAS, PA.AUTORIZACIONES = DEFINICIONES[reg_def], ETAPAS, AUTORIZACIONES
    try:
        yield
    finally:
        PA.DEFINICIONES_APROBADAS, PA.ETAPAS_DEFINIDAS, PA.AUTORIZACIONES = viejos


def etapa_del_error(mensaje: str) -> str:
    """Etapa que produjo el ErrorPolitica, por la forma de su mensaje."""
    if mensaje.startswith(("R1:", "R3:")):
        return mensaje[:2]
    if "no definida (A5)" in mensaje:
        return "etapa"
    if mensaje.startswith("autorización") and mensaje.endswith("desconocida"):
        return "autorizacion"
    if mensaje.startswith(("definición", "etapa", "autorización")):
        return "registros"
    return f"DESCONOCIDA: {mensaje}"


def ejecutar(PA, validez, etiqueta, reg_def, r1, r3, etapa, aut) -> tuple[str, object]:  # type: ignore[no-untyped-def]
    """Resultado de la IMPLEMENTACIÓN en el mismo formato que el oráculo."""
    try:
        ev = PA._evidencia_sintetica(validez, etiqueta, SHA_A, INICIO)
    except PA.ErrorPolitica:
        return "ERROR", "evidencia"
    with registros(PA, reg_def):
        try:
            s = PA._decidir(ev, valor_r("R1", r1), valor_r("R3", r3), etapa, aut)
        except PA.ErrorPolitica as e:
            return "ERROR", etapa_del_error(str(e))
    rob = s["robustez"]
    return "OK", {"etiqueta_estadistica": s["etiqueta_estadistica"], "etiqueta_declarada": s["etiqueta_declarada"],
                  "clase": s["clase_estadistica"], "robustez": rob["resumen"], "avance": s["decision_avance"]["resultado"],
                  "etapa_salida": s["decision_avance"]["etapa"], "autorizacion": s["autorizacion_ejecucion"]["estado"],
                  "R1": rob["R1"]["estado"], "R3": rob["R3"]["estado"], "post_hoc_R1": rob["R1"]["post_hoc"],
                  "post_hoc_R3": rob["R3"]["post_hoc"]}


def espacio() -> list[tuple]:
    return list(itertools.product(O.VALIDEZ, O.ETIQUETAS, O.REGISTRO_DEF, O.R, O.R, O.ETAPA, O.AUTORIZACION))
