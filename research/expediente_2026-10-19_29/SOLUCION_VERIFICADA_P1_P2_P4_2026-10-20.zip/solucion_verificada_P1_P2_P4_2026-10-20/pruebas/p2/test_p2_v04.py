"""P2 v0.4: espacio COMPLETO de entradas (86.400 combinaciones, incluidas las inválidas) contra el oráculo independiente,
evidencia sellada, interfaz pública mínima, paso por P1 v0.4 con todos sus estados, artefacto real en solo lectura y
comprobaciones estáticas."""
from __future__ import annotations

import ast
import hashlib
import inspect
import json
from collections import Counter
from pathlib import Path

import escenarios_p2 as E
import fabricas_t as F
import oraculo_p2 as O
import pytest
import version
from version import solo_v04

pytestmark = solo_v04
PA = version.p2()
T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.json").is_file(), reason="T no disponible")


def test_espacio_completo_contra_el_oraculo() -> None:
    combinaciones = E.espacio()
    assert len(combinaciones) == 5 * 8 * 4 * 6 * 6 * 3 * 5 == 86400
    clases: Counter = Counter()
    for c in combinaciones:
        obtenido, esperado = E.ejecutar(PA, *c), O.esperado(*c)
        assert obtenido == esperado, (c, obtenido, esperado)
        clases[obtenido[0] if obtenido[0] == "ERROR" else obtenido[1]["autorizacion"]] += 1  # type: ignore[index]
        if obtenido[0] == "ERROR":
            clases[f"ERROR:{obtenido[1]}"] += 1
    # todas las ramas se recorren
    assert {"NO_OTORGADA", "CONTRADICTORIA", "REGISTRADA_EXTERNAMENTE"} <= set(clases)
    assert {f"ERROR:{e}" for e in ("evidencia", "registros", "etapa", "R1", "R3", "autorizacion")} <= set(clases)


def test_registrada_externamente_solo_en_el_caso_coherente() -> None:
    """La política constata (nunca otorga): REGISTRADA_EXTERNAMENTE solo con evidencia válida RESPALDADA, la etapa de
    la autorización y el mismo resultado."""
    for c in E.espacio():
        r = E.ejecutar(PA, *c)
        if r[0] == "OK" and r[1]["autorizacion"] == "REGISTRADA_EXTERNAMENTE":  # type: ignore[index]
            validez, etiqueta, _, _, _, etapa, aut = c
            assert validez in PA.VALIDA and PA.ETIQUETAS[etiqueta] == "RESPALDADA"
            assert (etapa, aut) == ("ETAPA_SINTETICA", "COINCIDENTE")


def test_evidencia_sellada() -> None:
    with pytest.raises(PA.ErrorPolitica, match="solo la construye"):
        PA._Evidencia("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", E.SHA_A, E.INICIO, "", "P1", None, object())
    with pytest.raises(PA.ErrorPolitica, match="solo la construye"):
        PA._Evidencia("VERIFICADO", "RESPALDADA FUERA DE MUESTRA", E.SHA_A, E.INICIO, "", "P1", None)

    class Imitacion:  # misma forma, otra clase
        validez, etiqueta, resultado_sha256, fecha_inicio_ventana = "VERIFICADO", "VENTAJA RESPALDADA", E.SHA_A, E.INICIO
        motivo, origen, informe_p1_sha256, sello = "", "P1", None, None

    for falsa in ({"validez": "VERIFICADO", "etiqueta": "VENTAJA RESPALDADA"}, Imitacion()):
        with pytest.raises(PA.ErrorPolitica, match="construida por la política"):
            PA._decidir(falsa, "NO_DEFINIDO", "NO_DEFINIDO", None, None)  # type: ignore[arg-type]
    s = PA._decidir(PA._evidencia_sintetica("VERIFICADO", "VENTAJA RESPALDADA", E.SHA_A, E.INICIO), "NO_DEFINIDO",
                    "NO_DEFINIDO", None, None)
    assert s["evidencia"]["origen"].startswith("SINTETICA")


def test_interfaz_publica_minima_y_registros_vacios() -> None:
    propias = {n for n, x in vars(PA).items() if not n.startswith("_") and callable(x)
               and getattr(x, "__module__", None) == PA.__name__}
    assert propias == {"desde_resultado", "robustez", "ErrorPolitica"}
    params = inspect.signature(PA.desde_resultado).parameters
    assert not any(p.kind is p.VAR_KEYWORD for p in params.values())
    assert not {"definiciones", "etapas", "autorizaciones", "raices"} & set(params)
    assert PA.DEFINICIONES_APROBADAS == {} and PA.ETAPAS_DEFINIDAS == {} and PA.AUTORIZACIONES == {}


def _publicar(raiz: Path, obj: dict) -> Path:
    ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
    ruta.write_text(json.dumps(obj), encoding="utf-8")
    return ruta


def test_desde_resultado_con_cada_estado_de_p1(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = _publicar(raiz, F.oos(raiz=raiz))
    d = [F.declarar_archivo(ruta, raiz)]
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", declaraciones=d)
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"]) == ("VERIFICADO", "EVIDENCIA INSUFICIENTE")
    assert s["evidencia"]["origen"].startswith("P1 verificar_reproduccion_T v0.4") and s["evidencia"]["informe_p1_sha256"]
    assert s["evidencia"]["fecha_inicio_ventana"] == "2022-01-01"
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO")  # sin declaración firmada
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"], s["etiqueta_declarada"]) == (
        "INCONCLUSO", None, "EVIDENCIA INSUFICIENTE")
    assert s["evidencia"]["motivo"].startswith("SIN_REFERENCIA_INDEPENDIENTE")
    assert PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", declaraciones=d,
                              reproduccion=F.oos(raiz=raiz))["evidencia"]["validez"] == "REPRODUCIDO"
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", declaraciones=d, reproduccion=F.oos(p_conj=0.7, raiz=raiz))
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"]) == ("NO_REPRODUCIDO", None)
    (raiz / "src" / "tendencia" / "a.py").write_text("X = 9\n", encoding="utf-8")
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", declaraciones=d)
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"]) == ("CORRUPTO", None)
    assert s["evidencia"]["motivo"].startswith("HASH")
    ruta.write_text(json.dumps(F.corte_provisional()), encoding="utf-8")
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO")
    assert s["evidencia"]["validez"] == "INCONCLUSO" and "SIN_EVALUACION" in s["evidencia"]["motivo"]
    ruta.write_text("{roto", encoding="utf-8")
    assert PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO")["evidencia"]["validez"] == "CORRUPTO"


def test_respaldada_y_firmada_es_candidata_pero_nunca_autorizada(tmp_path: Path, raices) -> None:  # type: ignore[no-untyped-def]
    raiz = F.arbol_t(tmp_path / "T")
    ruta = _publicar(raiz, F.oos(p_conj=0.97, p_btc=0.95, x2=0.05, decision="RESPALDADA FUERA DE MUESTRA", raiz=raiz))
    s = PA.desde_resultado(ruta, raiz, "NO_DEFINIDO", "NO_DEFINIDO", declaraciones=[F.declarar_archivo(ruta, raiz)])
    assert (s["decision_avance"]["resultado"], s["autorizacion_ejecucion"]["estado"]) == (
        "CANDIDATA_A_REVISION_HUMANA", "NO_OTORGADA")


def _huella(p: Path) -> tuple[str, int]:
    return hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns


@con_t
def test_resultado_historico_real() -> None:
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    antes = _huella(ruta)
    s = PA.desde_resultado(ruta, T, "NO_DEFINIDO", "NO_DEFINIDO")
    assert (s["evidencia"]["validez"], s["etiqueta_estadistica"], s["etiqueta_declarada"], s["robustez"]["resumen"],
            s["decision_avance"]["resultado"], s["decision_avance"]["etapa"], s["autorizacion_ejecucion"]["estado"]) == (
        "INCONCLUSO", None, "EVIDENCIA INSUFICIENTE", "NO_APLICA", "NO_CANDIDATA", "NO_DEFINIDA", "NO_OTORGADA")
    assert s["resultado_verificado"]["resultado_sha256"].startswith("4f8fafde")
    assert [m["codigo"] for m in s["resultado_verificado"]["motivos"]] == ["SIN_REFERENCIA_INDEPENDIENTE"]
    assert _huella(ruta) == antes


def test_sin_umbrales_ni_importaciones_de_t() -> None:
    arbol = ast.parse((version.DIR_P2 / "politica_avance_T.py").read_bytes())
    numeros = sorted({n.value for n in ast.walk(arbol) if isinstance(n, ast.Constant) and type(n.value) in (int, float)})
    assert numeros == [0, 12, 64]  # «≤ 0» (nota informativa), 12 caracteres de un hash en un mensaje, longitud de SHA-256
    modulos = {a.name for n in ast.walk(arbol) if isinstance(n, ast.Import) for a in n.names} | {
        n.module for n in ast.walk(arbol) if isinstance(n, ast.ImportFrom)}
    assert modulos == {"__future__", "datetime", "hashlib", "json", "sys", "dataclasses", "pathlib",
                       "verificar_reproduccion_T"}


@con_t
def test_etiquetas_iguales_a_los_return_del_codigo_congelado() -> None:
    textos = set()
    for ruta, nombre in ((T / "experimentos" / "fuera_de_muestra_T.py", "decision"),
                         (T / "src" / "tendencia" / "papel.py", "decidir")):
        f = next(n for n in ast.parse(ruta.read_bytes()).body if isinstance(n, ast.FunctionDef) and n.name == nombre)
        textos |= {n.value.value for n in ast.walk(f) if isinstance(n, ast.Return)}
    assert textos == set(PA.ETIQUETAS) == set(O.CLASE)
