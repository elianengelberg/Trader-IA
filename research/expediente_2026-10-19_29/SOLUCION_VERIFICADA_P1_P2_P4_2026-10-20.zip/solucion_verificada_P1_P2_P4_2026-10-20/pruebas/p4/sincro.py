"""Utilidades de prueba para P4: entradas sintéticas, procesos hijo (conductor) con caída, pausa determinista (FIFO),
ancla firmada de prueba o fallos de escritura inyectados, y recuento de cálculos. El módulo es el de la VERSIÓN BAJO
PRUEBA salvo que se indique otro."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import fabricas_t as F
import version

AQUI = Path(__file__).resolve().parent
CONDUCTOR = AQUI / "_conductor.py"
CODIGOS = AQUI / "codigos_sinteticos"
DATOS = [0.01, -0.02, 0.03, 0.005, -0.01, 0.02, 0.015, -0.005] * 5


def preparar(tmp: Path, codigo: str = "det", nombre: str = "e", dir_estado: str | None = None) -> dict:
    ent = tmp / f"entradas_{nombre}"
    ent.mkdir(parents=True)
    (ent / "protocolo.md").write_text("protocolo sintético v1\n", encoding="utf-8")
    (ent / "codigo.py").write_bytes((CODIGOS / f"{codigo}.py").read_bytes())
    (ent / "datos.txt").write_text(" ".join(map(str, DATOS)), encoding="utf-8")
    contador = tmp / f"llamadas_{nombre}.txt"
    (ent / "contador.txt").write_text(str(contador), encoding="utf-8")
    return {"dir": dir_estado or str(tmp / f"estado_{nombre}"), "experimento": "SINTETICO-1", "semilla": 7,
            "contador": str(contador), "tmp": tmp, "ancla": str(tmp / "ancla" / "ANCLA.jsonl"),
            "ancla_firmada": {"ruta": str(tmp / "ancla_externa_prueba" / "ANCLA.jsonl"),
                              "semilla_hex": F.SEMILLA_ANCLA.hex(), "emisor": "PRUEBA-ANCLA"},
            "archivos": {k: str(ent / f) for k, f in (("protocolo", "protocolo.md"), ("codigo", "codigo.py"),
                                                      ("datos", "datos.txt"), ("contador", "contador.txt"))}}


def llamadas(e: dict) -> int:
    p = Path(e["contador"])
    return len(p.read_text(encoding="utf-8").splitlines()) if p.exists() else 0


class Hijo:
    """Proceso hijo que corre el conductor. ``ancla``: None, "archivo" o "firmada". Con ``pausa``,
    ``esperar_pausa()`` bloquea hasta que el hijo llegue al punto y ``seguir()`` lo libera. Sin tiempos."""

    def __init__(self, e: dict, ancla: str | None = None, modulo: Path | None = None, pausa: str | None = None,
                 **extra: object):
        firmada_extra = extra.pop("firmada_extra", {})
        args = {k: e[k] for k in ("dir", "experimento", "semilla", "archivos")} | {
            "modulo": str(modulo or version.MODULO_P4)} | extra
        if ancla == "archivo":
            args["ancla"] = e["ancla"]
        elif ancla == "firmada":
            args["ancla_firmada"] = e["ancla_firmada"] | firmada_extra  # type: ignore[operator]
        if pausa:
            base = Path(e["tmp"]) / f"fifo_{os.getpid()}_{id(self)}"
            args |= {"pausa": pausa, "listo": f"{base}_listo", "seguir": f"{base}_seguir"}
            os.mkfifo(args["listo"])
            os.mkfifo(args["seguir"])
        self.args = args
        self.p = subprocess.Popen([sys.executable, "-B", str(CONDUCTOR), json.dumps(args)], stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})

    def esperar_pausa(self) -> str:
        with open(self.args["listo"]) as fh:
            return fh.read()

    def seguir(self) -> None:
        with open(self.args["seguir"], "w") as fh:
            fh.write("x")

    def fin(self) -> dict:
        out, err = self.p.communicate(timeout=180)
        if self.p.returncode != 0:
            return {"estado": f"MURIO({self.p.returncode})", "stderr": err[-600:]}
        return json.loads(out)


def correr(e: dict, ancla: str | None = None, **extra: object) -> dict:
    return Hijo(e, ancla, **extra).fin()
