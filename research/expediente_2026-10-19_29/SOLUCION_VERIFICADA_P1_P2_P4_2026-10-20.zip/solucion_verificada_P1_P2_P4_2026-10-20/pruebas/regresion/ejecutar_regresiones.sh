#!/usr/bin/env bash
# Regresiones contra v0.4 con las suites de v0.3 SIN MODIFICAR (copiadas a directorios temporales junto al código de
# v0.4) y las sondas de v0.2 sobre v0.2. Escribe la salida ORIGINAL de pytest en $EVID. No modifica nada fuera de los
# temporales. Variables: PAQ (este paquete), V03 (carpeta del paquete v0.3 preservado), PY, EVID.
set -u
PAQ=${PAQ:?}; V03=${V03:?}; PY=${PY:?}; EVID=${EVID:?}
mkdir -p "$EVID"
TMPB=$(mktemp -d)
trap 'rm -rf "$TMPB"' EXIT
export PYTHONDONTWRITEBYTECODE=1

correr() {  # nombre, directorio
  (cd "$2" && "$PY" -B -m pytest -p no:cacheprovider -q -rfEs . > "$EVID/$1.txt" 2>&1; echo "código de salida de pytest: $?" >> "$EVID/$1.txt")
  tail -2 "$EVID/$1.txt" | head -1 | sed "s/^/$1: /"
}

# P1: suites v0.3 sin modificar contra v0.4 (se esperan fallos SOLO por la API renombrada; ver 20_*.md) y portadas
d="$TMPB/p1_sin_modificar"; mkdir -p "$d"
cp "$V03"/p1/test_verificar_reproduccion_T.py "$V03"/p1/test_v0_2.py "$V03"/p1/test_v0_3.py "$V03"/p1/fabricas.py "$d"/
cp "$PAQ"/codigo/verificacion/verificar_reproduccion_T.py "$PAQ"/codigo/verificacion/confianza.py "$d"/
correr 22_regresion_p1_v0_3_sin_modificar_contra_v0_4 "$d"
(cd "$PAQ/pruebas" && "$PY" -B -m pytest -p no:cacheprovider -q -rfEs regresion/p1_v0_3_portadas \
  > "$EVID/23_regresion_p1_v0_3_portadas_contra_v0_4.txt" 2>&1; echo "código de salida de pytest: $?" >> "$EVID/23_regresion_p1_v0_3_portadas_contra_v0_4.txt")
tail -2 "$EVID/23_regresion_p1_v0_3_portadas_contra_v0_4.txt" | head -1 | sed "s/^/23_regresion_p1_portadas: /"

# P2: suite v0.3 sin modificar contra v0.4 (se espera que falle: la API pública aplicar/evidencia se ELIMINÓ, N1/N3)
d="$TMPB/p2_sin_modificar"; mkdir -p "$d/p1" "$d/p2"
cp "$V03"/p2/test_politica_avance_T.py "$V03"/p2/generar_tabla.py "$V03"/p2/TABLA_DECISION_P2_v0.3.csv "$V03"/p2/TABLA_DECISION_P2_v0.3.md "$d/p2/"
cp "$V03"/p1/fabricas.py "$d/p1/"
cp "$PAQ"/codigo/verificacion/politica_avance_T.py "$d/p2/"
cp "$PAQ"/codigo/verificacion/verificar_reproduccion_T.py "$PAQ"/codigo/verificacion/confianza.py "$d/p1/"
cp "$PAQ"/codigo/verificacion/verificar_reproduccion_T.py "$PAQ"/codigo/verificacion/confianza.py "$d/p2/"
correr 24_regresion_p2_v0_3_sin_modificar_contra_v0_4 "$d/p2"

# P4: suites v0.3 sin modificar contra v0.4
d="$TMPB/p4_sin_modificar"; mkdir -p "$d"
cp -r "$V03"/p4/test_uso_unico.py "$V03"/p4/test_v0_3.py "$V03"/p4/_conductor.py "$V03"/p4/sincro.py "$V03"/p4/codigos_sinteticos "$d"/
cp "$PAQ"/codigo/verificacion/uso_unico.py "$PAQ"/codigo/verificacion/confianza.py "$d"/
correr 25_regresion_p4_v0_3_sin_modificar_contra_v0_4 "$d"

# Cruzada v0.3 sin modificar contra v0.4 (se espera que falle por la API; sus X1–X9 están en test_cruzada_v04.py)
d="$TMPB/cruzada_sin_modificar"; mkdir -p "$d/p1" "$d/p2" "$d/p4" "$d/cruzada"
cp "$V03"/cruzada/*.py "$d/cruzada/"; cp "$V03"/p1/fabricas.py "$d/p1/"
for s in p1 p2 p4; do cp "$PAQ"/codigo/verificacion/*.py "$d/$s/"; done
correr 26_regresion_cruzada_v0_3_sin_modificar_contra_v0_4 "$d/cruzada"

# Sondas de v0.2 (paquete v0.3 preservado): PASAN si el defecto EXISTE en v0.2. Cada archivo por separado (los tres
# se llaman igual y pytest no admite dos módulos de prueba con el mismo nombre en una misma ejecución sin paquetes).
: > "$EVID/40_sondas_v0_2_sobre_v0_2.txt"
for c in p1 p2 p4; do
  (cd "$V03" && echo "===== $c/test_sondas_v0_2.py" && "$PY" -B -m pytest -p no:cacheprovider -q -rA "$c/test_sondas_v0_2.py"; \
   echo "código de salida de pytest: $?") >> "$EVID/40_sondas_v0_2_sobre_v0_2.txt" 2>&1
done
grep -E "^(=====|[0-9]+ (passed|failed))" "$EVID/40_sondas_v0_2_sobre_v0_2.txt" | sed "s/^/40_sondas_v0_2: /"
(cd "$V03" && sha256sum -c --quiet SHA256SUMS.txt && echo "paquete v0.3 intacto tras las sondas") > "$EVID/41_paquete_v0_3_intacto.txt" 2>&1
cat "$EVID/41_paquete_v0_3_intacto.txt"
