"""Pruebas de P1 v0.3: corrección de S1–S8 y la lista adversarial del encargo de cierre. Datos sintéticos; lecturas de
solo lectura del árbol real de T (código, prerregistros, manifiestos y registros del repositorio, sin bytes de datos de
mercado); productor real de cortes solo con fuente simulada. Las pruebas test_LIMITE_* pasan cuando el límite EXISTE."""
from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import fabricas as F  # noqa: E402
import verificar_reproduccion_T as V  # noqa: E402

T = F.T_REAL
con_t = pytest.mark.skipif(not (T / "experimentos" / "fuera_de_muestra_T.py").is_file(), reason="T no disponible")
con_corte = pytest.mark.skipif(not (T / "papel" / "corte.py").is_file(), reason="corte.py no disponible")


def cod(f, *a, **k) -> str:  # type: ignore[no-untyped-def]
    with pytest.raises(V.ErrorVerificacion) as e:
        f(*a, **k)
    return e.value.codigo


def publicar(raiz: Path, obj: dict | None = None) -> Path:
    """Escribe el resultado donde lo pondría el productor, dentro del árbol."""
    ruta = raiz / "experimentos" / "fuera_de_muestra_T.json"
    ruta.write_text(json.dumps(obj if obj is not None else F.oos(raiz=raiz), ensure_ascii=False), encoding="utf-8")
    return ruta


# ---------- S1, S2 y claves duplicadas o inesperadas ----------
@pytest.mark.parametrize("cambio", [
    lambda o: o.update(decision="RESPALDADA FUERA DE MUESTRA"),
    lambda o: o["principal"].update(SOL={"exceso_anual": 0.1, "ic90_anual": [0, 0.2], "p": 0.9}),
    lambda o: o["principal"]["BTC"].update(p_alternativa=0.99),
    lambda o: o["manifiestos_sha256"].update(SOLUSDT="f" * 64),
    lambda o: o["secundarios"].update(otra_cosa=1),
    lambda o: o["secundarios"]["costes_x2"].update(SOL=0.1),
])
def test_S1_claves_inesperadas(cambio) -> None:  # type: ignore[no-untyped-def]
    o = F.oos()
    cambio(o)
    assert cod(V.verificar, o) == "CLAVE_INESPERADA"


@pytest.mark.parametrize("ruta", ["principal.ETH", "manifiestos_sha256.ETHUSDT", "secundarios.costes_x2.ETH",
                                  "categoria", "principal.ETH.p"])
def test_S2_simbolos_o_campos_faltantes(ruta: str) -> None:
    assert cod(V.verificar, F.quitar(F.oos(), ruta)) == "CLAVE_AUSENTE"


@pytest.mark.parametrize("ruta,valor", [("principal.ETH.p", 1.5), ("principal.ETH.ic90_anual", [0.3, 0.1]),
                                        ("secundarios.costes_x2.BTC", "0.06")])
def test_S2_simbolo_eth_validado(ruta: str, valor) -> None:  # type: ignore[no-untyped-def]
    assert cod(V.verificar, F.poner(F.oos(), ruta, valor)) in ("RANGO", "TIPO")


def test_claves_inesperadas_en_papel_y_corte() -> None:
    assert cod(V.verificar, F.evaluar() | {"decision_alternativa": "VENTAJA RESPALDADA"}) == "CLAVE_INESPERADA"
    assert cod(V.verificar, F.poner(F.evaluar(), "bootstrap_conjunto.p_ajustada", 0.99)) == "CLAVE_INESPERADA"
    assert cod(V.verificar, F.corte() | {"aprobado": True}) == "CLAVE_INESPERADA"
    assert cod(V.verificar, F.poner(F.corte(), "datos_sha256.SOLUSDT", "f" * 64)) == "CLAVE_INESPERADA"


def test_claves_duplicadas_anidadas(tmp_path: Path) -> None:
    texto = json.dumps(F.oos()).replace('"p": 0.8355', '"p": 0.99, "p": 0.8355')
    p = tmp_path / "d.json"
    p.write_text(texto, encoding="utf-8")
    assert cod(V.verificar_archivo, p) == "CLAVE_DUPLICADA"


# ---------- S3: manifiestos del repositorio ----------
def test_S3_modificacion_sin_actualizar_el_manifiesto(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    registro = F.cadena(raiz)
    assert V.verificar_archivo(ruta, raiz=raiz, manifiesto=registro)["integridad_local"] == "COMPLETA"
    script = raiz / "experimentos" / "fuera_de_muestra_T.py"
    script.write_text(script.read_text() + "# cambio\n", encoding="utf-8")
    o = json.loads(ruta.read_text())
    o["script_sha256"] = F.sha(script.read_bytes())  # falsificación coherente del resultado
    ruta.write_text(json.dumps(o), encoding="utf-8")
    assert V.verificar_archivo(ruta, raiz=raiz)["integridad_local"] == "COMPLETA"  # sin manifiesto pasa (S3)
    assert cod(V.verificar_archivo, ruta, raiz=raiz, manifiesto=registro) == "HASH_MANIFIESTO"


def test_S3_resultado_sustituido_por_otro_coherente(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    registro, presellado = F.cadena(raiz), F.sha(ruta.read_bytes())
    publicar(raiz, F.oos(p_conj=0.999, raiz=raiz))  # sigue siendo EVIDENCIA INSUFICIENTE: coherente
    assert cod(V.verificar_archivo, ruta, raiz=raiz, manifiesto=registro) == "HASH_MANIFIESTO"
    assert cod(V.verificar_archivo, ruta, raiz=raiz, resultado_sha256_esperado=presellado) == "HASH"


def test_S3_el_manifiesto_debe_describir_el_resultado(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    sin_resultado = {k: v for k, v in F.cadena(raiz).items() if not k.endswith(".json")}
    assert cod(V.verificar_archivo, ruta, raiz=raiz, manifiesto=sin_resultado) == "MANIFIESTO_NO_CUBRE"
    fuera = tmp_path / "fuera.json"
    fuera.write_text(ruta.read_text(), encoding="utf-8")
    assert cod(V.verificar_archivo, fuera, raiz=raiz, manifiesto=F.cadena(raiz)) == "MANIFIESTO_NO_CUBRE"


def test_LIMITE_archivo_y_manifiesto_no_autenticado_modificados_juntos(tmp_path: Path) -> None:
    """Sin raíz de confianza independiente, quien cambia el archivo Y el manifiesto no es detectado: el informe lo dice."""
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    script = raiz / "experimentos" / "fuera_de_muestra_T.py"
    script.write_text(script.read_text() + "# cambio\n", encoding="utf-8")
    publicar(raiz, F.oos(raiz=raiz))
    inf = V.verificar_archivo(ruta, raiz=raiz, manifiesto=F.cadena(raiz))  # manifiesto regenerado por el atacante
    assert inf["integridad_local"] == "COMPLETA"  # el LÍMITE local sigue: el nivel local no lo detecta
    assert V.evaluar_archivo(ruta, raiz=raiz, manifiesto=F.cadena(raiz))["estado"] == "INCONCLUSO"  # v0.4


def test_manifiesto_sha256sum_y_conflicto_entre_manifiestos(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    texto = "".join(f"{v['sha256']}  {k}\n" for k, v in F.cadena(raiz).items())
    (tmp_path / "SUMS.txt").write_text(texto, encoding="utf-8")
    assert V.cargar_manifiesto(tmp_path / "SUMS.txt") == {k: v["sha256"] for k, v in F.cadena(raiz).items()}
    (tmp_path / "otro.txt").write_text(texto.replace(texto[:64], "0" * 64, 1), encoding="utf-8")
    r = subprocess.run([sys.executable, "-I", "-B", str(Path(V.__file__)), str(ruta), "--raiz",
                        str(raiz), "--manifiesto", str(tmp_path / "SUMS.txt"), "--manifiesto", str(tmp_path / "otro.txt")],
                       capture_output=True, text=True, check=False)
    assert r.returncode == 1 and json.loads(r.stdout)["motivos"][0]["codigo"] == "CONTRADICCION"
    (tmp_path / "roto.txt").write_text("no es un manifiesto\n", encoding="utf-8")
    assert cod(V.cargar_manifiesto, tmp_path / "roto.txt") == "MANIFIESTO_NO_VALIDO"
    (tmp_path / "trunc.json").write_text('{"a": {"sha256": "', encoding="utf-8")
    assert cod(V.cargar_manifiesto, tmp_path / "trunc.json") == "MANIFIESTO_NO_VALIDO"


# ---------- S4 y S8: correspondencias con código y configuración ----------
def test_S4_codigo_del_resultado_igual_al_fijado_en_el_script(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    script = raiz / "experimentos" / "fuera_de_muestra_T.py"
    script.write_text(script.read_text().replace('CODIGO = "', 'CODIGO = "0', 1).replace('"\nDESDE', '"\nDESDE'),
                      encoding="utf-8")
    texto = script.read_text()
    script.write_text(texto.replace(texto[texto.index('CODIGO = "') + 10:texto.index('"\nDESDE')],
                                    "1" * 64), encoding="utf-8")
    assert cod(V.verificar, F.oos(raiz=raiz), raiz=raiz) == "CONTRADICCION"


def test_S8_inicio_contra_el_prerregistro(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    (raiz / "papel" / "prerregistro_papel.json").write_text(json.dumps({
        "estrategias": {"T_BTC": {"ventanas": [30, 90, 180]}},
        "ramas": {"A": {"primera_ejecucion": "2026-10-18"}, "B": {"primera_ejecucion": "primer día (2027-04-13)"}}}))
    (raiz / "src" / "tendencia" / "datos.py").write_text('RESERVADO_FIN = "2026-10-14"\n', encoding="utf-8")
    ev = F.evaluar(raiz=raiz)
    ev["inicio"] = "2027-04-13"  # rama B correcta
    assert V.verificar(ev, raiz=raiz)["integridad_desde_archivos"]["inicio_prerregistrado"] == "rama B"
    ev["inicio"] = "2027-01-01"
    assert cod(V.verificar, ev, raiz=raiz) == "CONTRADICCION"
    ev = F.evaluar(raiz=raiz) | {"rama": "A", "inicio": "2026-10-19"}
    assert cod(V.verificar, ev, raiz=raiz) == "CONTRADICCION"


@con_t
def test_S8_rama_b_real_coincide_con_el_texto_del_prerregistro() -> None:
    assert V.inicio_prerregistrado(T, "B") == "2027-04-13" and V.inicio_prerregistrado(T, "A") == "2026-10-18"


# ---------- S7: tablas y datos del corte (productor real, fuente simulada) ----------
@con_corte
@pytest.mark.parametrize("alteracion,codigo", [("fila_borrada", "CONTRADICCION"), ("valor_cambiado", "HASH"),
                                               ("manifiesto_de_datos", "HASH"), ("columna_cambiada", "ESQUEMA"),
                                               ("tabla_ausente", "ARCHIVO_AUSENTE"), ("dia_saltado", "CONTRADICCION")])
def test_S7_tablas_y_datos_del_corte(tmp_path: Path, alteracion: str, codigo: str) -> None:
    raiz = F.corte_real_simulado(tmp_path)
    d = raiz / "2027-10-19"
    inf = V.verificar_archivo(d / "resultado.json", raiz=T, registro=raiz / "REGISTRO.jsonl")
    assert inf["integridad_local"] == "COMPLETA" and inf["integridad_desde_archivos"]["decisiones_BTCUSDT"].endswith("366 filas")
    p = d / "decisiones_BTCUSDT.csv"
    if alteracion == "manifiesto_de_datos":
        m = d / "datos" / "ETHUSDT" / "MANIFIESTO.json"
        x = json.loads(m.read_text())
        x["archivos"] = x["archivos"][1:]
        m.write_text(json.dumps(x), encoding="utf-8")
    elif alteracion == "tabla_ausente":
        p.unlink()
    else:
        filas = list(csv.reader(p.open(encoding="utf-8")))
        if alteracion == "fila_borrada":
            del filas[-1]
        elif alteracion == "valor_cambiado":
            filas[11][8] = str(float(filas[11][8]) * 1.5)
        elif alteracion == "columna_cambiada":
            filas[0][8] = "equity"
        else:
            filas[5][0] = filas[6][0]
        with p.open("w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows(filas)
    assert cod(V.verificar_archivo, d / "resultado.json", raiz=T, registro=raiz / "REGISTRO.jsonl") == codigo


@con_corte
def test_S7_corte_sin_su_directorio_no_es_verificado(tmp_path: Path) -> None:
    raiz = F.corte_real_simulado(tmp_path)
    obj, sha = V.cargar(raiz / "2027-10-19" / "resultado.json")
    inf = V.verificar(obj, raiz=T, resultado_sha256=sha, registro=raiz / "REGISTRO.jsonl")
    assert inf["integridad_local"] == "PARCIAL"


# ---------- S5, S6 y REPRODUCIDO ----------
def recalculo_sintetico(datos: list[float], raiz: Path, sesgo: float = 0.0) -> dict:
    """Función SINTÉTICA de recálculo (no es la de T): arma el resultado desde datos inventados."""
    media = sum(datos) / len(datos) + sesgo
    o = F.oos(raiz=raiz)
    o["principal"]["conjunto"]["exceso_anual"] = media
    return o


def test_S6_reproducido_solo_tras_verificado_y_comparacion_completa(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    datos = [0.01, 0.03, -0.01, 0.05]
    ruta = publicar(raiz, recalculo_sintetico(datos, raiz))
    assert V.reproducir(ruta, recalculo_sintetico(datos, raiz), raiz=raiz)["comparacion"] == "SIN_DIFERENCIAS"
    r = V.reproducir(ruta, recalculo_sintetico(datos, raiz, sesgo=1e-6), raiz=raiz)  # discrepancia del recálculo
    assert r["comparacion"] == "CON_DIFERENCIAS" and r["discrepancias"][0].startswith("principal.conjunto.exceso_anual")
    assert V.reproducir(ruta, recalculo_sintetico(datos, raiz, 1e-6), tolerancia=1e-5, raiz=raiz)["comparacion"] == "SIN_DIFERENCIAS"
    assert cod(V.reproducir, ruta, recalculo_sintetico(datos, raiz)) == "INTEGRIDAD_INCOMPLETA"  # sin --raiz: no verificado
    otra = recalculo_sintetico(datos, raiz) | {"extra": 1}
    assert cod(V.reproducir, ruta, otra, raiz=raiz) == "REPRODUCCION_NO_VALIDA"  # la reproducción también se valida
    for tol in (-1.0, float("nan"), True, "0"):
        assert cod(V.reproducir, ruta, recalculo_sintetico(datos, raiz), tol, raiz=raiz) == "USO"


def test_S5_comparar_mira_todas_las_hojas() -> None:
    a = F.oos()
    b = F.poner(a, "principal.ETH.p", 0.01)
    assert any("principal.ETH.p" in d for d in V.comparar(a, b))
    assert V.comparar_completo(a, F.poner(a, "secundarios.costes_x2.BTC", 0.06 + 1e-12)) != []
    assert V.comparar_completo(a, F.poner(a, "secundarios.costes_x2.BTC", 0.06 + 1e-12), 1e-9) == []
    assert V.comparar_completo({"x": 1}, {"x": True}) and V.comparar_completo({"x": "1"}, {"x": 1})


def test_cli_reproduccion(tmp_path: Path) -> None:
    raiz = F.arbol_t(tmp_path / "T")
    ruta = publicar(raiz)
    otra = tmp_path / "otra.json"
    otra.write_text(json.dumps(F.oos(p_conj=0.76, raiz=raiz)), encoding="utf-8")
    base = [sys.executable, "-I", "-B", str(Path(V.__file__)), str(ruta), "--raiz", str(raiz)]
    r = subprocess.run(base + ["--reproduccion", str(otra)], capture_output=True, text=True, check=False)
    assert r.returncode == 3 and json.loads(r.stdout)["estado"] == "INCONCLUSO"  # sin raíz aprobada
    r = subprocess.run(base + ["--reproduccion", str(ruta)], capture_output=True, text=True, check=False)
    assert r.returncode == 3 and json.loads(r.stdout)["reproduccion"].startswith("NO EVALUADA")
    r = subprocess.run(base + ["--tolerancia", "0.1"], capture_output=True, text=True, check=False)
    assert r.returncode == 3 and json.loads(r.stdout)["motivos"][0]["codigo"] == "USO"


# ---------- artefacto real (solo lectura) ----------
@con_t
def test_artefacto_real_con_los_manifiestos_del_repositorio() -> None:
    ruta = T / "experimentos" / "fuera_de_muestra_T.json"
    manifiesto = V.cargar_manifiesto(T / "ARTEFACTOS_SHA256.txt")
    manifiesto.update(V.cargar_manifiesto(f"{T / 'EVIDENCIA_T_MULTI.json'}#cadena_historica_T_fuera_de_muestra"))
    inf = V.verificar_archivo(ruta, raiz=T, manifiesto=manifiesto)
    assert inf["integridad_local"] == "COMPLETA"
    assert V.evaluar_archivo(ruta, raiz=T, manifiesto=manifiesto)["estado"] == "INCONCLUSO"  # sin raíz
    c = inf["contraste_con_manifiestos"]
    assert {"experimentos/fuera_de_muestra_T.json", "experimentos/fuera_de_muestra_T.py",
            "PRERREGISTRO_FUERA_DE_MUESTRA_T.md", "datos/BTCUSDT/MANIFIESTO.json", "src/tendencia/papel.py"} <= set(
        c["coinciden"]) and c["no_listados"] == []
