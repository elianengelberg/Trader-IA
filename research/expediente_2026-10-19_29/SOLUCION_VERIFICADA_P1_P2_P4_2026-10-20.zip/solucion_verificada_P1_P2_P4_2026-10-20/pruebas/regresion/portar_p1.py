"""Porta las suites de P1 de v0.3 (sin modificarlas en su origen) a la API de v0.4.

Cada regla es un reemplazo EXACTO que debe aparecer el número de veces indicado, con su justificación. Solo hay dos
clases de cambio: (R) renombre de un campo o código sin cambio de fondo; (S) cambio DELIBERADO de semántica en v0.4,
con la referencia al defecto que lo motiva. Ninguna regla relaja una comprobación: donde v0.3 exigía un rechazo, v0.4
exige un rechazo de la clase correspondiente. Genera la tabla de cambios y el diff completo como evidencia.

Uso: python3 portar_p1.py <dir_suites_v0_3> <dir_salida> <archivo_tabla.md> <archivo_diff.txt>"""
from __future__ import annotations

import difflib
import sys
from pathlib import Path

N_VER = 'assert inf["nivel"] == "VERIFICADO"'
N_COMPL = 'assert inf["integridad_local"] == "COMPLETA"'
R_NIVEL = ("R", "el nivel local de v0.3 «VERIFICADO» se llama integridad_local = COMPLETA en v0.4; VERIFICADO exige "
                "además una raíz de confianza (N1)")
R_COH = ("R", "COHERENTE_SIN_INTEGRIDAD (v0.3) = integridad_local PARCIAL (v0.4)")
R_CLAVE = ("R", "AUSENTE de una CLAVE se llama CLAVE_AUSENTE (N2: se separa de un ARCHIVO ausente)")
R_ARCH = ("S", "un ARCHIVO ausente es ARCHIVO_AUSENTE → INCONCLUSO, no un rechazo (N2)")
R_USO = ("R", "HASH_SEMANTICA (uso incorrecto) se llama USO → INCONCLUSO (N2)")
R_CLI = ("R", "el JSON de la línea de órdenes informa «estado» y «motivos»; el código está en motivos[0]")

REGLAS: dict[str, list[tuple[str, str, int, tuple[str, str]]]] = {
    "test_verificar_reproduccion_T.py": [
        ('str(AQUI / "verificar_reproduccion_T.py")', "str(Path(V.__file__))", 1,
         ("R", "el módulo bajo prueba está en codigo/verificacion, no junto a la suite")),
        (N_VER, N_COMPL, 3, R_NIVEL),
        ('assert codigo(V.verificar, quitar(FABRICAS[esquema](), ruta)) == "AUSENTE"',
         'assert codigo(V.verificar, quitar(FABRICAS[esquema](), ruta)) == "CLAVE_AUSENTE"', 1, R_CLAVE),
        ('assert codigo(V.verificar, o, raiz=raiz) == "AUSENTE"', 'assert codigo(V.verificar, o, raiz=raiz) == "ARCHIVO_AUSENTE"',
         1, R_ARCH),
        ('assert codigo(V.verificar, raiz) == "TIPO"', 'assert codigo(V.verificar, raiz) == "TIPO_NO_ADMITIDO"', 1,
         ("S", "algo que no es un objeto JSON no es un resultado de T: TIPO_NO_ADMITIDO → INCONCLUSO (N2)")),
        ('"HASH_SEMANTICA"', '"USO"', 3, R_USO),
        ('({}, "ESQUEMA")', '({}, "TIPO_NO_ADMITIDO")', 1,
         ("S", "un objeto sin ninguna clave de T no pretende ser un resultado de T: TIPO_NO_ADMITIDO (N2)")),
        ('assert codigo(V.verificar, poner(sin_p, "decision", silenciosa)) == "AUSENTE"',
         'assert codigo(V.verificar, poner(sin_p, "decision", silenciosa)) == "CLAVE_AUSENTE"', 1, R_CLAVE),
        ('    r = _cli(str(bueno), "--raiz", str(tmp_path / "no_existe"))\n'
         '    assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "AUSENTE"',
         '    r = _cli(str(bueno), "--raiz", str(tmp_path / "no_existe"))\n'
         '    assert r.returncode == 3 and json.loads(r.stdout)["motivos"][0]["codigo"] == "ARCHIVO_AUSENTE"', 1, R_ARCH),
        ('assert r.returncode == 3 and json.loads(r.stdout)["resultado"] == "COHERENTE_SIN_INTEGRIDAD"',
         'assert r.returncode == 3 and json.loads(r.stdout)["estado"] == "INCONCLUSO"', 1, R_CLI),
        ('assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "AUSENTE"',
         'assert r.returncode == 1 and json.loads(r.stdout)["motivos"][0]["codigo"] == "CLAVE_AUSENTE"', 1, R_CLI),
        ('assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "LECTURA"',
         'assert r.returncode == 1 and json.loads(r.stdout)["motivos"][0]["codigo"] == "JSON_INVALIDO"', 1,
         ("R", "LECTURA de un JSON inválido se llama JSON_INVALIDO (sigue siendo CORRUPTO, salida 1)")),
        ('assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "HASH"',
         'assert r.returncode == 1 and json.loads(r.stdout)["motivos"][0]["codigo"] == "HASH"', 1, R_CLI),
    ],
    "test_v0_2.py": [
        ('str(AQUI / "verificar_reproduccion_T.py")', "str(Path(V.__file__))", 1,
         ("R", "el módulo bajo prueba está en codigo/verificacion")),
        ('assert (c, s["resultado"]) == (3, "COHERENTE_SIN_INTEGRIDAD")', 'assert (c, s["estado"]) == (3, "INCONCLUSO")',
         1, R_CLI),
        ('V.verificar(o, raiz=raiz)["nivel"] == "VERIFICADO"', 'V.verificar(o, raiz=raiz)["integridad_local"] == "COMPLETA"',
         1, R_NIVEL),
        ('assert inf["nivel"] == "COHERENTE_SIN_INTEGRIDAD"', 'assert inf["integridad_local"] == "PARCIAL"', 2, R_COH),
        ('assert cli(str(p))[0] == 4 and cli(str(p))[1]["resultado"] == "NO_EVALUABLE"',
         'assert cli(str(p))[0] == 3 and cli(str(p))[1]["motivos"][0]["codigo"] == "SIN_EVALUACION"', 1,
         ("S", "NO_EVALUABLE pasa a ser INCONCLUSO con motivo SIN_EVALUACION (salida 3); sigue distinto de CORRUPTO "
               "(salida 1), que es lo que D5 exige")),
        ('V.verificar_archivo(res, raiz=T, registro=reg)["nivel"] == "VERIFICADO"',
         'V.verificar_archivo(res, raiz=T, registro=reg)["integridad_local"] == "COMPLETA"', 1, R_NIVEL),
        ('assert (c, s["codigo"]) == (1, "CLAVE_DUPLICADA")', 'assert (c, s["motivos"][0]["codigo"]) == (1, "CLAVE_DUPLICADA")',
         1, R_CLI),
        ('assert cod(V.verificar, o, raiz=raiz, datos=True) == "AUSENTE"',
         'assert cod(V.verificar, o, raiz=raiz, datos=True) == "ARCHIVO_AUSENTE"', 1, R_ARCH),
        (N_VER, N_COMPL, 1, R_NIVEL),
        ('V.verificar_archivo(p, raiz=raiz)["nivel"] == "VERIFICADO"',
         'V.verificar_archivo(p, raiz=raiz)["integridad_local"] == "COMPLETA"', 1, R_NIVEL),
        ('assert (c, s["codigo"]) == (1, "HASH")', 'assert (c, s["motivos"][0]["codigo"]) == (1, "HASH")', 1, R_CLI),
    ],
    "test_v0_3.py": [
        ('str(AQUI / "verificar_reproduccion_T.py")', "str(Path(V.__file__))", 2,
         ("R", "el módulo bajo prueba está en codigo/verificacion")),
        ('assert cod(V.verificar, F.quitar(F.oos(), ruta)) == "AUSENTE"',
         'assert cod(V.verificar, F.quitar(F.oos(), ruta)) == "CLAVE_AUSENTE"', 1, R_CLAVE),
        ('manifiesto=registro)["nivel"] == "VERIFICADO"', 'manifiesto=registro)["integridad_local"] == "COMPLETA"', 1,
         R_NIVEL),
        ('assert V.verificar_archivo(ruta, raiz=raiz)["nivel"] == "VERIFICADO"',
         'assert V.verificar_archivo(ruta, raiz=raiz)["integridad_local"] == "COMPLETA"', 1, R_NIVEL),
        ('manifiesto=sin_resultado) == "AUSENTE"', 'manifiesto=sin_resultado) == "MANIFIESTO_NO_CUBRE"', 1,
         ("S", "un manifiesto que no describe el resultado no lo contradice: MANIFIESTO_NO_CUBRE → INCONCLUSO (N2)")),
        ('manifiesto=F.cadena(raiz)) == "CONTRADICCION"', 'manifiesto=F.cadena(raiz)) == "MANIFIESTO_NO_CUBRE"', 1,
         ("S", "un resultado fuera de --raiz no es una contradicción: el manifiesto no lo cubre (N2)")),
        ('    assert inf["nivel"] == "VERIFICADO" and inf["autenticidad"].startswith("NO_VERIFICADA")\n\n\ndef test_manifiesto',
         '    assert inf["integridad_local"] == "COMPLETA"  # el LÍMITE local sigue: el nivel local no lo detecta\n'
         '    assert V.evaluar_archivo(ruta, raiz=raiz, manifiesto=F.cadena(raiz))["estado"] == "INCONCLUSO"  # v0.4\n\n\n'
         'def test_manifiesto', 1,
         ("S", "el límite del nivel LOCAL se conserva y se prueba; además, en v0.4 el estado ya no es VERIFICADO sin "
               "raíz de confianza (N1)")),
        ('assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "CONTRADICCION"',
         'assert r.returncode == 1 and json.loads(r.stdout)["motivos"][0]["codigo"] == "CONTRADICCION"', 1, R_CLI),
        ('assert cod(V.cargar_manifiesto, tmp_path / "roto.txt") == "TIPO"',
         'assert cod(V.cargar_manifiesto, tmp_path / "roto.txt") == "MANIFIESTO_NO_VALIDO"', 1,
         ("S", "un manifiesto mal formado es una referencia inutilizable: MANIFIESTO_NO_VALIDO → INCONCLUSO (N2)")),
        ('assert cod(V.cargar_manifiesto, tmp_path / "trunc.json") == "LECTURA"',
         'assert cod(V.cargar_manifiesto, tmp_path / "trunc.json") == "MANIFIESTO_NO_VALIDO"', 1,
         ("S", "ídem: referencia ilegible → INCONCLUSO (N2)")),
        ('("tabla_ausente", "AUSENTE")', '("tabla_ausente", "ARCHIVO_AUSENTE")', 1, R_ARCH),
        ('    assert inf["nivel"] == "VERIFICADO" and inf["integridad_desde_archivos"]["decisiones_BTCUSDT"]',
         '    assert inf["integridad_local"] == "COMPLETA" and inf["integridad_desde_archivos"]["decisiones_BTCUSDT"]', 1,
         R_NIVEL),
        ('assert inf["nivel"] == "COHERENTE_SIN_INTEGRIDAD"', 'assert inf["integridad_local"] == "PARCIAL"', 1, R_COH),
        ('raiz=raiz)["nivel"] == "REPRODUCIDO"', 'raiz=raiz)["comparacion"] == "SIN_DIFERENCIAS"', 2,
         ("R", "reproducir (nivel local) informa «comparacion»; REPRODUCIDO lo declara evaluar_reproduccion con raíz (N1)")),
        ('assert r["nivel"] == "NO_REPRODUCIDO"', 'assert r["comparacion"] == "CON_DIFERENCIAS"', 1,
         ("R", "ídem para NO_REPRODUCIDO")),
        ('== "INTEGRIDAD"  #', '== "INTEGRIDAD_INCOMPLETA"  #', 1, ("R", "INTEGRIDAD se llama INTEGRIDAD_INCOMPLETA")),
        ('assert cod(V.reproducir, ruta, otra, raiz=raiz) == "CLAVE_INESPERADA"',
         'assert cod(V.reproducir, ruta, otra, raiz=raiz) == "REPRODUCCION_NO_VALIDA"', 1,
         ("S", "un defecto de la REPRODUCCIÓN no hace CORRUPTO al original: REPRODUCCION_NO_VALIDA (N2)")),
        ('tol, raiz=raiz) == "VALOR"', 'tol, raiz=raiz) == "USO"', 1, ("R", "tolerancia inválida: USO")),
        ('    assert r.returncode == 5 and json.loads(r.stdout)["resultado"] == "NO_REPRODUCIDO"',
         '    assert r.returncode == 3 and json.loads(r.stdout)["estado"] == "INCONCLUSO"  # sin raíz aprobada', 1,
         ("S", "por la línea de órdenes no hay raíces aprobadas (registro vacío): el original es INCONCLUSO y la "
               "reproducción no se evalúa; REPRODUCIDO/NO_REPRODUCIDO se prueban con raíces sintéticas en test_p1_v04")),
        ('    assert r.returncode == 0 and json.loads(r.stdout)["resultado"] == "REPRODUCIDO"',
         '    assert r.returncode == 3 and json.loads(r.stdout)["reproduccion"].startswith("NO EVALUADA")', 1,
         ("S", "ídem")),
        ('    assert r.returncode == 1 and json.loads(r.stdout)["codigo"] == "VALOR"',
         '    assert r.returncode == 3 and json.loads(r.stdout)["motivos"][0]["codigo"] == "USO"', 1,
         ("S", "uso incorrecto de --tolerancia: USO → INCONCLUSO, no un rechazo del resultado (N2)")),
        ('    assert inf["nivel"] == "VERIFICADO" and inf["autenticidad"].startswith("NO_VERIFICADA")\n    c = ',
         '    assert inf["integridad_local"] == "COMPLETA"\n'
         '    assert V.evaluar_archivo(ruta, raiz=T, manifiesto=manifiesto)["estado"] == "INCONCLUSO"  # sin raíz\n    c = ',
         1, ("S", "el artefacto real tiene integridad local completa; sin raíz aprobada es INCONCLUSO (N1)")),
    ],
}


def portar(origen: Path, destino: Path, tabla: Path, diff: Path) -> None:
    destino.mkdir(parents=True, exist_ok=True)
    filas = ["| Archivo | Clase | Reemplazos | Antes → después | Justificación |", "|---|---|---|---|---|"]
    difs: list[str] = []
    for nombre, reglas in REGLAS.items():
        texto = (origen / nombre).read_text(encoding="utf-8")
        nuevo = texto
        for viejo, reemplazo, n, (clase, motivo) in reglas:
            hallados = nuevo.count(viejo)
            if hallados != n:
                raise SystemExit(f"{nombre}: la regla {viejo[:60]!r} aparece {hallados} veces, se esperaban {n}")
            nuevo = nuevo.replace(viejo, reemplazo)
            corto = lambda s: s.strip().replace("\n", " ⏎ ").replace("|", "\\|")[:110]  # noqa: E731
            filas.append(f"| {nombre} | {clase} | {n} | `{corto(viejo)}` → `{corto(reemplazo)}` | {motivo} |")
        (destino / nombre).write_text(nuevo, encoding="utf-8")
        difs += difflib.unified_diff(texto.splitlines(keepends=True), nuevo.splitlines(keepends=True),
                                     f"v0.3/{nombre}", f"portada_v0.4/{nombre}")
    (destino / "fabricas.py").write_text((origen / "fabricas.py").read_text(encoding="utf-8"), encoding="utf-8")
    tabla.write_text("# Cambios de expectativa al portar las suites de P1 v0.3 a v0.4\n\n"
                     "R = renombre sin cambio de fondo · S = cambio deliberado de semántica (defecto citado)\n\n"
                     + "\n".join(filas) + "\n", encoding="utf-8")
    diff.write_text("".join(difs), encoding="utf-8")


if __name__ == "__main__":
    if len(sys.argv) != 5:
        print(__doc__)
        sys.exit(2)
    portar(*(Path(a) for a in sys.argv[1:]))
