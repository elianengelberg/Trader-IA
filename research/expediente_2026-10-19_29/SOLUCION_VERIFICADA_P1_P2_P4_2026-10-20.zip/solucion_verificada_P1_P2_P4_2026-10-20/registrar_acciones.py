"""Escribe REGISTRO_ACCIONES.jsonl: registro ENCADENADO (cada línea lleva el SHA-256 de la anterior) de las acciones de
esta ronda y de las que NO se ejecutaron por falta de autorización. Las fechas son las de los archivos de evidencia
correspondientes (mtime UTC). Uso: python3 registrar_acciones.py <paquete>"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

ACCIONES = [
    ("evidencia/00_estado_git_inicial.txt", "estado de git inicial registrado (solo lectura)", "dentro del encargo"),
    ("evidencia/00_preservacion.txt", "entregas anteriores preservadas en 00_preservado (copias; originales intactos)",
     "dentro del encargo"),
    ("evidencia/03_productor_contraste_btc_transcripcion.txt",
     "productor de contraste_btc_diario_vs_horario localizado en la transcripción local (solo lectura)", "dentro del encargo"),
    ("evidencia/04_cronologia_fuera_de_muestra_transcripcion.txt",
     "cronología de los artefactos fuera de muestra de T (transcripción local, solo lectura)", "dentro del encargo"),
    ("trazabilidad_T/TRAZABILIDAD_FUERA_DE_MUESTRA_T.json",
     "trazabilidad de T generada en el paquete (git y archivos en solo lectura; nada escrito en el repositorio)",
     "dentro del encargo"),
    ("codigo/verificacion/confianza.py", "confianza v0.4 (Ed25519 y declaraciones firmadas) escrita en la copia aislada",
     "dentro del encargo"),
    ("codigo/verificacion/verificar_reproduccion_T.py", "P1 v0.4 escrito en la copia aislada", "dentro del encargo"),
    ("codigo/verificacion/politica_avance_T.py", "P2 v0.4 escrito en la copia aislada", "dentro del encargo"),
    ("codigo/verificacion/uso_unico.py", "P4 v0.4 escrito en la copia aislada (no integrado)", "dentro del encargo"),
    ("evidencia/11_suite_v0_4.txt", "suite completa de v0.4 ejecutada (datos sintéticos)", "dentro del encargo"),
    ("evidencia/10_matriz_antes_despues/MATRIZ_ANTES_DESPUES.md",
     "pruebas de defectos ejecutadas contra v0.2, v0.3 y v0.4", "dentro del encargo"),
    ("evidencia/60_parches_comprobacion.txt",
     "parches comprobados sobre exportaciones temporales de HEAD y origin (git archive; repositorio intacto)",
     "dentro del encargo"),
    ("evidencia/99_estado_git_comparado.txt", "estado de git final comparado con el inicial", "dentro del encargo"),
]
NO_EJECUTADAS = [
    ("aplicar los parches, commit, push, versionar corte.py", "B-1: requiere autorización"),
    ("elegir o implementar el ancla externa, crear o aprobar claves, publicar hashes o commits", "B-2: requiere autorización"),
    ("integrar P4 en papel/corte.py u otro ejecutor", "B-3: requiere autorización"),
    ("leer bytes de datos reales o reproducir calidad_datos.json", "B-4: requiere autorización"),
    ("calibración estadística pendiente", "B-5: requiere autorización"),
    ("backtests, descargas, repetir T, dinero real, despliegues", "B-6: prohibido"),
]


def main(paq: Path) -> None:
    lineas, anterior = [], None
    for ruta, accion, aut in ACCIONES:
        p = paq / ruta
        utc = dt.datetime.fromtimestamp(p.stat().st_mtime, dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        reg = {"n": len(lineas), "utc": utc, "accion": accion, "autorizacion": aut, "evidencia": ruta,
               "evidencia_sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "anterior_sha256": anterior}
        linea = json.dumps(reg, ensure_ascii=False, sort_keys=True)
        lineas.append(linea)
        anterior = hashlib.sha256(linea.encode()).hexdigest()
    for accion, motivo in NO_EJECUTADAS:
        reg = {"n": len(lineas), "utc": None, "accion": f"NO EJECUTADA: {accion}", "autorizacion": motivo,
               "evidencia": None, "evidencia_sha256": None, "anterior_sha256": anterior}
        linea = json.dumps(reg, ensure_ascii=False, sort_keys=True)
        lineas.append(linea)
        anterior = hashlib.sha256(linea.encode()).hexdigest()
    (paq / "REGISTRO_ACCIONES.jsonl").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print(f"{len(lineas)} entradas; SHA-256 de la última: {anterior}")


if __name__ == "__main__":
    main(Path(sys.argv[1]))
