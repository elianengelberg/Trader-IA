# Tabla de decisión de P2 v0.4 (resumen)

- Combinaciones: 86400; con salida: 5776; con error de entrada (explícito): 80624.
- Coinciden con el oráculo independiente: 86400 de 86400.
- Alcanzables HOY (registros vacíos, sin etapa ni autorización): 38.

| Estado de la autorización | Filas |
|---|---|
| CONTRADICTORIA | 4256 |
| NO_OTORGADA | 1444 |
| REGISTRADA_EXTERNAMENTE | 76 |

| Avance (alcanzable hoy) | Validez | Filas |
|---|---|---|
| CANDIDATA_A_REVISION_HUMANA | REPRODUCIDO | 2 |
| CANDIDATA_A_REVISION_HUMANA | VERIFICADO | 2 |
| NO_CANDIDATA | CORRUPTO | 8 |
| NO_CANDIDATA | INCONCLUSO | 8 |
| NO_CANDIDATA | NO_REPRODUCIDO | 8 |
| NO_CANDIDATA | REPRODUCIDO | 5 |
| NO_CANDIDATA | VERIFICADO | 5 |

| Error de entrada en | Filas |
|---|---|
| R1 | 25080 |
| R3 | 8740 |
| autorizacion | 1444 |
| etapa | 20520 |
| evidencia | 4320 |
| registros | 20520 |
