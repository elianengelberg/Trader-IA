# Cómo dar a P1 una referencia independiente para los artefactos fuera de muestra de T (decisión tuya, B-2)

**Hoy** el resultado real de T es **INCONCLUSO** con un único motivo, `SIN_REFERENCIA_INDEPENDIENTE`:
- su integridad local es completa;
- coincide con los tres manifiestos locales;
- falta una firma de una raíz aprobada.

Nada de lo que sigue se hizo. Requiere tu autorización y, sobre todo, una clave que **no** esté en este equipo.

## Qué firmarías
`DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.json`: la declaración, sin firmar, de los tres artefactos con sus SHA-256:
- `experimentos/fuera_de_muestra_T.json` (`4f8fafde…`);
- `experimentos/fuera_de_muestra_T.py` (`941b6e11…`);
- `PRERREGISTRO_FUERA_DE_MUESTRA_T.md` (`94a16556…`).

`DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.bin` son sus **bytes canónicos exactos**, que es lo que se firma.

Firmar significa: «acepto que estos son los artefactos de T». **No** prueba que nada cambiara antes de la firma; ver
los límites de `TRAZABILIDAD_FUERA_DE_MUESTRA_T.json`.

## Procedimiento (en TU equipo, no en este)
```
openssl genpkey -algorithm ed25519 -out propietario.pem                            # una sola vez; guárdala fuera
openssl pkey -in propietario.pem -pubout -outform DER | tail -c 32 | od -An -v -tx1 | tr -d ' \n'   # clave pública (64 hex)
openssl pkeyutl -sign -inkey propietario.pem -rawin -in DECLARACION_A_FIRMAR_FUERA_DE_MUESTRA_T.bin \
  | od -An -v -tx1 | tr -d ' \n'                                                     # firma (128 hex)
```
Con esos valores se arma `DECLARACION_FIRMADA_FUERA_DE_MUESTRA_T.json`:
```
{"contenido": <el JSON de DECLARACION_A_FIRMAR…>, "firma_ed25519": "<128 hex>"}
```

## Aprobación de la raíz
Hace falta un cambio de código revisado. Se agrega a `RAICES_CONFIANZA` de `verificar_reproduccion_T.py`:
```
"PROPIETARIO-T": {"id": "PROPIETARIO-T", "tipo": "propietario", "clave_publica_ed25519": "<64 hex>",
                  "aprobada_por": "<tú>", "aprobada_utc": "<AAAA-MM-DDTHH:MM:SSZ>",
                  "descripcion": "clave del propietario, guardada fuera del equipo de T"}
```

Después:
```
python3 -I verificar_reproduccion_T.py experimentos/fuera_de_muestra_T.json --raiz . \
  --manifiesto ARTEFACTOS_FUERA_DE_MUESTRA_T_SHA256.txt --declaracion DECLARACION_FIRMADA_FUERA_DE_MUESTRA_T.json
```
El estado esperado es VERIFICADO.

El procedimiento con OpenSSL está probado con una clave sintética en
`pruebas/p1/test_confianza.py::test_procedimiento_de_firma_del_propietario_con_openssl`.
