"""Verifica el ZIP entregado: integridad (testzip), extracción a un temporal, igualdad EXACTA entre la lista de archivos
del ZIP y la de SHA256SUMS.txt (más el propio SHA256SUMS.txt), y comprobación de cada hash.
Uso: python3 verificar_zip_v04.py <zip> <nombre_carpeta_raiz>"""
from __future__ import annotations

import hashlib
import sys
import tempfile
import zipfile
from pathlib import Path


def main(zip_path: Path, raiz: str) -> int:
    with zipfile.ZipFile(zip_path) as z:
        malo = z.testzip()
        nombres = [n for n in z.namelist() if not n.endswith("/")]
        with tempfile.TemporaryDirectory() as tmp:
            z.extractall(tmp)
            base = Path(tmp) / raiz
            sums = {}
            for linea in (base / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
                h, _, r = linea.partition("  ")
                sums[r] = h
            en_zip = {n[len(raiz) + 1:] for n in nombres}
            esperados = set(sums) | {"SHA256SUMS.txt"}
            errores = [r for r, h in sums.items() if hashlib.sha256((base / r).read_bytes()).hexdigest() != h]
    print(f"ZIP: {zip_path.name}")
    print(f"SHA-256 del ZIP: {hashlib.sha256(zip_path.read_bytes()).hexdigest()}")
    print(f"integridad (testzip): {'OK' if malo is None else 'FALLA en ' + malo}")
    print(f"archivos en el ZIP: {len(en_zip)}; en SHA256SUMS.txt: {len(sums)} (+ SHA256SUMS.txt)")
    print(f"faltan en el ZIP: {sorted(esperados - en_zip) or 'ninguno'}")
    print(f"sobran en el ZIP: {sorted(en_zip - esperados) or 'ninguno'}")
    print(f"hashes que no coinciden tras extraer: {errores or 'ninguno'}")
    return 0 if malo is None and en_zip == esperados and not errores else 1


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1]), sys.argv[2]))
